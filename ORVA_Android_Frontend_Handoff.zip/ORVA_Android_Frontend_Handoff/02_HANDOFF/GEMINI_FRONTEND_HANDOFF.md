# Gemini Frontend Takeover — ORVA Android

Gemini now owns frontend implementation. Backend contracts and services must be adapted to the accepted frontend, not the other way around.

## 1. First action: inspect before editing

1. Inspect the existing Android Gradle project in Google AI Studio.
2. Inspect existing Kotlin/Compose packages and identify reusable components already present.
3. Compare the codebase with `CURRENT_FRONTEND_STATUS.md` and the authoritative Notion specification.
4. Do not create a parallel Android project, duplicate existing screens, or replace established ORVA code without explaining why.
5. Treat `03_RECOVERED_REFERENCE_ONLY/` as historical reference code only. It uses the generic `com.portfolio.agentic` namespace and predates the later ORVA DAG scheduler refactor. It is not an approved drop-in implementation.

## 2. Frontend ownership and scope

Gemini owns:
- Native Kotlin + Jetpack Compose Home and About Us screens.
- Shared showcase components, theme tokens, font integration and the shared scroll-controlled monochrome apothecary frieze.
- Home lantern interaction, editorial/cinematic scroll composition and physical layered folder shelf.
- About Us real Compose component tree and the mandatory Agentic Build construction experience.
- Responsive mobile layouts, touch/keyboard accessibility, English/Bengali parity and reduced-motion behaviour.
- Scene registry, deterministic task orchestration, builder choreography, HUD, guided tour, pause/speed/skip/replay and lifecycle handling.
- Frontend previews, automated tests, Gradle build and device visual validation.

ChatGPT will review Gemini's delivered source later, make targeted frontend corrections, and help define/adapt the backend contracts to the accepted frontend. Do not wait for backend work to design the screens; define the required UI state/events/interfaces as the screens are built and report them for the backend integration phase.

## 3. Locked visual direction

- Preserve ORVA's own established showcase identity: graphite/obsidian, chalk and restrained electric violet, using its approved typography and existing brand assets.
- Do not apply the saai.pro site's palette, typography, wording, portfolio layout or artwork. saai.pro is an animation-behaviour reference only.
- Home combines three cues into one coherent mobile composition: (1) darkness-first touch lantern reveal, (2) cinematic scroll-linked image/typography composition, and (3) atmospheric negative-space hero artwork. Do not stack three disconnected demos.
- Preserve and elevate the custom monochrome apothecary frieze. Do not replace it with generic stock pharmacy art.
- Use physical layered folders rather than generic SaaS feature cards. Folder stacks must remain usable by touch, keyboard and reduced-motion settings.
- Do not redesign operational Billing, Inventory, Returns, Reports or Settings screens as part of this task.

## 4. Home screen content and behaviour

Use `01_CONTENT/ORVA_HOME_ABOUT_DISPLAY_COPY.md` for the English/Bengali display copy.

Required composition:
- Opening hero with shop/date metadata, monumental headline, concise subtitle and immediate `Start Billing` / `+ Add Stock` actions.
- One compact readiness strip based only on real local application state: usable medicine count, expiring-within-30-days count and local backup status. Do not add KPI tiles, progress rings, invented counts or extra database queries.
- Editorial identity statement explaining ORVA's independent-pharmacy purpose without marketing fluff or fabricated claims.
- Three primary workspace folders: Quick Billing, Expiry & Stock, About ORVA. Each folder has three layered document sheets with truthful copy and meaningful navigation.
- Shared closing bar and scroll-controlled monochrome apothecary frieze with counter-gliding `ORVA.` lettering.
- Lantern should be neutral white, darkness-first and touch-controlled, with no amber/yellow colour shift. It should extinguish/reset cleanly and stop animation work when inactive/off-screen.
- Cinematic scroll progress must drive the composition itself (art crop/scale and headline/section positioning), not merely trigger generic fade-ins.

## 5. About Us content and composition

Use `01_CONTENT/ORVA_HOME_ABOUT_DISPLAY_COPY.md` for the approved English/Bengali wording.

Required composition:
- Metadata: `ORVA — ABOUT US` and dynamic `RINDLE WORKS · V{AppVersion}`.
- Monumental headline: `Made for the work behind the counter.`
- Lead: `Clear bills. Careful stock. Your records, kept close.`
- Two-paragraph, factual Rindle Works story. Do not invent a founding year, founder/team biography, corporate history, office address, users/customers, testimonials or prices.
- Five-principle section with a continuous five-node SVG cubic-Bezier wave. Make every node keyboard-accessible and allow scroll progress to drive the wave; focus/tap may temporarily highlight a node but must not permanently disable scroll control.
- Two-column Support & Contact / Product & Ownership section.
- Support phone/email must come only from settings. Omit absent rows; when both are absent, use the approved empty-state text. Never hardcode fallback contact details.
- Dynamic version/build metadata and explicit provisional Rindle Works name status.
- Shared monochrome apothecary frieze at the end.

## 6. Mandatory Agentic Build experience

This is a defining About Us feature. Do not replace it with generic fades, a spinner, a static illustration or a fake flattened website.

The final Compose page is the real interactive and accessible source of truth. Progressively reveal its real components in place. A Canvas/graphics overlay may draw temporary design-tool effects; do not use an inert full-page screenshot/clone or require a fake Go Live handoff.

### Agent roster and roles

- 16 total agents; target 6–8 simultaneously active builders in the portrait viewport. Others may inspect, orbit or stage work.
- Five roles:
  1. Layout Architects — construct parent geometry first; children remain blocked until the parent commits.
  2. Component Duplicators — capture a completed master component, move clone ghosts along authored curves to sibling slots, and trigger red spacing guides on real snaps.
  3. Typographers — reveal text using line/phrase chunks, caret and selection/overwrite effects without changing measured layout size every frame.
  4. Art Directors — stage media from wireframe/matte to monochrome and final image reveal, with restrained corner glints.
  5. Idle Scouts — bounded, low-speed inspection movement while waiting for more visible tasks.

### Four acts

1. Orbital scan around ORVA's identity mark.
2. Structural construction: parent frames, dimensions, margin/column guides, typography and media boundaries.
3. Scroll-coupled assembly: sections build in dependency order; clone groups are created from a master and sibling variants are mutated in parallel. Newly visible work is scheduled from measured viewport geometry.
4. Convergence: agents gather, contact lighting briefly intensifies, guides/cursors withdraw, and the completed About page remains normally usable.

### Visual grammar

- Cursor identity: ORVA-controlled violet with a white outline; not random rainbow colours.
- Blue editing frames (`#0D99FF`) and measurement badges identify component drafting.
- Red smart guides (`#FF3B30`) appear only when actual geometry snaps to a margin, column, sibling edge or baseline. Do not show decorative always-on red lines.
- Cyan/blue proximity bloom is a local interaction effect when cursors/visitor contact within the designed threshold; prefer additive blending where supported with safe alpha fallback.
- Clone ghosts are temporary. Each completed component resolves to its actual Compose composable.
- The HUD displays truthful builder count, actual completed/total registered work, tour state, playback speed, sound (off by default), pause, Skip/Finish and Replay.

### Runtime and accessibility guardrails

- Deterministic seeded movement/timeline; replay must reproduce the same choreography. No uncontrolled random cursor wandering.
- Parent-before-child and master-before-clone dependency constraints.
- Atomic task claim/state transitions. Release or restore claims in `finally` on cancellation.
- Responsive re-layout invalidates stale geometry/claims. Register bounds in one consistent root/content coordinate space.
- Manual touch scrolling immediately overrides guided auto-scroll; never fight the user's gesture.
- Pause/stop unnecessary frame work when About leaves view or the app backgrounds. Do not claim a guaranteed 120 fps; follow actual device frame cadence and profile.
- Reduced motion keeps a shorter, recognisable multi-agent build rather than removing the feature entirely.
- Use the real Compose content as the source of truth; do not cause text reflow by rebuilding `text.take(n)` each frame. Keep full text measured and mask the untyped tail during draw.
- Do not claim genuine AI agents. The visible team is an authored deterministic visual simulation.
- Do not copy saai.pro/swarm-site/swarm-cursors code or cursor artwork. Do not add optional audio, haptics or AGSL before the core build is correct, tested and profiled.

## 7. Backend boundary

This task is the frontend pass. Do not modify billing calculations, persistence or pharmacy domain rules while implementing Home/About. Define the ViewModel/state/events and domain-facing interfaces that the UI needs, document them, and let the backend be adapted to the accepted frontend after review.

## 8. Required delivery report

When complete, report:
1. Existing components reused.
2. Exact files created and modified.
3. Home/About interactions implemented and any remaining visual gaps.
4. UI state/contracts the backend must implement.
5. Tests passed and failed.
6. Gradle build result.
7. Emulator/physical-device validation performed and device/API details.
8. Remaining issues and risks.

Do not claim a build or test passed unless actually run.
