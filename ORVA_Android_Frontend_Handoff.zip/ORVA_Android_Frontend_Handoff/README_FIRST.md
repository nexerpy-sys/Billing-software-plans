# ORVA Android Frontend Handoff — Gemini

This package is a **recovery and handoff bundle**, not a claim that the missing latest Compose source has been recovered in full.

## Package contents

- `01_CONTENT/ORVA_HOME_ABOUT_DISPLAY_COPY.md` — consolidated Home and About Us display wording in English and Bengali, including dynamic fields and support-contact rules.
- `02_HANDOFF/CURRENT_FRONTEND_STATUS.md` — recorded completed work, verified tests and the exact continuation point.
- `02_HANDOFF/GEMINI_FRONTEND_HANDOFF.md` — instructions for taking over frontend ownership while preserving ORVA decisions.
- `03_RECOVERED_REFERENCE_ONLY/` — five Kotlin source excerpts recovered from the chat export. These are an **earlier prototype**, not the later DAG-scheduler/Compose-screen implementation recorded in the 20 Nov checkpoint. They are intentionally marked reference-only and must not be imported blindly.
- `04_PROVENANCE/RECOVERY_LIMITATIONS.md` — what source was and was not available for this package.

## Critical status warning

The latest developed files recorded in the 20 Nov 2026 checkpoint (HomeScreen, AboutUsScreen, AgentTaskScheduler, AgenticSceneRegistry, AgenticOverlayCanvas, AgenticOverlayState, shared tokens/frieze and scheduler tests) were **not present as raw source files** in the active workspace or Dropbox frontend folder when this archive was assembled. The Dropbox frontend folder held only an empty 200-byte Paper placeholder. The chat export contained an older prototype excerpt, not those latest files.

Therefore:
- Do not tell the user these five recovered Kotlin files are the latest finished ORVA frontend.
- Do not claim the latest Home/About Compose screens are included here.
- Use the copy document and handoff instructions as authoritative inputs.
- Inspect the existing Gemini Android project first. Build the frontend there, then align the backend to the accepted UI contracts.

The ORVA Android collaboration specification is the primary project authority:
https://app.notion.com/p/41dbaca0691681a7837cf353c026ac76

The source WPF archive is a **design/content reference**, not an Android Gradle project:
`/ORVA-WORKSPACE/04-INTEGRATION/ORVA-main.zip`

Recovered Kotlin excerpts: AgenticModels.kt, AgenticEngine.kt, AgenticOverlayCanvas.kt, AgenticModifiers.kt, AgenticStage.kt
