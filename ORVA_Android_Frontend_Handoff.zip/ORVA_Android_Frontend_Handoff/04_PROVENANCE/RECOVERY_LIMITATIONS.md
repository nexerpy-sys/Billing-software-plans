# Recovery Limitations & Provenance

## Sources inspected

1. Current conversation export: `Compile_WPF_Projects__4_ (1).txt` (2,117 lines; 112,890 bytes).
2. Existing Notion ORVA Android specification: `https://app.notion.com/p/41dbaca0691681a7837cf353c026ac76` (Sections 12–20 and the 20 Nov 2026 implementation checkpoint).
3. Dropbox WPF reference archive: `/ORVA-WORKSPACE/04-INTEGRATION/ORVA-main.zip` (3,722,750 bytes). Its extracted text was inspected for the authoritative Home/About design blueprint, bilingual wording, and factual restrictions.
4. Dropbox frontend destination: `/ORVA-WORKSPACE/04-INTEGRATION/ANDROID-FRONTEND/` contained only `ORVA Android — About Us Frontend Source.paper`, a 200-byte title-only placeholder.

## What was actually recovered

The conversation export contains five earlier Kotlin prototype excerpts: AgenticModels.kt, AgenticEngine.kt, AgenticOverlayCanvas.kt, AgenticModifiers.kt and AgenticStage.kt. They were extracted into `03_RECOVERED_REFERENCE_ONLY/` with a warning header. The old prototype uses a generic `com.portfolio.agentic` package and contains design/code decisions that were later superseded. `AgenticStage.kt` is a generic portfolio demo, not an ORVA screen.

## What was not recovered as raw source

The later checkpoint records HomeScreen.kt, AboutUsScreen.kt, OrvaShowcaseTokens.kt, OrvaScrollFrieze.kt, AgentTaskScheduler.kt, AgenticSceneRegistry.kt, AgenticOverlayState.kt, AgenticOverlayCanvas.kt and scheduler tests, but those actual file contents were not available in the current mounted workspace or Dropbox frontend folder at handoff time. The empty local `/mnt/data/orva-android-frontend` directory was only a scratch destination, not recovered source.

No files in this archive are represented as a verified Android build. The later checkpoint reports eight pure Kotlin scheduler checks passed and a Compose parser scan passed, but no full Android Gradle build was run.

## Why this warning matters

Gemini should not mistake the earlier prototype excerpt for the newer scheduler/runtime described in Notion. It should inspect its own current AI Studio project, reuse the actual code it already has, and use this package for display copy, requirements and limited historical reference only.
