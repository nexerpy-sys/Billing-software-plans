// RECOVERED FROM THE CHAT EXPORT. REFERENCE ONLY — NOT THE LATEST ORVA ANDROID IMPLEMENTATION.
// This is an earlier prototype excerpt. Check package/API compatibility and the current ORVA spec before reuse.

package com.portfolio.agentic

import androidx.compose.foundation.ScrollState
import androidx.compose.runtime.*
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import kotlinx.coroutines.*
import kotlin.math.*
import kotlin.random.Random

class AgenticEngine(
    val scrollState: ScrollState,
    val agentCount: Int = 16
) {
    val layers = LinkedHashMap<String, TrackedLayer>()
    val agents = mutableListOf<AgentCursor>()
    val activeWireframes = mutableMapOf<Int, ActiveWireframe>()
    val smartGuides = mutableListOf<SmartGuide>()
    val cloneGhosts = mutableMapOf<String, CloneGhost>()
    val mediaGlints = mutableListOf<MediaGlint>()

    var act by mutableStateOf(BuildAct.SCANNING)
    var completedCount by mutableIntStateOf(0)
    var totalCount by mutableIntStateOf(0)
    var touringEnabled by mutableStateOf(true)
    var speedMultiplier by mutableFloatStateOf(1f)
    var elapsedSeconds by mutableFloatStateOf(0f)

    // Touch-as-Agent-#17 (user finger position in content-space, null when lifted)
    var userTouchContentPos: Offset? = null

    // Read ONLY inside Canvas draw lambda -> 0 recompositions/sec
    var frameTick by mutableLongStateOf(0L)
        private set

    var viewportWidthPx: Float = 1080f
    var viewportHeightPx: Float = 2400f

    private var clockMs: Long = 0L
    private var buildStartMs: Long = 0L

    init {
        repeat(agentCount) { i ->
            val theta = (i.toFloat() / agentCount) * (2f * PI.toFloat())
            agents += AgentCursor(
                id = i,
                color = AgentPalette[i % AgentPalette.size],
                pos = Offset(540f + cos(theta) * 140f, 900f + sin(theta) * 140f)
            )
        }
    }

    fun registerLayer(
        id: String,
        kind: LayerKind,
        contentRect: Rect,
        parentId: String?,
        cloneGroupId: String?,
        cloneIndex: Int,
        targetText: String,
        masterText: String
    ) {
        val existing = layers[id]
        if (existing != null) {
            existing.contentRect = contentRect
        } else {
            layers[id] = TrackedLayer(
                id = id, kind = kind, parentId = parentId,
                cloneGroupId = cloneGroupId, cloneIndex = cloneIndex,
                contentRect = contentRect, targetText = targetText,
                masterText = masterText
            )
            totalCount = layers.size
        }
    }

    // Main 120Hz Physics Loop (call inside LaunchedEffect)
    suspend fun runSimulation(scope: CoroutineScope, onSnapHaptic: () -> Unit) {
        var lastNanos = 0L

        // Act I: Orbital Scan around center monogram (2.2s)
        val scanJob = scope.launch {
            delay(2200L)
            act = BuildAct.BUILDING
            buildStartMs = clockMs
            startAgentWorkers(scope, onSnapHaptic)
        }

        while (currentCoroutineContext().isActive) {
            withFrameNanos { frameNanos ->
                val dt = if (lastNanos == 0L) 0.016f
                else ((frameNanos - lastNanos) / 1_000_000_000f).coerceIn(0.001f, 0.05f)
                lastNanos = frameNanos
                clockMs += (dt * 1000f).toLong()

                when (act) {
                    BuildAct.SCANNING -> updateOrbitalBoids(dt)
                    BuildAct.BUILDING -> {
                        elapsedSeconds = (clockMs - buildStartMs) / 1000f
                        updateIdleWanderBoids(dt)
                    }
                    BuildAct.FINISHED -> updateVictoryFlock(dt)
                }

                // Prune expired guides (hold 110ms + fade 210ms = 320ms) & glints
                smartGuides.removeAll { clockMs - it.createdAtMs > 320L }
                mediaGlints.removeAll { clockMs - it.createdAtMs > it.durationMs }

                frameTick = frameNanos
            }
        }
        scanJob.cancel()
    }

    fun currentTimeMs(): Long = clockMs

    // --- ACT I: Orbital Boids around screen center ---
    private fun updateOrbitalBoids(dt: Float) {
        val center = Offset(viewportWidthPx * 0.5f, scrollState.value + viewportHeightPx * 0.45f)
        for (a in agents) {
            a.mode = CursorMode.BOID_FLIGHT
            val toCenter = center - a.pos
            val dist = toCenter.getDistance().coerceAtLeast(1f)
            val radialDir = toCenter / dist
            val tangent = Offset(-radialDir.y, radialDir.x)

            val targetRadius = 110f + sin(clockMs * 0.003f + a.id) * 45f
            val radialForce = radialDir * ((dist - targetRadius) * 4.5f)
            val swirlForce = tangent * 360f
            val sepForce = computeSeparation(a, radius = 48f, strength = 220f)

            a.vel = (a.vel + (radialForce + swirlForce + sepForce) * dt).clampLength(520f)
            a.pos += a.vel * dt
            a.angleRad = lerpAngle(a.angleRad, atan2(a.vel.y, a.vel.x), (dt * 12f).coerceAtMost(1f))
        }
    }

    // --- ACT III: Organic Reynolds Wander for idle agents (no frozen cursors!) ---
    private fun updateIdleWanderBoids(dt: Float) {
        val minY = scrollState.value.toFloat() + 60f
        val maxY = scrollState.value + viewportHeightPx - 120f

        for (a in agents) {
            if (a.busy) continue
            a.mode = CursorMode.BOID_FLIGHT
            a.wanderAngle += (Random.nextFloat() - 0.5f) * 3.5f * dt
            var steer = Offset(cos(a.wanderAngle), sin(a.wanderAngle)) * 110f
            steer += computeSeparation(a, radius = 65f, strength = 140f)

            // Soft pull back into active viewport
            if (a.pos.y < minY) steer += Offset(0f, (minY - a.pos.y) * 3f)
            if (a.pos.y > maxY) steer += Offset(0f, (maxY - a.pos.y) * 3f)
            if (a.pos.x < 40f) steer += Offset((40f - a.pos.x) * 3f, 0f)
            if (a.pos.x > viewportWidthPx - 40f) steer += Offset((viewportWidthPx - 40f - a.pos.x) * 3f, 0f)

            a.vel = (a.vel + steer * dt).clampLength(160f)
            a.pos += a.vel * dt
            if (a.vel.getDistance() > 8f) {
                a.angleRad = lerpAngle(a.angleRad, atan2(a.vel.y, a.vel.x), (dt * 8f).coerceAtMost(1f))
            }
        }
    }

    // --- ACT IV: Tight Victory Convergence (triggers strong blue contact glow!) ---
    private fun updateVictoryFlock(dt: Float) {
        val t = clockMs * 0.0018f
        val defaultAttractor = Offset(
            viewportWidthPx * (0.5f + 0.28f * cos(t)),
            scrollState.value + viewportHeightPx * (0.42f + 0.18f * sin(t * 1.4f))
        )
        // If user touches the screen post-build, the swarm playfully converges near their finger!
        val attractor = userTouchContentPos ?: defaultAttractor

        for (a in agents) {
            a.mode = CursorMode.BOID_FLIGHT
            val toTarget = attractor - a.pos
            val cohesion = toTarget * 3.4f
            val sep = computeSeparation(a, radius = 26f, strength = 190f) // Tight radius = strong blue glow!
            val swirl = Offset(-toTarget.y, toTarget.x) * 0.65f

            a.vel = (a.vel + (cohesion + sep + swirl) * dt).clampLength(480f)
            a.pos += a.vel * dt
            a.angleRad = lerpAngle(a.angleRad, atan2(a.vel.y, a.vel.x), (dt * 10f).coerceAtMost(1f))
        }
    }

    private fun computeSeparation(self: AgentCursor, radius: Float, strength: Float): Offset {
        var force = Offset.Zero
        for (other in agents) {
            if (other.id == self.id) continue
            val diff = self.pos - other.pos
            val d = diff.getDistance()
            if (d in 0.1f..radius) {
                force += (diff / d) * ((1f - d / radius) * strength)
            }
        }
        return force
    }

    // --- COROUTINE TASK DISPATCHER ---
    private fun startAgentWorkers(scope: CoroutineScope, onSnapHaptic: () -> Unit) {
        // Touring Auto-Scroll Coroutine
        scope.launch {
            while (act == BuildAct.BUILDING) {
                if (touringEnabled) {
                    val nextUnbuilt = layers.values
                        .filter { it.phase != LayerPhase.REVEALED && it.contentRect != Rect.Zero }
                        .minByOrNull { it.contentRect.top }
                    if (nextUnbuilt != null) {
                        val targetScroll = (nextUnbuilt.contentRect.top - viewportHeightPx * 0.35f)
                            .toInt().coerceIn(0, scrollState.maxValue)
                        if (abs(targetScroll - scrollState.value) > 40) {
                            scrollState.animateScrollTo(targetScroll)
                        }
                    }
                }
                delay(180L)
            }
        }

        // Launch 16 independent worker coroutines
        agents.forEach { agent ->
            scope.launch {
                // Staggered burst scatter out of orbital scan
                delay((agent.id * 28L / speedMultiplier).toLong())
                while (act == BuildAct.BUILDING) {
                    val task = claimNextReadyLayer(agent)
                    if (task != null) {
                        agent.busy = true
                        executeLayerTask(agent, task, onSnapHaptic)
                        agent.busy = false
                        checkCompletion(scope)
                    } else {
                        delay(45L)
                    }
                }
            }
        }
    }

    private fun claimNextReadyLayer(agent: AgentCursor): TrackedLayer? {
        val visibleTop = scrollState.value - 120f
        val visibleBottom = scrollState.value + viewportHeightPx + 180f

        val candidate = layers.values
            .filter { layer ->
                if (layer.phase != LayerPhase.HIDDEN || layer.claimedByAgent != null) return@filter false
                if (layer.contentRect == Rect.Zero) return@filter false
                // Viewport-chunked gating (pauses build when user stops scrolling!)
                if (layer.contentRect.top > visibleBottom || layer.contentRect.bottom < visibleTop) return@filter false
                // Parent dependency check
                val parentOk = layer.parentId == null || layers[layer.parentId]?.phase == LayerPhase.REVEALED
                // Clone master dependency check (Master [0] must finish before Clones [1..N])
                val masterOk = if (layer.cloneGroupId != null && layer.cloneIndex > 0) {
                    layers.values.any {
                        it.cloneGroupId == layer.cloneGroupId &&
                            it.cloneIndex == 0 &&
                            it.phase == LayerPhase.REVEALED
                    }
                } else true
                parentOk && masterOk
            }
            // Pick closest ready layer to this cursor for natural locality
            .minByOrNull { (it.contentRect.topLeft - agent.pos).getDistance() }

        candidate?.claimedByAgent = agent.id
        candidate?.phase = LayerPhase.BUILDING
        return candidate
    }

    private suspend fun executeLayerTask(
        agent: AgentCursor,
        layer: TrackedLayer,
        onSnapHaptic: () -> Unit
    ) {
        val rect = layer.contentRect
        val isClone = layer.cloneGroupId != null && layer.cloneIndex > 0

        if (isClone) {
            executeAltDragCloneAndMutate(agent, layer, onSnapHaptic)
            return
        }

        when (layer.kind) {
            LayerKind.CONTAINER, LayerKind.MEDIA -> {
                // 1. Fly in arc to top-left corner -> switch to '+' crosshair
                moveToArc(agent, rect.topLeft, durationMs = scaled(260L), endMode = CursorMode.CROSSHAIR)
                delay(scaled(40L))

                // 2. Drag wireframe diagonally with live W x H pill
                val dragDuration = scaled(320L)
                animateProgress(dragDuration) { t ->
                    val e = easeOutExpo(t)
                    val curW = rect.width * e
                    val curH = rect.height * e
                    val liveRect = Rect(rect.left, rect.top, rect.left + curW, rect.top + curH)
                    agent.pos = liveRect.bottomRight
                    activeWireframes[agent.id] = ActiveWireframe(agent.id, liveRect, showDimensions = true)
                }

                // 3. Snap & Fire Red Smart Guides (Full-viewport left margin lock!)
                fireRedSmartGuides(rect, fullViewportLeftLock = rect.width > viewportWidthPx * 0.45f)
                onSnapHaptic()

                // 4. Materialize real Composable & corner glints for media
                if (layer.kind == LayerKind.MEDIA) {
                    spawnMediaGlints(rect)
                }
                animateProgress(scaled(150L)) { t -> layer.revealAlpha = t }
                activeWireframes.remove(agent.id)
                layer.revealAlpha = 1f
            }

            LayerKind.TEXT -> {
                moveToArc(agent, rect.topLeft + Offset(8f, rect.height * 0.5f), scaled(220L), CursorMode.I_BEAM)
                activeWireframes[agent.id] = ActiveWireframe(agent.id, rect, showDimensions = false, isTextEditBox = true)
                layer.revealAlpha = 1f

                // Stream characters live with slight organic jitter
                val len = layer.targetText.length.coerceAtLeast(1)
                val perCharMs = (1000f / (85f * speedMultiplier)).toLong().coerceIn(4L, 28L)
                for (i in 1..len) {
                    layer.visibleCharCount = i
                    // Cursor glides horizontally across the text box as it types
                    val progress = i.toFloat() / len
                    agent.pos = Offset(
                        rect.left + rect.width * (progress % 1f).coerceIn(0.05f, 0.96f),
                        rect.center.y
                    )
                    delay((perCharMs * Random.nextFloat().coerceIn(0.7f, 1.3f)).toLong().coerceAtLeast(2L))
                }
                delay(scaled(50L))
                activeWireframes.remove(agent.id)
            }

            LayerKind.LINE -> {
                // Pen-tool horizontal rubber-band draw
                val start = Offset(rect.left, rect.center.y)
                val end = Offset(rect.right, rect.center.y)
                moveToArc(agent, start, scaled(200L), CursorMode.CROSSHAIR)
                animateProgress(scaled(220L)) { t ->
                    val e = easeOutCubic(t)
                    val curX = lerp(start.x, end.x, e)
                    agent.pos = Offset(curX, start.y)
                    activeWireframes[agent.id] = ActiveWireframe(
                        agent.id, Rect(start.x, start.y - 1f, curX, start.y + 1f), showDimensions = false
                    )
                }
                layer.revealAlpha = 1f
                activeWireframes.remove(agent.id)
            }
        }

        layer.phase = LayerPhase.REVEALED
        completedCount++
    }

    // --- SIGNATURE EFFECT: Alt-Drag Clone + Cmd+A Blue Highlight Overwrite ---
    private suspend fun executeAltDragCloneAndMutate(
        agent: AgentCursor,
        layer: TrackedLayer,
        onSnapHaptic: () -> Unit
    ) {
        val master = layers.values.firstOrNull {
            it.cloneGroupId == layer.cloneGroupId && it.cloneIndex == 0
        } ?: return
        val fromRect = master.contentRect
        val toRect = layer.contentRect

        // 1. Grab Master in Upright Pointer mode
        moveToArc(agent, fromRect.center, scaled(210L), CursorMode.POINTER)

        // 2. Alt-Drag red-outlined Ghost from Master slot -> Target slot along subtle arc
        val ghostId = layer.id
        animateProgress(scaled(340L)) { t ->
            val e = easeOutCubic(t)
            val arcLift = sin(e * PI.toFloat()) * -28f
            val curLeft = lerp(fromRect.left, toRect.left, e)
            val curTop = lerp(fromRect.top, toRect.top, e) + arcLift
            val liveRect = Rect(curLeft, curTop, curLeft + toRect.width, curTop + toRect.height)
            cloneGhosts[ghostId] = CloneGhost(ghostId, liveRect)
            agent.pos = liveRect.center
        }

        // 3. Snap into place with red alignment guides
        cloneGhosts.remove(ghostId)
        fireRedSmartGuides(toRect, fullViewportLeftLock = false)
        onSnapHaptic()

        // 4. Mount cloned master text first, then run Cmd+A Blue Highlight -> Overwrite!
        layer.revealAlpha = 1f
        if (layer.kind == LayerKind.TEXT && layer.masterText.isNotEmpty()) {
            layer.showingMasterCloneText = true
            layer.visibleCharCount = layer.masterText.length
            delay(scaled(90L))

            // Switch to I-Beam & flash translucent blue Cmd+A selection highlight (160ms beat)
            agent.mode = CursorMode.I_BEAM
            layer.highlightOverwriteActive = true
            activeWireframes[agent.id] = ActiveWireframe(agent.id, toRect, showDimensions = false, isTextEditBox = true)
            delay(scaled(160L))

            // Wipe selection & stream unique replacement text
            layer.highlightOverwriteActive = false
            layer.showingMasterCloneText = false
            layer.visibleCharCount = 0
            val len = layer.targetText.length.coerceAtLeast(1)
            val perCharMs = (1000f / (95f * speedMultiplier)).toLong().coerceIn(4L, 22L)
            for (i in 1..len) {
                layer.visibleCharCount = i
                agent.pos = Offset(toRect.left + toRect.width * (i.toFloat() / len), toRect.center.y)
                delay(perCharMs)
            }
            activeWireframes.remove(agent.id)
        }

        layer.phase = LayerPhase.REVEALED
        completedCount++
    }

    private fun fireRedSmartGuides(rect: Rect, fullViewportLeftLock: Boolean) {
        val now = clockMs
        // Left-edge vertical alignment line
        smartGuides += SmartGuide(
            isVertical = true,
            position = rect.left,
            spanStart = if (fullViewportLeftLock) scrollState.value.toFloat() else rect.top - 48f,
            spanEnd = if (fullViewportLeftLock) scrollState.value + viewportHeightPx else rect.bottom + 48f,
            fullViewport = fullViewportLeftLock,
            createdAtMs = now
        )
        // Top baseline horizontal tick
        smartGuides += SmartGuide(
            isVertical = false,
            position = rect.top,
            spanStart = rect.left - 36f,
            spanEnd = rect.right + 36f,
            createdAtMs = now
        )
    }

    private fun spawnMediaGlints(rect: Rect) {
        val corners = listOf(rect.topLeft, rect.topRight, rect.bottomLeft, rect.bottomRight)
        corners.forEachIndexed { idx, pt ->
            mediaGlints += MediaGlint(
                pos = pt + Offset(if (idx % 2 == 0) 10f else -10f, if (idx < 2) 10f else -10f),
                createdAtMs = clockMs + idx * 75L
            )
        }
    }

    private suspend fun moveToArc(
        agent: AgentCursor,
        target: Offset,
        durationMs: Long,
        endMode: CursorMode
    ) {
        val start = agent.pos
        val delta = target - start
        val dist = delta.getDistance().coerceAtLeast(1f)
        val perp = Offset(-delta.y / dist, delta.x / dist)
        val curveSign = if (agent.id % 2 == 0) 1f else -1f
        val control = (start + target) * 0.5f + perp * (dist * 0.22f * curveSign)

        agent.mode = CursorMode.BOID_FLIGHT
        animateProgress(durationMs) { t ->
            val e = easeInOutCubic(t)
            val prev = agent.pos
            val inv = 1f - e
            agent.pos = start * (inv * inv) + control * (2f * inv * e) + target * (e * e)
            val step = agent.pos - prev
            if (step.getDistance() > 0.5f) {
                agent.angleRad = atan2(step.y, step.x)
            }
        }
        agent.pos = target
        agent.mode = endMode
    }

    private suspend fun checkCompletion(scope: CoroutineScope) {
        if (completedCount >= totalCount && totalCount > 0 && act == BuildAct.BUILDING) {
            act = BuildAct.FINISHED
            // Victory sweep back to Hero
            scope.launch {
                delay(800L)
                scrollState.animateScrollTo(0)
            }
        }
    }

    private suspend fun animateProgress(durationMs: Long, onUpdate: (Float) -> Unit) {
        val start = clockMs
        val dur = durationMs.coerceAtLeast(16L)
        while (true) {
            val t = ((clockMs - start).toFloat() / dur).coerceIn(0f, 1f)
            onUpdate(t)
            if (t >= 1f) break
            delay(8L)
        }
    }

    private fun scaled(ms: Long) = (ms / speedMultiplier).toLong().coerceAtLeast(16L)
}

// --- Math Helpers ---
private fun Offset.clampLength(maxLen: Float): Offset {
    val d = getDistance()
    return if (d > maxLen && d > 0f) this * (maxLen / d) else this
}
private fun lerp(a: Float, b: Float, t: Float) = a + (b - a) * t
private fun lerpAngle(a: Float, b: Float, t: Float): Float {
    var diff = (b - a + PI.toFloat()) % (2f * PI.toFloat()) - PI.toFloat()
    if (diff < -PI.toFloat()) diff += 2f * PI.toFloat()
    return a + diff * t
}
private fun easeOutExpo(t: Float) = if (t >= 1f) 1f else 1f - 2f.pow(-10f * t)
private fun easeOutCubic(t: Float) = 1f - (1f - t).pow(3)
private fun easeInOutCubic(t: Float) = if (t < 0.5f) 4f * t * t * t else 1f - (-2f * t + 2f).pow(3) / 2f
