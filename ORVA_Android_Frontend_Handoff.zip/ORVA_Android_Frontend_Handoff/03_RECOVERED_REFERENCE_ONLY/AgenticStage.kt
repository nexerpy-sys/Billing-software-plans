// RECOVERED FROM THE CHAT EXPORT. REFERENCE ONLY — NOT THE LATEST ORVA ANDROID IMPLEMENTATION.
// This is an earlier prototype excerpt. Check package/API compatibility and the current ORVA spec before reuse.

package com.portfolio.agentic

import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun AgenticPortfolioScreen() {
    val scrollState = rememberScrollState()
    val engine = remember { AgenticEngine(scrollState, agentCount = 16) }
    val haptics = LocalHapticFeedback.current
    val scope = rememberCoroutineScope()

    LaunchedEffect(engine) {
        engine.runSimulation(scope) {
            // Subtle tactile tick whenever a Red Smart Guide snaps!
            haptics.performHapticFeedback(HapticFeedbackType.TextHandleMove)
        }
    }

    CompositionLocalProvider(LocalAgenticEngine provides engine) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black)
                // Turn the visitor's finger into Agent #17 for interactive blue contact glow!
                .pointerInput(Unit) {
                    awaitEachGesture {
                        val down = awaitFirstDown(requireUnconsumed = false)
                        engine.userTouchContentPos = down.position + Offset(0f, scrollState.value.toFloat())
                        do {
                            val event = awaitPointerEvent()
                            val pt = event.changes.firstOrNull()
                            if (pt != null && pt.pressed) {
                                engine.userTouchContentPos = pt.position + Offset(0f, scrollState.value.toFloat())
                            } else {
                                engine.userTouchContentPos = null
                            }
                        } while (event.changes.any { it.pressed })
                        engine.userTouchContentPos = null
                    }
                }
        ) {
            // LAYER 1: Real interactive Compose UI (never cloned, live immediately!)
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(scrollState)
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Hero Card
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(220.dp)
                        .agentLayer(id = "hero_card", kind = LayerKind.CONTAINER)
                        .background(Color(0xFF141416), RoundedCornerShape(16.dp))
                        .padding(20.dp)
                ) {
                    AgenticText(
                        id = "hero_title",
                        parentId = "hero_card",
                        text = "Building Autonomous Systems & Native Craft.",
                        style = TextStyle(color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold)
                    )
                }

                // Clone Group Example: Metric Tile [0] builds -> [1] & [2] Alt-Drag Clone & Cmd+A Overwrite!
                val metrics = listOf("478 Tools", "14 Servers", "120Hz Native")
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    metrics.forEachIndexed { idx, label ->
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .height(92.dp)
                                .agentLayer(
                                    id = "metric_box_$idx",
                                    kind = LayerKind.CONTAINER,
                                    cloneGroupId = "metrics",
                                    cloneIndex = idx
                                )
                                .background(Color(0xFF18181B), RoundedCornerShape(12.dp))
                                .padding(12.dp),
                            contentAlignment = Alignment.CenterStart
                        ) {
                            AgenticText(
                                id = "metric_txt_$idx",
                                parentId = "metric_box_$idx",
                                cloneGroupId = "metrics_txt",
                                cloneIndex = idx,
                                text = label,
                                masterText = metrics.first(),
                                style = TextStyle(color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                            )
                        }
                    }
                }
            }

            // LAYER 2: 120Hz High-DPI Canvas Overlay
            AgenticOverlayCanvas(engine = engine)

            // LAYER 3: Floating Agentic HUD Pill
            Row(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(bottom = 24.dp)
                    .background(Color(0xEE18181B), RoundedCornerShape(999.dp))
                    .border(1.dp, Color.White.copy(alpha = 0.12f), RoundedCornerShape(999.dp))
                    .padding(horizontal = 16.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                val status = when (engine.act) {
                    BuildAct.SCANNING -> "Scanning tree..."
                    BuildAct.BUILDING -> "16 agents · ${engine.completedCount} / ${engine.totalCount}"
                    BuildAct.FINISHED -> "Built in %.1fs".format(engine.elapsedSeconds)
                }
                Text(status, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Medium)
            }
        }
    }
}
