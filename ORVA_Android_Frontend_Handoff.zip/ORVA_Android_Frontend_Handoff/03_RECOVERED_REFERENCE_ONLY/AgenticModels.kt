// RECOVERED FROM THE CHAT EXPORT. REFERENCE ONLY — NOT THE LATEST ORVA ANDROID IMPLEMENTATION.
// This is an earlier prototype excerpt. Check package/API compatibility and the current ORVA spec before reuse.

package com.portfolio.agentic

import androidx.compose.runtime.*
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Color
import kotlin.math.*

enum class LayerKind { CONTAINER, MEDIA, TEXT, LINE }
enum class CursorMode { BOID_FLIGHT, POINTER, CROSSHAIR, I_BEAM }
enum class BuildAct { SCANNING, BUILDING, FINISHED }

enum class LayerPhase { HIDDEN, BUILDING, CLONED_MASTER_TEXT, REVEALED }

class TrackedLayer(
    val id: String,
    val kind: LayerKind,
    val parentId: String? = null,
    val cloneGroupId: String? = null,
    val cloneIndex: Int = 0, // 0 = Master, >0 = Alt-Drag Clone
    var contentRect: Rect = Rect.Zero,
    val targetText: String = "",
    val masterText: String = ""
) {
    // Mutable state read ONLY inside graphicsLayer or text draw lambdas
    var revealAlpha by mutableFloatStateOf(0f)
    var visibleCharCount by mutableIntStateOf(0)
    var showingMasterCloneText by mutableStateOf(false)
    var highlightOverwriteActive by mutableStateOf(false)
    var phase: LayerPhase = LayerPhase.HIDDEN
    var claimedByAgent: Int? = null
}

class AgentCursor(
    val id: Int,
    val color: Color,
    var pos: Offset,
    var vel: Offset = Offset.Zero,
    var angleRad: Float = -0.6f,
    var mode: CursorMode = CursorMode.BOID_FLIGHT,
    var busy: Boolean = false,
    var wanderAngle: Float = id * 0.7f
)

data class ActiveWireframe(
    val agentId: Int,
    var currentRect: Rect, // Content-space rect
    val showDimensions: Boolean = true,
    val isTextEditBox: Boolean = false
)

data class SmartGuide(
    val isVertical: Boolean,
    val position: Float,     // x (if vertical) or content-y (if horizontal)
    val spanStart: Float,
    val spanEnd: Float,
    val fullViewport: Boolean = false,
    val createdAtMs: Long
)

data class CloneGhost(
    val id: String,
    var rect: Rect, // Content-space rect flying from master -> target
    var alpha: Float = 0.85f
)

data class MediaGlint(
    val pos: Offset, // Content-space
    val createdAtMs: Long,
    val durationMs: Long = 550L,
    val maxRadiusPx: Float = 18f
)

val AgentPalette = listOf(
    Color(0xFFFF6B6B), Color(0xFF4ECDC4), Color(0xFF45B7D1), Color(0xFFFFBE0B),
    Color(0xFFFB5607), Color(0xFFFF006E), Color(0xFF8338EC), Color(0xFF3A86FF),
    Color(0xFF06D6A0), Color(0xFFFFD166), Color(0xFFEF476F), Color(0xFF118AB2),
    Color(0xFFA8DADC), Color(0xFFE07A5F), Color(0xFF81B29A), Color(0xFFF2CC8F)
)
