// RECOVERED FROM THE CHAT EXPORT. REFERENCE ONLY — NOT THE LATEST ORVA ANDROID IMPLEMENTATION.
// This is an earlier prototype excerpt. Check package/API compatibility and the current ORVA spec before reuse.

package com.portfolio.agentic

import androidx.compose.foundation.background
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.text.TextStyle

val LocalAgenticEngine = compositionLocalOf<AgenticEngine> {
    error("Wrap your screen inside AgenticStage")
}

fun Modifier.agentLayer(
    id: String,
    kind: LayerKind = LayerKind.CONTAINER,
    parentId: String? = null,
    cloneGroupId: String? = null,
    cloneIndex: Int = 0,
    targetText: String = "",
    masterText: String = ""
): Modifier = composed {
    val engine = LocalAgenticEngine.current

    this
        .onGloballyPositioned { coords ->
            val rootRect = coords.boundsInRoot()
            // Convert viewport coordinates -> scroll-independent content coordinates
            val contentRect = rootRect.translate(0f, engine.scrollState.value.toFloat())
            engine.registerLayer(
                id = id, kind = kind, contentRect = contentRect,
                parentId = parentId, cloneGroupId = cloneGroupId,
                cloneIndex = cloneIndex, targetText = targetText, masterText = masterText
            )
        }
        .graphicsLayer {
            // Draw-phase read ONLY -> zero recompositions during reveal!
            alpha = engine.layers[id]?.revealAlpha ?: 0f
        }
}

@Composable
fun AgenticText(
    id: String,
    text: String,
    style: TextStyle,
    modifier: Modifier = Modifier,
    parentId: String? = null,
    cloneGroupId: String? = null,
    cloneIndex: Int = 0,
    masterText: String = ""
) {
    val engine = LocalAgenticEngine.current
    val layer = engine.layers[id]

    // Keep full text layout size measured (0.00 layout shift!) while streaming characters
    val displayText = when {
        layer == null || layer.revealAlpha == 0f -> text // Invisible due to graphicsLayer alpha = 0
        layer.showingMasterCloneText -> layer.masterText
        layer.phase == LayerPhase.REVEALED -> text
        else -> text.take(layer.visibleCharCount) + if (layer.visibleCharCount < text.length) "│" else ""
    }

    val highlightBg = if (layer?.highlightOverwriteActive == true) {
        Color(0x590D99FF) // Translucent Figma Cmd+A selection highlight
    } else Color.Transparent

    Text(
        text = displayText,
        style = style,
        modifier = modifier
            .agentLayer(
                id = id, kind = LayerKind.TEXT, parentId = parentId,
                cloneGroupId = cloneGroupId, cloneIndex = cloneIndex,
                targetText = text, masterText = masterText
            )
            .background(highlightBg)
    )
}
