// RECOVERED FROM THE CHAT EXPORT. REFERENCE ONLY — NOT THE LATEST ORVA ANDROID IMPLEMENTATION.
// This is an earlier prototype excerpt. Check package/API compatibility and the current ORVA spec before reuse.

package com.portfolio.agentic

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.*
import androidx.compose.ui.text.*
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import kotlin.math.*

private val FigmaBlue = Color(0xFF0D99FF)
private val SmartGuideRed = Color(0xFFFF3B30)
private val IceCyanCore = Color(0xFF7DD3FC)
private val ElectricBlueBloom = Color(0xFF0EA5E9)

@Composable
fun AgenticOverlayCanvas(
    engine: AgenticEngine,
    modifier: Modifier = Modifier
) {
    val textMeasurer = rememberTextMeasurer()
    val badgeStyle = remember {
        TextStyle(
            color = Color.White,
            fontSize = 9.sp,
            fontWeight = FontWeight.SemiBold,
            fontFamily = FontFamily.Monospace
        )
    }

    Canvas(modifier = modifier.fillMaxSize()) {
        // Subscribe ONLY the Canvas draw phase to the 120Hz tick
        val _tick = engine.frameTick
        engine.viewportWidthPx = size.width
        engine.viewportHeightPx = size.height

        val scrollY = engine.scrollState.value.toFloat()
        val nowMs = engine.currentTimeMs()

        // 1. RED SMART GUIDES (Instant appear -> 110ms hold -> 210ms linear fade)
        for (guide in engine.smartGuides) {
            val age = nowMs - guide.createdAtMs
            val alpha = when {
                age < 110L -> 1f
                else -> (1f - (age - 110L) / 210f).coerceIn(0f, 1f)
            }
            val color = SmartGuideRed.copy(alpha = alpha)
            if (guide.isVertical) {
                val x = floor(guide.position) + 0.5f
                drawLine(
                    color = color,
                    start = Offset(x, guide.spanStart - scrollY),
                    end = Offset(x, guide.spanEnd - scrollY),
                    strokeWidth = 1f
                )
            } else {
                val y = floor(guide.position - scrollY) + 0.5f
                drawLine(
                    color = color,
                    start = Offset(guide.spanStart, y),
                    end = Offset(guide.spanEnd, y),
                    strokeWidth = 1f
                )
            }
        }

        // 2. ALT-DRAG CLONE GHOSTS (Red bounding frame + translucent preview)
        for (ghost in engine.cloneGhosts.values) {
            val r = ghost.rect.translate(0f, -scrollY)
            drawRect(Color.White.copy(alpha = 0.08f), r.topLeft, r.size)
            drawRect(SmartGuideRed.copy(alpha = ghost.alpha), r.topLeft, r.size, style = Stroke(1.5f))
        }

        // 3. BLUE WIREFRAME & TEXT EDIT BOXES + LIVE "W x H" PILL
        val handleSize = 4.dp.toPx()
        for (wf in engine.activeWireframes.values) {
            val r = wf.currentRect.translate(0f, -scrollY)
            if (!wf.isTextEditBox) {
                drawRect(Color.White.copy(alpha = 0.09f), r.topLeft, r.size)
            }
            drawRect(FigmaBlue, r.topLeft, r.size, style = Stroke(width = 1.25.dp.toPx()))

            // Four white/blue Figma corner handles
            val corners = listOf(r.topLeft, r.topRight, r.bottomLeft, r.bottomRight)
            for (c in corners) {
                val hTopLeft = Offset(c.x - handleSize / 2f, c.y - handleSize / 2f)
                drawRect(Color.White, hTopLeft, Size(handleSize, handleSize))
                drawRect(FigmaBlue, hTopLeft, Size(handleSize, handleSize), style = Stroke(1.dp.toPx()))
            }

            // Live pixel dimension pill (e.g. "388 × 478")
            if (wf.showDimensions && r.width > 24f && r.height > 16f) {
                val label = "${r.width.roundToInt()} × ${r.height.roundToInt()}"
                val measured = textMeasurer.measure(label, badgeStyle)
                val padX = 5.dp.toPx()
                val padY = 2.dp.toPx()
                val pillW = measured.size.width + padX * 2
                val pillH = measured.size.height + padY * 2
                val pillLeft = r.center.x - pillW / 2f
                val pillTop = r.bottom + 6.dp.toPx()

                drawRoundRect(
                    color = FigmaBlue,
                    topLeft = Offset(pillLeft, pillTop),
                    size = Size(pillW, pillH),
                    cornerRadius = CornerRadius(3.dp.toPx())
                )
                drawText(measured, topLeft = Offset(pillLeft + padX, pillTop + padY))
            }
        }

        // 4. 4-POINT MEDIA MATERIALIZATION GLINTS
        for (g in engine.mediaGlints) {
            val age = nowMs - g.createdAtMs
            if (age !in 0..g.durationMs) continue
            val t = age.toFloat() / g.durationMs
            val scale = sin(t * PI.toFloat())
            drawFourPointStar(
                center = Offset(g.pos.x, g.pos.y - scrollY),
                radius = g.maxRadiusPx * scale,
                alpha = scale
            )
        }

        // 5. ELECTROSTATIC BLUE CURSOR-CONTACT LIGHTING (Additive BlendMode.Plus)
        val touchRadiusPx = 46.dp.toPx()
        val points = buildList {
            engine.agents.forEach { add(Offset(it.pos.x, it.pos.y - scrollY)) }
            engine.userTouchContentPos?.let { add(Offset(it.x, it.y - scrollY)) }
        }
        for (i in points.indices) {
            for (j in i + 1 until points.size) {
                val a = points[i]
                val b = points[j]
                val d = (a - b).getDistance()
                if (d < touchRadiusPx) {
                    val p = (1f - d / touchRadiusPx).pow(2)
                    val mid = (a + b) * 0.5f
                    val glowRadius = (24.dp.toPx() + 28.dp.toPx() * p)
                    drawCircle(
                        brush = Brush.radialGradient(
                            0.0f to IceCyanCore.copy(alpha = 0.34f * p),
                            0.45f to ElectricBlueBloom.copy(alpha = 0.18f * p),
                            1.0f to Color.Transparent,
                            center = mid,
                            radius = glowRadius
                        ),
                        radius = glowRadius,
                        center = mid,
                        blendMode = BlendMode.Plus
                    )
                }
            }
        }

        // 6. THE 16 MULTI-STATE AGENT CURSORS
        for (agent in engine.agents) {
            val screenPos = Offset(agent.pos.x, agent.pos.y - scrollY)
            when (agent.mode) {
                CursorMode.BOID_FLIGHT -> drawChevronCursor(screenPos, agent.angleRad, agent.color)
                CursorMode.POINTER -> drawChevronCursor(screenPos, -2.35f, agent.color) // Classic NW upright
                CursorMode.CROSSHAIR -> drawCrosshairCursor(screenPos, agent.color)
                CursorMode.I_BEAM -> drawIBeamCursor(screenPos)
            }
        }
    }
}

private fun DrawScope.drawChevronCursor(pos: Offset, angleRad: Float, color: Color) {
    val deg = Math.toDegrees(angleRad.toDouble()).toFloat() + 90f
    val s = 7.dp.toPx()
    val path = Path().apply {
        moveTo(0f, -s * 1.4f)      // Tip
        lineTo(s * 0.95f, s)       // Right wing
        lineTo(0f, s * 0.45f)      // Inner notch
        lineTo(-s * 0.95f, s)      // Left wing
        close()
    }
    withTransform({
        translate(pos.x, pos.y)
        rotate(deg, pivot = Offset.Zero)
    }) {
        drawPath(path, color = color)
        drawPath(path, color = Color.Black.copy(alpha = 0.85f), style = Stroke(width = 1.2.dp.toPx()))
    }
}

private fun DrawScope.drawCrosshairCursor(pos: Offset, color: Color) {
    val arm = 6.dp.toPx()
    val gap = 2.dp.toPx()
    val stroke = 1.5.dp.toPx()
    drawLine(color, Offset(pos.x - arm, pos.y), Offset(pos.x - gap, pos.y), stroke)
    drawLine(color, Offset(pos.x + gap, pos.y), Offset(pos.x + arm, pos.y), stroke)
    drawLine(color, Offset(pos.x, pos.y - arm), Offset(pos.x, pos.y - gap), stroke)
    drawLine(color, Offset(pos.x, pos.y + gap), Offset(pos.x, pos.y + arm), stroke)
}

private fun DrawScope.drawIBeamCursor(pos: Offset) {
    val h = 7.dp.toPx()
    val serif = 3.dp.toPx()
    val c = Color(0xFFE0F2FE)
    val sw = 1.3.dp.toPx()
    drawLine(c, Offset(pos.x, pos.y - h), Offset(pos.x, pos.y + h), sw)
    drawLine(c, Offset(pos.x - serif, pos.y - h), Offset(pos.x + serif, pos.y - h), sw)
    drawLine(c, Offset(pos.x - serif, pos.y + h), Offset(pos.x + serif, pos.y + h), sw)
}

private fun DrawScope.drawFourPointStar(center: Offset, radius: Float, alpha: Float) {
    val inner = radius * 0.18f
    val path = Path().apply {
        moveTo(center.x, center.y - radius)
        lineTo(center.x + inner, center.y - inner)
        lineTo(center.x + radius, center.y)
        lineTo(center.x + inner, center.y + inner)
        lineTo(center.x, center.y + radius)
        lineTo(center.x - inner, center.y + inner)
        lineTo(center.x - radius, center.y)
        lineTo(center.x - inner, center.y - inner)
        close()
    }
    drawPath(path, Color.White.copy(alpha = alpha * 0.9f))
}
