package com.rindleworks.orva.ui.showcase

import android.content.Context
import android.provider.Settings
import androidx.compose.foundation.ScrollState
import androidx.compose.material3.Text
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.mutableStateOf
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.SemanticsProperties
import androidx.compose.ui.test.assertContentDescriptionEquals
import androidx.compose.ui.test.assertDoesNotExist
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.assertIsNotEnabled
import androidx.compose.ui.test.assertTextContains
import androidx.compose.ui.test.assertTextEquals
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performScrollTo
import androidx.compose.ui.test.performTouchInput
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LifecycleRegistry
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.test.core.app.ApplicationProvider
import com.rindleworks.orva.domain.settings.AppLanguage
import com.rindleworks.orva.ui.about.AboutUsScreen
import com.rindleworks.orva.ui.about.agentic.AgenticBuildController
import com.rindleworks.orva.ui.about.agentic.CompletionSparkVisual
import com.rindleworks.orva.ui.about.agentic.MediaGlintVisual
import com.rindleworks.orva.ui.about.agentic.SmartGuideLine
import com.rindleworks.orva.ui.about.agentic.SnapRippleVisual
import com.rindleworks.orva.ui.home.HomeScreen
import com.rindleworks.orva.ui.navigation.rememberSystemReducedMotion
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class HomeAboutShowcaseRobolectricTest {

  @get:Rule
  val composeRule = createComposeRule()

  @Test
  fun `system animation scale changes update reduced motion without recomposition input`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val resolver = context.contentResolver
    val keys =
      listOf(
        Settings.Global.ANIMATOR_DURATION_SCALE,
        Settings.Global.TRANSITION_ANIMATION_SCALE,
        Settings.Global.WINDOW_ANIMATION_SCALE,
      )
    val originalValues = keys.associateWith { Settings.Global.getString(resolver, it) }

    try {
      keys.forEach { Settings.Global.putFloat(resolver, it, 1f) }
      composeRule.setContent {
        Text(if (rememberSystemReducedMotion(context)) "REDUCED" else "MOTION")
      }
      composeRule.onNodeWithText("MOTION").assertTextEquals("MOTION")

      Settings.Global.putFloat(resolver, Settings.Global.TRANSITION_ANIMATION_SCALE, 0f)
      composeRule.waitForIdle()
      composeRule.onNodeWithText("REDUCED").assertTextEquals("REDUCED")
    } finally {
      originalValues.forEach { (key, value) ->
        if (value == null) {
          Settings.Global.putString(resolver, key, null)
        } else {
          Settings.Global.putString(resolver, key, value)
        }
      }
    }
  }

  @Test
  fun `system reduced motion update preserves the active Agentic build controller`() {
    composeRule.mainClock.autoAdvance = false
    val reducedMotion = mutableStateOf(false)
    val state =
      AboutShowcaseUiState(
        appVersion = "1.0",
        buildNumber = "1",
        supportPhone = null,
        supportEmail = null,
        language = AppLanguage.English,
      )

    composeRule.setContent {
      AboutUsScreen(
        state = state,
        reducedMotion = reducedMotion.value,
        onEvent = {},
      )
    }
    composeRule.mainClock.advanceTimeBy(1400)
    composeRule
      .onNodeWithTag("agentic_hud_status")
      .assertTextEquals("INTRO")

    reducedMotion.value = true
    composeRule.mainClock.advanceTimeBy(100)

    val statusAfterUpdate =
      composeRule
        .onNodeWithTag("agentic_hud_status")
        .fetchSemanticsNode()
        .config[SemanticsProperties.Text]
        .joinToString(separator = "") { it.text }
    assertNotEquals(
      "Changing the motion preference must update the existing build instead of restarting it",
      "INTRO",
      statusAfterUpdate,
    )
  }

  @Test
  fun `Agentic build stays paused when composed before its lifecycle is resumed`() {
    composeRule.mainClock.autoAdvance = false
    val lifecycleOwner =
      object : LifecycleOwner {
        override val lifecycle: LifecycleRegistry = LifecycleRegistry(this)
      }
    composeRule.runOnUiThread {
      lifecycleOwner.lifecycle.handleLifecycleEvent(Lifecycle.Event.ON_CREATE)
      lifecycleOwner.lifecycle.handleLifecycleEvent(Lifecycle.Event.ON_START)
    }

    val state =
      AboutShowcaseUiState(
        appVersion = "1.0",
        buildNumber = "1",
        supportPhone = null,
        supportEmail = null,
        language = AppLanguage.English,
      )

    composeRule.setContent {
      CompositionLocalProvider(LocalLifecycleOwner provides lifecycleOwner) {
        AboutUsScreen(
          state = state,
          reducedMotion = false,
          onEvent = {},
        )
      }
    }

    composeRule.mainClock.advanceTimeBy(6200)
    composeRule.onNodeWithTag("agentic_hud_status").assertTextEquals("INTRO")

    composeRule.runOnUiThread {
      lifecycleOwner.lifecycle.handleLifecycleEvent(Lifecycle.Event.ON_RESUME)
    }
    composeRule.mainClock.advanceTimeBy(6200)
    val resumedStatus =
      composeRule
        .onNodeWithTag("agentic_hud_status")
        .fetchSemanticsNode()
        .config[SemanticsProperties.Text]
        .joinToString(separator = "") { it.text }
    assertNotEquals("The build should progress after the owner reaches RESUMED", "INTRO", resumedStatus)
  }

  @Test
  fun `viewport resize clears old geometry effects and repositions the agent swarm`() {
    val controller = AgenticBuildController(scrollState = ScrollState(0))
    controller.onViewportSized(widthPx = 400f, heightPx = 800f, density = 1f)
    val oldAgentX = controller.agents.first().pos.x

    controller.smartGuides += SmartGuideLine(Offset(10f, 10f), Offset(20f, 20f), createdAtMs = 0L)
    controller.mediaGlints += MediaGlintVisual(Offset(30f, 30f), progress = 0.5f)
    controller.snapRipples += SnapRippleVisual(Offset(40f, 40f), Color.Red, createdAtMs = 0L)
    controller.completionSparks +=
      CompletionSparkVisual(Offset(50f, 50f), Offset(2f, 2f), Color.Blue, createdAtMs = 0L)

    controller.onViewportSized(widthPx = 420f, heightPx = 800f, density = 1f)

    assertEquals(0, controller.smartGuides.size)
    assertEquals(0, controller.mediaGlints.size)
    assertEquals(0, controller.snapRipples.size)
    assertEquals(0, controller.completionSparks.size)
    assertNotEquals("Agents must be re-seeded against the new viewport", oldAgentX, controller.agents.first().pos.x)
  }

  @Test
  fun `HomeScreen renders real local readiness strip, exact EN copy, and 3 workspace folders`() {
    val events = mutableListOf<ShowcaseUiEvent>()
    val state =
      HomeShowcaseUiState(
        shopName = "Arogya Medico",
        dateText = "20 NOV 2026",
        usableMedicineCount = 42,
        expiringSoonCount = 3,
        backupStatus = ReadinessBackupState.Saved,
        appVersion = "1.0",
        language = AppLanguage.English,
        isLoaded = true,
      )

    composeRule.setContent {
      HomeScreen(
        state = state,
        reducedMotion = true,
        onEvent = { events += it },
      )
    }
    composeRule.waitForIdle()

    composeRule.onNodeWithTag("home_hero_headline").assertIsDisplayed().assertTextContains("BUILT AROUND")
    composeRule.onNodeWithTag("home_hero_section_index").assertTextContains("01 / 05")
    composeRule.onNodeWithTag("home_folder_section_heading").performScrollTo()
      .assertTextContains("05 / THREE PILLARS OF THE WORK.")
    composeRule.onNodeWithTag("home_lantern_eyebrow").performScrollTo()
      .assertTextContains("02 / ILLUMINATION STUDY")
    composeRule.onNodeWithTag("home_lantern_caption").performScrollTo()
      .assertTextContains("APOTHECARY / DETAIL 01")
    composeRule.onNodeWithTag("home_precision_eyebrow").performScrollTo()
      .assertTextContains("03 / PRECISION")
    composeRule.onNodeWithTag("home_precision_image").assertContentDescriptionEquals(
      "Macro detail of thermal counter paper roll and aluminum hardware",
    )
    composeRule.onNodeWithTag("home_flagship_case_code").performScrollTo()
      .assertTextContains("CASE / 001")
    composeRule.onNodeWithTag("home_flagship_study_label").performScrollTo()
      .assertTextContains("RINDLE WORKS / PRODUCT STUDY")
    composeRule
      .onNodeWithTag("home_readiness_strip")
      .performScrollTo()
      .assertIsDisplayed()
      .assertTextContains("Arogya Medico")
      .assertTextContains("42 medicines ready")
      .assertTextContains("3 expiring within 30 days")
      .assertTextContains("Backup: Saved")

    composeRule.onNodeWithTag("home_start_billing_btn").performScrollTo().performClick()
    composeRule.onNodeWithTag("home_add_stock_btn").performScrollTo().performClick()
    composeRule.onNodeWithTag("home_folder_details_quick_billing").performScrollTo().assertIsDisplayed()
    composeRule.onNodeWithTag("home_folder_toggle_quick_billing").performScrollTo().performClick()
    composeRule.onNodeWithTag("home_folder_details_quick_billing").assertDoesNotExist()
    composeRule.onNodeWithTag("home_folder_toggle_expiry_stock").performScrollTo().performClick()
    composeRule.onNodeWithTag("home_folder_details_expiry_stock").performScrollTo().assertIsDisplayed()
    composeRule.onNodeWithTag("home_folder_toggle_expiry_stock").performScrollTo().performClick()
    composeRule.onNodeWithTag("home_folder_details_expiry_stock").assertDoesNotExist()
    composeRule.onNodeWithTag("home_folder_action_about_orva").performScrollTo().performClick()
    composeRule.onNodeWithTag("home_folder_details_about_orva").assertDoesNotExist()
    composeRule.waitForIdle()

    assertEquals(
      listOf(
        ShowcaseUiEvent.StartBilling,
        ShowcaseUiEvent.AddStock,
        ShowcaseUiEvent.OpenAboutUs,
      ),
      events,
    )
  }

  @Test
  fun `HomeScreen switches cleanly to authoritative Bengali copy`() {
    val state =
      HomeShowcaseUiState(
        shopName = "Arogya Medico",
        dateText = "20 NOV 2026",
        usableMedicineCount = 0,
        expiringSoonCount = 0,
        backupStatus = ReadinessBackupState.NotYetBackedUp,
        appVersion = "1.0",
        language = AppLanguage.Bengali,
        isLoaded = true,
      )

    composeRule.setContent {
      HomeScreen(
        state = state,
        reducedMotion = true,
        onEvent = {},
      )
    }
    composeRule.waitForIdle()

    composeRule.onNodeWithTag("home_hero_headline").assertTextContains("কাজের ছন্দেই")
    composeRule.onNodeWithTag("home_hero_section_index").assertTextContains("০১ / ০৫")
    composeRule.onNodeWithTag("home_folder_section_heading").performScrollTo()
      .assertTextContains("০৫ / তিনটি স্তম্ভ।")
    composeRule.onNodeWithTag("home_lantern_eyebrow").performScrollTo()
      .assertTextContains("০২ / আলোর অধ্যয়ন")
    composeRule.onNodeWithTag("home_lantern_caption").performScrollTo()
      .assertTextContains("ঔষধালয় / বিস্তারিত ০১")
    composeRule.onNodeWithTag("home_precision_eyebrow").performScrollTo()
      .assertTextContains("০৩ / নির্ভুলতা")
    composeRule.onNodeWithTag("home_precision_image").assertContentDescriptionEquals(
      "থার্মাল কাগজের রোল ও ধাতব যন্ত্রাংশের কাছের দৃশ্য",
    )
    composeRule.onNodeWithTag("home_flagship_case_code").performScrollTo()
      .assertTextContains("কেস / ০০১")
    composeRule.onNodeWithTag("home_flagship_study_label").performScrollTo()
      .assertTextContains("RINDLE WORKS / পণ্য-সমীক্ষা")
    composeRule
      .onNodeWithTag("home_readiness_strip")
      .assertTextContains("০টি ওষুধ প্রস্তুত")
      .assertTextContains("এখনো ব্যাকআপ হয়নি")
  }

  @Test
  fun `AboutUsScreen omits absent Support phone and email rows and displays approved empty state`() {
    composeRule.mainClock.autoAdvance = false
    val state =
      AboutShowcaseUiState(
        appVersion = "1.0",
        buildNumber = "1",
        supportPhone = null,
        supportEmail = null,
        language = AppLanguage.English,
      )

    composeRule.setContent {
      AboutUsScreen(
        state = state,
        reducedMotion = true,
        onEvent = {},
      )
    }
    composeRule.mainClock.advanceTimeByFrame()

    // Skip Agentic Build via HUD so all layers immediately finalize to COMPLETED
    composeRule.onNodeWithTag("hud_skip_btn").performClick()
    composeRule.mainClock.advanceTimeByFrame()

    // Replay chip appears once Completed
    composeRule.onNodeWithTag("hud_replay_btn").assertIsDisplayed()

    composeRule.onNodeWithTag("about_hero_headline").assertTextContains("THE WORK DOESN'T FIT IN A SCREEN.")
    composeRule.onNodeWithTag("about_hero_scene_index").assertTextContains("SCENE 01 / 09")
    composeRule.onNodeWithTag("about_hero_version_label").assertTextContains("RINDLE WORKS · V1.0")
    composeRule.onNodeWithTag("about_hero_artwork").assertContentDescriptionEquals("Conceptual monochrome studio workbench artwork")
    composeRule.onNodeWithTag("about_pov_media_image").assertContentDescriptionEquals("Conceptual monochrome apothecary glass-shelving artwork")
    composeRule.onNodeWithTag("about_pov_media_caption").performScrollTo().assertTextContains("FIG. 01 — WORKING CONTEXT")
    composeRule.onNodeWithTag("about_marquee_primary_text").assertTextContains("LOCAL-FIRST · INTEGER PAISE")
    composeRule.onNodeWithTag("about_marquee_secondary_text").assertTextContains("BATCH SAFETY · PORTABLE BACKUPS")
    composeRule.onNodeWithTag("about_philosophy_eyebrow").performScrollTo().assertTextContains("03 / PHILOSOPHY")
    composeRule.onNodeWithTag("about_principle_progress").performScrollTo().assertTextContains("01 / 05")
    composeRule.onNodeWithTag("about_case_code_01").performScrollTo().assertTextContains("ORVA_01")
    composeRule.onNodeWithTag("about_support_empty_state").performScrollTo().assertIsDisplayed()
    composeRule
      .onNodeWithTag("about_support_empty_state")
      .assertTextContains("Support contact details are not configured yet. Add them in Settings.")
    composeRule.onNodeWithTag("about_support_phone").assertDoesNotExist()
    composeRule.onNodeWithTag("about_support_email").assertDoesNotExist()
    composeRule
      .onNodeWithTag("about_provisional_status")
      .performScrollTo()
      .assertTextContains("Provisional; Indian trademark clearance pending.")
    composeRule.onNodeWithTag("about_version_value").performScrollTo().assertTextContains("1.0")

    composeRule
      .onNodeWithTag("about_commitments_headline")
      .performScrollTo()
      .assertTextContains("EVERY PROMISE NEEDS A RULE.")
    composeRule
      .onNodeWithTag("about_commitments_left_item_1")
      .performScrollTo()
      .assertTextContains("Billing integrity")
    composeRule
      .onNodeWithTag("about_commitments_right_item_3")
      .performScrollTo()
      .assertTextContains("FEFO allocation")
    composeRule
      .onNodeWithTag("about_mosaic_headline")
      .performScrollTo()
      .assertTextContains("A PHARMACY IS MORE THAN A COUNTER.")
    composeRule
      .onNodeWithTag("about_mosaic_1_caption")
      .performScrollTo()
      .assertTextContains("BATCH / INVENTORY")
    composeRule
      .onNodeWithTag("about_deep_dive_spec_money_value")
      .performScrollTo()
      .assertTextContains("INTEGER PAISE")
    composeRule
      .onNodeWithTag("about_deep_dive_spec_invoice_value")
      .performScrollTo()
      .assertTextContains("ATOMIC FINALISATION")
    composeRule
      .onNodeWithTag("about_deep_dive_perspective_hint")
      .performScrollTo()
      .assertTextContains("STATIC VIEW / REDUCED MOTION")
      .assertIsNotEnabled()
  }

  @Test
  fun `AboutUsScreen localizes scene markers, figure labels and principle numbers in Bengali`() {
    composeRule.mainClock.autoAdvance = false
    val state =
      AboutShowcaseUiState(
        appVersion = "1.2",
        buildNumber = "2",
        supportPhone = null,
        supportEmail = null,
        language = AppLanguage.Bengali,
      )

    composeRule.setContent {
      AboutUsScreen(
        state = state,
        reducedMotion = true,
        onEvent = {},
      )
    }
    composeRule.mainClock.advanceTimeByFrame()
    composeRule.onNodeWithTag("hud_skip_btn").performClick()
    composeRule.mainClock.advanceTimeByFrame()

    composeRule.onNodeWithTag("about_hero_scene_index").assertTextContains("দৃশ্য ০১ / ০৯")
    composeRule.onNodeWithTag("about_hero_version_label").assertTextContains("RINDLE WORKS · সংস্করণ V১.২")
    composeRule.onNodeWithTag("about_hero_artwork").assertContentDescriptionEquals("ধারণামূলক একরঙা স্টুডিও ওয়ার্কবেঞ্চের চিত্র")
    composeRule.onNodeWithTag("about_pov_media_image").assertContentDescriptionEquals("ধারণামূলক একরঙা ঔষধালয়ের কাচের তাকের চিত্র")
    composeRule.onNodeWithTag("about_pov_media_caption").performScrollTo()
      .assertTextContains("চিত্র ০১ — কাজের প্রেক্ষাপট")
    composeRule.onNodeWithTag("about_marquee_primary_text").assertTextContains("স্থানীয়-প্রথম · পূর্ণ পয়সার হিসাব")
    composeRule.onNodeWithTag("about_marquee_secondary_text").assertTextContains("ব্যাচ সুরক্ষা · বহনযোগ্য ব্যাকআপ")
    composeRule.onNodeWithTag("about_philosophy_eyebrow").performScrollTo()
      .assertTextContains("০৩ / দর্শন")
    composeRule.onNodeWithTag("about_principle_progress").performScrollTo()
      .assertTextContains("০১ / ০৫")
    composeRule.onNodeWithTag("about_principle_active_label").performScrollTo()
      .assertTextContains("(০১) মূলনীতি")
    composeRule.onNodeWithTag("about_case_code_01").performScrollTo()
      .assertTextContains("ORVA_০১")
    composeRule.onNodeWithTag("about_commitments_left_row_1_index").performScrollTo()
      .assertTextContains("০১")
    composeRule.onNodeWithTag("about_deep_dive_eyebrow").performScrollTo()
      .assertTextContains("০৮ / গভীর পর্যবেক্ষণ / ORVA")
  }

  @Test
  fun `horizontal selected work swipe does not cancel guided page tour`() {
    composeRule.mainClock.autoAdvance = false
    val state =
      AboutShowcaseUiState(
        appVersion = "1.0",
        buildNumber = "1",
        supportPhone = null,
        supportEmail = null,
        language = AppLanguage.English,
      )

    composeRule.setContent {
      AboutUsScreen(
        state = state,
        reducedMotion = true,
        onEvent = {},
      )
    }
    composeRule.mainClock.advanceTimeByFrame()
    composeRule.onNodeWithTag("hud_tour_btn").assertTextContains("TOUR")

    composeRule
      .onNodeWithTag("about_selected_work_rail")
      .performScrollTo()
      .performTouchInput { swipeLeft() }
    composeRule.mainClock.advanceTimeBy(100)

    // Horizontal rail movement is not a manual vertical page scroll.
    composeRule.onNodeWithTag("hud_tour_btn").assertTextContains("TOUR")
  }

  @Test
  fun `manual scroll cancels tour and releases a pinned principle chapter`() {
    composeRule.mainClock.autoAdvance = false
    val state =
      AboutShowcaseUiState(
        appVersion = "1.0",
        buildNumber = "1",
        supportPhone = null,
        supportEmail = null,
        language = AppLanguage.English,
      )

    composeRule.setContent {
      AboutUsScreen(
        state = state,
        reducedMotion = false,
        onEvent = {},
      )
    }
    composeRule.mainClock.advanceTimeByFrame()

    // An explicit chapter selection pins the chosen principle while the reader is stationary.
    composeRule.onNodeWithTag("about_wave_node_1").performScrollTo().performClick()
    composeRule.onNodeWithTag("about_principle_progress").assertTextContains("01 / 05")
    val pinnedProgress =
      composeRule
        .onNodeWithTag("about_principle_progress")
        .fetchSemanticsNode()
        .config[SemanticsProperties.Text]
        .joinToString(separator = "") { it.text }
    composeRule.onNodeWithTag("hud_tour_btn").assertTextContains("TOUR")

    // The first real vertical drag yields the guided scroll and resumes chapter scrubbing.
    composeRule.onNodeWithTag("about_scroll_container").performTouchInput { swipeUp() }
    composeRule.mainClock.advanceTimeBy(400)

    composeRule.onNodeWithTag("hud_tour_btn").assertTextContains("FREE")
    val afterManualScroll =
      composeRule
        .onNodeWithTag("about_principle_progress")
        .fetchSemanticsNode()
        .config[SemanticsProperties.Text]
        .joinToString(separator = "") { it.text }
    assertNotEquals("A manual scroll should release the pinned chapter", pinnedProgress, afterManualScroll)
  }

  @Test
  fun `AboutUsScreen shows only configured Support phone and omits blank email, plus supports Replay`() {
    composeRule.mainClock.autoAdvance = false
    val state =
      AboutShowcaseUiState(
        appVersion = "1.0",
        buildNumber = "7",
        supportPhone = "+91 98300 00000",
        supportEmail = null,
        language = AppLanguage.English,
      )

    composeRule.setContent {
      AboutUsScreen(
        state = state,
        reducedMotion = true,
        onEvent = {},
      )
    }
    composeRule.mainClock.advanceTimeByFrame()

    // Finish -> shows Replay -> verify settings-driven contact rows & 5 wave nodes -> click Replay
    composeRule.onNodeWithTag("hud_skip_btn").performClick()
    composeRule.mainClock.advanceTimeByFrame()
    composeRule.onNodeWithTag("about_support_phone").performScrollTo().assertTextContains("+91 98300 00000")
    composeRule.onNodeWithTag("about_support_heading").performScrollTo().assertTextContains("START WITH THE HARD PART.")
    composeRule.onNodeWithTag("about_support_email").assertDoesNotExist()
    composeRule.onNodeWithTag("about_support_empty_state").assertDoesNotExist()
    composeRule
      .onNodeWithTag("about_film_end_tagline")
      .performScrollTo()
      .assertTextContains("SOFTWARE, WITH INTENTION.")
    composeRule.onNodeWithTag("about_wave_node_1").performScrollTo().assertIsDisplayed()
    composeRule.onNodeWithTag("about_wave_node_5").assertIsDisplayed()

    composeRule.onNodeWithTag("hud_replay_btn").performClick()
    composeRule.mainClock.advanceTimeByFrame()
    composeRule.onNodeWithTag("hud_skip_btn").assertIsDisplayed()
  }

  @Test
  fun `Deep Dive perspective control toggles and exposes its current action`() {
    composeRule.mainClock.autoAdvance = false
    val state =
      AboutShowcaseUiState(
        appVersion = "1.0",
        buildNumber = "1",
        supportPhone = null,
        supportEmail = null,
        language = AppLanguage.English,
      )

    composeRule.setContent {
      AboutUsScreen(
        state = state,
        reducedMotion = false,
        onEvent = {},
      )
    }
    composeRule.mainClock.advanceTimeByFrame()
    composeRule.onNodeWithTag("hud_skip_btn").performClick()
    composeRule.mainClock.advanceTimeByFrame()

    composeRule
      .onNodeWithTag("about_deep_dive_perspective_hint")
      .performScrollTo()
      .assertTextContains("TAP TO FLATTEN")
      .performClick()
      .assertTextContains("TAP TO RESTORE ANGLE")
  }

  @Test
  fun `About architecture and field notes scenes use Bengali copy`() {
    composeRule.mainClock.autoAdvance = false
    val state =
      AboutShowcaseUiState(
        appVersion = "1.0",
        buildNumber = "1",
        supportPhone = null,
        supportEmail = null,
        language = AppLanguage.Bengali,
      )

    composeRule.setContent {
      AboutUsScreen(
        state = state,
        reducedMotion = true,
        onEvent = {},
      )
    }
    composeRule.mainClock.advanceTimeByFrame()
    composeRule.onNodeWithTag("hud_skip_btn").performClick()
    composeRule.mainClock.advanceTimeByFrame()

    composeRule
      .onNodeWithTag("about_commitments_headline")
      .performScrollTo()
      .assertTextContains("প্রতিটি প্রতিশ্রুতির")
    composeRule
      .onNodeWithTag("about_mosaic_headline")
      .performScrollTo()
      .assertTextContains("ফার্মেসি শুধু একটি কাউন্টার নয়।")
    composeRule
      .onNodeWithTag("about_mosaic_1_caption")
      .performScrollTo()
      .assertTextContains("ব্যাচ / ইনভেন্টরি")
    composeRule
      .onNodeWithTag("about_deep_dive_spec_stock_value")
      .performScrollTo()
      .assertTextContains("FEFO বরাদ্দ")
    composeRule
      .onNodeWithTag("about_deep_dive_spec_money_value")
      .performScrollTo()
      .assertTextContains("পূর্ণ পয়সা")
    composeRule
      .onNodeWithTag("about_deep_dive_perspective_hint")
      .performScrollTo()
      .assertTextContains("স্থির দৃশ্য / কম গতি")
    composeRule
      .onNodeWithTag("about_film_end_tagline")
      .performScrollTo()
      .assertTextContains("উদ্দেশ্য নিয়ে তৈরি সফটওয়্যার।")
    composeRule
      .onNodeWithTag("about_support_heading")
      .performScrollTo()
      .assertTextContains("কঠিন অংশটা দিয়ে শুরু হোক।")
  }

}
