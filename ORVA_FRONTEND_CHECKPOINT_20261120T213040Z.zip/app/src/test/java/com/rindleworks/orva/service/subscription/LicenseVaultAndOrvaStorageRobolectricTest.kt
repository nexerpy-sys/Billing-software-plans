package com.rindleworks.orva.service.subscription

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.rindleworks.orva.data.local.OrvaDatabaseProvider
import com.rindleworks.orva.data.local.OrvaStoragePaths
import com.rindleworks.orva.data.local.OrvaTransactionRunner
import com.rindleworks.orva.data.repository.RoomAppSettingsRepository
import com.rindleworks.orva.data.repository.RoomShopRepository
import com.rindleworks.orva.data.repository.RoomTaxSettingsRepository
import com.rindleworks.orva.di.OrvaAppContainer
import com.rindleworks.orva.domain.billing.InvoiceCustomerDraft
import com.rindleworks.orva.domain.billing.InvoiceDraft
import com.rindleworks.orva.domain.billing.InvoiceItemDraft
import com.rindleworks.orva.domain.billing.InvoicePaymentMethod
import com.rindleworks.orva.domain.billing.PaymentTenderDraft
import com.rindleworks.orva.domain.common.OrvaSettingKeys
import com.rindleworks.orva.domain.engine.FixedBillingClock
import com.rindleworks.orva.domain.engine.GstinValidator
import com.rindleworks.orva.domain.inventory.PurchaseDocumentType
import com.rindleworks.orva.domain.inventory.StockEntryInput
import com.rindleworks.orva.domain.records.InvoiceStatusFilter
import com.rindleworks.orva.domain.records.RegisterDateFilter
import com.rindleworks.orva.domain.settings.RoundOffMode
import com.rindleworks.orva.domain.settings.ShopProfile
import com.rindleworks.orva.domain.settings.SupplyType
import com.rindleworks.orva.domain.settings.TaxPricingMode
import com.rindleworks.orva.service.billing.DefaultBillingService
import com.rindleworks.orva.service.inventory.DefaultStockEntryService
import com.rindleworks.orva.service.records.DefaultReportingService
import java.io.File
import java.time.Duration
import java.time.Instant
import java.util.UUID
import java.util.concurrent.atomic.AtomicInteger
import kotlinx.coroutines.test.runTest
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class LicenseVaultAndOrvaStorageRobolectricTest {

  private lateinit var context: Context
  private lateinit var rootDir: File
  private lateinit var internalRoot: File
  private lateinit var orvaFolder: File
  private lateinit var dbProvider: OrvaDatabaseProvider
  private lateinit var tx: OrvaTransactionRunner
  private lateinit var settings: RoomAppSettingsRepository
  private lateinit var clock: FixedBillingClock

  @Before
  fun setUp() {
    context = ApplicationProvider.getApplicationContext()
    rootDir = File(context.cacheDir, "orva-vault-test-${UUID.randomUUID()}").apply { mkdirs() }
    internalRoot = File(rootDir, "app_private_orva")
    orvaFolder = File(rootDir, "shared_storage/ORVA")
    clock = FixedBillingClock(Instant.parse("2026-06-15T06:00:00Z"), localOffsetMinutes = 330)
    dbProvider =
      OrvaDatabaseProvider(
        context = context,
        databaseFile = File(internalRoot, "orva.sqlite"),
        allowMainThreadQueries = true,
      )
    tx = OrvaTransactionRunner(dbProvider)
    settings = RoomAppSettingsRepository(dbProvider, tx, clock)
  }

  @After
  fun tearDown() {
    dbProvider.closeCurrent()
    rootDir.deleteRecursively()
  }

  private fun buildVault(
    deviceId: String = "device-A-uuid-1111",
    licenseDir: File = orvaFolder,
    anchorFile: File = File(internalRoot, ".license_anchor"),
    publicKeySpkiBase64: String? = null,
    fallbackFile: File? = null,
  ): OrvaLicenseVault =
    OrvaLicenseVault(
      licenseFileProvider = { File(licenseDir, OrvaStoragePaths.LICENSE_FILE_NAME) },
      anchorFile = anchorFile,
      deviceInstallIdProvider = { deviceId },
      vendorSignatureVerifier = VendorSignatureVerifier(publicKeySpkiBase64),
      fallbackLicenseFileProvider = fallbackFile?.let { { it } },
    )

  private fun csvFor(
    username: String,
    plan: String = "Yearly",
    startDate: String = "01-06-2026",
    expiryDate: String = "01-06-2027",
    status: String = "Active",
    activationCode: String = "ACT-9999",
    signature: String? = null,
  ): String {
    val hash = DefaultSubscriptionService.sha256Hex(activationCode)
    return if (signature != null) {
      "username,plan,start_date,expiry_date,status,activation_code_sha256,signature\n" +
        "$username,$plan,$startDate,$expiryDate,$status,$hash,$signature\n"
    } else {
      "username,plan,start_date,expiry_date,status,activation_code_sha256\n" +
        "$username,$plan,$startDate,$expiryDate,$status,$hash\n"
    }
  }

  @Test
  fun orvaFolderIsNotPreCreatedOnInitAndAutoCreatesOnFirstFileWrite() = runTest {
    val containerInternal = File(rootDir, "container_private")
    val containerOrva = File(rootDir, "external_root/ORVA")
    val container =
      OrvaAppContainer(
        context = context,
        rootDirectory = containerInternal,
        clock = clock,
        allowMainThreadQueries = true,
        customOrvaFolder = containerOrva,
      )
    try {
      // ORVA folder must NOT exist before any portable file is actually saved.
      assertFalse("ORVA/ must not be pre-created before first file save", containerOrva.exists())

      // Setup shop + tax (writes only to private SQLite DB, not portable ORVA/).
      assertTrue(
        container.shopRepository
          .saveProfileWithAudit(
            ShopProfile(
              shopId = "shop-storage",
              shopName = "Orva Care Pharmacy",
              stateName = "West Bengal",
              stateCode = "19",
              gstin = "19AAACA1234A1Z" + GstinValidator.computeChecksumCharacter("19AAACA1234A1Z"),
            )
          )
          .isSuccess
      )
      assertTrue(
        "Live SQLite DB must stay in app-private storage, never inside ORVA/",
        container.databaseFile.parentFile!!.absolutePath == containerInternal.absolutePath,
      )
      assertFalse(File(containerOrva, "orva.sqlite").exists())

      // First portable write (receiveStock -> StockData.json) auto-creates ORVA/ folder.
      val stockRes =
        container.stockEntryService.receiveStock(
          StockEntryInput(
            medicineName = "Paracetamol 650mg",
            stockUnitName = "strip",
            batchNumber = "P650",
            expiryYearMonth = 202712,
            quantityMilli = 10_000L,
            mrpPaise = 3_200L,
            purchasePricePaise = 2_000L,
            supplierName = "MedDist",
            documentType = PurchaseDocumentType.TaxInvoice,
            documentReference = "INV-1",
          )
        )
      assertTrue(stockRes.succeeded)
      assertTrue("ORVA/ should auto-create on first StockData.json write", containerOrva.exists())
      assertTrue(File(containerOrva, "StockData.json").exists())

      // Backup writes both Daily/*.shopbackup and rolling ORVA/ShopBackup.shopbackup.
      val backup = container.backupRestoreService.runBackupNow()
      assertTrue(backup.succeeded)
      assertTrue(File(containerOrva, "ShopBackup.shopbackup").exists())
      assertTrue(File(containerOrva, "Daily").listFiles()?.any { it.name.endsWith(".shopbackup") } == true)
    } finally {
      container.close()
    }
  }

  @Test
  fun firstTimeOnlineActivationSealsLicenseAndSubsequentLaunchesWorkCompletelyOffline() = runTest {
    val fetchCount = AtomicInteger(0)
    val vault = buildVault()
    val onlineService =
      DefaultSubscriptionService(
        settings = settings,
        clock = clock,
        registryCsvFetcher = {
          fetchCount.incrementAndGet()
          csvFor(username = "medicare_kolkata", activationCode = "ORVA-KEY-7788")
        },
        licenseVault = vault,
      )

    assertFalse("ORVA/ should not exist before activation", orvaFolder.exists())
    onlineService.saveCredentials(
      username = "medicare_kolkata",
      activationCode = "ORVA-KEY-7788",
      registryUrl = "https://raw.githubusercontent.com/nexerpy-sys/ORVA/main/licenses.csv",
    )

    val activated = onlineService.refreshFromRegistry()
    assertEquals(1, fetchCount.get())
    assertTrue(activated.isActive)
    assertTrue(activated.allowNewBilling)
    assertEquals("medicare_kolkata", activated.username)

    val licenseFile = File(orvaFolder, OrvaStoragePaths.LICENSE_FILE_NAME)
    assertTrue("ORVA/license.orvalic must be auto-created on activation", licenseFile.exists())
    assertTrue("App-private .license_anchor must be created", File(internalRoot, ".license_anchor").exists())

    // Verify file is encrypted (plaintext username/expiry must NOT appear in raw file text).
    val rawText = licenseFile.readText(Charsets.UTF_8)
    assertFalse("Username must not appear in plaintext inside license.orvalic", rawText.contains("medicare_kolkata"))
    assertFalse("Expiry date must not appear in plaintext inside license.orvalic", rawText.contains("01-06-2027"))

    // Simulate next app launch completely offline (network fetcher ALWAYS throws).
    clock.utcNow = clock.utcNow.plus(Duration.ofHours(6))
    val offlineService =
      DefaultSubscriptionService(
        settings = settings,
        clock = clock,
        registryCsvFetcher = { error("Offline — no internet connection!") },
        licenseVault = buildVault(),
      )
    val statusOffline = offlineService.evaluateLocalStatus()
    assertTrue("App must stay active offline after 1st-time activation", statusOffline.isActive)
    assertTrue(statusOffline.allowNewBilling)
    assertEquals("medicare_kolkata", statusOffline.username)
  }

  @Test
  fun editingOneByteOfLicenseFileTriggersTamperedLicenseAndBlocksBillingWhileKeepingHistoryOpen() = runTest {
    val vault = buildVault()
    val subService =
      DefaultSubscriptionService(
        settings = settings,
        clock = clock,
        registryCsvFetcher = { csvFor("shree_pharma", activationCode = "KEY-111") },
        licenseVault = vault,
      )
    subService.saveCredentials("shree_pharma", "KEY-111", "https://example.com/licenses.csv")
    assertTrue(subService.refreshFromRegistry().allowNewBilling)

    // Setup shop, tax, stock, and 1 historical invoice while licence is valid.
    val shopRepo = RoomShopRepository(dbProvider, tx, clock)
    val taxRepo = RoomTaxSettingsRepository(dbProvider, tx, clock)
    val stockEntry = DefaultStockEntryService(tx, clock)
    val billing = DefaultBillingService(tx, clock, subscriptionService = subService)
    val reporting = DefaultReportingService(tx, clock)

    assertTrue(
      shopRepo
        .saveProfileWithAudit(
          ShopProfile(
            shopId = "shop-tamper",
            shopName = "Shree Pharma",
            stateName = "West Bengal",
            stateCode = "19",
            gstin = "19AAACA1234A1Z" + GstinValidator.computeChecksumCharacter("19AAACA1234A1Z"),
          )
        )
        .isSuccess
    )
    assertTrue(
      taxRepo
        .saveTaxSettings(true, TaxPricingMode.TaxInclusive, SupplyType.IntraState, RoundOffMode.None)
        .isSuccess
    )
    assertTrue(
      stockEntry
        .receiveStock(
          StockEntryInput(
            medicineName = "Amoxicillin 500mg",
            stockUnitName = "strip",
            batchNumber = "AMX1",
            expiryYearMonth = 202712,
            quantityMilli = 10_000L,
            mrpPaise = 10_000L,
            purchasePricePaise = 7_000L,
            supplierName = "Sup",
            documentType = PurchaseDocumentType.TaxInvoice,
            documentReference = "D1",
          )
        )
        .succeeded
    )
    val medId = taxRepo.getMedicinesForTaxConfig("Amoxicillin").single().medicineId
    assertTrue(taxRepo.updateMedicineTaxConfig(medId, "30042099", 1200, true).isSuccess)
    val firstInvoice =
      billing.finalizeInvoice(
        InvoiceDraft(
          items = listOf(InvoiceItemDraft(medId, 1_000L)),
          customer = InvoiceCustomerDraft(name = "Rohan Das"),
          tenders = listOf(PaymentTenderDraft(InvoicePaymentMethod.Cash, 10_000L)),
        )
      )
    assertTrue(firstInvoice.succeeded)

    // ATTACK: Edit 1 byte of ORVA/license.orvalic!
    val licFile = File(orvaFolder, OrvaStoragePaths.LICENSE_FILE_NAME)
    val tampered = licFile.readBytes()
    tampered[tampered.size / 2] = (tampered[tampered.size / 2].toInt() xor 0x01).toByte()
    licFile.writeBytes(tampered)

    val status = subService.evaluateLocalStatus()
    assertEquals("TamperedLicense", status.status)
    assertFalse(status.allowNewBilling)

    // New billing MUST be blocked...
    val blocked =
      billing.finalizeInvoice(
        InvoiceDraft(
          items = listOf(InvoiceItemDraft(medId, 1_000L)),
          customer = InvoiceCustomerDraft(name = "Blocked Customer"),
          tenders = listOf(PaymentTenderDraft(InvoicePaymentMethod.Cash, 10_000L)),
        )
      )
    assertFalse("Billing must be blocked when license.orvalic is tampered", blocked.succeeded)
    assertTrue("Blocked billing must explain subscription failure", blocked.issues.isNotEmpty())

    // ...while historical invoices remain completely readable.
    val history =
      reporting.getSalesRegister(
        RegisterDateFilter("2026-06-15", "2026-06-15"),
        InvoiceStatusFilter.Issued,
        null,
      )
    assertEquals(1, history.size)
  }

  @Test
  fun copyingLicenseFileToAnotherPhoneFailsDeviceBindingAndKeyVerification() = runTest {
    // Phone A activates cleanly and creates ORVA/license.orvalic.
    val vaultA = buildVault(deviceId = "phone-A-device-id")
    val serviceA =
      DefaultSubscriptionService(
        settings = settings,
        clock = clock,
        registryCsvFetcher = { csvFor("apollo_store", activationCode = "SECRET-A") },
        licenseVault = vaultA,
      )
    serviceA.saveCredentials("apollo_store", "SECRET-A", "https://example.com/licenses.csv")
    assertTrue(serviceA.refreshFromRegistry().allowNewBilling)

    val phoneALicense = File(orvaFolder, OrvaStoragePaths.LICENSE_FILE_NAME)
    assertTrue(phoneALicense.exists())

    // ATTACK: Copy Phone A's ORVA/license.orvalic onto Phone B (different deviceId & derived/Keystore key).
    val phoneBOrva = File(rootDir, "phoneB/ORVA").apply { mkdirs() }
    val phoneBAnchor = File(rootDir, "phoneB_private/.license_anchor")
    phoneALicense.copyTo(File(phoneBOrva, OrvaStoragePaths.LICENSE_FILE_NAME), overwrite = true)

    val vaultB = buildVault(deviceId = "phone-B-different-device-id", licenseDir = phoneBOrva, anchorFile = phoneBAnchor)
    val readOnPhoneB = vaultB.readAndVerify("apollo_store")
    assertTrue("Copied licence file must fail on Phone B", readOnPhoneB is LicenseVaultReadResult.Tampered)

    val serviceB = DefaultSubscriptionService(settings = settings, clock = clock, licenseVault = vaultB)
    val statusB = serviceB.evaluateLocalStatus()
    assertEquals("TamperedLicense", statusB.status)
    assertFalse(statusB.allowNewBilling)
  }

  @Test
  fun deletingLicenseFileAfterActivationTriggersLicenseFileMissingNotUnconfigured() = runTest {
    val vault = buildVault()
    val subService =
      DefaultSubscriptionService(
        settings = settings,
        clock = clock,
        registryCsvFetcher = { csvFor("green_pharmacy", activationCode = "KEY-222") },
        licenseVault = vault,
      )
    subService.saveCredentials("green_pharmacy", "KEY-222", "https://example.com/licenses.csv")
    assertTrue(subService.refreshFromRegistry().allowNewBilling)

    // ATTACK: User deletes ORVA/license.orvalic trying to reset back to "Not configured" free mode.
    val licFile = File(orvaFolder, OrvaStoragePaths.LICENSE_FILE_NAME)
    assertTrue(licFile.delete())

    val status = subService.evaluateLocalStatus()
    assertEquals("LicenseFileMissing", status.status)
    assertTrue(status.isConfigured)
    assertFalse("Deleting license.orvalic must NEVER re-enable free billing", status.allowNewBilling)
  }

  @Test
  fun directSqliteEditToExtendExpiryOrForceActiveTriggersTamperedLicense() = runTest {
    val vault = buildVault()
    val subService =
      DefaultSubscriptionService(
        settings = settings,
        clock = clock,
        registryCsvFetcher = {
          csvFor(
            username = "city_meds",
            expiryDate = "01-07-2026",
            status = "Active",
            activationCode = "KEY-333",
          )
        },
        licenseVault = vault,
      )
    subService.saveCredentials("city_meds", "KEY-333", "https://example.com/licenses.csv")
    assertTrue(subService.refreshFromRegistry().allowNewBilling)

    // ATTACK: Staff opens orva.sqlite in a DB browser and extends subscription.cached_expiry to 2099!
    settings.set(OrvaSettingKeys.SUBSCRIPTION_CACHED_EXPIRY, "2099-12-31")

    val status = subService.evaluateLocalStatus()
    assertEquals("TamperedLicense", status.status)
    assertFalse("SQLite expiry tamper must be caught against sealed vault", status.allowNewBilling)
  }

  @Test
  fun erasingSqliteLastSeenAndRollingClockBackIsCaughtBySealedVaultLastSeen() = runTest {
    val vault = buildVault()
    val subService =
      DefaultSubscriptionService(
        settings = settings,
        clock = clock,
        registryCsvFetcher = { csvFor("metro_meds", activationCode = "KEY-444") },
        licenseVault = vault,
      )
    subService.saveCredentials("metro_meds", "KEY-444", "https://example.com/licenses.csv")
    assertTrue(subService.refreshFromRegistry().allowNewBilling)

    // Advance 3 days and evaluate -> advances vault's encrypted lastSeenUtc to June 18.
    clock.utcNow = clock.utcNow.plus(Duration.ofDays(3))
    assertTrue(subService.evaluateLocalStatus().allowNewBilling)

    // ATTACK: Clear subscription.last_seen_utc in SQLite AND turn device clock back 48 hours to June 16!
    settings.set(OrvaSettingKeys.SUBSCRIPTION_LAST_SEEN_UTC, "")
    clock.utcNow = Instant.parse("2026-06-16T05:00:00Z")

    val status = subService.evaluateLocalStatus()
    assertEquals("ClockMismatch", status.status)
    assertFalse("Vault lastSeenUtc must catch clock rollback even if SQLite timestamp was cleared", status.allowNewBilling)
  }

  @Test
  fun ecdsaP256VendorSignatureAcceptsValidSignedRowAndRejectsModifiedExpiry() = runTest {
    val keyPair = VendorSignatureVerifier.generateP256KeyPair()
    val pubKeyB64 = VendorSignatureVerifier.encodePublicKeySpkiBase64(keyPair.public)
    val activationCode = "RINDLE-PRO-2026"
    val activationHash = DefaultSubscriptionService.sha256Hex(activationCode)

    val validSignature =
      VendorSignatureVerifier.signRow(
        privateKey = keyPair.private,
        username = "rindle_signed_shop",
        plan = "Yearly",
        startDateRaw = "01-06-2026",
        expiryDateRaw = "01-06-2027",
        status = "Active",
        activationCodeSha256 = activationHash,
      )

    val vault = buildVault(publicKeySpkiBase64 = pubKeyB64)
    val subService =
      DefaultSubscriptionService(
        settings = settings,
        clock = clock,
        licenseVault = vault,
      )
    subService.saveCredentials("rindle_signed_shop", activationCode, "https://example.com/licenses.csv")

    // 1. Valid ECDSA-signed row activates & seals cleanly.
    val validCsv =
      csvFor(
        username = "rindle_signed_shop",
        expiryDate = "01-06-2027",
        activationCode = activationCode,
        signature = validSignature,
      )
    val ok = subService.applyRegistryCsv(validCsv, "rindle_signed_shop", activationCode)
    assertTrue(ok.isActive)
    assertTrue(ok.allowNewBilling)

    // 2. ATTACK: Someone alters expiry_date to 01-06-2099 in a spoofed CSV using the old signature!
    val forgedCsv =
      csvFor(
        username = "rindle_signed_shop",
        expiryDate = "01-06-2099",
        activationCode = activationCode,
        signature = validSignature,
      )
    val rejected = subService.applyRegistryCsv(forgedCsv, "rindle_signed_shop", activationCode)
    assertEquals("InvalidSignature", rejected.status)
    assertFalse("Forged expiry with invalid ECDSA signature must be blocked", rejected.allowNewBilling)
  }

  @Test
  fun grantingAllFilesAccessAfterActivationSeamlesslyMigratesSealedLicenseFile() = runTest {
    val internalFallbackFile = File(internalRoot, "ORVA/${OrvaStoragePaths.LICENSE_FILE_NAME}")
    val externalFile = File(orvaFolder, OrvaStoragePaths.LICENSE_FILE_NAME)
    val anchorFile = File(internalRoot, ".license_anchor")

    // Step 1: User activates BEFORE granting All Files Access -> sealed into internal fallback ORVA/.
    var useExternal = false
    val vault =
      OrvaLicenseVault(
        licenseFileProvider = { if (useExternal) externalFile else internalFallbackFile },
        anchorFile = anchorFile,
        deviceInstallIdProvider = { "device-migrate-1" },
        fallbackLicenseFileProvider = { internalFallbackFile },
      )
    val subService =
      DefaultSubscriptionService(
        settings = settings,
        clock = clock,
        registryCsvFetcher = { csvFor("sunrise_pharmacy", activationCode = "MIG-1") },
        licenseVault = vault,
      )
    subService.saveCredentials("sunrise_pharmacy", "MIG-1", "https://example.com/licenses.csv")
    assertTrue(subService.refreshFromRegistry().allowNewBilling)
    assertTrue(internalFallbackFile.exists())
    assertFalse(externalFile.exists())

    // Step 2: User grants "All files access" -> active path switches to /storage/emulated/0/ORVA/license.orvalic.
    useExternal = true
    val afterGrant = subService.evaluateLocalStatus()
    assertTrue("Granting All Files Access must migrate licence seamlessly", afterGrant.isActive)
    assertTrue(afterGrant.allowNewBilling)
    assertTrue("Migrated file must now exist in external ORVA/", externalFile.exists())
    assertFalse("Old internal fallback copy must be removed after migration", internalFallbackFile.exists())

    // Step 3: Deleting external ORVA/license.orvalic afterwards must still trigger LicenseFileMissing.
    assertTrue(externalFile.delete())
    val afterDelete = subService.evaluateLocalStatus()
    assertEquals("LicenseFileMissing", afterDelete.status)
    assertFalse(afterDelete.allowNewBilling)
  }

  @Test
  fun monotonicUptimeDetectsSub24HourClockRollbackWithinSameBootSessionAndSurvivesReboot() = runTest {
    var elapsedMs = 60L * 60L * 1000L // 1 hour since boot
    val vault = buildVault()
    val subService =
      DefaultSubscriptionService(
        settings = settings,
        clock = clock,
        registryCsvFetcher = { csvFor("uptime_pharma", activationCode = "UP-100") },
        licenseVault = vault,
        monotonicElapsedMsProvider = { elapsedMs },
      )
    subService.saveCredentials("uptime_pharma", "UP-100", "https://example.com/licenses.csv")
    assertTrue(subService.refreshFromRegistry().allowNewBilling)

    // 1. Normal passage of 2 hours (both uptime and wall clock advance by 2 hours) -> stays Active.
    elapsedMs += 2L * 60L * 60L * 1000L
    clock.utcNow = clock.utcNow.plus(Duration.ofHours(2))
    assertTrue(subService.evaluateLocalStatus().allowNewBilling)

    // 2. ATTACK: 5 hours of real uptime pass, but staff rolls phone wall-clock back 1 hour
    //    (wall rollback is only 1h — well under 24h! — but uptime drift is 6h > 2h tolerance).
    elapsedMs += 5L * 60L * 60L * 1000L
    clock.utcNow = clock.utcNow.minus(Duration.ofHours(1))
    val caught = subService.evaluateLocalStatus()
    assertEquals("ClockMismatch", caught.status)
    assertFalse("Sub-24h clock rollback within same boot must be caught by elapsedRealtime()", caught.allowNewBilling)

    // 3. Recovery after reboot: user fixes wall clock forward and reboots phone (elapsedMs resets to 30s).
    elapsedMs = 30_000L
    clock.utcNow = clock.utcNow.plus(Duration.ofHours(8))
    val afterReboot = subService.evaluateLocalStatus()
    assertTrue("Normal device reboot with valid wall clock must not false-trigger ClockMismatch", afterReboot.allowNewBilling)
  }

  @Test
  fun deletingBothLicenseFileAndInternalAnchorIsStillCaughtBySqliteAnchor() = runTest {
    val anchorFile = File(internalRoot, ".license_anchor")
    val vault = buildVault(anchorFile = anchorFile)
    val subService =
      DefaultSubscriptionService(
        settings = settings,
        clock = clock,
        registryCsvFetcher = { csvFor("dual_anchor_shop", activationCode = "ANCHOR-1") },
        licenseVault = vault,
      )
    subService.saveCredentials("dual_anchor_shop", "ANCHOR-1", "https://example.com/licenses.csv")
    assertTrue(subService.refreshFromRegistry().allowNewBilling)

    // Confirm SQLite anchor mirror was written alongside .license_anchor.
    assertTrue(settings.get(DefaultSubscriptionService.SETTING_LICENSE_ANCHOR_SHA256).length == 64)

    // ATTACK: Delete BOTH ORVA/license.orvalic AND app-private .license_anchor!
    assertTrue(File(orvaFolder, OrvaStoragePaths.LICENSE_FILE_NAME).delete())
    assertTrue(anchorFile.delete())

    val status = subService.evaluateLocalStatus()
    assertEquals("LicenseFileMissing", status.status)
    assertFalse("SQLite anchor mirror must still block billing if both license file & .license_anchor are deleted", status.allowNewBilling)
  }

  @Test
  fun swappingOlderValidCopyOfLicenseFileIsCaughtByDualAnchorDigestMismatch() = runTest {
    val vault = buildVault()
    val subService =
      DefaultSubscriptionService(
        settings = settings,
        clock = clock,
        registryCsvFetcher = { csvFor("replay_shop", activationCode = "REPLAY-1") },
        licenseVault = vault,
      )
    subService.saveCredentials("replay_shop", "REPLAY-1", "https://example.com/licenses.csv")
    assertTrue(subService.refreshFromRegistry().allowNewBilling)

    // Attacker saves a backup copy of the freshly activated license.orvalic.
    val licFile = File(orvaFolder, OrvaStoragePaths.LICENSE_FILE_NAME)
    val oldSnapshotBytes = licFile.readBytes()

    // 3 hours later, normal app usage updates lastSeenUtc inside license.orvalic & both anchors.
    clock.utcNow = clock.utcNow.plus(Duration.ofHours(3))
    assertTrue(subService.evaluateLocalStatus().allowNewBilling)

    // ATTACK: Attacker overwrites ORVA/license.orvalic with the older saved copy to rewind lastSeenUtc!
    licFile.writeBytes(oldSnapshotBytes)

    val status = subService.evaluateLocalStatus()
    assertEquals("TamperedLicense", status.status)
    assertFalse("Replay of older license.orvalic snapshot must be rejected by anchor digest check", status.allowNewBilling)
  }

  @Test
  fun pythonSignerGeneratedSignatureVerifiesCleanlyInKotlinVendorSignatureVerifier() = runTest {
    // Ephemeral test vector generated by `tools/orva_license_signer.py keygen` + `sign-row`
    // (private key immediately discarded; verifies byte-for-byte Python/OpenSSL <-> Android JCA interop).
    val pythonPubKeySpkiB64 =
      "MFkwEwYHKoZIzj0CAQYIKoZIzj0DAQcDQgAEWNgS201vtSyUlEAF26e7gAlbaiwTBpmeGpNnOoyr8XLCQS72FgBKI6yE+n9eNoiYEc2ux2ABDNcNqzUgE8NkZA=="
    val pythonSignedCsv =
      "username,plan,start_date,expiry_date,status,activation_code_sha256,signature\n" +
        "arogya_kol_01,Annual,01-06-2026,01-06-2027,Active," +
        "32a857d3c7c442b11adbaf27f9759fc9486efc6636bd202aaffb8c363cc6176e," +
        "MEUCIQDvlMguTHqmsAzne3fs0V0Zc/UJpJEVLY82E2VnDrMtpQIgeBwSFP2c681rMxiU5TO4FqCRJjullJ5YOGmtulcKbHA=\n"

    val vault = buildVault(publicKeySpkiBase64 = pythonPubKeySpkiB64)
    val subService =
      DefaultSubscriptionService(
        settings = settings,
        clock = clock,
        registryCsvFetcher = { pythonSignedCsv },
        licenseVault = vault,
      )
    subService.saveCredentials("arogya_kol_01", "ORVA-8492-KX71", "https://example.com/licenses.csv")

    val activated = subService.refreshFromRegistry()
    assertTrue("Python-signed CSV row must activate cleanly in Android Kotlin", activated.isActive)
    assertTrue(activated.allowNewBilling)
    assertEquals("arogya_kol_01", activated.username)
    assertEquals("Annual", activated.plan)
    assertEquals("2027-06-01", activated.expiryDateIso)
  }
}

