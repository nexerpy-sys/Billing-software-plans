package com.rindleworks.orva.ui.about.agentic

import org.junit.Assert.assertEquals
import org.junit.Test

class AgenticGraphemeBoundariesTest {
  @Test
  fun `combining marks are revealed with their base character`() {
    val text = "A\u0301B"
    assertEquals(listOf(0, 2, 3), AgenticGraphemeBoundaries.boundaries(text))
  }

  @Test
  fun `Bengali vowel sign stays with its base consonant`() {
    val text = "কিX"
    assertEquals(listOf(0, 2, 3), AgenticGraphemeBoundaries.boundaries(text))
  }

  @Test
  fun `Bengali conjunct is not split after virama`() {
    val text = "ক্ষX"
    assertEquals(listOf(0, 3, 4), AgenticGraphemeBoundaries.boundaries(text))
  }

  @Test
  fun `Indic conjunct with joiner is not split`() {
    val text = "ক্‍ষX"
    assertEquals(listOf(0, 4, 5), AgenticGraphemeBoundaries.boundaries(text))
  }

  @Test
  fun `emoji family remains a single visible character`() {
    val text = "👨‍👩‍👧‍👦X"
    val boundaries = AgenticGraphemeBoundaries.boundaries(text)
    assertEquals(3, boundaries.size)
    assertEquals(0, boundaries.first())
    assertEquals(text.length, boundaries.last())
  }

  @Test
  fun `progress maps only to grapheme boundaries`() {
    val boundaries = AgenticGraphemeBoundaries.boundaries("ক্ষ🙂")
    assertEquals(0, AgenticGraphemeBoundaries.offsetAtProgress(boundaries, 0f))
    assertEquals(3, AgenticGraphemeBoundaries.offsetAtProgress(boundaries, 0.5f))
    assertEquals(5, AgenticGraphemeBoundaries.offsetAtProgress(boundaries, 1f))
  }
}
