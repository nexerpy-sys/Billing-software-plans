package com.rindleworks.orva.service.backup

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.rindleworks.orva.data.local.OrvaDatabaseProvider
import com.rindleworks.orva.data.local.OrvaTransactionRunner
import com.rindleworks.orva.data.repository.RoomShopRepository
import com.rindleworks.orva.data.repository.RoomTaxSettingsRepository
import com.rindleworks.orva.data.repository.StockSnapshotState
import com.rindleworks.orva.domain.common.AppVersionInfo
import com.rindleworks.orva.domain.engine.FixedBillingClock
import com.rindleworks.orva.domain.inventory.StockEntryInput
import com.rindleworks.orva.domain.settings.ShopProfile
import com.rindleworks.orva.service.inventory.DefaultMedicineCatalogueImportService
import com.rindleworks.orva.service.inventory.DefaultStockEntryService
import com.rindleworks.orva.service.snapshot.DefaultStockSnapshotService
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.time.Instant
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class SnapshotBackupImportRobolectricTest {

  private fun appContext(): Context = ApplicationProvider.getApplicationContext()

  private class Stage5Harness(context: Context) {
    val root = File(context.cacheDir, "stage5_test_${System.nanoTime()}").apply { mkdirs() }
    val dbFile = File(root, "orva.sqlite")
    val snapshotDir = File(root, "snapshots")
    val backupsDir = File(root, "backups")
    val stagingDir = File(root, "staging")

    val provider = OrvaDatabaseProvider(context, dbFile, allowMainThreadQueries = true)
    val txRunner = OrvaTransactionRunner(provider, Dispatchers.IO)
    val clock = FixedBillingClock(Instant.parse("2026-04-15T10:00:00Z"), localOffsetMinutes = 330)
    val versionInfo = AppVersionInfo(versionName = "1.0.0", versionCode = 1)

    val shopRepo = RoomShopRepository(provider, txRunner, clock)
    val taxRepo = RoomTaxSettingsRepository(provider, txRunner, clock)
    val stockEntry = DefaultStockEntryService(txRunner, clock)
    val snapshotService = DefaultStockSnapshotService(txRunner, clock, snapshotDir, versionInfo)
    val catalogueService = DefaultMedicineCatalogueImportService(txRunner, clock)
    val backupService =
      DefaultBackupRestoreService(
        databaseProvider = provider,
        transactionRunner = txRunner,
        clock = clock,
        backupsDirectory = backupsDir,
        stagingParentDirectory = stagingDir,
        appVersionInfo = versionInfo,
        snapshotRefresher = { snapshotService.refreshSnapshot() },
        portableCopyDirectory = snapshotDir,
      )

    suspend fun seedShop(shopId: String = "shop-alpha", name: String = "Alpha Medicos") {
      shopRepo.saveProfileWithAudit(
        ShopProfile(shopId = shopId, shopName = name, stateCode = "19", invoicePrefix = "ALP")
      ).getOrThrow()
    }

    fun close() = provider.closeCurrent()
  }

  @Test
  fun stockSnapshot_generationRaceGuard_leavesDirtyWhenMutationInterleaves() = runBlocking {
    val h = Stage5Harness(appContext())
    try {
      h.seedShop()
      h.stockEntry.receiveStock(StockEntryInput("Dolo 650", "strip", "D1", 202705, 5_000L, 2000L, 3000L))
      assertTrue(h.txRunner.runRead { StockSnapshotState.isDirty(it) })

      // Simulate a concurrent stock write committing BEFORE refreshSnapshot marks dirty=0
      var injected = false
      h.snapshotService.beforeMarkCleanHook = {
        if (!injected) {
          injected = true
          h.stockEntry.receiveStock(StockEntryInput("Dolo 650", "strip", "D1", 202705, 2_000L, 2000L, 3000L))
        }
      }

      val firstRefresh = h.snapshotService.refreshSnapshot().getOrThrow()
      assertFalse("Must return false because generation advanced mid-write", firstRefresh)
      assertTrue("Dirty flag must remain 1 when newer mutation committed", h.txRunner.runRead { StockSnapshotState.isDirty(it) })

      // Second refresh with no interleaving write marks clean = 0
      h.snapshotService.beforeMarkCleanHook = null
      val secondRefresh = h.snapshotService.refreshSnapshot().getOrThrow()
      assertTrue(secondRefresh)
      assertFalse(h.txRunner.runRead { StockSnapshotState.isDirty(it) })

      val writtenJson = h.snapshotService.snapshotFile().readText()
      assertTrue(writtenJson.contains("\"Format\":\"ORVA_STOCK_DATA\""))
      assertTrue(writtenJson.contains("\"FormatVersion\":2"))
    } finally {
      h.close()
    }
  }

  @Test
  fun stockDataImport_supportsV1AndV2_rejectsFutureVersion_andRollsBackOnMidpointFailure() =
    runBlocking {
      val h = Stage5Harness(appContext())
      try {
        h.seedShop()
        h.stockEntry.receiveStock(StockEntryInput("Med One", "strip", "B1", 202705, 10_000L, 1000L, 1500L))
        val medId = h.txRunner.runRead { it.medicineDao().getAll().first().medicineId }
        h.taxRepo.updateMedicineTaxConfig(medId, "3004", 1200, true).getOrThrow()

        // Export v2 StockData
        val exportedBytes = ByteArrayOutputStream().also { h.snapshotService.exportSnapshotTo(it).getOrThrow() }.toByteArray()

        // Add an extra medicine locally that should be soft-inactivated on import
        h.stockEntry.receiveStock(StockEntryInput("Local Only Med", "strip", "L1", 202705, 4_000L, 500L, 800L))

        // Midpoint failure MUST roll back completely
        h.snapshotService.importMidpointFailureHook = { throw RuntimeException("Simulated disk I/O error") }
        val failedImport = h.snapshotService.executeStockDataImport(exportedBytes.inputStream(), "StockData.json", true)
        assertFalse(failedImport.succeeded)
        assertEquals(2, h.txRunner.runRead { it.medicineDao().getActiveMedicines().size })

        // Clean v2 import soft-inactivates Local Only Med and zeroes its batch
        h.snapshotService.importMidpointFailureHook = null
        val preview = h.snapshotService.previewStockDataImport(exportedBytes.inputStream(), "StockData.json")
        assertTrue(preview.isValid)
        assertEquals(1, preview.softInactivatedMedicineCount)
        assertEquals(1, preview.zeroedBatchCount)

        val okImport = h.snapshotService.executeStockDataImport(exportedBytes.inputStream(), "StockData.json", true)
        assertTrue(okImport.succeeded)
        assertEquals(1, okImport.batchesZeroed)
        h.txRunner.runRead { db ->
          assertEquals(1, db.medicineDao().getActiveMedicines().size)
          assertEquals(0, db.medicineDao().getByNormalizedName("local only med")?.isActive)
        }

        // Legacy v1 import leaves unconfigured GST at 0 on new medicine
        val v1Json =
          """{"Format":"ORVA_STOCK_DATA","FormatVersion":1,"ShopId":"shop-alpha","ShopName":"Alpha Medicos","Medicines":[{"Name":"Legacy V1 Med","StockUnit":"strip","GstRateBasisPoints":1200,"Batches":[{"BatchNumber":"V1B","ExpiryYearMonth":202801,"MrpPaise":2000,"LatestPurchasePricePaise":1500,"QuantityMilli":3000,"Status":"ACTIVE"}]}]}"""
        val v1Res = h.snapshotService.executeStockDataImport(v1Json.byteInputStream(), "v1.json", true)
        assertTrue(v1Res.succeeded)
        assertEquals(0, h.txRunner.runRead { it.medicineDao().getByNormalizedName("legacy v1 med")?.gstRateConfigured })

        // Future v99 rejected loudly
        val v99Json = """{"Format":"ORVA_STOCK_DATA","FormatVersion":99,"Medicines":[]}"""
        val v99Preview = h.snapshotService.previewStockDataImport(v99Json.byteInputStream(), "v99.json")
        assertFalse(v99Preview.isValid)

        // Unit conflict on existing medicine ("Med One" is "strip", file claims "bottle") MUST be rejected!
        val unitConflictJson =
          """{"Format":"ORVA_STOCK_DATA","FormatVersion":2,"ShopId":"shop-alpha","ShopName":"Alpha Medicos","Medicines":[{"Name":"Med One","StockUnit":"bottle","GstRateBasisPoints":1200,"GstRateConfigured":true,"Batches":[]}]}"""
        val conflictPreview =
          h.snapshotService.previewStockDataImport(unitConflictJson.byteInputStream(), "conflict.json")
        assertFalse(conflictPreview.isValid)
        assertTrue(conflictPreview.errors.any { it.contains("Unit conflict", ignoreCase = true) })
        val conflictExec =
          h.snapshotService.executeStockDataImport(unitConflictJson.byteInputStream(), "conflict.json", true)
        assertFalse(conflictExec.succeeded)

        // Barcode ownership protection (INSERT OR IGNORE): importing another medicine with an already-owned barcode MUST NOT hijack it
        val medOneId = h.txRunner.runRead { it.medicineDao().getByNormalizedName("med one")!!.medicineId }
        h.txRunner.runWriteTransaction { db ->
          db.barcodeMappingDao()
            .upsert(com.rindleworks.orva.data.local.entity.BarcodeMappingEntity("8901234567890", medOneId, "2026-04-15T00:00:00.0000000Z"))
        }
        val hijackJson =
          """{"Format":"ORVA_STOCK_DATA","FormatVersion":2,"ShopId":"shop-alpha","ShopName":"Alpha Medicos","Medicines":[{"Name":"Med One","StockUnit":"strip","GstRateBasisPoints":1200,"GstRateConfigured":true,"Batches":[]},{"Name":"Other Med","StockUnit":"strip","GstRateBasisPoints":500,"GstRateConfigured":true,"Barcodes":["8901234567890"],"Batches":[]}]}"""
        assertTrue(h.snapshotService.executeStockDataImport(hijackJson.byteInputStream(), "hijack.json", true).succeeded)
        assertEquals(
          "Existing barcode owner must NOT be hijacked",
          medOneId,
          h.txRunner.runRead { it.barcodeMappingDao().getByBarcode("8901234567890")?.medicineId },
        )
      } finally {
        h.close()
      }
    }

  @Test
  fun catalogueImport_writesTemplateAndImportsCsvCleanly() = runBlocking {
    val h = Stage5Harness(appContext())
    try {
      h.seedShop()
      val templateOut = ByteArrayOutputStream()
      h.catalogueService.writeTemplateCsv(templateOut)
      val csvBytes = templateOut.toByteArray()

      val preview = h.catalogueService.previewCatalogueImport(csvBytes.inputStream(), "template.csv")
      assertTrue("Template CSV must be valid: ${preview.errors}", preview.isValid)
      assertEquals(1, preview.newMedicineCount)
      assertEquals(1, preview.openingBatchRowCount)

      val result =
        h.catalogueService.executeCatalogueImport(
          input = csvBytes.inputStream(),
          fileName = "template.csv",
          markProvidedGstRatesAsConfigured = true,
        )
      assertTrue(result.succeeded)
      assertEquals(1, result.medicinesCreated)
      assertEquals(1, result.batchesUpdatedOrCreated)

      h.txRunner.runRead { db ->
        val med = db.medicineDao().getByNormalizedName("paracetamol 500mg")
        assertNotNull(med)
        assertEquals(1200, med?.gstRateBasisPoints)
        assertEquals(1, med?.gstRateConfigured)
        val batches = db.stockBatchDao().getByMedicineId(med!!.medicineId)
        assertEquals(1, batches.size)
        assertEquals(50_000L, batches[0].quantityMilli)
        assertEquals(202812, batches[0].expiryYyyyMm)
      }
    } finally {
      h.close()
    }
  }

  @Test
  fun backupAndRestore_verifiesSha256TamperDetection_recoversOnFailure_andRespectsRetention() =
    runBlocking {
      val h = Stage5Harness(appContext())
      try {
        h.seedShop(shopId = "shop-1", name = "Original Pharmacy")
        h.stockEntry.receiveStock(StockEntryInput("Crocin", "strip", "CR1", 202705, 10_000L, 1000L, 2000L))

        // 1. Create backup -> stored in Daily/ AND updates rolling portable snapshots/ShopBackup.shopbackup
        assertEquals(7, h.backupService.getBackupStatus().retentionDays)
        val backupRes = h.backupService.runBackupNow()
        assertTrue("Backup failed: ${backupRes.errorMessage}", backupRes.succeeded)
        val backupFile = File(backupRes.backupPathOrUri!!)
        assertTrue(backupFile.exists())
        assertEquals("Daily", backupFile.parentFile?.name)
        assertTrue(backupFile.name.startsWith("ORVA_Daily_"))
        assertTrue(h.backupService.portableShopBackupFile()!!.exists())
        assertEquals(1L, backupRes.manifest?.medicineCount)
        assertEquals(1L, backupRes.manifest?.batchCount)

        // Daily backup should no longer be due today
        assertEquals(null, h.backupService.runDailyBackupIfDue())

        // 2. Tamper detection: corrupt 1 byte of orva.sqlite inside a copy of the archive
        val tamperedFile = File(h.root, "tampered.shopbackup")
        tamperSqliteEntryInZip(backupFile, tamperedFile)
        val tamperedPreview = FileInputStream(tamperedFile).use { h.backupService.previewRestore(it, "tampered.shopbackup") }
        assertFalse("Tampered backup MUST fail validation", tamperedPreview.isValid)
        assertTrue(tamperedPreview.errors.any { it.contains("SHA-256", ignoreCase = true) })

        // 3. Mutate live database AFTER backup
        h.stockEntry.receiveStock(StockEntryInput("Post Backup Med", "strip", "PB1", 202705, 5_000L, 500L, 900L))
        assertEquals(2, h.txRunner.runRead { it.medicineDao().countAll() })

        // 4. Simulate mid-restore failure -> automatic rollback must preserve "Post Backup Med"!
        h.backupService.restoreAfterReplaceFailureHook = { throw RuntimeException("Simulated storage fault") }
        val failedRestore = FileInputStream(backupFile).use { h.backupService.executeRestore(it, backupFile.name) }
        assertFalse(failedRestore.succeeded)
        assertTrue("Original DB must be recovered automatically", failedRestore.originalDatabaseRecovered)
        assertEquals(2, h.txRunner.runRead { it.medicineDao().countAll() })

        // 5. Clean live restore -> restores back to 1 medicine ("Crocin") and bumps databaseGeneration!
        h.backupService.restoreAfterReplaceFailureHook = null
        val genBefore = h.provider.databaseGeneration.value
        val restored = FileInputStream(backupFile).use { h.backupService.executeRestore(it, backupFile.name) }
        assertTrue("Restore failed: ${restored.errorMessage}", restored.succeeded)
        assertEquals("Original Pharmacy", restored.restoredShopName)
        val safetyFile = File(restored.safetyBackupPath!!)
        assertTrue(safetyFile.exists())
        assertEquals("Safety", safetyFile.parentFile?.name)
        assertTrue(h.provider.databaseGeneration.value > genBefore)
        assertEquals(1, h.txRunner.runRead { it.medicineDao().countAll() })
        assertNotNull(h.txRunner.runRead { it.medicineDao().getByNormalizedName("crocin") })

        // 6. Count-based retention keeps newest N daily backups and NEVER deletes the last valid backup
        backupFile.setLastModified(Instant.parse("2020-01-01T00:00:00Z").toEpochMilli())
        h.backupService.pruneOldBackupsNeverDeletingLastValid(
          retentionDays = 1,
          nowUtc = Instant.parse("2026-04-15T10:00:00Z"),
        )
        assertTrue("Last valid backup must NEVER be deleted by retention", backupFile.exists())
      } finally {
        h.close()
      }
    }

  private fun tamperSqliteEntryInZip(sourceZip: File, destZip: File) {
    ZipInputStream(FileInputStream(sourceZip)).use { zis ->
      ZipOutputStream(FileOutputStream(destZip)).use { zos ->
        var entry = zis.nextEntry
        while (entry != null) {
          val bytes = zis.readBytes()
          if (entry.name == DefaultBackupRestoreService.DATABASE_ENTRY && bytes.isNotEmpty()) {
            bytes[bytes.size - 1] = (bytes[bytes.size - 1].toInt() xor 0xFF).toByte()
          }
          zos.putNextEntry(ZipEntry(entry.name))
          zos.write(bytes)
          zos.closeEntry()
          entry = zis.nextEntry
        }
      }
    }
  }
}
