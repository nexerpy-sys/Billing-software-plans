package com.rindleworks.orva.service.returns

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.rindleworks.orva.data.local.OrvaDatabaseProvider
import com.rindleworks.orva.data.local.OrvaTransactionRunner
import com.rindleworks.orva.data.repository.RoomInventoryRepository
import com.rindleworks.orva.data.repository.RoomShopRepository
import com.rindleworks.orva.data.repository.RoomTaxSettingsRepository
import com.rindleworks.orva.domain.billing.InvoiceDraft
import com.rindleworks.orva.domain.billing.InvoiceItemDraft
import com.rindleworks.orva.domain.billing.InvoicePaymentMethod
import com.rindleworks.orva.domain.billing.PaymentTenderDraft
import com.rindleworks.orva.domain.engine.FixedBillingClock
import com.rindleworks.orva.domain.inventory.BatchStatus
import com.rindleworks.orva.domain.inventory.ExpiryAlertLevel
import com.rindleworks.orva.domain.inventory.MedicineDetailsInput
import com.rindleworks.orva.domain.inventory.PurchaseDocumentType
import com.rindleworks.orva.domain.inventory.StockAdjustmentInput
import com.rindleworks.orva.domain.inventory.StockEntryInput
import com.rindleworks.orva.domain.returns.ResaleDisposition
import com.rindleworks.orva.domain.returns.SalesRefundMethod
import com.rindleworks.orva.domain.returns.SalesReturnLineRequest
import com.rindleworks.orva.domain.returns.SalesReturnRequest
import com.rindleworks.orva.domain.settings.RoundOffMode
import com.rindleworks.orva.domain.settings.ShopProfile
import com.rindleworks.orva.domain.settings.SupplyType
import com.rindleworks.orva.domain.settings.TaxPricingMode
import com.rindleworks.orva.service.billing.DefaultBillingService
import com.rindleworks.orva.service.inventory.DefaultStockAdjustmentService
import com.rindleworks.orva.service.inventory.DefaultStockEntryService
import java.io.File
import java.time.Instant
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class InventoryReturnsCancellationRobolectricTest {

  private fun appContext(): Context = ApplicationProvider.getApplicationContext()

  private class Stage4Harness(context: Context) {
    val dbFile =
      File(File(context.cacheDir, "stage4_test_${System.nanoTime()}").apply { mkdirs() }, "orva.sqlite")
    val provider = OrvaDatabaseProvider(context, dbFile, allowMainThreadQueries = true)
    val txRunner = OrvaTransactionRunner(provider, Dispatchers.IO)
    val clock = FixedBillingClock(Instant.parse("2026-04-15T06:00:00Z"), localOffsetMinutes = 330)
    val shopRepo = RoomShopRepository(provider, txRunner, clock)
    val taxRepo = RoomTaxSettingsRepository(provider, txRunner, clock)
    val inventoryRepo = RoomInventoryRepository(provider, txRunner, clock)
    val stockEntry = DefaultStockEntryService(txRunner, clock)
    val stockAdjust = DefaultStockAdjustmentService(txRunner, clock)
    val billing = DefaultBillingService(txRunner, clock)
    val returns = DefaultSalesReturnService(txRunner, clock)
    val cancellation = DefaultInvoiceCancellationService(txRunner, clock)

    suspend fun seedShopAndTax(roundOffMode: RoundOffMode = RoundOffMode.None) {
      shopRepo.saveProfileWithAudit(
        ShopProfile(
          shopId = "shop-1",
          shopName = "Rindle Pharmacy",
          stateCode = "19",
          invoicePrefix = "INV",
          financialYearStartMonth = 4,
        )
      ).getOrThrow()
      taxRepo.saveTaxSettings(
        taxConfigured = true,
        pricingMode = TaxPricingMode.TaxExclusive,
        defaultSupplyType = SupplyType.IntraState,
        roundOffMode = roundOffMode,
      ).getOrThrow()
    }

    fun close() = provider.closeCurrent()
  }

  @Test
  fun stockEntry_mergesNormalizedBatches_andLowStockExcludesExpiredOrQuarantined() = runBlocking {
    val h = Stage4Harness(appContext())
    try {
      // Receive 2 strips of B-01 (active, 2027-05)
      val r1 =
        h.stockEntry.receiveStock(
          StockEntryInput(
            medicineName = "Pan 40",
            stockUnitName = "strip",
            batchNumber = "B-01",
            expiryYearMonth = 202705,
            quantityMilli = 2_000L,
            purchasePricePaise = 8000L,
            mrpPaise = 12000L,
            supplierName = "MedDist",
            documentType = PurchaseDocumentType.TaxInvoice,
          )
        )
      assertTrue(r1.succeeded)
      assertEquals(2_000L, r1.newQuantityMilli)

      // Receive 1 more strip with lowercase/padded batch number -> must merge into B-01!
      val r2 =
        h.stockEntry.receiveStock(
          StockEntryInput(
            medicineName = "pan 40",
            stockUnitName = "strip",
            batchNumber = "  b-01 ",
            expiryYearMonth = 202705,
            quantityMilli = 1_000L,
            purchasePricePaise = 8200L,
            mrpPaise = 12500L,
          )
        )
      assertTrue(r2.succeeded)
      assertEquals(3_000L, r2.newQuantityMilli)
      assertEquals(1 to 1, h.inventoryRepo.getCounts())

      // Receiving an already-expired batch (2026-03 while clock is 2026-04) MUST be rejected!
      val rExpRejected =
        h.stockEntry.receiveStock(
          StockEntryInput(
            medicineName = "Pan 40",
            stockUnitName = "strip",
            batchNumber = "B-OLD",
            expiryYearMonth = 202603,
            quantityMilli = 50_000L,
            purchasePricePaise = 7000L,
            mrpPaise = 10000L,
          )
        )
      assertFalse(rExpRejected.succeeded)
      assertTrue(rExpRejected.errorMessage!!.contains("expiry", ignoreCase = true))

      // Seed B-OLD back when it was still unexpired (2026-02), then advance clock to 2026-04
      val savedNow = h.clock.utcNow
      h.clock.utcNow = Instant.parse("2026-02-15T06:00:00Z")
      val rExpSeeded =
        h.stockEntry.receiveStock(
          StockEntryInput(
            medicineName = "Pan 40",
            stockUnitName = "strip",
            batchNumber = "B-OLD",
            expiryYearMonth = 202603,
            quantityMilli = 50_000L,
            purchasePricePaise = 7000L,
            mrpPaise = 10000L,
          )
        )
      assertTrue(rExpSeeded.succeeded)
      h.clock.utcNow = savedNow

      // Set low-stock threshold to 5 strips (5000 milli) -> usable is only 3000 <= 5000 => LOW STOCK!
      val medId = h.txRunner.runRead { it.medicineDao().getAll().first().medicineId }
      val details = h.inventoryRepo.getMedicineDetails(medId)!!
      h.inventoryRepo.updateMedicineDetails(details.copy(lowStockThresholdMilli = 5_000L)).getOrThrow()

      val lowStock = h.inventoryRepo.observeLowStockAlerts().first()
      assertEquals(1, lowStock.size)
      assertEquals(3_000L, lowStock[0].usableQuantityMilli)

      val expiryAlerts = h.inventoryRepo.observeExpiryAlerts().first()
      assertEquals(1, expiryAlerts.size)
      assertEquals(ExpiryAlertLevel.Expired, expiryAlerts[0].alertLevel)
      assertEquals("B-OLD", expiryAlerts[0].batchNumber)
    } finally {
      h.close()
    }
  }

  @Test
  fun stockEntry_enforcesUnitMismatchReactivationQuarantinedMergeZeroMrpAndUnitPreservation() =
    runBlocking {
      val h = Stage4Harness(appContext())
      try {
        val r1 =
          h.stockEntry.receiveStock(
            StockEntryInput(
              medicineName = "Azithral 500",
              stockUnitName = "strip",
              batchNumber = "AZ-1",
              expiryYearMonth = 202708,
              quantityMilli = 4_000L,
              purchasePricePaise = 9000L,
              mrpPaise = 13500L,
            )
          )
        assertTrue(r1.succeeded)
        val medId = h.txRunner.runRead { it.medicineDao().getAll().first().medicineId }
        val batchId = h.txRunner.runRead { it.stockBatchDao().getAll().first().batchId }

        // 1. Unit mismatch on existing medicine MUST fail
        val unitMismatch =
          h.stockEntry.receiveStock(
            StockEntryInput(
              medicineName = "Azithral 500",
              stockUnitName = "bottle",
              batchNumber = "AZ-2",
              expiryYearMonth = 202708,
              quantityMilli = 1_000L,
              purchasePricePaise = 9000L,
              mrpPaise = 13500L,
            )
          )
        assertFalse(unitMismatch.succeeded)
        assertTrue(unitMismatch.errorMessage!!.contains("unit", ignoreCase = true))

        // 2. Merging into existing batch with mrpPaise = 0 preserves existing MRP (13500L)
        val zeroMrpMerge =
          h.stockEntry.receiveStock(
            StockEntryInput(
              medicineName = "Azithral 500",
              stockUnitName = "strip",
              batchNumber = "AZ-1",
              expiryYearMonth = 202708,
              quantityMilli = 1_000L,
              purchasePricePaise = 9100L,
              mrpPaise = 0L,
            )
          )
        assertTrue(zeroMrpMerge.succeeded)
        assertEquals(13500L, h.txRunner.runRead { it.stockBatchDao().getById(batchId)?.mrpPaise })

        // 3. Soft-inactivated medicine is automatically reactivated when new stock is received
        h.txRunner.runWriteTransaction { db ->
          val existing = db.medicineDao().getById(medId)!!
          db.medicineDao().update(existing.copy(isActive = 0))
        }
        val reactivated =
          h.stockEntry.receiveStock(
            StockEntryInput(
              medicineName = "Azithral 500",
              stockUnitName = "strip",
              batchNumber = "AZ-NEW",
              expiryYearMonth = 202709,
              quantityMilli = 2_000L,
              purchasePricePaise = 9200L,
              mrpPaise = 14000L,
            )
          )
        assertTrue(reactivated.succeeded)
        assertEquals(1, h.txRunner.runRead { it.medicineDao().getById(medId)?.isActive })

        // 4. Merging into a QUARANTINED batch MUST be rejected
        h.inventoryRepo.updateBatchStatus(batchId, BatchStatus.Quarantined, "Damaged seal").getOrThrow()
        val quarantinedMerge =
          h.stockEntry.receiveStock(
            StockEntryInput(
              medicineName = "Azithral 500",
              stockUnitName = "strip",
              batchNumber = "AZ-1",
              expiryYearMonth = 202708,
              quantityMilli = 1_000L,
              purchasePricePaise = 9000L,
              mrpPaise = 13500L,
            )
          )
        assertFalse(quarantinedMerge.succeeded)
        assertTrue(quarantinedMerge.errorMessage!!.contains("QUARANTINED", ignoreCase = true))

        // 5. updateMedicineDetails MUST preserve existing stockUnitName
        val details = h.inventoryRepo.getMedicineDetails(medId)!!
        h.inventoryRepo.updateMedicineDetails(details.copy(stockUnitName = "box")).getOrThrow()
        assertEquals("strip", h.inventoryRepo.getMedicineDetails(medId)!!.stockUnitName)
      } finally {
        h.close()
      }
    }

  @Test
  fun stockAdjustment_recordsDiscrepancyAndMovement_andRejectsZeroDelta() = runBlocking {
    val h = Stage4Harness(appContext())
    try {
      h.stockEntry.receiveStock(
        StockEntryInput("Calpol", "bottle", "C1", 202705, 10_000L, 4000L, 6000L)
      )
      val batchId = h.txRunner.runRead { it.stockBatchDao().getAll().first().batchId }

      val noOp = h.stockAdjust.adjustBatchQuantity(StockAdjustmentInput(batchId, 10_000L, "Same"))
      assertFalse(noOp.succeeded)

      val adj =
        h.stockAdjust.adjustBatchQuantity(
          StockAdjustmentInput(batchId, 8_000L, "2 bottles damaged during transit")
        )
      assertTrue(adj.succeeded)
      assertEquals(-2_000L, adj.differenceMilli)

      h.txRunner.runRead { db ->
        assertEquals(8_000L, db.stockBatchDao().getById(batchId)?.quantityMilli)
        val disc = db.ledgerDao().getDiscrepanciesForBatch(batchId)
        assertEquals(1, disc.size)
        assertEquals(-2_000L, disc[0].differenceMilli)
      }
    } finally {
      h.close()
    }
  }

  @Test
  fun salesReturn_enforcesQuarantineDefault_blocksExpiredRestock_andReconcilesNearestRupeeRoundOff() =
    runBlocking {
      val h = Stage4Harness(appContext())
      try {
        h.seedShopAndTax(roundOffMode = RoundOffMode.NearestRupee)
        h.stockEntry.receiveStock(
          StockEntryInput("Syrup X", "bottle", "S1", 202605, 10_000L, 800L, 1090L)
        )
        val medId = h.txRunner.runRead { it.medicineDao().getAll().first().medicineId }
        val batchId = h.txRunner.runRead { it.stockBatchDao().getAll().first().batchId }
        h.taxRepo.updateMedicineTaxConfig(medId, "3004", 500, true).getOrThrow()

        // 2 bottles @ ₹10.90 exclusive + 5% = 2180 + 109 = 2289 -> rounds to 2300 (+11 round-off!)
        val inv =
          h.billing.finalizeInvoice(
            InvoiceDraft(
              items = listOf(InvoiceItemDraft(medId, 2_000L)),
              tenders = listOf(PaymentTenderDraft(InvoicePaymentMethod.Cash, 2300L)),
            )
          )
        assertTrue(inv.succeeded)
        assertEquals(2300L, inv.grandTotalPaise)

        val invoiceId = inv.invoiceId!!
        val returnableLines = h.returns.getReturnableLines(invoiceId)
        assertEquals(1, returnableLines.size)
        val lineId = returnableLines[0].invoiceLineId

        // Step 1: Partial return of 1 bottle to QUARANTINE (must NOT increment sellable batch!)
        val req1 =
          SalesReturnRequest(
            invoiceId = invoiceId,
            reason = "Customer changed prescription",
            refundMethod = SalesRefundMethod.Cash,
            lines = listOf(SalesReturnLineRequest(lineId, 1_000L, ResaleDisposition.Quarantine)),
          )
        val prev1 = h.returns.previewReturn(req1)
        assertTrue(prev1.canFinalize)
        val res1 = h.returns.finalizeReturn(req1)
        assertTrue(res1.succeeded)
        assertEquals(prev1.totalRefundPaise, res1.refundAmountPaise)
        assertEquals("RET/26-27/000001", res1.returnNumber)
        // Batch quantity stays at 8_000 (10 - 2 sold, NOT restocked!)
        assertEquals(8_000L, h.txRunner.runRead { it.stockBatchDao().getById(batchId)?.quantityMilli })

        // Cancellation MUST now be blocked because a completed return exists!
        val cancelBlocked = h.cancellation.cancelInvoice(invoiceId, "Mistake", restoreStock = true)
        assertFalse(cancelBlocked.succeeded)

        // Advance clock past batch expiry (2026-06-01) -> RESTOCK must be rejected!
        h.clock.utcNow = Instant.parse("2026-06-02T06:00:00Z")
        val restockExpired =
          h.returns.previewReturn(
            SalesReturnRequest(
              invoiceId = invoiceId,
              reason = "Second bottle returned",
              refundMethod = SalesRefundMethod.Cash,
              lines = listOf(SalesReturnLineRequest(lineId, 1_000L, ResaleDisposition.Restock)),
            )
          )
        assertFalse(restockExpired.canFinalize)
        assertTrue(restockExpired.errors.any { it.contains("expired", ignoreCase = true) })

        // Step 2: Return final remaining bottle as EXPIRED -> cumulative refund MUST equal invoice grandTotal (2300L)!
        val req2 =
          SalesReturnRequest(
            invoiceId = invoiceId,
            reason = "Remaining bottle returned expired",
            refundMethod = SalesRefundMethod.Upi,
            lines = listOf(SalesReturnLineRequest(lineId, 1_000L, ResaleDisposition.Expired)),
          )
        val prev2 = h.returns.previewReturn(req2)
        assertTrue(prev2.canFinalize)
        val res2 = h.returns.finalizeReturn(req2)
        assertTrue(res2.succeeded)
        assertEquals(prev2.totalRefundPaise, res2.refundAmountPaise)
        assertEquals(
          "Cumulative refund must equal rounded grandTotalPaise",
          2300L,
          res1.refundAmountPaise + res2.refundAmountPaise,
        )
      } finally {
        h.close()
      }
    }

  @Test
  fun invoiceCancellation_restoresStockAndWarnsIfBatchQuarantined() = runBlocking {
    val h = Stage4Harness(appContext())
    try {
      h.seedShopAndTax()
      h.stockEntry.receiveStock(
        StockEntryInput("Augmentin 625", "strip", "AUG1", 202705, 5_000L, 15000L, 20000L)
      )
      val medId = h.txRunner.runRead { it.medicineDao().getAll().first().medicineId }
      val batchId = h.txRunner.runRead { it.stockBatchDao().getAll().first().batchId }
      h.taxRepo.updateMedicineTaxConfig(medId, "3004", 0, true).getOrThrow()

      val inv =
        h.billing.finalizeInvoice(
          InvoiceDraft(
            items = listOf(InvoiceItemDraft(medId, 2_000L)),
            tenders = listOf(PaymentTenderDraft(InvoicePaymentMethod.Cash, 40_000L)),
          )
        )
      assertTrue(inv.succeeded)
      assertEquals(3_000L, h.txRunner.runRead { it.stockBatchDao().getById(batchId)?.quantityMilli })

      // Quarantine the batch before cancelling the invoice
      h.inventoryRepo.updateBatchStatus(batchId, BatchStatus.Quarantined, "Recall check").getOrThrow()

      val cancel =
        h.cancellation.cancelInvoice(inv.invoiceId!!, "Wrong patient billed", restoreStock = true)
      assertTrue(cancel.succeeded)
      assertTrue(cancel.stockRestored)
      assertNotNull(cancel.stockWarning)
      assertTrue(cancel.stockWarning!!.contains("QUARANTINED"))
      assertEquals(5_000L, h.txRunner.runRead { it.stockBatchDao().getById(batchId)?.quantityMilli })
    } finally {
      h.close()
    }
  }
}
