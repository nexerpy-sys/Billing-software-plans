package com.rindleworks.orva.service.records

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.rindleworks.orva.data.local.OrvaDatabaseProvider
import com.rindleworks.orva.data.local.OrvaTransactionRunner
import com.rindleworks.orva.data.repository.RoomAppSettingsRepository
import com.rindleworks.orva.data.repository.RoomShopRepository
import com.rindleworks.orva.data.repository.RoomTaxSettingsRepository
import com.rindleworks.orva.domain.billing.InvoiceCustomerDraft
import com.rindleworks.orva.domain.billing.InvoiceDraft
import com.rindleworks.orva.domain.billing.InvoiceItemDraft
import com.rindleworks.orva.domain.billing.InvoicePaperFormat
import com.rindleworks.orva.domain.billing.InvoicePaymentMethod
import com.rindleworks.orva.domain.billing.InvoicePrintRequest
import com.rindleworks.orva.domain.billing.PaymentTenderDraft
import com.rindleworks.orva.domain.billing.ThermalPrinterTransport
import com.rindleworks.orva.domain.engine.FixedBillingClock
import com.rindleworks.orva.domain.engine.GstinValidator
import com.rindleworks.orva.domain.inventory.PurchaseDocumentType
import com.rindleworks.orva.domain.inventory.StockEntryInput
import com.rindleworks.orva.domain.records.ExpenseInput
import com.rindleworks.orva.domain.records.ExportFormat
import com.rindleworks.orva.domain.records.InvoiceStatusFilter
import com.rindleworks.orva.domain.records.RegisterDateFilter
import com.rindleworks.orva.domain.records.ReportType
import com.rindleworks.orva.domain.returns.ResaleDisposition
import com.rindleworks.orva.domain.returns.SalesRefundMethod
import com.rindleworks.orva.domain.returns.SalesReturnLineRequest
import com.rindleworks.orva.domain.returns.SalesReturnRequest
import com.rindleworks.orva.domain.settings.RoundOffMode
import com.rindleworks.orva.domain.settings.ShopProfile
import com.rindleworks.orva.domain.settings.SupplyType
import com.rindleworks.orva.domain.settings.TaxPricingMode
import com.rindleworks.orva.service.billing.DefaultBillingService
import com.rindleworks.orva.service.export.CsvExportHelper
import com.rindleworks.orva.service.inventory.DefaultStockEntryService
import com.rindleworks.orva.service.printing.DefaultInvoicePrintService
import com.rindleworks.orva.service.printing.EscPosInvoiceEncoder
import com.rindleworks.orva.service.returns.DefaultSalesReturnService
import com.rindleworks.orva.service.subscription.DefaultSubscriptionService
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.time.Instant
import java.time.temporal.ChronoUnit
import java.util.UUID
import java.util.zip.ZipInputStream
import kotlinx.coroutines.test.runTest
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ReportingExportPrintSubscriptionRobolectricTest {

  private lateinit var context: Context
  private lateinit var testDir: File
  private lateinit var clock: FixedBillingClock
  private lateinit var provider: OrvaDatabaseProvider
  private lateinit var tx: OrvaTransactionRunner
  private lateinit var shopRepo: RoomShopRepository
  private lateinit var appSettingsRepo: RoomAppSettingsRepository
  private lateinit var taxRepo: RoomTaxSettingsRepository
  private lateinit var stockEntryService: DefaultStockEntryService
  private lateinit var billingService: DefaultBillingService
  private lateinit var salesReturnService: DefaultSalesReturnService
  private lateinit var reportingService: DefaultReportingService
  private lateinit var printService: DefaultInvoicePrintService

  @Before
  fun setUp() {
    context = ApplicationProvider.getApplicationContext()
    testDir = File(context.cacheDir, "orva-stage6-${UUID.randomUUID()}").apply { mkdirs() }
    clock = FixedBillingClock(Instant.parse("2026-06-10T06:00:00Z"), localOffsetMinutes = 330)
    provider =
      OrvaDatabaseProvider(
        context = context,
        databaseFile = File(testDir, "orva.sqlite"),
        allowMainThreadQueries = true,
      )
    tx = OrvaTransactionRunner(provider)
    shopRepo = RoomShopRepository(provider, tx, clock)
    appSettingsRepo = RoomAppSettingsRepository(provider, tx, clock)
    taxRepo = RoomTaxSettingsRepository(provider, tx, clock)
    stockEntryService = DefaultStockEntryService(tx, clock)
    billingService = DefaultBillingService(tx, clock)
    salesReturnService = DefaultSalesReturnService(tx, clock)
    reportingService = DefaultReportingService(tx, clock)
    printService = DefaultInvoicePrintService(appSettingsRepo)
  }

  @After
  fun tearDown() {
    provider.closeCurrent()
    testDir.deleteRecursively()
  }

  private suspend fun seedPharmacyTransactions(): String {
    assertTrue(
      shopRepo
        .saveProfileWithAudit(
          ShopProfile(
            shopId = "shop-stage6",
            shopName = "Arogya Medico",
            legalName = "Arogya Medico Pvt Ltd",
            address = "14 Park Street, Kolkata",
            phone = "9830011223",
            stateName = "West Bengal",
            stateCode = "19",
            gstin = "19AAACA1234A1Z" + GstinValidator.computeChecksumCharacter("19AAACA1234A1Z"),
            drugLicenceNumber = "WB-KOL-20B-991",
            invoicePrefix = "INV",
            financialYearStartMonth = 4,
          )
        )
        .isSuccess
    )
    assertTrue(
      taxRepo
        .saveTaxSettings(
          taxConfigured = true,
          pricingMode = TaxPricingMode.TaxExclusive,
          defaultSupplyType = SupplyType.IntraState,
          roundOffMode = RoundOffMode.None,
        )
        .isSuccess
    )

    val entry =
      stockEntryService.receiveStock(
        StockEntryInput(
          medicineName = "Paracetamol 500mg",
          stockUnitName = "strip",
          batchNumber = "PCM01",
          expiryYearMonth = 202806,
          quantityMilli = 20_000L, // 20 strips
          mrpPaise = 5000L, // Rs 50.00
          purchasePricePaise = 3500L, // Rs 35.00
          supplierName = "Bengal Pharma Distributors",
          documentType = PurchaseDocumentType.TaxInvoice,
          documentReference = "BPD-2026-88",
        )
      )
    assertTrue(entry.succeeded)
    val medId = taxRepo.getMedicinesForTaxConfig("Paracetamol").single().medicineId
    assertTrue(taxRepo.updateMedicineTaxConfig(medId, "30049011", 1200, true).isSuccess) // 12% GST

    // Issue invoice for 4 strips: Taxable = 4 * 50.00 = 200.00, GST 12% = 24.00 (12 CGST + 12 SGST), Total = 224.00
    val inv =
      billingService.finalizeInvoice(
        InvoiceDraft(
          items = listOf(InvoiceItemDraft(medId, 4_000L)),
          customer = InvoiceCustomerDraft(name = "Rohan Das", phone = "9830099999"),
          tenders = listOf(PaymentTenderDraft(InvoicePaymentMethod.Upi, 22_400L, "UPI-8899")),
        )
      )
    assertTrue(inv.succeeded)
    val invoiceId = inv.invoiceId!!

    // Record a 1-strip sales return (quarantine)
    val returnableLines = salesReturnService.getReturnableLines(invoiceId)
    val ret =
      salesReturnService.finalizeReturn(
        SalesReturnRequest(
          invoiceId = invoiceId,
          reason = "Patient changed prescription",
          refundMethod = SalesRefundMethod.Cash,
          lines =
            listOf(
              SalesReturnLineRequest(
                invoiceLineId = returnableLines.single().invoiceLineId,
                returnQuantityMilli = 1_000L,
                resaleDisposition = ResaleDisposition.Quarantine,
              )
            ),
        )
      )
    assertTrue(ret.succeeded)

    // Record an expense
    val exp =
      reportingService.addExpense(
        ExpenseInput(
          category = "Electricity",
          description = "May CESC bill",
          amountPaise = 345_000L,
          paymentMethod = InvoicePaymentMethod.Upi,
          documentReference = "CESC-0526",
        )
      )
    assertTrue(exp.isSuccess)
    return invoiceId
  }

  @Test
  fun allSixRegistersAndReprintReturnExactFigures() = runTest {
    val invoiceId = seedPharmacyTransactions()
    val todayFilter = RegisterDateFilter("2026-06-10", "2026-06-10")

    val sales = reportingService.getSalesRegister(todayFilter, InvoiceStatusFilter.All, null)
    assertEquals(1, sales.size)
    assertEquals("INV/26-27/000001", sales.single().invoiceNumber)
    assertEquals("CREDIT_NOTE_ISSUED", sales.single().status)
    assertEquals(20_000L, sales.single().taxableValuePaise)
    assertEquals(1_200L, sales.single().cgstPaise)
    assertEquals(1_200L, sales.single().sgstPaise)
    assertEquals(22_400L, sales.single().grandTotalPaise)

    val purchases = reportingService.getPurchaseRegister(todayFilter, "bengal")
    assertEquals(1, purchases.size)
    assertEquals("BPD-2026-88", purchases.single().documentReference)
    assertEquals(70_000L, purchases.single().totalPaise) // 20 * 35.00
    assertTrue(purchases.single().isDocumentedForReview)

    val gst = reportingService.getGstSummary(todayFilter)
    assertEquals(1, gst.size)
    assertEquals("30049011", gst.single().hsnCode)
    assertEquals(1200, gst.single().gstRateBasisPoints)
    // Sold 4 strips (₹200 taxable, ₹24 GST) and returned 1 strip -> NET 3 strips (₹150 taxable, ₹18 GST, ₹168 total)
    assertEquals(15_000L, gst.single().taxableValuePaise)
    assertEquals(900L, gst.single().cgstPaise)
    assertEquals(900L, gst.single().sgstPaise)
    assertEquals(16_800L, gst.single().totalValuePaise)

    val valuation = reportingService.getStockValuation()
    assertEquals(1, valuation.size)
    // Started with 20 strips, sold 4, returned 1 to QUARANTINE -> 16 usable strips remain
    assertEquals(16_000L, valuation.single().usableQuantityMilli)
    assertEquals(56_000L, valuation.single().purchaseCostValuePaise) // 16 * 35.00
    assertEquals(80_000L, valuation.single().mrpValuePaise) // 16 * 50.00

    val returns = reportingService.getSalesReturnsRegister(todayFilter, null)
    assertEquals(1, returns.size)
    assertEquals("RET/26-27/000001", returns.single().returnNumber)
    assertEquals(5_600L, returns.single().refundAmountPaise)

    val expenses = reportingService.getExpenses(todayFilter)
    assertEquals(1, expenses.size)
    assertEquals("Electricity", expenses.single().category)
    assertEquals(345_000L, expenses.single().amountPaise)

    val reprint = reportingService.getInvoiceForReprint(invoiceId)
    assertNotNull(reprint)
    assertEquals("INV/26-27/000001", reprint!!.committedInvoice.invoiceNumber)
    assertEquals(22_400L, reprint.preview.grandTotalPaise)
    assertEquals("Rohan Das", reprint.customer.name)
    assertEquals(1, reprint.tenders.size)
    assertEquals(InvoicePaymentMethod.Upi, reprint.tenders.single().method)
  }

  @Test
  fun csvFormulaNeutralizationPreservesPlainNegativeDecimalsAndNeutralizesFormulas() {
    assertEquals("'=SUM(A1:A5)", CsvExportHelper.neutralizeFormulaCell("=SUM(A1:A5)"))
    assertEquals("'+cmd|' /C calc'!A0", CsvExportHelper.neutralizeFormulaCell("+cmd|' /C calc'!A0"))
    assertEquals("'@IMPORTXML", CsvExportHelper.neutralizeFormulaCell("@IMPORTXML"))
    assertEquals("'-SUM(A1)", CsvExportHelper.neutralizeFormulaCell("-SUM(A1)"))
    // Plain negative monetary/round-off decimals must stay numeric without apostrophe
    assertEquals("-45.00", CsvExportHelper.neutralizeFormulaCell("-45.00"))
    assertEquals("-0.35", CsvExportHelper.neutralizeFormulaCell("-0.35"))
    assertEquals("-100", CsvExportHelper.neutralizeFormulaCell("-100"))
  }

  @Test
  fun multiFormatReportExportsProduceValidCsvXlsxAndPdf() = runTest {
    seedPharmacyTransactions()
    val filter = RegisterDateFilter("2026-06-10", "2026-06-10")

    // 1. CSV with UTF-8 BOM
    val csvOut = ByteArrayOutputStream()
    assertTrue(
      reportingService.exportReport(ReportType.SalesRegister, ExportFormat.Csv, csvOut, filter).isSuccess
    )
    val csvBytes = csvOut.toByteArray()
    assertEquals(0xEF.toByte(), csvBytes[0])
    assertEquals(0xBB.toByte(), csvBytes[1])
    assertEquals(0xBF.toByte(), csvBytes[2])
    val csvText = String(csvBytes, 3, csvBytes.size - 3, Charsets.UTF_8)
    assertTrue(csvText.contains("INV/26-27/000001"))
    assertTrue(csvText.contains("224.00"))

    // 2. XLSX valid OOXML ZIP package
    val xlsxOut = ByteArrayOutputStream()
    assertTrue(
      reportingService.exportReport(ReportType.GstSummary, ExportFormat.Xlsx, xlsxOut, filter).isSuccess
    )
    val entries = mutableMapOf<String, String>()
    ZipInputStream(ByteArrayInputStream(xlsxOut.toByteArray())).use { zis ->
      while (true) {
        val entry = zis.nextEntry ?: break
        entries[entry.name] = zis.readBytes().toString(Charsets.UTF_8)
      }
    }
    assertTrue(entries.containsKey("[Content_Types].xml"))
    assertTrue(entries.containsKey("xl/workbook.xml"))
    assertTrue(entries.containsKey("xl/worksheets/sheet1.xml"))
    assertTrue(entries["xl/worksheets/sheet1.xml"]!!.contains("30049011"))
    assertTrue(entries["xl/worksheets/sheet1.xml"]!!.contains("<v>168.00</v>"))

    // 3. PDF 1.4 with valid header & EOF
    val pdfOut = ByteArrayOutputStream()
    assertTrue(
      reportingService
        .exportReport(
          reportType = ReportType.SalesRegister,
          format = ExportFormat.Pdf,
          output = pdfOut,
          filter = filter,
          subtitle = "Arogya Medico | 10-Jun-2026",
        )
        .isSuccess
    )
    val pdfText = pdfOut.toByteArray().toString(Charsets.ISO_8859_1)
    assertTrue(pdfText.startsWith("%PDF-1.4\n"))
    assertTrue(pdfText.trimEnd().endsWith("%%EOF"))
    assertTrue(pdfText.contains("INV/26-27/000001"))
  }

  @Test
  fun invoicePrintingRendersAllFourPaperFormatsAndEncodesEscPosAndRaster() = runTest {
    val invoiceId = seedPharmacyTransactions()
    val shop = shopRepo.getProfile()!!
    val record = reportingService.getInvoiceForReprint(invoiceId)!!

    // Verify all 4 paper formats render valid PDF
    for (format in InvoicePaperFormat.entries) {
      val pdfOut = ByteArrayOutputStream()
      val req =
        InvoicePrintRequest(
          shopProfile = shop,
          committedInvoice = record.committedInvoice,
          preview = record.preview,
          customer = record.customer,
          tenders = record.tenders,
          paperFormat = format,
        )
      printService.renderInvoicePdf(req, pdfOut)
      val pdfStr = pdfOut.toByteArray().toString(Charsets.ISO_8859_1)
      assertTrue("Expected PDF header for $format", pdfStr.startsWith("%PDF-1.4\n"))
      assertTrue("Expected invoice number for $format", pdfStr.contains("INV/26-27/000001"))
    }

    // Verify ESC/POS receipt + transport write + last printer name persistence
    val captured = ByteArrayOutputStream()
    val fakeTransport =
      object : ThermalPrinterTransport {
        override val displayName: String = "Epson TM-T82 BT"

        override suspend fun write(bytes: ByteArray): Result<Unit> {
          captured.write(bytes)
          return Result.success(Unit)
        }
      }

    val printRes =
      printService.printViaThermalTransport(
        InvoicePrintRequest(
          shopProfile = shop,
          committedInvoice = record.committedInvoice,
          preview = record.preview,
          customer = record.customer,
          tenders = record.tenders,
          paperFormat = InvoicePaperFormat.Thermal58,
        ),
        fakeTransport,
      )
    assertTrue(printRes.printed)
    assertEquals("Epson TM-T82 BT", printService.getLastPrinterName())

    val escBytes = captured.toByteArray()
    // Starts with ESC @ (0x1B 0x40) and ends with GS V 66 0 (0x1D 0x56 0x42 0x00)
    assertEquals(0x1B.toByte(), escBytes[0])
    assertEquals(0x40.toByte(), escBytes[1])
    assertEquals(0x1D.toByte(), escBytes[escBytes.size - 4])
    assertEquals(0x56.toByte(), escBytes[escBytes.size - 3])
    assertEquals(0x42.toByte(), escBytes[escBytes.size - 2])
    assertEquals(0x00.toByte(), escBytes[escBytes.size - 1])
    val escAscii = escBytes.toString(Charsets.US_ASCII)
    assertTrue(escAscii.contains("INV/26-27/000001"))
    assertTrue(escAscii.contains("Rs.224.00"))

    // Verify ESC/POS GS v 0 raster encoder (384 dots = 48 bytes/row x 10 rows)
    val mono = ByteArray(48 * 10) { 0x55 }
    val raster = EscPosInvoiceEncoder.encodeRasterImage(EscPosInvoiceEncoder.WIDTH_DOTS_58MM, 10, mono)
    assertEquals(0x1D.toByte(), raster[2])
    assertEquals(0x76.toByte(), raster[3])
    assertEquals(0x30.toByte(), raster[4])
    assertEquals(48.toByte(), raster[6]) // xL = 48
    assertEquals(10.toByte(), raster[8]) // yL = 10
  }

  @Test
  fun subscriptionServiceEnforcesSha256RegistryOfflineGraceClockRollbackAndLinks() = runTest {
    val activationCode = "ORVA-2026-PRO-9988"
    val hash = DefaultSubscriptionService.sha256Hex(activationCode)
    val csv =
      """
      username,activation_code_sha256,plan,start_date,expiry_date,status
      arogya_kol,$hash,Annual,2026-01-01,2026-07-05,ACTIVE
      """.trimIndent()

    val subService =
      DefaultSubscriptionService(
        settings = appSettingsRepo,
        clock = clock,
        registryCsvFetcher = { csv },
      )

    // 1. Save credentials & verify online against CSV registry
    subService.saveCredentials("arogya_kol", activationCode, "https://licenses.rindleworks.example/licenses.csv")
    val verified = subService.refreshFromRegistry()
    assertTrue(verified.isActive)
    assertTrue(verified.allowNewBilling)
    assertFalse(verified.isInGracePeriod)
    assertEquals("Annual", verified.plan)

    // 2. Advance 5 days offline -> inside 14-day grace period
    clock.utcNow = clock.utcNow.plus(5, ChronoUnit.DAYS)
    val grace5 = subService.evaluateLocalStatus()
    assertTrue(grace5.isActive)
    assertTrue(grace5.allowNewBilling)
    assertTrue(grace5.isInGracePeriod)
    assertEquals(9, grace5.graceDaysRemaining)

    // 3. Advance to 2026-06-30 (20 days offline > 14-day grace, even though expiry is 2026-07-05)
    clock.utcNow = clock.utcNow.plus(15, ChronoUnit.DAYS)
    val graceExpired = subService.evaluateLocalStatus()
    assertEquals("ACTIVE", graceExpired.status)
    assertFalse(graceExpired.allowNewBilling)

    // 4. Refresh online on 2026-06-30 -> active again AND within 7-day renewal reminder window (5 days left)
    val refreshed = subService.refreshFromRegistry()
    assertTrue(refreshed.isActive)
    assertTrue(refreshed.allowNewBilling)
    assertTrue(refreshed.isRenewalReminderDue)
    assertEquals(5, refreshed.daysUntilExpiry)

    // 5. Roll device clock backward by 48 hours -> ClockMismatch blocks billing
    clock.utcNow = clock.utcNow.minus(48, ChronoUnit.HOURS)
    val rolledBack = subService.evaluateLocalStatus()
    assertEquals("ClockMismatch", rolledBack.status)
    assertFalse(rolledBack.allowNewBilling)

    // 6. UPI payment URI & WhatsApp click-to-chat URL formatting
    val upi = subService.buildUpiPaymentUri("rindleworks@upi", "Rindle Works", "999.00", "ORVA Renewal")
    assertEquals(
      "upi://pay?pa=rindleworks%40upi&pn=Rindle%20Works&am=999.00&cu=INR&tn=ORVA%20Renewal",
      upi,
    )
    assertEquals("upi://pay?pa=rindleworks%40upi&cu=INR", subService.buildUpiPaymentUri("rindleworks@upi", "", "", ""))
    assertEquals("", subService.buildUpiPaymentUri("   ", "Rindle Works", "999.00", "Note"))
    val wa = subService.buildWhatsAppClickToChatUrl("+91 98300-12345", "Need license renewal")
    assertEquals("https://wa.me/919830012345?text=Need%20license%20renewal", wa)
  }

  @Test
  fun subscriptionServiceSupportsOneTimeLicensesPostExpiryGraceAndFlexibleCsvDates() = runTest {
    val oneTimeCode = "ORVA-LIFETIME-01"
    val annualCode = "ORVA-ANNUAL-02"
    val csv =
      """
      licence_id,activation_hash,subscription_plan,start,expiry,status
      lifetime_shop,${DefaultSubscriptionService.sha256Hex(oneTimeCode)},One-Time,01-01-2026,,ACTIVE
      grace_shop,${DefaultSubscriptionService.sha256Hex(annualCode)},Annual,01-01-2026,05-07-2026,ACTIVE
      """.trimIndent()

    val subService =
      DefaultSubscriptionService(
        settings = appSettingsRepo,
        clock = clock,
        registryCsvFetcher = { csv },
      )

    // 1. One-Time license stays permanently active with no 14-day offline timeout
    subService.saveCredentials("lifetime_shop", oneTimeCode, "https://licenses.rindleworks.example/licenses.csv")
    val oneTime = subService.refreshFromRegistry()
    assertTrue(oneTime.isActive)
    assertTrue(oneTime.allowNewBilling)
    assertFalse(oneTime.isInGracePeriod)

    clock.utcNow = clock.utcNow.plus(60, ChronoUnit.DAYS)
    val oneTimeOffline60 = subService.evaluateLocalStatus()
    assertTrue(oneTimeOffline60.isActive)
    assertTrue(oneTimeOffline60.allowNewBilling)
    assertFalse(oneTimeOffline60.isInGracePeriod)

    // 2. Post-expiry 14-day grace period with dd-MM-yyyy CSV date format (expiry = 2026-07-05)
    clock.utcNow = Instant.parse("2026-07-04T06:00:00Z")
    subService.saveCredentials("grace_shop", annualCode, "")
    val beforeExpiry = subService.refreshFromRegistry()
    assertTrue(beforeExpiry.isActive)
    assertEquals(1, beforeExpiry.daysUntilExpiry)
    assertTrue(beforeExpiry.isRenewalReminderDue)

    // Day +5 after expiry (2026-07-10) -> inside 14-day post-expiry grace (9 days left, billing still allowed)
    clock.utcNow = Instant.parse("2026-07-10T06:00:00Z")
    val postExpiryGrace = subService.evaluateLocalStatus()
    assertFalse(postExpiryGrace.isActive)
    assertTrue(postExpiryGrace.isInGracePeriod)
    assertEquals(9, postExpiryGrace.graceDaysRemaining)
    assertTrue(postExpiryGrace.allowNewBilling)

    // Day +15 after expiry (2026-07-20) -> grace exhausted, billing blocked
    clock.utcNow = Instant.parse("2026-07-20T06:00:00Z")
    val postExpiryBlocked = subService.evaluateLocalStatus()
    assertFalse(postExpiryBlocked.isActive)
    assertFalse(postExpiryBlocked.isInGracePeriod)
    assertFalse(postExpiryBlocked.allowNewBilling)

    // 3. Backend billing gate blocks finalizeInvoice when subscription grace is exhausted,
    //    while 12-hour refreshIfStaleOrNeeded fetches only when >= 12 hours stale
    var fetchCount = 0
    val trackedSubService =
      DefaultSubscriptionService(
        settings = appSettingsRepo,
        clock = clock,
        registryCsvFetcher = {
          fetchCount++
          csv
        },
      )
    val gatedBilling =
      DefaultBillingService(
        transactionRunner = tx,
        clock = clock,
        subscriptionService = trackedSubService,
      )
    val blockedBill =
      gatedBilling.finalizeInvoice(
        InvoiceDraft(
          items = listOf(InvoiceItemDraft("any-med", 1000L)),
          tenders = listOf(PaymentTenderDraft(InvoicePaymentMethod.Cash, 1000L)),
        )
      )
    assertFalse(blockedBill.succeeded)
    assertTrue(blockedBill.issues.any { it.code == "SUBSCRIPTION_BILLING_PAUSED" })

    // Verify 12h refresh threshold: refresh now -> count=1; 6h later -> skipped (count=1); 13h later -> fetched (count=2)
    trackedSubService.refreshIfStaleOrNeeded()
    assertEquals(1, fetchCount)
    clock.utcNow = clock.utcNow.plus(6, ChronoUnit.HOURS)
    trackedSubService.refreshIfStaleOrNeeded()
    assertEquals(1, fetchCount)
    clock.utcNow = clock.utcNow.plus(7, ChronoUnit.HOURS)
    trackedSubService.refreshIfStaleOrNeeded()
    assertEquals(2, fetchCount)
  }
}
