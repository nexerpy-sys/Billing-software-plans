package com.rindleworks.orva.ui.about.gesture

import kotlin.math.abs
import kotlin.math.hypot

/**
 * Axis-locks an initial touch movement after platform touch slop is crossed.
 * A horizontal work-rail swipe must never be mistaken for page scrolling.
 */
internal enum class AboutGestureAxis {
  UNDECIDED,
  HORIZONTAL,
  VERTICAL,
}

internal fun classifyAboutGestureAxis(
  deltaX: Float,
  deltaY: Float,
  touchSlopPx: Float,
): AboutGestureAxis {
  val distance = hypot(deltaX.toDouble(), deltaY.toDouble()).toFloat()
  if (distance <= touchSlopPx.coerceAtLeast(0f)) return AboutGestureAxis.UNDECIDED

  val horizontal = abs(deltaX)
  val vertical = abs(deltaY)
  val dominanceMarginPx = touchSlopPx.coerceAtLeast(0f) * 0.5f

  return when {
    vertical - horizontal > dominanceMarginPx -> AboutGestureAxis.VERTICAL
    horizontal - vertical > dominanceMarginPx -> AboutGestureAxis.HORIZONTAL
    else -> AboutGestureAxis.UNDECIDED
  }
}
