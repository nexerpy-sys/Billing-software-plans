package com.rindleworks.orva.service.records

import com.rindleworks.orva.data.local.OrvaTransactionRunner
import com.rindleworks.orva.data.local.SqlLikeEscaper
import com.rindleworks.orva.data.local.entity.AuditLogEntity
import com.rindleworks.orva.data.local.entity.ExpenseRecordEntity
import com.rindleworks.orva.domain.billing.BatchAllocationPreview
import com.rindleworks.orva.domain.billing.InvoiceCustomerDraft
import com.rindleworks.orva.domain.billing.InvoiceLinePreview
import com.rindleworks.orva.domain.billing.InvoicePaymentMethod
import com.rindleworks.orva.domain.billing.InvoicePreviewResult
import com.rindleworks.orva.domain.billing.InvoiceResult
import com.rindleworks.orva.domain.billing.PaymentTenderDraft
import com.rindleworks.orva.domain.common.OrvaDateTimeFormatters
import com.rindleworks.orva.domain.common.OrvaFormatters
import com.rindleworks.orva.domain.engine.BillingClock
import com.rindleworks.orva.domain.engine.BillingInstant
import com.rindleworks.orva.domain.engine.CheckedMath
import com.rindleworks.orva.domain.engine.InventoryAlertCalculator
import com.rindleworks.orva.domain.engine.InvoiceCalculator
import com.rindleworks.orva.domain.inventory.PurchaseDocumentType
import com.rindleworks.orva.domain.records.ExpenseInput
import com.rindleworks.orva.domain.records.ExpenseRow
import com.rindleworks.orva.domain.records.ExportFormat
import com.rindleworks.orva.domain.records.GstSummaryRow
import com.rindleworks.orva.domain.records.HistoricalInvoiceRecord
import com.rindleworks.orva.domain.records.InvoiceStatusFilter
import com.rindleworks.orva.domain.records.PurchaseRegisterRow
import com.rindleworks.orva.domain.records.RegisterDateFilter
import com.rindleworks.orva.domain.records.ReportType
import com.rindleworks.orva.domain.records.ReportingService
import com.rindleworks.orva.domain.records.SalesRegisterRow
import com.rindleworks.orva.domain.records.SalesReturnRegisterRow
import com.rindleworks.orva.domain.records.StockValuationRow
import com.rindleworks.orva.service.export.CsvExportHelper
import com.rindleworks.orva.service.export.PdfExportHelper
import com.rindleworks.orva.service.export.SpreadsheetExportHelper
import com.rindleworks.orva.service.export.XlsxCell
import java.io.OutputStream
import java.math.BigDecimal
import java.math.RoundingMode
import java.time.LocalDate
import java.time.ZoneOffset
import java.util.Locale
import java.util.UUID

/**
 * Production reporting, expense ledger, historical invoice reprint, and multi-format export service.
 */
class DefaultReportingService(
  private val transactionRunner: OrvaTransactionRunner,
  private val clock: BillingClock,
) : ReportingService {

  override suspend fun getSalesRegister(
    filter: RegisterDateFilter,
    statusFilter: InvoiceStatusFilter,
    search: String?,
  ): List<SalesRegisterRow> =
    transactionRunner.runRead { db ->
      val (fromUtc, toUtcExclusive) = toUtcBounds(filter)
      val statusDb = if (statusFilter == InvoiceStatusFilter.All) null else statusFilter.dbValue
      val pattern = toLikePattern(search)
      db.invoiceDao()
        .querySalesRegister(fromUtc, toUtcExclusive, statusDb, pattern)
        .map { r ->
          SalesRegisterRow(
            invoiceId = r.invoiceId,
            invoiceNumber = r.invoiceNumber,
            issuedAtUtc = r.issuedAtUtc,
            issuedDateText = OrvaDateTimeFormatters.formatUtcToLocalDisplay(r.issuedAtUtc),
            customerName = r.customerName?.ifBlank { null } ?: "Walk-in Customer",
            customerGstin = r.customerGstin.orEmpty(),
            taxableValuePaise = r.taxableValuePaise,
            cgstPaise = r.cgstPaise,
            sgstPaise = r.sgstPaise,
            igstPaise = r.igstPaise,
            roundOffPaise = r.roundOffPaise,
            grandTotalPaise = r.grandTotalPaise,
            paidTotalPaise = r.paidTotalPaise,
            status = r.status,
            cancellationReason = r.cancellationReason.orEmpty(),
          )
        }
    }

  override suspend fun getPurchaseRegister(
    filter: RegisterDateFilter,
    supplierSearch: String?,
  ): List<PurchaseRegisterRow> =
    transactionRunner.runRead { db ->
      val (fromUtc, toUtcExclusive) = toUtcBounds(filter)
      val pattern = toLikePattern(supplierSearch)
      db.purchaseDao()
        .queryPurchaseRegister(fromUtc, toUtcExclusive, pattern)
        .map { p ->
          val documented =
            p.documentType == PurchaseDocumentType.TaxInvoice.dbValue ||
              p.documentType == PurchaseDocumentType.CashCreditMemo.dbValue
          PurchaseRegisterRow(
            purchaseId = p.purchaseId,
            receivedAtUtc = p.receivedAtUtc,
            receivedDateText = OrvaDateTimeFormatters.formatUtcToLocalDisplay(p.receivedAtUtc),
            supplierName = p.supplierNameText?.ifBlank { null } ?: "Unspecified Supplier",
            documentType = p.documentType,
            documentReference = p.documentReference.orEmpty(),
            totalPaise = p.totalPaise,
            isDocumentedForReview = documented,
          )
        }
    }

  override suspend fun getGstSummary(filter: RegisterDateFilter): List<GstSummaryRow> =
    transactionRunner.runRead { db ->
      val (fromUtc, toUtcExclusive) = toUtcBounds(filter)
      val lines = db.invoiceDao().queryGstSummaryLines(fromUtc, toUtcExclusive)

      data class MutableGstAgg(
        val hsnCode: String,
        val gstRateBasisPoints: Int,
        var taxableValuePaise: Long = 0L,
        var cgstPaise: Long = 0L,
        var sgstPaise: Long = 0L,
        var igstPaise: Long = 0L,
        var totalValuePaise: Long = 0L,
      )

      val groups = LinkedHashMap<String, MutableGstAgg>()
      for (line in lines) {
        val hsn = line.hsnCode?.ifBlank { null } ?: "UNSPECIFIED"
        val origQty = line.quantityMilli
        val returnedQty = line.returnedQtyMilli.coerceAtLeast(0L)
        val netQty = (origQty - returnedQty).coerceAtLeast(0L)
        if (netQty <= 0L) continue

        var taxable = line.taxableValuePaise
        var cgst = line.cgstPaise
        var sgst = line.sgstPaise
        var igst = line.igstPaise
        var total = line.lineTotalPaise

        if (returnedQty > 0L && origQty > 0L) {
          taxable = scaleProportionalPaise(taxable, netQty, origQty)
          cgst = scaleProportionalPaise(cgst, netQty, origQty)
          sgst = scaleProportionalPaise(sgst, netQty, origQty)
          igst = scaleProportionalPaise(igst, netQty, origQty)
          total =
            CheckedMath.addExact(
              CheckedMath.addExact(taxable, cgst),
              CheckedMath.addExact(sgst, igst),
            )
        }

        val key = "$hsn|${line.gstRateBasisPoints}"
        val agg = groups.getOrPut(key) { MutableGstAgg(hsn, line.gstRateBasisPoints) }
        agg.taxableValuePaise = CheckedMath.addExact(agg.taxableValuePaise, taxable)
        agg.cgstPaise = CheckedMath.addExact(agg.cgstPaise, cgst)
        agg.sgstPaise = CheckedMath.addExact(agg.sgstPaise, sgst)
        agg.igstPaise = CheckedMath.addExact(agg.igstPaise, igst)
        agg.totalValuePaise = CheckedMath.addExact(agg.totalValuePaise, total)
      }

      groups.values.map { a ->
        GstSummaryRow(
          hsnCode = a.hsnCode,
          gstRateBasisPoints = a.gstRateBasisPoints,
          taxableValuePaise = a.taxableValuePaise,
          cgstPaise = a.cgstPaise,
          sgstPaise = a.sgstPaise,
          igstPaise = a.igstPaise,
          totalValuePaise = a.totalValuePaise,
        )
      }
    }

  private fun scaleProportionalPaise(
    amountPaise: Long,
    netQtyMilli: Long,
    origQtyMilli: Long,
  ): Long {
    if (amountPaise == 0L || netQtyMilli <= 0L || origQtyMilli <= 0L) return 0L
    return BigDecimal.valueOf(amountPaise)
      .multiply(BigDecimal.valueOf(netQtyMilli))
      .divide(BigDecimal.valueOf(origQtyMilli), 0, RoundingMode.HALF_UP)
      .longValueExact()
  }

  override suspend fun getStockValuation(): List<StockValuationRow> =
    transactionRunner.runRead { db ->
      val localDate = BillingInstant.capture(clock).localBusinessDate
      val activeMedicines = db.medicineDao().getActiveMedicines()
      val batchesByMed = db.stockBatchDao().getAll().groupBy { it.medicineId }

      activeMedicines.map { med ->
        var usableQty = 0L
        var purchaseVal = 0L
        var mrpVal = 0L
        for (b in batchesByMed[med.medicineId].orEmpty()) {
          if (
            InventoryAlertCalculator.isBatchUsableForSale(
              batchStatus = b.batchStatus,
              expiryYyyyMm = b.expiryYyyyMm,
              quantityMilli = b.quantityMilli,
              localBusinessDate = localDate,
            )
          ) {
            usableQty = CheckedMath.addExact(usableQty, b.quantityMilli)
            purchaseVal =
              CheckedMath.addExact(
                purchaseVal,
                InvoiceCalculator.calculateGrossPaise(b.quantityMilli, b.latestPurchasePricePaise),
              )
            mrpVal =
              CheckedMath.addExact(
                mrpVal,
                InvoiceCalculator.calculateGrossPaise(b.quantityMilli, b.mrpPaise),
              )
          }
        }
        val lowStock =
          InventoryAlertCalculator.isLowStock(
            isMedicineActive = true,
            usableQuantityMilli = usableQty,
            thresholdMilli = med.lowStockThresholdMilli,
          )
        StockValuationRow(
          medicineId = med.medicineId,
          medicineName = med.displayName,
          stockUnitName = med.stockUnitName,
          usableQuantityMilli = usableQty,
          lowStockThresholdMilli = med.lowStockThresholdMilli,
          isLowStock = lowStock,
          purchaseCostValuePaise = purchaseVal,
          mrpValuePaise = mrpVal,
        )
      }
    }

  override suspend fun getSalesReturnsRegister(
    filter: RegisterDateFilter,
    search: String?,
  ): List<SalesReturnRegisterRow> =
    transactionRunner.runRead { db ->
      val (fromUtc, toUtcExclusive) = toUtcBounds(filter)
      val pattern = toLikePattern(search)
      db.salesReturnDao()
        .querySalesReturnsRegister(fromUtc, toUtcExclusive, pattern)
        .map { r ->
          SalesReturnRegisterRow(
            returnId = r.returnId,
            returnNumber = r.returnNumber,
            invoiceNumber = r.invoiceNumber,
            returnedAtUtc = r.returnedAtUtc,
            returnedDateText = OrvaDateTimeFormatters.formatUtcToLocalDisplay(r.returnedAtUtc),
            reason = r.reason,
            refundMethod = r.refundMethod.orEmpty(),
            refundAmountPaise = r.refundAmountPaise,
            status = r.status,
          )
        }
    }

  override suspend fun getExpenses(filter: RegisterDateFilter): List<ExpenseRow> =
    transactionRunner.runRead { db ->
      val (fromUtc, toUtcExclusive) = toUtcBounds(filter)
      db.ledgerDao()
        .queryExpenses(fromUtc, toUtcExclusive)
        .map { e ->
          ExpenseRow(
            expenseId = e.expenseId,
            expenseDateUtc = e.expenseDateUtc,
            expenseDateText = OrvaDateTimeFormatters.formatUtcToLocalDisplay(e.expenseDateUtc),
            category = e.category,
            description = e.description.orEmpty(),
            amountPaise = e.amountPaise,
            paymentMethod = e.paymentMethod.orEmpty(),
            documentReference = e.documentReference.orEmpty(),
          )
        }
    }

  override suspend fun addExpense(input: ExpenseInput): Result<Unit> = runCatching {
    val cleanCategory = input.category.trim()
    require(cleanCategory.isNotEmpty()) { "Expense category is required." }
    require(input.amountPaise > 0L) { "Expense amount must be greater than zero." }

    val now = BillingInstant.capture(clock)
    val expenseId = UUID.randomUUID().toString()

    transactionRunner.runWriteTransaction { db ->
      db.ledgerDao()
        .insertExpense(
          ExpenseRecordEntity(
            expenseId = expenseId,
            expenseDateUtc = now.utcIsoText,
            category = cleanCategory,
            description = input.description?.trim()?.ifEmpty { null },
            amountPaise = input.amountPaise,
            paymentMethod = input.paymentMethod?.dbValue,
            documentReference = input.documentReference?.trim()?.ifEmpty { null },
            createdAtUtc = now.utcIsoText,
          )
        )
      db.ledgerDao()
        .insertAuditLog(
          AuditLogEntity(
            auditId = UUID.randomUUID().toString(),
            actionType = "EXPENSE_RECORDED",
            entityType = "expense_record",
            entityId = expenseId,
            summary =
              "Recorded expense '$cleanCategory' for ₹${OrvaFormatters.formatRupees(input.amountPaise)}",
            beforeJson = null,
            afterJson = null,
            createdAtUtc = now.utcIsoText,
            createdLocalText = now.localLogText,
          )
        )
    }
  }

  override suspend fun getInvoiceForReprint(invoiceId: String): HistoricalInvoiceRecord? =
    transactionRunner.runRead { db ->
      val inv = db.invoiceDao().getInvoiceById(invoiceId) ?: return@runRead null
      val lines = db.invoiceDao().getLinesForInvoice(invoiceId)
      val payments = db.invoiceDao().getPaymentsForInvoice(invoiceId)

      val groupedLines =
        lines
          .groupBy { it.lineGroupId }
          .values
          .map { group ->
            val first = group.first()
            InvoiceLinePreview(
              medicineId = first.medicineId,
              medicineName = first.medicineNameSnapshot,
              quantityMilli = group.fold(0L) { acc, l -> CheckedMath.addExact(acc, l.quantityMilli) },
              stockUnitName = first.unitNameSnapshot,
              batchAllocations =
                group.map { l ->
                  BatchAllocationPreview(
                    batchNumber = l.batchNumberSnapshot,
                    expiryYyyyMm = l.expiryYyyyMmSnapshot,
                    quantityMilli = l.quantityMilli,
                    unitPricePaise = l.unitPricePaise,
                    subtotalPaise =
                      InvoiceCalculator.calculateGrossPaise(l.quantityMilli, l.unitPricePaise),
                    taxableValuePaise = l.taxableValuePaise,
                    cgstPaise = l.cgstPaise,
                    sgstPaise = l.sgstPaise,
                    igstPaise = l.igstPaise,
                    lineTotalPaise = l.lineTotalPaise,
                  )
                },
              subtotalPaise =
                group.fold(0L) { acc, l ->
                  CheckedMath.addExact(
                    acc,
                    InvoiceCalculator.calculateGrossPaise(l.quantityMilli, l.unitPricePaise),
                  )
                },
              taxableValuePaise =
                group.fold(0L) { acc, l -> CheckedMath.addExact(acc, l.taxableValuePaise) },
              cgstPaise = group.fold(0L) { acc, l -> CheckedMath.addExact(acc, l.cgstPaise) },
              sgstPaise = group.fold(0L) { acc, l -> CheckedMath.addExact(acc, l.sgstPaise) },
              igstPaise = group.fold(0L) { acc, l -> CheckedMath.addExact(acc, l.igstPaise) },
              lineTotalPaise =
                group.fold(0L) { acc, l -> CheckedMath.addExact(acc, l.lineTotalPaise) },
            )
          }

      val tenders =
        payments.mapNotNull { p ->
          val method = InvoicePaymentMethod.fromDbValue(p.method) ?: return@mapNotNull null
          PaymentTenderDraft(method, p.amountPaise, p.referenceText)
        }
      val tenderTotal = tenders.fold(0L) { acc, t -> CheckedMath.addExact(acc, t.amountPaise) }

      HistoricalInvoiceRecord(
        committedInvoice =
          InvoiceResult(
            succeeded = true,
            invoiceId = inv.invoiceId,
            invoiceNumber = inv.invoiceNumber,
            issuedAtUtc = inv.issuedAtUtc,
            issuedLocalOffsetMinutes = inv.issuedLocalOffsetMinutes,
            grandTotalPaise = inv.grandTotalPaise,
          ),
        preview =
          InvoicePreviewResult(
            isDraftValid = true,
            canFinalize = true,
            lines = groupedLines,
            subtotalPaise = inv.subtotalPaise,
            discountPaise = inv.discountPaise,
            taxableValuePaise = inv.taxableValuePaise,
            cgstPaise = inv.cgstPaise,
            sgstPaise = inv.sgstPaise,
            igstPaise = inv.igstPaise,
            roundOffPaise = inv.roundOffPaise,
            grandTotalPaise = inv.grandTotalPaise,
            tenderTotalPaise = tenderTotal,
            amountRemainingPaise = CheckedMath.subtractExact(inv.grandTotalPaise, tenderTotal),
            isFullyPaid = tenderTotal == inv.grandTotalPaise,
          ),
        customer =
          InvoiceCustomerDraft(
            name = inv.customerName,
            phone = inv.customerPhone,
            address = inv.customerAddress,
            gstin = inv.customerGstin,
          ),
        tenders = tenders,
      )
    }

  override suspend fun exportReport(
    reportType: ReportType,
    format: ExportFormat,
    output: OutputStream,
    filter: RegisterDateFilter,
    statusFilter: InvoiceStatusFilter,
    search: String?,
    subtitle: String?,
  ): Result<Unit> = runCatching {
    val table = buildReportTable(reportType, filter, statusFilter, search)
    when (format) {
      ExportFormat.Csv -> CsvExportHelper.writeCsv(output, table.headers, table.textRows)
      ExportFormat.Xlsx ->
        SpreadsheetExportHelper.writeXlsx(output, table.title, table.headers, table.xlsxRows)
      ExportFormat.Pdf ->
        PdfExportHelper.writeTabularReportPdf(
          output = output,
          title = table.title,
          subtitle = subtitle,
          headers = table.headers,
          rows = table.textRows,
          landscape = true,
        )
    }
  }

  private suspend fun buildReportTable(
    reportType: ReportType,
    filter: RegisterDateFilter,
    statusFilter: InvoiceStatusFilter,
    search: String?,
  ): ReportTable =
    when (reportType) {
      ReportType.SalesRegister -> {
        val data = getSalesRegister(filter, statusFilter, search)
        val headers =
          listOf(
            "Invoice No",
            "Date",
            "Customer",
            "GSTIN",
            "Taxable (Rs)",
            "CGST (Rs)",
            "SGST (Rs)",
            "IGST (Rs)",
            "Round-Off (Rs)",
            "Grand Total (Rs)",
            "Status",
          )
        val textRows =
          data.map { r ->
            listOf(
              r.invoiceNumber,
              r.issuedDateText,
              r.customerName,
              r.customerGstin,
              plainRupees(r.taxableValuePaise),
              plainRupees(r.cgstPaise),
              plainRupees(r.sgstPaise),
              plainRupees(r.igstPaise),
              plainRupees(r.roundOffPaise),
              plainRupees(r.grandTotalPaise),
              r.status,
            )
          }
        val xlsxRows =
          data.map { r ->
            listOf(
              XlsxCell.Text(r.invoiceNumber),
              XlsxCell.Text(r.issuedDateText),
              XlsxCell.Text(r.customerName),
              XlsxCell.Text(r.customerGstin),
              XlsxCell.Number(plainRupees(r.taxableValuePaise)),
              XlsxCell.Number(plainRupees(r.cgstPaise)),
              XlsxCell.Number(plainRupees(r.sgstPaise)),
              XlsxCell.Number(plainRupees(r.igstPaise)),
              XlsxCell.Number(plainRupees(r.roundOffPaise)),
              XlsxCell.Number(plainRupees(r.grandTotalPaise)),
              XlsxCell.Text(r.status),
            )
          }
        ReportTable("Sales Register", headers, textRows, xlsxRows)
      }
      ReportType.PurchaseRegister -> {
        val data = getPurchaseRegister(filter, search)
        val headers = listOf("Date", "Supplier", "Document Type", "Reference", "Total (Rs)", "Documented")
        val textRows =
          data.map { p ->
            listOf(
              p.receivedDateText,
              p.supplierName,
              p.documentType,
              p.documentReference,
              plainRupees(p.totalPaise),
              if (p.isDocumentedForReview) "Yes" else "No",
            )
          }
        val xlsxRows =
          data.map { p ->
            listOf(
              XlsxCell.Text(p.receivedDateText),
              XlsxCell.Text(p.supplierName),
              XlsxCell.Text(p.documentType),
              XlsxCell.Text(p.documentReference),
              XlsxCell.Number(plainRupees(p.totalPaise)),
              XlsxCell.Text(if (p.isDocumentedForReview) "Yes" else "No"),
            )
          }
        ReportTable("Purchase Register", headers, textRows, xlsxRows)
      }
      ReportType.GstSummary -> {
        val data = getGstSummary(filter)
        val headers =
          listOf("HSN", "GST Rate", "Taxable (Rs)", "CGST (Rs)", "SGST (Rs)", "IGST (Rs)", "Total (Rs)")
        val textRows =
          data.map { g ->
            listOf(
              g.hsnCode,
              OrvaFormatters.formatGstPercent(g.gstRateBasisPoints),
              plainRupees(g.taxableValuePaise),
              plainRupees(g.cgstPaise),
              plainRupees(g.sgstPaise),
              plainRupees(g.igstPaise),
              plainRupees(g.totalValuePaise),
            )
          }
        val xlsxRows =
          data.map { g ->
            listOf(
              XlsxCell.Text(g.hsnCode),
              XlsxCell.Text(OrvaFormatters.formatGstPercent(g.gstRateBasisPoints)),
              XlsxCell.Number(plainRupees(g.taxableValuePaise)),
              XlsxCell.Number(plainRupees(g.cgstPaise)),
              XlsxCell.Number(plainRupees(g.sgstPaise)),
              XlsxCell.Number(plainRupees(g.igstPaise)),
              XlsxCell.Number(plainRupees(g.totalValuePaise)),
            )
          }
        ReportTable("GST Summary", headers, textRows, xlsxRows)
      }
      ReportType.StockValuation -> {
        val data = getStockValuation()
        val headers =
          listOf("Medicine", "Unit", "Usable Qty", "Low Stock", "Purchase Value (Rs)", "MRP Value (Rs)")
        val textRows =
          data.map { s ->
            listOf(
              s.medicineName,
              s.stockUnitName,
              OrvaFormatters.formatQuantity(s.usableQuantityMilli),
              if (s.isLowStock) "Yes" else "No",
              plainRupees(s.purchaseCostValuePaise),
              plainRupees(s.mrpValuePaise),
            )
          }
        val xlsxRows =
          data.map { s ->
            listOf(
              XlsxCell.Text(s.medicineName),
              XlsxCell.Text(s.stockUnitName),
              XlsxCell.Number(OrvaFormatters.formatQuantity(s.usableQuantityMilli)),
              XlsxCell.Text(if (s.isLowStock) "Yes" else "No"),
              XlsxCell.Number(plainRupees(s.purchaseCostValuePaise)),
              XlsxCell.Number(plainRupees(s.mrpValuePaise)),
            )
          }
        ReportTable("Stock Valuation", headers, textRows, xlsxRows)
      }
      ReportType.SalesReturnsRegister -> {
        val data = getSalesReturnsRegister(filter, search)
        val headers =
          listOf("Return No", "Invoice No", "Date", "Reason", "Refund Method", "Refund (Rs)", "Status")
        val textRows =
          data.map { r ->
            listOf(
              r.returnNumber,
              r.invoiceNumber,
              r.returnedDateText,
              r.reason,
              r.refundMethod,
              plainRupees(r.refundAmountPaise),
              r.status,
            )
          }
        val xlsxRows =
          data.map { r ->
            listOf(
              XlsxCell.Text(r.returnNumber),
              XlsxCell.Text(r.invoiceNumber),
              XlsxCell.Text(r.returnedDateText),
              XlsxCell.Text(r.reason),
              XlsxCell.Text(r.refundMethod),
              XlsxCell.Number(plainRupees(r.refundAmountPaise)),
              XlsxCell.Text(r.status),
            )
          }
        ReportTable("Sales Returns Register", headers, textRows, xlsxRows)
      }
      ReportType.Expenses -> {
        val data = getExpenses(filter)
        val headers = listOf("Date", "Category", "Description", "Method", "Reference", "Amount (Rs)")
        val textRows =
          data.map { e ->
            listOf(
              e.expenseDateText,
              e.category,
              e.description,
              e.paymentMethod,
              e.documentReference,
              plainRupees(e.amountPaise),
            )
          }
        val xlsxRows =
          data.map { e ->
            listOf(
              XlsxCell.Text(e.expenseDateText),
              XlsxCell.Text(e.category),
              XlsxCell.Text(e.description),
              XlsxCell.Text(e.paymentMethod),
              XlsxCell.Text(e.documentReference),
              XlsxCell.Number(plainRupees(e.amountPaise)),
            )
          }
        ReportTable("Expenses Register", headers, textRows, xlsxRows)
      }
    }

  private fun toUtcBounds(filter: RegisterDateFilter): Pair<String?, String?> {
    val offset = ZoneOffset.ofTotalSeconds(BillingInstant.capture(clock).localOffsetMinutes * 60)
    val fromUtc =
      filter.fromLocalDateIso?.trim()?.takeIf { it.isNotEmpty() }?.let { iso ->
        val date = LocalDate.parse(iso)
        OrvaDateTimeFormatters.formatUtcRoundTrip(date.atStartOfDay().toInstant(offset))
      }
    val toUtcExclusive =
      filter.toLocalDateIso?.trim()?.takeIf { it.isNotEmpty() }?.let { iso ->
        val nextDay = LocalDate.parse(iso).plusDays(1)
        OrvaDateTimeFormatters.formatUtcRoundTrip(nextDay.atStartOfDay().toInstant(offset))
      }
    return fromUtc to toUtcExclusive
  }

  private fun toLikePattern(raw: String?): String = SqlLikeEscaper.containsPattern(raw)

  private fun plainRupees(paise: Long): String =
    BigDecimal.valueOf(paise).divide(BigDecimal.valueOf(100L), 2, RoundingMode.UNNECESSARY).toPlainString()

  private data class ReportTable(
    val title: String,
    val headers: List<String>,
    val textRows: List<List<String>>,
    val xlsxRows: List<List<XlsxCell>>,
  )
}
