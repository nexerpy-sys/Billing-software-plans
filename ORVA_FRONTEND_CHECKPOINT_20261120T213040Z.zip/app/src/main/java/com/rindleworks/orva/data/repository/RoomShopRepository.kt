package com.rindleworks.orva.data.repository

import com.rindleworks.orva.data.local.OrvaDatabaseProvider
import com.rindleworks.orva.data.local.OrvaTransactionRunner
import com.rindleworks.orva.data.local.entity.AuditLogEntity
import com.rindleworks.orva.data.local.entity.ShopProfileEntity
import com.rindleworks.orva.domain.common.OrvaDateTimeFormatters
import com.rindleworks.orva.domain.engine.BillingClock
import com.rindleworks.orva.domain.engine.GstinValidator
import com.rindleworks.orva.domain.engine.IndianGstStateCatalog
import com.rindleworks.orva.domain.engine.InvoiceCalculator
import com.rindleworks.orva.domain.settings.IndianGstState
import com.rindleworks.orva.domain.settings.ShopProfile
import com.rindleworks.orva.domain.settings.ShopRepository
import java.util.Locale
import java.util.UUID
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.map
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

@OptIn(ExperimentalCoroutinesApi::class)
class RoomShopRepository(
  private val databaseProvider: OrvaDatabaseProvider,
  private val transactionRunner: OrvaTransactionRunner,
  private val clock: BillingClock,
) : ShopRepository {

  private val json = Json { encodeDefaults = true }

  override fun observeProfile(): Flow<ShopProfile?> =
    databaseProvider.databaseGeneration.flatMapLatest {
      databaseProvider.current().shopProfileDao().observeProfile().map { it?.toDomain() }
    }

  override suspend fun getProfile(): ShopProfile? =
    transactionRunner.runRead { db -> db.shopProfileDao().getProfile()?.toDomain() }

  override suspend fun saveProfileWithAudit(profile: ShopProfile): Result<Unit> = runCatching {
    val cleanName = profile.shopName.trim()
    require(cleanName.isNotEmpty()) { "Shop name is required." }

    val cleanPrefix = profile.invoicePrefix.trim().uppercase(Locale.ROOT)
    require(InvoiceCalculator.isValidInvoicePrefix(cleanPrefix)) {
      "Invoice prefix must be 1 to 3 letters, digits, or '-' to stay within the 16-character GST Rule 46 limit."
    }
    require(profile.financialYearStartMonth in 1..12) {
      "Financial year start month must be between 1 and 12."
    }

    var normalizedGstin: String? = null
    var resolvedStateCode = profile.stateCode?.trim()?.ifEmpty { null }
    var resolvedStateName = profile.stateName?.trim()?.ifEmpty { null }

    val rawGstin = profile.gstin?.trim().orEmpty()
    if (rawGstin.isNotEmpty()) {
      val validation = GstinValidator.validate(rawGstin)
      require(validation.isValid) { validation.errorMessage ?: "Invalid shop GSTIN." }
      normalizedGstin = validation.normalizedGstin
      if (resolvedStateCode == null) {
        resolvedStateCode = validation.stateCode
      } else {
        require(resolvedStateCode == validation.stateCode) {
          "Shop GSTIN state code (${validation.stateCode}) does not match selected state code ($resolvedStateCode)."
        }
      }
    }

    if (resolvedStateCode != null) {
      val state = IndianGstStateCatalog.findByCode(resolvedStateCode)
      require(state != null) { "Invalid Indian GST state code '$resolvedStateCode'." }
      resolvedStateCode = state.code
      if (resolvedStateName == null) {
        resolvedStateName = state.name
      }
    }

    val now = com.rindleworks.orva.domain.engine.BillingInstant.capture(clock)
    val utcIso = now.utcIsoText
    val localText = now.localLogText

    transactionRunner.runWriteTransaction { db ->
      val existing = db.shopProfileDao().getProfile()
      val shopId = existing?.shopId ?: profile.shopId.trim().ifEmpty { UUID.randomUUID().toString() }
      val createdAt = existing?.createdAtUtc ?: utcIso

      val updated =
        ShopProfileEntity(
          profileId = 1,
          shopId = shopId,
          shopName = cleanName,
          legalName = profile.legalName?.trim()?.ifEmpty { null },
          address = profile.address?.trim()?.ifEmpty { null },
          phone = profile.phone?.trim()?.ifEmpty { null },
          email = profile.email?.trim()?.ifEmpty { null },
          stateName = resolvedStateName,
          stateCode = resolvedStateCode,
          gstin = normalizedGstin,
          drugLicenceNumber = profile.drugLicenceNumber?.trim()?.ifEmpty { null },
          invoicePrefix = cleanPrefix,
          financialYearStartMonth = profile.financialYearStartMonth,
          createdAtUtc = createdAt,
          updatedAtUtc = utcIso,
        )
      db.shopProfileDao().upsert(updated)

      db.ledgerDao()
        .insertAuditLog(
          AuditLogEntity(
            auditId = UUID.randomUUID().toString(),
            actionType = "SHOP_PROFILE_SAVED",
            entityType = "shop_profile",
            entityId = shopId,
            summary = "Saved shop profile '$cleanName' (prefix '$cleanPrefix')",
            beforeJson = existing?.let { json.encodeToString(it.toAuditDto()) },
            afterJson = json.encodeToString(updated.toAuditDto()),
            createdAtUtc = utcIso,
            createdLocalText = localText,
          )
        )
    }
  }

  override fun getIndianGstStates(): List<IndianGstState> = IndianGstStateCatalog.allStates

  @Serializable
  private data class ShopProfileAuditDto(
    val shopId: String,
    val shopName: String,
    val stateCode: String?,
    val gstin: String?,
    val invoicePrefix: String,
    val financialYearStartMonth: Int,
  )

  private fun ShopProfileEntity.toAuditDto(): ShopProfileAuditDto =
    ShopProfileAuditDto(
      shopId = shopId,
      shopName = shopName,
      stateCode = stateCode,
      gstin = gstin,
      invoicePrefix = invoicePrefix,
      financialYearStartMonth = financialYearStartMonth,
    )

  private fun ShopProfileEntity.toDomain(): ShopProfile =
    ShopProfile(
      shopId = shopId,
      shopName = shopName,
      legalName = legalName,
      address = address,
      phone = phone,
      email = email,
      stateName = stateName,
      stateCode = stateCode,
      gstin = gstin,
      drugLicenceNumber = drugLicenceNumber,
      invoicePrefix = invoicePrefix,
      financialYearStartMonth = financialYearStartMonth,
    )
}
