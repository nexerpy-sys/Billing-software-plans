package com.rindleworks.orva.domain.engine

import com.rindleworks.orva.domain.settings.IndianGstState

/**
 * Official 2-digit Indian GST State / Union Territory code catalogue (CBIC / GSTN).
 * Exact parity with ORVA WPF IndianGstStateCatalog.cs.
 */
object IndianGstStateCatalog {
  val allStates: List<IndianGstState> =
    listOf(
      IndianGstState("01", "Jammu and Kashmir"),
      IndianGstState("02", "Himachal Pradesh"),
      IndianGstState("03", "Punjab"),
      IndianGstState("04", "Chandigarh"),
      IndianGstState("05", "Uttarakhand"),
      IndianGstState("06", "Haryana"),
      IndianGstState("07", "Delhi"),
      IndianGstState("08", "Rajasthan"),
      IndianGstState("09", "Uttar Pradesh"),
      IndianGstState("10", "Bihar"),
      IndianGstState("11", "Sikkim"),
      IndianGstState("12", "Arunachal Pradesh"),
      IndianGstState("13", "Nagaland"),
      IndianGstState("14", "Manipur"),
      IndianGstState("15", "Mizoram"),
      IndianGstState("16", "Tripura"),
      IndianGstState("17", "Meghalaya"),
      IndianGstState("18", "Assam"),
      IndianGstState("19", "West Bengal"),
      IndianGstState("20", "Jharkhand"),
      IndianGstState("21", "Odisha"),
      IndianGstState("22", "Chhattisgarh"),
      IndianGstState("23", "Madhya Pradesh"),
      IndianGstState("24", "Gujarat"),
      IndianGstState("26", "Dadra and Nagar Haveli and Daman and Diu"),
      IndianGstState("27", "Maharashtra"),
      IndianGstState("29", "Karnataka"),
      IndianGstState("30", "Goa"),
      IndianGstState("31", "Lakshadweep"),
      IndianGstState("32", "Kerala"),
      IndianGstState("33", "Tamil Nadu"),
      IndianGstState("34", "Puducherry"),
      IndianGstState("35", "Andaman and Nicobar Islands"),
      IndianGstState("36", "Telangana"),
      IndianGstState("37", "Andhra Pradesh"),
      IndianGstState("38", "Ladakh"),
    )

  private val byCode: Map<String, IndianGstState> = allStates.associateBy { it.code }
  private val byNameLower: Map<String, IndianGstState> =
    allStates.associateBy { it.name.lowercase() }

  fun isValidShopStateCode(code: String?): Boolean {
    val trimmed = code?.trim().orEmpty()
    return trimmed.isNotEmpty() && byCode.containsKey(trimmed)
  }

  fun isValidGstinStateCode(code: String?): Boolean {
    val trimmed = code?.trim().orEmpty()
    if (trimmed.isEmpty()) return false
    if (byCode.containsKey(trimmed)) return true
    // 97 = Other Territory, 99 = Centre Jurisdiction
    return trimmed == "97" || trimmed == "99"
  }

  fun findByCode(code: String?): IndianGstState? =
    code?.trim()?.takeIf { it.isNotEmpty() }?.let { byCode[it] }

  fun findByName(name: String?): IndianGstState? =
    name?.trim()?.takeIf { it.isNotEmpty() }?.let { byNameLower[it.lowercase()] }
}
