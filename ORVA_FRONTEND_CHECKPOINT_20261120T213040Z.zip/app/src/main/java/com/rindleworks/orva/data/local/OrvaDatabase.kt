package com.rindleworks.orva.data.local

import androidx.room.Database
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.rindleworks.orva.data.local.entity.AppMetaEntity
import com.rindleworks.orva.data.local.entity.AppSettingEntity
import com.rindleworks.orva.data.local.entity.AuditLogEntity
import com.rindleworks.orva.data.local.entity.BarcodeMappingEntity
import com.rindleworks.orva.data.local.entity.ExpenseRecordEntity
import com.rindleworks.orva.data.local.entity.InvoiceEntity
import com.rindleworks.orva.data.local.entity.InvoiceLineEntity
import com.rindleworks.orva.data.local.entity.InvoiceSequenceEntity
import com.rindleworks.orva.data.local.entity.MedicineEntity
import com.rindleworks.orva.data.local.entity.PaymentEntity
import com.rindleworks.orva.data.local.entity.PurchaseLineEntity
import com.rindleworks.orva.data.local.entity.PurchaseReceiptEntity
import com.rindleworks.orva.data.local.entity.SalesReturnEntity
import com.rindleworks.orva.data.local.entity.SalesReturnLineEntity
import com.rindleworks.orva.data.local.entity.ShopProfileEntity
import com.rindleworks.orva.data.local.entity.StockBatchEntity
import com.rindleworks.orva.data.local.entity.StockDiscrepancyEntity
import com.rindleworks.orva.data.local.entity.StockMovementEntity
import com.rindleworks.orva.domain.common.OrvaSchemaInteropContract

@Database(
  entities =
    [
      AppMetaEntity::class,
      ShopProfileEntity::class,
      AppSettingEntity::class,
      MedicineEntity::class,
      BarcodeMappingEntity::class,
      StockBatchEntity::class,
      PurchaseReceiptEntity::class,
      PurchaseLineEntity::class,
      InvoiceSequenceEntity::class,
      InvoiceEntity::class,
      InvoiceLineEntity::class,
      PaymentEntity::class,
      SalesReturnEntity::class,
      SalesReturnLineEntity::class,
      StockMovementEntity::class,
      StockDiscrepancyEntity::class,
      AuditLogEntity::class,
      ExpenseRecordEntity::class,
    ],
  version = OrvaSchemaInteropContract.CURRENT_SCHEMA_VERSION,
  exportSchema = false,
)
abstract class OrvaDatabase : RoomDatabase() {
  abstract fun appMetaDao(): AppMetaDao
  abstract fun shopProfileDao(): ShopProfileDao
  abstract fun appSettingDao(): AppSettingDao
  abstract fun medicineDao(): MedicineDao
  abstract fun barcodeMappingDao(): BarcodeMappingDao
  abstract fun stockBatchDao(): StockBatchDao
  abstract fun invoiceDao(): InvoiceDao
  abstract fun salesReturnDao(): SalesReturnDao
  abstract fun purchaseDao(): PurchaseDao
  abstract fun ledgerDao(): LedgerDao

  internal fun compiledIdentityHash(): String {
    val delegate = createOpenDelegate() as androidx.room.RoomOpenDelegate
    return delegate.identityHash
  }

  companion object {
    const val DEFAULT_DB_NAME: String = "orva.sqlite"

    fun pragmaCallback(): Callback =
      object : Callback() {
        override fun onOpen(db: SupportSQLiteDatabase) {
          super.onOpen(db)
          db.execSQL("PRAGMA foreign_keys = ON;")
          db.query("PRAGMA busy_timeout = 5000;").use { it.moveToFirst() }
          db.query("PRAGMA journal_mode = WAL;").use { it.moveToFirst() }
          db.execSQL("PRAGMA synchronous = FULL;")
        }
      }
  }
}
