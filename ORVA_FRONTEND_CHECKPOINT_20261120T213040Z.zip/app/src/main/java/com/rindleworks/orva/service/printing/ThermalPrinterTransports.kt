package com.rindleworks.orva.service.printing

import android.annotation.SuppressLint
import android.bluetooth.BluetoothDevice
import android.hardware.usb.UsbConstants
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbEndpoint
import android.hardware.usb.UsbInterface
import android.hardware.usb.UsbManager
import com.rindleworks.orva.domain.billing.ThermalPrinterTransport
import java.util.UUID
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Standard Bluetooth Classic Serial Port Profile (SPP / RFCOMM) transport for 58mm/80mm
 * thermal receipt printers. Caller is responsible for ensuring BLUETOOTH_CONNECT permission
 * on Android 12+ before passing a paired [BluetoothDevice].
 */
class BluetoothSppThermalTransport(
  private val device: BluetoothDevice,
  override val displayName: String,
  private val ioDispatcher: CoroutineDispatcher = Dispatchers.IO,
) : ThermalPrinterTransport {

  companion object {
    val SPP_UUID: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
  }

  @SuppressLint("MissingPermission")
  override suspend fun write(bytes: ByteArray): Result<Unit> =
    withContext(ioDispatcher) {
      runCatching {
        val socket = device.createRfcommSocketToServiceRecord(SPP_UUID)
        socket.use { s ->
          s.connect()
          val out = s.outputStream
          out.write(bytes)
          out.flush()
        }
      }
    }
}

/**
 * Android USB-OTG Bulk-Out transport for USB ESC/POS thermal receipt printers.
 * Caller is responsible for obtaining USB permission via [UsbManager.requestPermission].
 */
class UsbOtgThermalTransport(
  private val usbManager: UsbManager,
  private val device: UsbDevice,
  override val displayName: String = device.productName ?: "USB Thermal Printer",
  private val ioDispatcher: CoroutineDispatcher = Dispatchers.IO,
  private val timeoutMs: Int = 5_000,
) : ThermalPrinterTransport {

  override suspend fun write(bytes: ByteArray): Result<Unit> =
    withContext(ioDispatcher) {
      runCatching {
        var targetInterface: UsbInterface? = null
        var bulkOutEndpoint: UsbEndpoint? = null

        for (i in 0 until device.interfaceCount) {
          val iface = device.getInterface(i)
          for (e in 0 until iface.endpointCount) {
            val ep = iface.getEndpoint(e)
            if (ep.type == UsbConstants.USB_ENDPOINT_XFER_BULK &&
              ep.direction == UsbConstants.USB_DIR_OUT
            ) {
              targetInterface = iface
              bulkOutEndpoint = ep
              break
            }
          }
          if (bulkOutEndpoint != null) break
        }

        val iface =
          targetInterface ?: throw IllegalStateException("No USB printer interface found on device.")
        val endpoint =
          bulkOutEndpoint ?: throw IllegalStateException("No USB bulk-out endpoint found on device.")

        val conn =
          usbManager.openDevice(device)
            ?: throw IllegalStateException("Unable to open USB device connection (permission required).")
        try {
          check(conn.claimInterface(iface, true)) { "Failed to claim USB printer interface." }
          try {
            val sent = conn.bulkTransfer(endpoint, bytes, bytes.size, timeoutMs)
            check(sent == bytes.size) {
              "Incomplete USB write to thermal printer: sent $sent of ${bytes.size} bytes."
            }
          } finally {
            conn.releaseInterface(iface)
          }
        } finally {
          conn.close()
        }
      }
    }
}
