package com.rindleworks.orva.data.local.entity

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName = "app_meta")
data class AppMetaEntity(
  @PrimaryKey @ColumnInfo(name = "meta_key") val metaKey: String,
  @ColumnInfo(name = "meta_value") val metaValue: String,
)

@Entity(tableName = "shop_profile")
data class ShopProfileEntity(
  @PrimaryKey @ColumnInfo(name = "profile_id") val profileId: Int = 1,
  @ColumnInfo(name = "shop_id") val shopId: String,
  @ColumnInfo(name = "shop_name") val shopName: String,
  @ColumnInfo(name = "legal_name") val legalName: String? = null,
  @ColumnInfo(name = "address") val address: String? = null,
  @ColumnInfo(name = "phone") val phone: String? = null,
  @ColumnInfo(name = "email") val email: String? = null,
  @ColumnInfo(name = "state_name") val stateName: String? = null,
  @ColumnInfo(name = "state_code") val stateCode: String? = null,
  @ColumnInfo(name = "gstin") val gstin: String? = null,
  @ColumnInfo(name = "drug_licence_number") val drugLicenceNumber: String? = null,
  @ColumnInfo(name = "invoice_prefix", defaultValue = "'INV'") val invoicePrefix: String = "INV",
  @ColumnInfo(name = "financial_year_start_month", defaultValue = "4")
  val financialYearStartMonth: Int = 4,
  @ColumnInfo(name = "created_at_utc") val createdAtUtc: String,
  @ColumnInfo(name = "updated_at_utc") val updatedAtUtc: String,
)

@Entity(tableName = "app_setting")
data class AppSettingEntity(
  @PrimaryKey @ColumnInfo(name = "setting_key") val settingKey: String,
  @ColumnInfo(name = "setting_value") val settingValue: String,
  @ColumnInfo(name = "updated_at_utc") val updatedAtUtc: String,
)

@Entity(
  tableName = "medicine",
  indices = [Index(name = "ix_medicine_name", value = ["normalized_name"])],
)
data class MedicineEntity(
  @PrimaryKey @ColumnInfo(name = "medicine_id") val medicineId: String,
  @ColumnInfo(name = "display_name") val displayName: String,
  @ColumnInfo(name = "normalized_name") val normalizedName: String,
  @ColumnInfo(name = "generic_name") val genericName: String? = null,
  @ColumnInfo(name = "brand_name") val brandName: String? = null,
  @ColumnInfo(name = "strength") val strength: String? = null,
  @ColumnInfo(name = "dosage_form") val dosageForm: String? = null,
  @ColumnInfo(name = "stock_unit_name", defaultValue = "'unit'") val stockUnitName: String = "unit",
  @ColumnInfo(name = "hsn_code") val hsnCode: String? = null,
  @ColumnInfo(name = "gst_rate_basis_points", defaultValue = "0") val gstRateBasisPoints: Int = 0,
  @ColumnInfo(name = "gst_rate_configured", defaultValue = "0") val gstRateConfigured: Int = 0,
  @ColumnInfo(name = "low_stock_threshold_milli", defaultValue = "0")
  val lowStockThresholdMilli: Long = 0L,
  @ColumnInfo(name = "is_active", defaultValue = "1") val isActive: Int = 1,
  @ColumnInfo(name = "created_at_utc") val createdAtUtc: String,
  @ColumnInfo(name = "updated_at_utc") val updatedAtUtc: String,
)

@Entity(
  tableName = "barcode_mapping",
  foreignKeys =
    [
      ForeignKey(
        entity = MedicineEntity::class,
        parentColumns = ["medicine_id"],
        childColumns = ["medicine_id"],
      )
    ],
)
data class BarcodeMappingEntity(
  @PrimaryKey @ColumnInfo(name = "barcode") val barcode: String,
  @ColumnInfo(name = "medicine_id") val medicineId: String,
  @ColumnInfo(name = "created_at_utc") val createdAtUtc: String,
)

@Entity(
  tableName = "stock_batch",
  foreignKeys =
    [
      ForeignKey(
        entity = MedicineEntity::class,
        parentColumns = ["medicine_id"],
        childColumns = ["medicine_id"],
      )
    ],
  indices = [Index(name = "ix_batch_medicine_expiry", value = ["medicine_id", "expiry_yyyymm"])],
)
data class StockBatchEntity(
  @PrimaryKey @ColumnInfo(name = "batch_id") val batchId: String,
  @ColumnInfo(name = "medicine_id") val medicineId: String,
  @ColumnInfo(name = "batch_number") val batchNumber: String,
  @ColumnInfo(name = "expiry_yyyymm") val expiryYyyyMm: Int,
  @ColumnInfo(name = "stock_unit_name") val stockUnitName: String,
  @ColumnInfo(name = "mrp_paise") val mrpPaise: Long,
  @ColumnInfo(name = "latest_purchase_price_paise") val latestPurchasePricePaise: Long,
  @ColumnInfo(name = "quantity_milli", defaultValue = "0") val quantityMilli: Long = 0L,
  @ColumnInfo(name = "batch_status", defaultValue = "'ACTIVE'") val batchStatus: String = "ACTIVE",
  @ColumnInfo(name = "created_at_utc") val createdAtUtc: String,
  @ColumnInfo(name = "updated_at_utc") val updatedAtUtc: String,
)
