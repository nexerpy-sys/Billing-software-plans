package com.rindleworks.orva.domain.engine

import com.rindleworks.orva.domain.inventory.ExpiryAlertLevel
import java.time.LocalDate
import java.time.YearMonth
import java.time.temporal.ChronoUnit

/**
 * Authoritative month-end expiry date and low-stock alert evaluator.
 * Correctly handles leap-year February and exact 90/60/30-day boundaries.
 * Exact parity with ORVA WPF InventoryAlertCalculator.cs.
 */
object InventoryAlertCalculator {
  fun getMonthEndExpiryDate(expiryYyyyMm: Int): LocalDate {
    val year = expiryYyyyMm / 100
    val month = expiryYyyyMm % 100
    require(year in 2000..2199 && month in 1..12) {
      "Expiry must be a valid YYYYMM value between 200001 and 219912."
    }
    return YearMonth.of(year, month).atEndOfMonth()
  }

  fun classifyExpiry(
    batchStatus: String?,
    expiryYyyyMm: Int,
    localBusinessDate: LocalDate,
  ): ExpiryAlertLevel {
    if (batchStatus.equals("EXPIRED", ignoreCase = true)) {
      return ExpiryAlertLevel.Expired
    }
    val year = expiryYyyyMm / 100
    val month = expiryYyyyMm % 100
    if (year !in 2000..2199 || month !in 1..12) {
      return ExpiryAlertLevel.Expired
    }
    val expiryDate = getMonthEndExpiryDate(expiryYyyyMm)
    if (expiryDate.isBefore(localBusinessDate)) {
      return ExpiryAlertLevel.Expired
    }
    val daysRemaining = ChronoUnit.DAYS.between(localBusinessDate, expiryDate)
    return when {
      daysRemaining <= 30L -> ExpiryAlertLevel.UrgentWarning30Days
      daysRemaining <= 60L -> ExpiryAlertLevel.Warning60Days
      daysRemaining <= 90L -> ExpiryAlertLevel.EarlyWarning90Days
      else -> ExpiryAlertLevel.None
    }
  }

  fun isBatchUsableForSale(
    batchStatus: String?,
    expiryYyyyMm: Int,
    quantityMilli: Long,
    localBusinessDate: LocalDate,
  ): Boolean {
    if (batchStatus != "ACTIVE") return false
    if (quantityMilli <= 0L) return false
    return !getMonthEndExpiryDate(expiryYyyyMm).isBefore(localBusinessDate)
  }

  fun isLowStock(
    isMedicineActive: Boolean,
    usableQuantityMilli: Long,
    thresholdMilli: Long,
  ): Boolean {
    if (!isMedicineActive) return false
    if (thresholdMilli <= 0L) return false
    return usableQuantityMilli <= thresholdMilli
  }

  fun resolveDisplayStatus(
    batchStatus: String,
    expiryLevel: ExpiryAlertLevel,
    quantityMilli: Long,
    isLowStock: Boolean,
  ): Pair<String, String> =
    when {
      batchStatus.equals("QUARANTINED", ignoreCase = true) -> "Quarantined" to "#FF4B1F"
      batchStatus.equals("BLOCKED", ignoreCase = true) -> "Blocked" to "#C9362B"
      expiryLevel == ExpiryAlertLevel.Expired -> ExpiryAlertLevel.Expired.label to ExpiryAlertLevel.Expired.colourHex
      quantityMilli <= 0L -> "Out of Stock" to "#C9362B"
      expiryLevel == ExpiryAlertLevel.UrgentWarning30Days ->
        ExpiryAlertLevel.UrgentWarning30Days.label to ExpiryAlertLevel.UrgentWarning30Days.colourHex
      expiryLevel == ExpiryAlertLevel.Warning60Days ->
        ExpiryAlertLevel.Warning60Days.label to ExpiryAlertLevel.Warning60Days.colourHex
      expiryLevel == ExpiryAlertLevel.EarlyWarning90Days ->
        ExpiryAlertLevel.EarlyWarning90Days.label to ExpiryAlertLevel.EarlyWarning90Days.colourHex
      isLowStock -> "Low Stock" to "#FF4B1F"
      else -> "Available" to "#16845B"
    }
}
