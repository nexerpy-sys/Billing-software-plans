package com.rindleworks.orva.fake

import com.rindleworks.orva.domain.billing.BatchAllocationPreview
import com.rindleworks.orva.domain.billing.BillingIssue
import com.rindleworks.orva.domain.billing.BillingIssueCodes
import com.rindleworks.orva.domain.billing.BillingIssueSeverity
import com.rindleworks.orva.domain.billing.BillingService
import com.rindleworks.orva.domain.billing.InvoiceDraft
import com.rindleworks.orva.domain.billing.InvoiceLinePreview
import com.rindleworks.orva.domain.billing.InvoicePaperFormat
import com.rindleworks.orva.domain.billing.InvoicePreviewResult
import com.rindleworks.orva.domain.billing.InvoicePrintRequest
import com.rindleworks.orva.domain.billing.InvoicePrintResult
import com.rindleworks.orva.domain.billing.InvoicePrintService
import com.rindleworks.orva.domain.billing.InvoiceResult
import com.rindleworks.orva.domain.billing.MedicineLookupResult
import com.rindleworks.orva.domain.billing.ThermalPrinterTransport
import com.rindleworks.orva.domain.common.OrvaDateTimeFormatters
import com.rindleworks.orva.domain.common.OrvaFormatters
import java.io.OutputStream
import java.math.BigDecimal
import java.math.RoundingMode
import java.time.Instant
import java.util.UUID

/**
 * Minimal in-memory fake [BillingService] for independent Compose frontend development.
 * Not a production billing engine (Stage 1 & Stage 3 will implement authoritative FEFO/GST rules).
 */
class FakeBillingService : BillingService {
  private data class FakeStockItem(
    val lookup: MedicineLookupResult,
    val batchNumber: String,
    val expiryYyyyMm: Int,
    val unitPricePaise: Long,
    val gstRateBasisPoints: Int,
  )

  private val catalog =
    listOf(
      FakeStockItem(
        lookup =
          MedicineLookupResult(
            medicineId = "fake-med-1",
            displayName = "Paracetamol 500mg",
            genericName = "Paracetamol",
            brandName = "Dolo-500",
            strength = "500mg",
            dosageForm = "Tablet",
            stockUnitName = "strip",
            availableQuantityMilli = 24_000L,
            lowStockThresholdMilli = 5_000L,
            isLowStock = false,
            canSell = true,
            availabilityMessage = "24 strip available",
          ),
        batchNumber = "P26A",
        expiryYyyyMm = 202803,
        unitPricePaise = 3_200L,
        gstRateBasisPoints = 1_200,
      ),
      FakeStockItem(
        lookup =
          MedicineLookupResult(
            medicineId = "fake-med-2",
            displayName = "Amoxicillin 250mg",
            genericName = "Amoxicillin",
            brandName = "Mox",
            strength = "250mg",
            dosageForm = "Capsule",
            stockUnitName = "strip",
            availableQuantityMilli = 3_000L,
            lowStockThresholdMilli = 5_000L,
            isLowStock = true,
            canSell = true,
            availabilityMessage = "Low stock: 3 strip available",
          ),
        batchNumber = "AMX09",
        expiryYyyyMm = 202706,
        unitPricePaise = 8_500L,
        gstRateBasisPoints = 1_200,
      ),
      FakeStockItem(
        lookup =
          MedicineLookupResult(
            medicineId = "fake-med-3",
            displayName = "ORS Powder 21.8g",
            genericName = "Oral Rehydration Salts",
            brandName = "Electral",
            strength = "21.8g",
            dosageForm = "Sachet",
            stockUnitName = "sachet",
            availableQuantityMilli = 0L,
            lowStockThresholdMilli = 10_000L,
            isLowStock = false,
            canSell = false,
            availabilityMessage = "Out of stock",
          ),
        batchNumber = "ORS00",
        expiryYyyyMm = 202712,
        unitPricePaise = 2_100L,
        gstRateBasisPoints = 500,
      ),
    )

  private var sequenceCounter: Long = 1L

  override suspend fun searchMedicines(
    query: String,
    maximumResults: Int,
  ): List<MedicineLookupResult> {
    if (maximumResults <= 0) return emptyList()
    val needle = query.trim()
    return catalog
      .map { it.lookup }
      .filter {
        needle.isEmpty() ||
          it.displayName.contains(needle, ignoreCase = true) ||
          (it.genericName?.contains(needle, ignoreCase = true) == true) ||
          (it.brandName?.contains(needle, ignoreCase = true) == true)
      }
      .take(maximumResults)
  }

  override suspend fun previewInvoice(draft: InvoiceDraft): InvoicePreviewResult =
    evaluateDraft(draft, requireExactPayment = false)

  override suspend fun finalizeInvoice(draft: InvoiceDraft): InvoiceResult {
    val preview = evaluateDraft(draft, requireExactPayment = true)
    if (!preview.canFinalize) {
      return InvoiceResult(succeeded = false, issues = preview.issues)
    }
    val nextSeq = sequenceCounter++
    val invoiceNumber = "INV/26-27/${nextSeq.toString().padStart(6, '0')}"
    return InvoiceResult(
      succeeded = true,
      invoiceId = UUID.randomUUID().toString().replace("-", ""),
      invoiceNumber = invoiceNumber,
      issuedAtUtc = OrvaDateTimeFormatters.formatUtcRoundTrip(Instant.now()),
      issuedLocalOffsetMinutes = 330,
      grandTotalPaise = preview.grandTotalPaise,
    )
  }

  private fun evaluateDraft(
    draft: InvoiceDraft,
    requireExactPayment: Boolean,
  ): InvoicePreviewResult {
    val issues = mutableListOf<BillingIssue>()
    if (draft.items.isEmpty()) {
      issues +=
        BillingIssue(
          severity = BillingIssueSeverity.Blocking,
          code = BillingIssueCodes.DRAFT_EMPTY,
          message = "Add at least one medicine to create an invoice.",
        )
    }

    val lines = mutableListOf<InvoiceLinePreview>()
    var subtotalSum = 0L
    var taxableSum = 0L
    var cgstSum = 0L
    var sgstSum = 0L

    for (item in draft.items) {
      if (item.quantityMilli <= 0L) {
        issues +=
          BillingIssue(
            severity = BillingIssueSeverity.Blocking,
            code = BillingIssueCodes.INVALID_QUANTITY,
            message = "Enter a quantity greater than zero.",
            medicineId = item.medicineId,
          )
        continue
      }
      val stock = catalog.firstOrNull { it.lookup.medicineId == item.medicineId }
      if (stock == null) {
        issues +=
          BillingIssue(
            severity = BillingIssueSeverity.Blocking,
            code = BillingIssueCodes.MEDICINE_NOT_FOUND,
            message = "One of the selected medicines could not be found.",
            medicineId = item.medicineId,
          )
        continue
      }
      if (item.quantityMilli > stock.lookup.availableQuantityMilli) {
        issues +=
          BillingIssue(
            severity = BillingIssueSeverity.Blocking,
            code = BillingIssueCodes.INSUFFICIENT_STOCK,
            message =
              "Only ${OrvaFormatters.formatQuantity(stock.lookup.availableQuantityMilli)} ${stock.lookup.stockUnitName} of ${stock.lookup.displayName} available.",
            medicineId = item.medicineId,
          )
        continue
      }

      val gross =
        BigDecimal.valueOf(item.quantityMilli)
          .multiply(BigDecimal.valueOf(stock.unitPricePaise))
          .divide(BigDecimal.valueOf(OrvaFormatters.QUANTITY_SCALE), 0, RoundingMode.HALF_UP)
          .longValueExact()
      val taxable =
        BigDecimal.valueOf(gross)
          .multiply(BigDecimal.valueOf(10_000L))
          .divide(BigDecimal.valueOf(10_000L + stock.gstRateBasisPoints), 0, RoundingMode.HALF_UP)
          .longValueExact()
      val tax = gross - taxable
      val cgst = tax / 2L + (tax % 2L)
      val sgst = tax / 2L

      val batchPreview =
        BatchAllocationPreview(
          batchNumber = stock.batchNumber,
          expiryYyyyMm = stock.expiryYyyyMm,
          quantityMilli = item.quantityMilli,
          unitPricePaise = stock.unitPricePaise,
          subtotalPaise = gross,
          taxableValuePaise = taxable,
          cgstPaise = cgst,
          sgstPaise = sgst,
          igstPaise = 0L,
          lineTotalPaise = gross,
        )
      lines +=
        InvoiceLinePreview(
          medicineId = stock.lookup.medicineId,
          medicineName = stock.lookup.displayName,
          quantityMilli = item.quantityMilli,
          stockUnitName = stock.lookup.stockUnitName,
          batchAllocations = listOf(batchPreview),
          subtotalPaise = gross,
          taxableValuePaise = taxable,
          cgstPaise = cgst,
          sgstPaise = sgst,
          igstPaise = 0L,
          lineTotalPaise = gross,
        )
      subtotalSum += gross
      taxableSum += taxable
      cgstSum += cgst
      sgstSum += sgst
    }

    var tenderTotal = 0L
    for (tender in draft.tenders) {
      if (tender.amountPaise <= 0L) {
        issues +=
          BillingIssue(
            severity = BillingIssueSeverity.Blocking,
            code = BillingIssueCodes.INVALID_PAYMENT_AMOUNT,
            message = "Enter a payment amount greater than zero.",
          )
      } else {
        tenderTotal += tender.amountPaise
      }
    }

    val grandTotal = taxableSum + cgstSum + sgstSum
    val remaining = grandTotal - tenderTotal
    if (lines.isNotEmpty()) {
      if (tenderTotal > grandTotal) {
        issues +=
          BillingIssue(
            severity = BillingIssueSeverity.Blocking,
            code = BillingIssueCodes.PAYMENT_OVERPAID,
            message =
              "Payment exceeds the invoice total by Rs. ${OrvaFormatters.formatRupees(tenderTotal - grandTotal)}.",
          )
      } else if (requireExactPayment && tenderTotal < grandTotal) {
        issues +=
          BillingIssue(
            severity = BillingIssueSeverity.Blocking,
            code = BillingIssueCodes.PAYMENT_SHORT,
            message =
              "Payment is short by Rs. ${OrvaFormatters.formatRupees(grandTotal - tenderTotal)}.",
          )
      }
    }

    val hasBlocking = issues.any { it.severity == BillingIssueSeverity.Blocking }
    val hasAllLines = draft.items.isNotEmpty() && lines.size == draft.items.size
    val isDraftValid = hasAllLines && !hasBlocking
    val isFullyPaid = hasAllLines && remaining == 0L && (grandTotal == 0L || draft.tenders.isNotEmpty())
    return InvoicePreviewResult(
      isDraftValid = isDraftValid,
      canFinalize = isDraftValid && isFullyPaid,
      lines = lines,
      issues = issues,
      subtotalPaise = subtotalSum,
      discountPaise = 0L,
      taxableValuePaise = taxableSum,
      cgstPaise = cgstSum,
      sgstPaise = sgstSum,
      igstPaise = 0L,
      roundOffPaise = 0L,
      grandTotalPaise = grandTotal,
      tenderTotalPaise = tenderTotal,
      amountRemainingPaise = remaining,
      isFullyPaid = isFullyPaid,
    )
  }
}

class FakeInvoicePrintService : InvoicePrintService {
  private var defaultPaperFormat: InvoicePaperFormat = InvoicePaperFormat.Thermal80
  private var lastPrinterName: String = "Demo 80mm Thermal"

  override suspend fun getDefaultPaperFormat(): InvoicePaperFormat = defaultPaperFormat

  override suspend fun setDefaultPaperFormat(format: InvoicePaperFormat) {
    defaultPaperFormat = format
  }

  override suspend fun getLastPrinterName(): String = lastPrinterName

  override suspend fun renderInvoicePdf(request: InvoicePrintRequest, output: OutputStream) {
    val placeholder = "%PDF-1.4\n% ORVA Stage 0 Fake PDF (${request.committedInvoice.invoiceNumber.orEmpty()})\n%%EOF\n"
    output.write(placeholder.toByteArray(Charsets.UTF_8))
    output.flush()
  }

  override suspend fun printViaThermalTransport(
    request: InvoicePrintRequest,
    transport: ThermalPrinterTransport,
  ): InvoicePrintResult {
    lastPrinterName = transport.displayName
    val payload = "ORVA ${request.committedInvoice.invoiceNumber.orEmpty()}\n".toByteArray(Charsets.UTF_8)
    val writeResult = transport.write(payload)
    return if (writeResult.isSuccess) {
      InvoicePrintResult(printed = true, printerName = transport.displayName)
    } else {
      InvoicePrintResult(
        printed = false,
        printerName = transport.displayName,
        errorMessage = writeResult.exceptionOrNull()?.message ?: "Thermal write failed.",
      )
    }
  }
}
