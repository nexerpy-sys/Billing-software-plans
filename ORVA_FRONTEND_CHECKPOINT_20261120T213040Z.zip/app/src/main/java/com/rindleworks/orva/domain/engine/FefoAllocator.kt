package com.rindleworks.orva.domain.engine

import java.util.Locale

data class BillingBatchRecord(
  val batchId: String,
  val medicineId: String,
  val batchNumber: String,
  val expiryYyyyMm: Int,
  val stockUnitName: String,
  val mrpPaise: Long,
  val quantityMilli: Long,
  val batchStatus: String,
)

data class FefoBatchAllocation(
  val batchId: String,
  val batchNumber: String,
  val expiryYyyyMm: Int,
  val quantityMilli: Long,
  val unitPricePaise: Long,
  val stockUnitName: String,
  val previousQuantityMilli: Long,
)

data class FefoAllocationOutcome(
  val succeeded: Boolean,
  val requestedQuantityMilli: Long,
  val availableQuantityMilli: Long,
  val allocations: List<FefoBatchAllocation> = emptyList(),
)

/**
 * Deterministic First-Expired-First-Out (FEFO) batch allocator.
 * Excludes expired, quarantined, blocked, and non-positive batches.
 * Exact parity with ORVA WPF FefoAllocator.cs.
 */
class FefoAllocator {
  fun allocate(
    candidateBatches: List<BillingBatchRecord>?,
    requestedQuantityMilli: Long,
    currentExpiryYearMonth: Int,
  ): FefoAllocationOutcome {
    require(requestedQuantityMilli > 0L) { "Requested quantity must be greater than zero." }

    val eligible =
      candidateBatches
        .orEmpty()
        .filter { isBatchEligible(it, currentExpiryYearMonth) }
        .sortedWith(FEFO_COMPARATOR)

    var totalAvailable = 0L
    for (batch in eligible) {
      totalAvailable = CheckedMath.addExact(totalAvailable, batch.quantityMilli)
    }

    if (totalAvailable < requestedQuantityMilli) {
      return FefoAllocationOutcome(
        succeeded = false,
        requestedQuantityMilli = requestedQuantityMilli,
        availableQuantityMilli = totalAvailable,
      )
    }

    val allocations = mutableListOf<FefoBatchAllocation>()
    var remaining = requestedQuantityMilli
    for (batch in eligible) {
      if (remaining <= 0L) break
      val take = minOf(batch.quantityMilli, remaining)
      if (take <= 0L) continue
      allocations +=
        FefoBatchAllocation(
          batchId = batch.batchId,
          batchNumber = batch.batchNumber,
          expiryYyyyMm = batch.expiryYyyyMm,
          quantityMilli = take,
          unitPricePaise = batch.mrpPaise,
          stockUnitName = batch.stockUnitName,
          previousQuantityMilli = batch.quantityMilli,
        )
      remaining = CheckedMath.subtractExact(remaining, take)
    }

    return FefoAllocationOutcome(
      succeeded = remaining == 0L,
      requestedQuantityMilli = requestedQuantityMilli,
      availableQuantityMilli = totalAvailable,
      allocations = allocations,
    )
  }

  companion object {
    fun isBatchEligible(batch: BillingBatchRecord?, currentExpiryYearMonth: Int): Boolean {
      if (batch == null) return false
      if (batch.batchStatus != "ACTIVE") return false
      if (batch.quantityMilli <= 0L) return false
      if (batch.expiryYyyyMm < currentExpiryYearMonth) return false
      return true
    }

    private val FEFO_COMPARATOR =
      Comparator<BillingBatchRecord> { left, right ->
        val expiryCompare = left.expiryYyyyMm.compareTo(right.expiryYyyyMm)
        if (expiryCompare != 0) return@Comparator expiryCompare

        val leftNum = left.batchNumber.trim().uppercase(Locale.ROOT)
        val rightNum = right.batchNumber.trim().uppercase(Locale.ROOT)
        val numberCompare = leftNum.compareTo(rightNum)
        if (numberCompare != 0) return@Comparator numberCompare

        left.batchId.compareTo(right.batchId)
      }
  }
}
