package com.rindleworks.orva.di

import android.content.Context
import com.rindleworks.orva.BuildConfig
import com.rindleworks.orva.data.local.OrvaDatabase
import com.rindleworks.orva.data.local.OrvaDatabaseProvider
import com.rindleworks.orva.data.local.OrvaStoragePaths
import com.rindleworks.orva.data.local.OrvaTransactionRunner
import com.rindleworks.orva.data.repository.RoomAppSettingsRepository
import com.rindleworks.orva.data.repository.RoomInventoryRepository
import com.rindleworks.orva.data.repository.RoomShopRepository
import com.rindleworks.orva.data.repository.RoomTaxSettingsRepository
import com.rindleworks.orva.domain.billing.BillingService
import com.rindleworks.orva.domain.billing.InvoicePrintService
import com.rindleworks.orva.domain.common.AppVersionInfo
import com.rindleworks.orva.domain.common.OrvaDatabaseSignal
import com.rindleworks.orva.domain.engine.BillingClock
import com.rindleworks.orva.domain.engine.SystemBillingClock
import com.rindleworks.orva.domain.inventory.InventoryRepository
import com.rindleworks.orva.domain.inventory.MedicineCatalogueImportService
import com.rindleworks.orva.domain.inventory.StockAdjustmentService
import com.rindleworks.orva.domain.inventory.StockEntryService
import com.rindleworks.orva.domain.inventory.StockSnapshotService
import com.rindleworks.orva.domain.records.ReportingService
import com.rindleworks.orva.domain.returns.InvoiceCancellationService
import com.rindleworks.orva.domain.returns.SalesReturnService
import com.rindleworks.orva.domain.settings.AppSettingsRepository
import com.rindleworks.orva.domain.settings.BackupRestoreService
import com.rindleworks.orva.domain.settings.ShopRepository
import com.rindleworks.orva.domain.settings.SubscriptionService
import com.rindleworks.orva.domain.settings.TaxSettingsRepository
import com.rindleworks.orva.service.backup.DefaultBackupRestoreService
import com.rindleworks.orva.service.billing.DefaultBillingService
import com.rindleworks.orva.service.inventory.DefaultMedicineCatalogueImportService
import com.rindleworks.orva.service.inventory.DefaultStockAdjustmentService
import com.rindleworks.orva.service.inventory.DefaultStockEntryService
import com.rindleworks.orva.service.printing.DefaultInvoicePrintService
import com.rindleworks.orva.service.records.DefaultReportingService
import com.rindleworks.orva.service.returns.DefaultInvoiceCancellationService
import com.rindleworks.orva.service.returns.DefaultSalesReturnService
import com.rindleworks.orva.service.snapshot.DefaultStockSnapshotService
import com.rindleworks.orva.service.subscription.DefaultSubscriptionService
import com.rindleworks.orva.service.subscription.OrvaLicenseConfig
import com.rindleworks.orva.service.subscription.OrvaLicenseVault
import com.rindleworks.orva.service.subscription.VendorSignatureVerifier
import java.io.File
import kotlinx.coroutines.flow.StateFlow

/**
 * Production manual dependency injection graph for ORVA Android.
 *
 * Exposes the exact same property names and frozen domain interfaces as
 * [com.rindleworks.orva.fake.FakeOrvaServiceRegistry] so the independent Compose frontend
 * can bind to `(applicationContext as OrvaApplication).container` with zero contract changes.
 *
 * Storage split:
 * - Live SQLite database (`orva.sqlite`) + security anchors stay in app-private storage (`filesDir/orva/`).
 * - Portable files (`StockData.json`, `ShopBackup.shopbackup`, `Daily/`, `Safety/`, `Exports/`,
 *   and sealed `license.orvalic`) auto-create and atomically overwrite inside `/storage/emulated/0/ORVA/`
 *   when All Files Access is granted, falling back safely to `filesDir/orva/ORVA/` otherwise.
 */
class OrvaAppContainer(
  context: Context,
  rootDirectory: File? = null,
  val clock: BillingClock = SystemBillingClock(),
  allowMainThreadQueries: Boolean = false,
  customOrvaFolder: File? = null,
  vendorLicensePublicKeySpkiBase64: String? = OrvaLicenseConfig.VENDOR_PUBLIC_KEY_SPKI_BASE64.ifBlank { null },
) : OrvaDatabaseSignal {

  private val appContext = context.applicationContext

  val storagePaths: OrvaStoragePaths =
    OrvaStoragePaths(
      context = appContext,
      customInternalRoot = rootDirectory,
      customOrvaFolder = customOrvaFolder ?: rootDirectory?.let { File(it, OrvaStoragePaths.ORVA_FOLDER_NAME) },
    )

  val databaseFile: File
    get() = storagePaths.databaseFile

  val snapshotsDirectory: File
    get() = storagePaths.activeOrvaFolder()

  val backupsDirectory: File
    get() = storagePaths.activeOrvaFolder()

  val exportsDirectory: File
    get() = storagePaths.exportsDirectory()

  val stagingDirectory: File
    get() = storagePaths.stagingDirectory

  val appVersionInfo: AppVersionInfo =
    AppVersionInfo(
      versionName = BuildConfig.VERSION_NAME,
      versionCode = BuildConfig.VERSION_CODE,
    )

  val databaseProvider: OrvaDatabaseProvider =
    OrvaDatabaseProvider(
      context = appContext,
      databaseFile = databaseFile,
      allowMainThreadQueries = allowMainThreadQueries,
    )

  override val databaseGeneration: StateFlow<Long>
    get() = databaseProvider.databaseGeneration

  val transactionRunner: OrvaTransactionRunner = OrvaTransactionRunner(databaseProvider)

  // Core Repositories
  val shopRepository: ShopRepository =
    RoomShopRepository(databaseProvider, transactionRunner, clock)

  val appSettingsRepository: AppSettingsRepository =
    RoomAppSettingsRepository(databaseProvider, transactionRunner, clock)

  private val snapshotRefresher: suspend () -> Result<Boolean> = {
    defaultStockSnapshotService.refreshSnapshot()
  }

  val taxSettingsRepository: TaxSettingsRepository =
    RoomTaxSettingsRepository(databaseProvider, transactionRunner, clock, snapshotRefresher)

  val inventoryRepository: InventoryRepository =
    RoomInventoryRepository(databaseProvider, transactionRunner, clock, snapshotRefresher)

  // Portable Snapshots & Backup / Restore (auto-creates ORVA/ on first write; mutually wired for safety backups)
  private val defaultStockSnapshotService: DefaultStockSnapshotService by lazy {
    DefaultStockSnapshotService(
      transactionRunner = transactionRunner,
      clock = clock,
      snapshotDirectoryProvider = { storagePaths.activeOrvaFolder() },
      appVersionInfo = appVersionInfo,
      safetyBackupCreator = {
        val res = defaultBackupRestoreService.createSafetyBackup()
        if (res.succeeded) res.backupPathOrUri else null
      },
    )
  }

  private val defaultBackupRestoreService: DefaultBackupRestoreService by lazy {
    DefaultBackupRestoreService(
      databaseProvider = databaseProvider,
      transactionRunner = transactionRunner,
      clock = clock,
      backupsDirectoryProvider = { storagePaths.activeOrvaFolder() },
      stagingParentDirectory = stagingDirectory,
      appVersionInfo = appVersionInfo,
      snapshotRefresher = { defaultStockSnapshotService.refreshSnapshot() },
      portableCopyDirectoryProvider = { storagePaths.activeOrvaFolder() },
    )
  }

  val stockSnapshotService: StockSnapshotService
    get() = defaultStockSnapshotService

  val backupRestoreService: BackupRestoreService
    get() = defaultBackupRestoreService

  val licenseVault: OrvaLicenseVault =
    OrvaLicenseVault(
      licenseFileProvider = { storagePaths.licenseFile() },
      anchorFile = storagePaths.licenseAnchorFile,
      deviceInstallIdProvider = { storagePaths.getOrCreateDeviceInstallId() },
      vendorSignatureVerifier = VendorSignatureVerifier(vendorLicensePublicKeySpkiBase64),
      fallbackLicenseFileProvider = {
        File(storagePaths.internalOrvaFallbackDirectory, OrvaStoragePaths.LICENSE_FILE_NAME)
      },
    )

  private val defaultSubscriptionService: DefaultSubscriptionService =
    DefaultSubscriptionService(
      settings = appSettingsRepository,
      clock = clock,
      licenseVault = licenseVault,
    )

  val subscriptionService: SubscriptionService
    get() = defaultSubscriptionService

  // Transactional Domain Services
  val billingService: BillingService =
    DefaultBillingService(
      transactionRunner = transactionRunner,
      clock = clock,
      snapshotRefresher = snapshotRefresher,
      subscriptionService = subscriptionService,
    )

  val invoicePrintService: InvoicePrintService =
    DefaultInvoicePrintService(appSettingsRepository = appSettingsRepository)

  val stockEntryService: StockEntryService =
    DefaultStockEntryService(
      transactionRunner = transactionRunner,
      clock = clock,
      snapshotRefresher = snapshotRefresher,
    )

  val stockAdjustmentService: StockAdjustmentService =
    DefaultStockAdjustmentService(
      transactionRunner = transactionRunner,
      clock = clock,
      snapshotRefresher = snapshotRefresher,
    )

  val medicineCatalogueImportService: MedicineCatalogueImportService =
    DefaultMedicineCatalogueImportService(
      transactionRunner = transactionRunner,
      clock = clock,
      snapshotRefresher = snapshotRefresher,
    )

  val salesReturnService: SalesReturnService =
    DefaultSalesReturnService(
      transactionRunner = transactionRunner,
      clock = clock,
      snapshotRefresher = snapshotRefresher,
    )

  val invoiceCancellationService: InvoiceCancellationService =
    DefaultInvoiceCancellationService(
      transactionRunner = transactionRunner,
      clock = clock,
      snapshotRefresher = snapshotRefresher,
    )

  val reportingService: ReportingService =
    DefaultReportingService(
      transactionRunner = transactionRunner,
      clock = clock,
    )

  /**
   * Mirrors WPF `App.xaml.cs` non-blocking startup maintenance:
   * 1. Repairs dirty or missing `StockData.json` if shop setup is complete.
   * 2. Runs daily `.shopbackup` (and refreshes rolling portable `ShopBackup.shopbackup`) if due today.
   * 3. Refreshes configured GitHub/HTTPS `licenses.csv` subscription if >= 12 hours stale.
   */
  suspend fun runStartupMaintenance() {
    val hasShop = runCatching { shopRepository.getProfile() != null }.getOrDefault(false)
    if (hasShop) {
      runCatching {
        val needsRefresh =
          !defaultStockSnapshotService.snapshotFile().exists() ||
            transactionRunner.runRead { com.rindleworks.orva.data.repository.StockSnapshotState.isDirty(it) }
        if (needsRefresh) {
          defaultStockSnapshotService.refreshSnapshot()
        }
      }
      runCatching { defaultBackupRestoreService.runDailyBackupIfDue() }
    }
    runCatching { defaultSubscriptionService.refreshIfStaleOrNeeded() }
  }

  /** Cleanly closes the active Room SQLite connection (used in tests and teardown). */
  fun close() {
    databaseProvider.closeCurrent()
  }
}
