package com.rindleworks.orva.ui.about

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas as AndroidCanvas
import android.graphics.Color as AndroidColor
import android.graphics.Paint as AndroidPaint
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import androidx.annotation.DrawableRes
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.Easing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextLayoutResult
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.em
import androidx.compose.ui.unit.sp
import com.rindleworks.orva.R
import com.rindleworks.orva.ui.showcase.OrvaShowcaseFonts
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.pow
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.random.Random
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

// ============================================================================
// 1. PUBLIC CONFIGURATION & SCREEN ENTRY POINT (RINDLE WORKS × ORVA)
// ============================================================================
@Immutable
data class AboutIntroConfig(
  val initialWord: String = "RINDLE",
  val pivotCharIndex: Int = 1, // Index of 'I' in RINDLE (measured glyph acts as '!' stem)
  val finalWord: String = "PORTFOLIO",
  val headerBrand: String = "RINDLE WORKS",
  val subtitlePrimary: String = "Rindle Works",
  val subtitleSecondary: String = "ORVA Studio",
  val ctaLabel: String = "Explore ORVA",
  val navLinks: List<String> = listOf("HOME", "ABOUT", "ORVA", "CONTACT"),
  val activeNavIndex: Int = 1,
  val fontFamily: FontFamily = OrvaShowcaseFonts.SpaceGrotesk,
  @DrawableRes val portraitResId: Int? = R.drawable.editorial_apothecary_shelves,
  val morphStepMs: Long = 85L,
  val showTopHeader: Boolean = false,
)

@Composable
fun AboutUsIntroScreen(
  modifier: Modifier = Modifier,
  config: AboutIntroConfig = AboutIntroConfig(showTopHeader = true),
  onCtaClick: () -> Unit = {},
  onNavClick: (String) -> Unit = {},
  aboutContent: @Composable () -> Unit = { DefaultAboutUsContent() },
) {
  val scrollState = rememberScrollState()
  var replayToken by remember { mutableIntStateOf(0) }

  BoxWithConstraints(
    modifier = modifier.fillMaxSize().background(Color.Black),
  ) {
    val heroHeightDp = maxHeight
    val heroHeightPx = with(LocalDensity.current) { heroHeightDp.toPx() }

    Column(
      modifier = Modifier.fillMaxSize().verticalScroll(scrollState),
    ) {
      AboutIntroHeroSection(
        config = config,
        replayToken = replayToken,
        scrollProgressProvider = {
          if (heroHeightPx <= 0f) 0f
          else (scrollState.value / (heroHeightPx * 0.72f)).coerceIn(0f, 1.35f)
        },
        onCtaClick = onCtaClick,
        onNavClick = onNavClick,
        modifier = Modifier.fillMaxWidth().height(heroHeightDp),
      )
      aboutContent()
    }

    Box(
      modifier =
        Modifier
          .align(Alignment.BottomEnd)
          .padding(16.dp)
          .background(Color(0x99161618), RoundedCornerShape(20.dp))
          .border(0.5.dp, Color(0x33FFFFFF), RoundedCornerShape(20.dp))
          .clickable { replayToken++ }
          .padding(horizontal = 12.dp, vertical = 6.dp),
    ) {
      Text(
        text = "Replay",
        color = Color(0xFFA1A1AA),
        fontSize = 11.sp,
        fontWeight = FontWeight.Medium,
      )
    }
  }
}

// ============================================================================
// 2. CHOREOGRAPHED 7-PHASE HERO COMPOSABLE (ZERO PER-FRAME RECOMPOSITIONS)
// ============================================================================
private val Power2In = CubicBezierEasing(0.55f, 0.085f, 0.68f, 0.53f)
private val Power2Out = CubicBezierEasing(0.25f, 0.46f, 0.45f, 0.94f)
private val Power2InOut = CubicBezierEasing(0.455f, 0.03f, 0.515f, 0.955f)
private val Power3In = CubicBezierEasing(0.55f, 0.055f, 0.675f, 0.19f)
private val HeroExpandEase = CubicBezierEasing(0.22f, 1.0f, 0.36f, 1.0f)

private fun backOutEasing(overshoot: Float = 1.4f): Easing = Easing { t ->
  val s = overshoot
  val inv = t - 1f
  1f + inv * inv * ((s + 1f) * inv + s)
}

private val BackOutLaunch = backOutEasing(1.4f)
private val BackOutSnap = backOutEasing(2.1f)

@Composable
fun AboutIntroHeroSection(
  config: AboutIntroConfig,
  replayToken: Int,
  scrollProgressProvider: () -> Float,
  onCtaClick: () -> Unit,
  onNavClick: (String) -> Unit,
  modifier: Modifier = Modifier,
  reducedMotion: Boolean = false,
  onIntroSettled: () -> Unit = {},
) {
  val context = LocalContext.current
  val density = LocalDensity.current
  val textMeasurer = rememberTextMeasurer()

  BoxWithConstraints(modifier = modifier.background(Color.Black)) {
    val widthPx = with(density) { maxWidth.toPx() }
    val heightPx = with(density) { maxHeight.toPx() }

    val maxHeroScale = 1.32f
    val metallicBrush = remember {
      Brush.verticalGradient(
        0.00f to Color(0xFFFFFFFF),
        0.42f to Color(0xFFF4F4F6),
        1.00f to Color(0xFF7B7E86),
      )
    }

    val baseFontSizeSp =
      remember(widthPx, config.finalWord, config.fontFamily) {
        val probeSp = 100f
        val probeStyle =
          TextStyle(
            fontSize = probeSp.sp,
            fontWeight = FontWeight.Black,
            fontFamily = config.fontFamily,
            letterSpacing = (-0.04).em,
          )
        val probeWidth = textMeasurer.measure(config.finalWord, style = probeStyle).size.width.toFloat()
        val targetFinalWidth = widthPx * 0.90f
        val finalSp = if (probeWidth > 0f) (targetFinalWidth / probeWidth) * probeSp else 52f
        (finalSp / maxHeroScale).coerceIn(24f, 110f)
      }

    val wordTextStyle =
      remember(baseFontSizeSp, config.fontFamily) {
        TextStyle(
          brush = metallicBrush,
          fontSize = baseFontSizeSp.sp,
          fontWeight = FontWeight.Black,
          fontFamily = config.fontFamily,
          letterSpacing = (-0.04).em,
        )
      }

    // Memoized TextLayoutResults: sub-pixel accurate stem-to-glyph handoff, zero draw-time allocations
    val initialWordLayout =
      remember(config.initialWord, wordTextStyle) {
        textMeasurer.measure(config.initialWord, style = wordTextStyle)
      }
    val glyphLayouts =
      remember(config.initialWord, wordTextStyle) {
        config.initialWord.map { ch -> textMeasurer.measure(ch.toString(), style = wordTextStyle) }
      }
    val morphSteps =
      remember(config.initialWord, config.finalWord) {
        buildMorphSteps(config.initialWord, config.finalWord)
      }
    val morphLayouts =
      remember(morphSteps, wordTextStyle) {
        morphSteps.map { step -> textMeasurer.measure(step, style = wordTextStyle) }
      }
    val finalExpandedWidthDp =
      remember(morphLayouts, maxHeroScale, density) {
        with(density) { (morphLayouts.last().size.width * maxHeroScale).toDp() }
      }

    val pivotIndex = config.pivotCharIndex.coerceIn(0, (config.initialWord.length - 1).coerceAtLeast(0))
    val leftIndices = remember(config.initialWord, pivotIndex) { (pivotIndex - 1 downTo 0).toList() }
    val rightIndices =
      remember(config.initialWord, pivotIndex) { (pivotIndex + 1 until config.initialWord.length).toList() }

    // Animatable timeline state
    val dotYNorm = remember(replayToken) { Animatable(-0.56f) }
    val dotScaleX = remember(replayToken) { Animatable(0.92f) }
    val dotScaleY = remember(replayToken) { Animatable(1.12f) }
    val dotAlpha = remember(replayToken) { Animatable(1f) }
    val glowAlpha = remember(replayToken) { Animatable(0.05f) }
    val glowScale = remember(replayToken) { Animatable(1f) }
    val stemOffsetYNorm = remember(replayToken) { Animatable(-0.58f) }
    val stemAlpha = remember(replayToken) { Animatable(0f) }
    val stemScaleY = remember(replayToken) { Animatable(1f) }
    val stemRotation = remember(replayToken) { Animatable(0f) }
    val glyphProgress =
      remember(replayToken, config.initialWord) { List(config.initialWord.length) { Animatable(0f) } }

    var isMorphPhase by remember(replayToken) { mutableStateOf(false) }
    var morphIndex by remember(replayToken) { mutableIntStateOf(0) }
    val wordScale = remember(replayToken) { Animatable(1f) }
    val wordTranslateYNorm = remember(replayToken) { Animatable(0f) }
    val subRowAlpha = remember(replayToken) { Animatable(0f) }
    val subRowOffsetY = remember(replayToken) { Animatable(14f) }
    val navAlpha = remember(replayToken) { Animatable(0f) }

    // Background-sampled FloatArray particle engine (zero GC churn)
    val particleEngine = remember(replayToken) { ParticlePortraitEngine() }
    val starfieldAnim = remember(replayToken) { Animatable(0f) }
    var convergeTriggered by remember(replayToken) { mutableStateOf(false) }
    var particleFrameTick by remember(replayToken) { mutableLongStateOf(0L) }

    LaunchedEffect(replayToken, widthPx, heightPx, config.portraitResId) {
      if (widthPx > 0f && heightPx > 0f) {
        withContext(Dispatchers.Default) {
          val bitmap = loadOrGeneratePortraitBitmap(context, config.portraitResId)
          particleEngine.initializeFromBitmap(
            bitmap = bitmap,
            canvasWidth = widthPx,
            canvasHeight = heightPx,
          )
        }
      }
    }

    LaunchedEffect(replayToken) {
      var lastNanos = 0L
      var elapsedSec = 0f
      while (true) {
        withFrameNanos { now ->
          if (lastNanos != 0L) {
            val dt = ((now - lastNanos) / 1_000_000_000f).coerceIn(0.001f, 0.05f)
            elapsedSec += dt
            if (starfieldAnim.value > 0.005f) {
              particleEngine.step(
                dt = dt,
                elapsedSec = elapsedSec,
                converge = convergeTriggered,
                scrollProgress = scrollProgressProvider(),
              )
              particleFrameTick = now
            }
          }
          lastNanos = now
        }
      }
    }

    // Master 7-Phase Deterministic Choreography Timeline
    LaunchedEffect(replayToken, reducedMotion) {
      if (reducedMotion) {
        isMorphPhase = true
        morphIndex = morphSteps.lastIndex
        wordScale.snapTo(maxHeroScale)
        wordTranslateYNorm.snapTo(0.21f)
        subRowAlpha.snapTo(1f)
        subRowOffsetY.snapTo(0f)
        navAlpha.snapTo(1f)
        starfieldAnim.snapTo(1f)
        convergeTriggered = true
        onIntroSettled()
        return@LaunchedEffect
      }

      // PHASE 1: Ball Drop & Double Squash-and-Stretch Bounce (0.00s – 0.73s)
      dotYNorm.animateTo(0f, tween(220, easing = Power2In))
      coroutineScope {
        launch { dotScaleX.animateTo(1.45f, tween(50, easing = Power2Out)) }
        launch { dotScaleY.animateTo(0.55f, tween(50, easing = Power2Out)) }
        launch { glowAlpha.animateTo(0.24f, tween(70, easing = Power2Out)) }
        launch { glowScale.animateTo(1.22f, tween(70, easing = Power2Out)) }
      }
      coroutineScope {
        launch { dotYNorm.animateTo(-0.14f, tween(170, easing = Power2Out)) }
        launch { dotScaleX.animateTo(0.94f, tween(140, easing = Power2Out)) }
        launch { dotScaleY.animateTo(1.06f, tween(140, easing = Power2Out)) }
        launch { glowAlpha.animateTo(0.06f, tween(170, easing = Power2Out)) }
        launch { glowScale.animateTo(1.0f, tween(170, easing = Power2Out)) }
      }
      dotYNorm.animateTo(0f, tween(150, easing = Power2In))
      coroutineScope {
        launch { dotScaleX.animateTo(1.32f, tween(50, easing = Power2Out)) }
        launch { dotScaleY.animateTo(0.68f, tween(50, easing = Power2Out)) }
        launch { glowAlpha.animateTo(0.18f, tween(60, easing = Power2Out)) }
      }
      coroutineScope {
        launch { dotScaleX.animateTo(1f, tween(80, easing = Power2Out)) }
        launch { dotScaleY.animateTo(1f, tween(80, easing = Power2Out)) }
        launch { glowAlpha.animateTo(0.05f, tween(110, easing = Power2Out)) }
      }

      // PHASE 2: Exclamation Stem Drop (0.73s – 1.07s)
      stemAlpha.snapTo(1f)
      stemOffsetYNorm.animateTo(0f, tween(145, easing = Power3In))
      stemScaleY.animateTo(0.90f, tween(45, easing = Power2Out))
      stemScaleY.animateTo(1.00f, tween(55, easing = Power2Out))
      delay(100)

      // PHASE 3: Pivot-Arm Ejection ('!' -> RINDLE) (1.07s – 2.27s)
      coroutineScope {
        launch { stemRotation.animateTo(-58f, tween(140, easing = Power2InOut)) }
        launch { glowAlpha.animateTo(0.22f, tween(110, easing = Power2Out)) }
      }
      coroutineScope {
        leftIndices.forEachIndexed { order, charIdx ->
          launch {
            delay(order * 65L)
            glyphProgress[charIdx].animateTo(1f, tween(360, easing = LinearEasing))
          }
        }
        launch {
          delay(240)
          stemRotation.animateTo(58f, tween(170, easing = Power2InOut))
          rightIndices.forEachIndexed { order, charIdx ->
            launch {
              delay(order * 65L)
              glyphProgress[charIdx].animateTo(1f, tween(340, easing = LinearEasing))
            }
          }
          delay(260)
          launch { stemRotation.animateTo(0f, tween(180, easing = BackOutSnap)) }
          launch { dotScaleX.animateTo(0f, tween(140, easing = Power2In)) }
          launch { dotScaleY.animateTo(0f, tween(140, easing = Power2In)) }
          launch { dotAlpha.animateTo(0f, tween(140, easing = Power2In)) }
          launch { glowAlpha.animateTo(0.05f, tween(220, easing = Power2Out)) }
        }
      }
      delay(130)

      // PHASE 4: Deterministic Left-to-Right Word Morph (2.40s – 3.12s)
      isMorphPhase = true
      for (i in 1 until morphSteps.size) {
        delay(config.morphStepMs)
        morphIndex = i
      }
      delay(90)

      // PHASE 5: Hero Expansion & Lower-Third Settle (3.20s – 3.85s)
      coroutineScope {
        launch { wordScale.animateTo(maxHeroScale, tween(640, easing = HeroExpandEase)) }
        launch { wordTranslateYNorm.animateTo(0.21f, tween(640, easing = HeroExpandEase)) }
        launch {
          delay(280)
          launch { subRowAlpha.animateTo(1f, tween(420, easing = Power2Out)) }
          launch { subRowOffsetY.animateTo(0f, tween(420, easing = Power2Out)) }
        }
      }

      // PHASE 6: Starfield Fade -> Top Nav -> Particle Portrait Convergence (3.85s – 5.80s)
      coroutineScope {
        launch { starfieldAnim.animateTo(1f, tween(550, easing = Power2Out)) }
        launch {
          delay(480)
          navAlpha.animateTo(1f, tween(450, easing = Power2Out))
        }
        launch {
          delay(620)
          particleEngine.applySwirlImpulse()
          convergeTriggered = true
        }
      }
      onIntroSettled()
    }

    // Z-0 & Z-1: Backdrop Vignette, Impact Glow, & Particle Canvas
    Canvas(modifier = Modifier.fillMaxSize()) {
      val unusedTick = particleFrameTick
      val scrollP = scrollProgressProvider()

      drawRect(
        brush =
          Brush.radialGradient(
            colors = listOf(Color(0xFF1A1A1E), Color(0xFF000000)),
            center = Offset(size.width * 0.5f, size.height * 0.52f),
            radius = size.maxDimension * 0.62f,
          ),
      )

      val gAlpha = glowAlpha.value
      if (gAlpha > 0.005f) {
        val glowCenter = Offset(size.width * 0.5f, size.height * 0.58f)
        drawCircle(
          brush =
            Brush.radialGradient(
              colors = listOf(Color.White.copy(alpha = gAlpha), Color.Transparent),
              center = glowCenter,
              radius = size.minDimension * 0.48f * glowScale.value,
            ),
          radius = size.minDimension * 0.48f * glowScale.value,
          center = glowCenter,
        )
      }

      val fieldOpacity = starfieldAnim.value
      if (fieldOpacity > 0.005f && unusedTick >= 0L) {
        particleEngine.draw(
          scope = this,
          fieldOpacity = fieldOpacity,
          scrollProgress = scrollP,
        )
      }
    }

    // Z-2: Hero Typography Canvas (Phases 1–5)
    Canvas(
      modifier =
        Modifier
          .fillMaxSize()
          .graphicsLayer {
            val scrollP = scrollProgressProvider()
            translationY = -scrollP * size.height * 0.14f
            alpha = (1f - scrollP * 0.9f).coerceIn(0f, 1f)
          },
    ) {
      val centerX = size.width * 0.5f
      val baseCenterY = size.height * 0.50f

      if (!isMorphPhase) {
        val wordLeft = centerX - initialWordLayout.size.width / 2f
        val wordTop = baseCenterY - initialWordLayout.size.height / 2f
        val pivotBox = initialWordLayout.getBoundingBox(pivotIndex)
        val pivotCenterX = wordLeft + (pivotBox.left + pivotBox.right) / 2f
        val baselineY = wordTop + initialWordLayout.firstBaseline
        val fontPx = with(density) { baseFontSizeSp.sp.toPx() }
        val dotRadius = fontPx * 0.125f
        val dotCenterX = pivotCenterX
        val dotRestY = baselineY + dotRadius * 1.45f
        val dotCurrentY = dotRestY + dotYNorm.value * size.height

        if (dotAlpha.value > 0.01f && dotScaleX.value > 0.01f) {
          withTransform({
            scale(
              scaleX = dotScaleX.value,
              scaleY = dotScaleY.value,
              pivot = Offset(dotCenterX, dotCurrentY + dotRadius),
            )
          }) {
            drawCircle(
              color = Color.White.copy(alpha = dotAlpha.value),
              radius = dotRadius,
              center = Offset(dotCenterX, dotCurrentY),
            )
          }
        }

        val stemLength = fontPx * 0.72f
        for (i in config.initialWord.indices) {
          if (i == pivotIndex) continue
          val rawP = glyphProgress[i].value
          if (rawP <= 0.001f) continue
          val isLeft = i < pivotIndex
          val targetBox = initialWordLayout.getBoundingBox(i)
          val targetX = wordLeft + targetBox.left
          val targetY = wordTop

          val launchAngleRad = Math.toRadians(if (isLeft) -54.0 else 54.0)
          val muzzleX = dotCenterX + (sin(launchAngleRad) * stemLength).toFloat() - targetBox.width / 2f
          val muzzleY = dotRestY - (cos(launchAngleRad) * stemLength).toFloat() - initialWordLayout.size.height * 0.55f

          val easeX = BackOutLaunch.transform(rawP)
          val easeY = Power2Out.transform(rawP)
          val arcLift = sin(rawP * PI).toFloat() * fontPx * (0.48f + kotlin.math.abs(i - pivotIndex) * 0.14f)

          val curX = lerp(muzzleX, targetX, easeX)
          val curY = lerp(muzzleY, targetY, easeY) - arcLift
          val curRot = lerp(if (isLeft) -38f else 38f, 0f, easeX)
          val curScale = lerp(0.55f, 1f, easeY)
          val curAlpha = (rawP * 4.5f).coerceIn(0f, 1f)

          val glyphLayout = glyphLayouts[i]
          val glyphCenter = Offset(curX + glyphLayout.size.width / 2f, curY + glyphLayout.size.height / 2f)
          withTransform({
            rotate(curRot, pivot = glyphCenter)
            scale(curScale, curScale, pivot = glyphCenter)
          }) {
            drawText(
              textLayoutResult = glyphLayout,
              topLeft = Offset(curX, curY),
              alpha = curAlpha,
            )
          }
        }

        if (stemAlpha.value > 0.01f) {
          val stemLayout = glyphLayouts[pivotIndex]
          val stemLeft = wordLeft + pivotBox.left
          val stemTop = wordTop + stemOffsetYNorm.value * size.height
          withTransform({
            rotate(degrees = stemRotation.value, pivot = Offset(dotCenterX, dotRestY))
            scale(scaleX = 1f, scaleY = stemScaleY.value, pivot = Offset(dotCenterX, baselineY))
          }) {
            drawText(
              textLayoutResult = stemLayout,
              topLeft = Offset(stemLeft, stemTop),
              alpha = stemAlpha.value,
            )
          }
        }
      } else {
        val currentLayout: TextLayoutResult = morphLayouts[morphIndex]
        val targetCenterY = baseCenterY + wordTranslateYNorm.value * size.height
        val topLeft =
          Offset(
            x = centerX - currentLayout.size.width / 2f,
            y = targetCenterY - currentLayout.size.height / 2f,
          )
        withTransform({
          scale(
            scaleX = wordScale.value,
            scaleY = wordScale.value,
            pivot = Offset(centerX, targetCenterY),
          )
        }) {
          drawText(textLayoutResult = currentLayout, topLeft = topLeft)
        }
      }
    }

    // Z-2b: Sub-Row aligned flush to expanded PORTFOLIO edges
    val subRowTopOffsetDp =
      remember(heightPx, morphLayouts, maxHeroScale, density) {
        val wordCenterY = heightPx * (0.50f + 0.21f)
        val wordHalfHeight = (morphLayouts.last().size.height * maxHeroScale) / 2f
        with(density) { (wordCenterY + wordHalfHeight + 8f).toDp() }
      }

    Row(
      modifier =
        Modifier
          .align(Alignment.TopCenter)
          .padding(top = subRowTopOffsetDp)
          .width(finalExpandedWidthDp)
          .graphicsLayer {
            val scrollP = scrollProgressProvider()
            alpha = (subRowAlpha.value * (1f - scrollP * 1.1f)).coerceIn(0f, 1f)
            translationY = subRowOffsetY.value - scrollP * size.height * 0.4f
          },
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Text(
        text =
          buildAnnotatedString {
            withStyle(SpanStyle(color = Color.White, fontWeight = FontWeight.SemiBold)) {
              append(config.subtitlePrimary)
            }
            append(" ")
            withStyle(SpanStyle(color = Color(0xFF8E8E93), fontWeight = FontWeight.Normal)) {
              append(config.subtitleSecondary)
            }
          },
        fontSize = 13.sp,
        letterSpacing = (-0.01).em,
      )

      Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.clickable(onClick = onCtaClick).padding(vertical = 4.dp),
      ) {
        Box(
          modifier =
            Modifier
              .size(width = 10.dp, height = 16.dp)
              .border(1.dp, Color(0x88FFFFFF), RoundedCornerShape(5.dp)),
          contentAlignment = Alignment.TopCenter,
        ) {
          Box(
            modifier =
              Modifier
                .padding(top = 3.dp)
                .size(width = 2.dp, height = 4.dp)
                .background(Color.White, CircleShape),
          )
        }
        Spacer(modifier = Modifier.width(8.dp))
        Text(
          text = config.ctaLabel,
          color = Color(0xFFA1A1AA),
          fontSize = 12.sp,
          fontWeight = FontWeight.Medium,
        )
      }
    }

    // Z-3: Optional Top Header Bar (shown in standalone mode)
    if (config.showTopHeader) {
      Row(
        modifier =
          Modifier
            .align(Alignment.TopCenter)
            .fillMaxWidth()
            .statusBarsPadding()
            .padding(horizontal = 20.dp, vertical = 18.dp)
            .graphicsLayer { alpha = navAlpha.value },
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Text(
          text = config.headerBrand,
          color = Color.White,
          fontSize = 11.sp,
          fontWeight = FontWeight.Bold,
          letterSpacing = 0.08.em,
        )
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
          config.navLinks.forEachIndexed { index, label ->
            Text(
              text = label,
              color = if (index == config.activeNavIndex) Color.White else Color(0xFF71717A),
              fontSize = 9.sp,
              fontWeight = FontWeight.SemiBold,
              letterSpacing = 0.12.em,
              modifier = Modifier.clickable { onNavClick(label) },
            )
          }
        }
      }
    }
  }
}

// ============================================================================
// 3. DETERMINISTIC WORD MORPH GENERATOR (ZERO RANDOM SCRAMBLE)
// ============================================================================
private fun buildMorphSteps(from: String, to: String): List<String> {
  val steps = mutableListOf(from)
  val buffer = StringBuilder(from)
  val maxLen = maxOf(from.length, to.length)
  for (i in 0 until maxLen) {
    when {
      i < buffer.length && i < to.length -> {
        if (buffer[i] != to[i]) {
          buffer.setCharAt(i, to[i])
          steps.add(buffer.toString())
        }
      }
      i >= buffer.length && i < to.length -> {
        buffer.append(to[i])
        steps.add(buffer.toString())
      }
      i >= to.length && buffer.length > to.length -> {
        buffer.deleteCharAt(buffer.length - 1)
        steps.add(buffer.toString())
      }
    }
  }
  return steps
}

// ============================================================================
// 4. HIGH-FPS LUMINANCE-STIPPLED PARTICLE PORTRAIT ENGINE (PRIMITIVE ARRAYS)
// ============================================================================
private class ParticlePortraitEngine {
  @Volatile private var count: Int = 0
  private var px = FloatArray(0)
  private var py = FloatArray(0)
  private var vx = FloatArray(0)
  private var vy = FloatArray(0)
  private var tx = FloatArray(0)
  private var ty = FloatArray(0)
  private var sx = FloatArray(0)
  private var sy = FloatArray(0)
  private var pSize = FloatArray(0)
  private var baseAlpha = FloatArray(0)
  private var isPortrait = BooleanArray(0)
  private var canvasW = 1f
  private var canvasH = 1f
  private var currentElapsed = 0f

  fun initializeFromBitmap(
    bitmap: Bitmap,
    canvasWidth: Float,
    canvasHeight: Float,
    ambientStars: Int = 550,
  ) {
    canvasW = canvasWidth
    canvasH = canvasHeight
    val targetH = (canvasHeight * 0.72f).roundToInt().coerceIn(220, 520)
    val aspect = bitmap.width.toFloat() / bitmap.height.coerceAtLeast(1)
    val targetW = (targetH * aspect).roundToInt().coerceAtLeast(120)
    val scaled = Bitmap.createScaledBitmap(bitmap, targetW, targetH, true)
    val pixels = IntArray(targetW * targetH)
    scaled.getPixels(pixels, 0, targetW, 0, 0, targetW, targetH)

    val step = if (targetW * targetH > 140_000) 4 else 3
    val offsetX = (canvasWidth - targetW) * 0.5f
    val offsetY = canvasHeight * 0.14f
    val rng = Random(42)
    val tempCountEstimate = (targetW / step) * (targetH / step) + ambientStars

    val _px = FloatArray(tempCountEstimate)
    val _py = FloatArray(tempCountEstimate)
    val _vx = FloatArray(tempCountEstimate)
    val _vy = FloatArray(tempCountEstimate)
    val _tx = FloatArray(tempCountEstimate)
    val _ty = FloatArray(tempCountEstimate)
    val _sx = FloatArray(tempCountEstimate)
    val _sy = FloatArray(tempCountEstimate)
    val _size = FloatArray(tempCountEstimate)
    val _alpha = FloatArray(tempCountEstimate)
    val _portrait = BooleanArray(tempCountEstimate)

    var idx = 0
    for (y in 0 until targetH step step) {
      for (x in 0 until targetW step step) {
        val c = pixels[y * targetW + x]
        val a = (c ushr 24) and 0xFF
        if (a < 110) continue
        val r = (c ushr 16) and 0xFF
        val g = (c ushr 8) and 0xFF
        val b = c and 0xFF
        val lum = (0.299f * r + 0.587f * g + 0.114f * b) / 255f
        if (lum < 0.08f || rng.nextFloat() > lum.pow(1.28f)) continue
        if (idx >= tempCountEstimate - ambientStars) break

        val scatterAngle = rng.nextFloat() * (2.0 * PI).toFloat()
        val scatterDist = 140f + rng.nextFloat() * (canvasWidth * 0.55f)
        _px[idx] = rng.nextFloat() * canvasWidth
        _py[idx] = rng.nextFloat() * canvasHeight
        _tx[idx] = offsetX + x
        _ty[idx] = offsetY + y
        _sx[idx] = cos(scatterAngle) * scatterDist
        _sy[idx] = sin(scatterAngle) * scatterDist - canvasHeight * 0.24f
        _size[idx] = 2.0f + lum * 2.2f
        _alpha[idx] = (0.34f + lum * 0.66f).coerceIn(0f, 1f)
        _portrait[idx] = true
        idx++
      }
    }

    for (s in 0 until ambientStars) {
      if (idx >= tempCountEstimate) break
      val rx = rng.nextFloat() * canvasWidth
      val ry = rng.nextFloat() * canvasHeight
      _px[idx] = rx
      _py[idx] = ry
      _tx[idx] = rx
      _ty[idx] = ry
      _sx[idx] = 0f
      _sy[idx] = -canvasHeight * 0.12f
      _size[idx] = 1.4f + rng.nextFloat() * 1.8f
      _alpha[idx] = 0.16f + rng.nextFloat() * 0.38f
      _portrait[idx] = false
      idx++
    }

    px = _px
    py = _py
    vx = _vx
    vy = _vy
    tx = _tx
    ty = _ty
    sx = _sx
    sy = _sy
    pSize = _size
    baseAlpha = _alpha
    isPortrait = _portrait
    count = idx
    if (scaled != bitmap) scaled.recycle()
  }

  fun applySwirlImpulse() {
    val cx = canvasW * 0.5f
    val cy = canvasH * 0.45f
    val n = count
    for (i in 0 until n) {
      if (!isPortrait[i]) continue
      val dx = cx - px[i]
      val dy = cy - py[i]
      vx[i] += dx * 0.045f - dy * 0.025f
      vy[i] += dy * 0.045f + dx * 0.025f
    }
  }

  fun step(
    dt: Float,
    elapsedSec: Float,
    converge: Boolean,
    scrollProgress: Float,
  ) {
    currentElapsed = elapsedSec
    val n = count
    if (n == 0) return
    val step60 = dt * 60f
    val springK = 0.062f * step60
    val damping = 0.83f.pow(step60)
    val p = scrollProgress.coerceAtLeast(0f)

    for (i in 0 until n) {
      if (isPortrait[i] && converge) {
        val destX = tx[i] + sx[i] * p
        val destY = ty[i] + sy[i] * p
        vx[i] = (vx[i] + (destX - px[i]) * springK) * damping
        vy[i] = (vy[i] + (destY - py[i]) * springK) * damping
        px[i] += vx[i] * step60
        py[i] += vy[i] * step60
      } else if (!isPortrait[i]) {
        py[i] -= 0.08f * step60
        if (py[i] < 0f) py[i] += canvasH
      }
    }
  }

  fun draw(
    scope: androidx.compose.ui.graphics.drawscope.DrawScope,
    fieldOpacity: Float,
    scrollProgress: Float,
  ) {
    val n = count
    if (n == 0) return
    val p = scrollProgress.coerceAtLeast(0f)
    val portraitFade = (1f - p * 1.15f).coerceIn(0f, 1f)
    val applyShimmer = p < 0.05f
    val t = currentElapsed * 2.1f

    for (i in 0 until n) {
      val alpha =
        baseAlpha[i] * fieldOpacity *
          if (isPortrait[i]) portraitFade else (1f - p * 0.4f).coerceIn(0f, 1f)
      if (alpha <= 0.015f) continue
      val jx = if (applyShimmer && isPortrait[i]) sin(t + tx[i] * 0.04f) * 0.7f else 0f
      val jy = if (applyShimmer && isPortrait[i]) cos(t + ty[i] * 0.04f) * 0.7f else 0f
      val s = pSize[i]
      scope.drawRect(
        color = Color.White.copy(alpha = alpha),
        topLeft = Offset(px[i] + jx, py[i] + jy),
        size = Size(s, s),
      )
    }
  }
}

// ============================================================================
// 5. PORTRAIT LOADER + STUDIO-LIT PROCEDURAL FALLBACK BITMAP
// ============================================================================
private fun loadOrGeneratePortraitBitmap(
  context: Context,
  @DrawableRes resId: Int?,
): Bitmap {
  if (resId != null) {
    BitmapFactory.decodeResource(context.resources, resId)?.let { return it }
  }
  return generateProceduralPortraitBitmap()
}

private fun generateProceduralPortraitBitmap(w: Int = 360, h: Int = 440): Bitmap {
  val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
  val c = AndroidCanvas(bmp)
  val paint = AndroidPaint(AndroidPaint.ANTI_ALIAS_FLAG)
  val cx = w * 0.5f

  paint.shader =
    RadialGradient(
      cx,
      h * 0.78f,
      w * 0.52f,
      intArrayOf(AndroidColor.rgb(190, 190, 195), AndroidColor.rgb(55, 55, 60), AndroidColor.TRANSPARENT),
      floatArrayOf(0f, 0.72f, 1f),
      Shader.TileMode.CLAMP,
    )
  c.drawOval(RectF(w * 0.08f, h * 0.56f, w * 0.92f, h * 1.15f), paint)

  paint.shader = null
  paint.color = AndroidColor.rgb(245, 245, 250)
  val collar =
    android.graphics.Path().apply {
      moveTo(cx - w * 0.15f, h * 0.60f)
      lineTo(cx, h * 0.84f)
      lineTo(cx + w * 0.15f, h * 0.60f)
      close()
    }
  c.drawPath(collar, paint)

  paint.color = AndroidColor.rgb(155, 155, 160)
  c.drawRect(cx - w * 0.09f, h * 0.48f, cx + w * 0.09f, h * 0.66f, paint)

  paint.shader =
    RadialGradient(
      cx - w * 0.04f,
      h * 0.34f,
      w * 0.24f,
      intArrayOf(AndroidColor.rgb(255, 255, 255), AndroidColor.rgb(175, 175, 180), AndroidColor.rgb(65, 65, 70)),
      floatArrayOf(0f, 0.62f, 1f),
      Shader.TileMode.CLAMP,
    )
  c.drawOval(RectF(cx - w * 0.19f, h * 0.17f, cx + w * 0.19f, h * 0.54f), paint)
  return bmp
}

@Composable
private fun DefaultAboutUsContent() {
  Column(
    modifier = Modifier.fillMaxWidth().background(Color.Black).padding(horizontal = 24.dp, vertical = 48.dp),
  ) {
    Text(
      text = "ABOUT RINDLE WORKS",
      color = Color(0xFF71717A),
      fontSize = 11.sp,
      fontWeight = FontWeight.SemiBold,
      letterSpacing = 0.2.em,
    )
    Spacer(modifier = Modifier.height(12.dp))
    Text(
      text = "Intro",
      color = Color.White,
      fontSize = 36.sp,
      fontWeight = FontWeight.Bold,
      letterSpacing = (-0.03).em,
    )
  }
}

private fun lerp(start: Float, stop: Float, fraction: Float): Float = start + (stop - start) * fraction
