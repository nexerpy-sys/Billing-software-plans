package com.rindleworks.orva

import android.graphics.Color
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.rindleworks.orva.ui.navigation.OrvaShowcaseApp
import com.rindleworks.orva.ui.theme.OrvaStarterTheme

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge(
      statusBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
      navigationBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
    )
    val container = (application as OrvaApplication).container
    setContent {
      OrvaStarterTheme(darkTheme = true, dynamicColor = false) {
        OrvaShowcaseApp(container = container)
      }
    }
  }
}
