package com.rindleworks.orva.data.repository

import com.rindleworks.orva.data.local.OrvaDatabase
import com.rindleworks.orva.data.local.entity.AppSettingEntity
import com.rindleworks.orva.domain.common.OrvaSettingKeys

/**
 * Atomic generation-tracking helpers for `StockData.json` dirty-state coordination.
 * Must be called inside an active [com.rindleworks.orva.data.local.OrvaTransactionRunner.runWriteTransaction]
 * whenever stock-affecting tables are mutated.
 */
object StockSnapshotState {

  fun upsertSetting(db: OrvaDatabase, key: String, value: String, updatedAtUtc: String) {
    db.appSettingDao().upsert(AppSettingEntity(key, value, updatedAtUtc))
  }

  fun readGeneration(db: OrvaDatabase): Long =
    db.appSettingDao().getValue(OrvaSettingKeys.SNAPSHOT_GENERATION)?.trim()?.toLongOrNull() ?: 0L

  fun isDirty(db: OrvaDatabase): Boolean =
    db.appSettingDao().getValue(OrvaSettingKeys.SNAPSHOT_DIRTY)?.trim() == "1"

  /**
   * Marks the portable stock snapshot dirty and monotonically increments its generation counter
   * within the caller's write transaction.
   */
  fun markDirtyAndIncrementGeneration(db: OrvaDatabase, updatedAtUtc: String): Long {
    val nextGeneration = readGeneration(db) + 1L
    upsertSetting(db, OrvaSettingKeys.SNAPSHOT_DIRTY, "1", updatedAtUtc)
    upsertSetting(db, OrvaSettingKeys.SNAPSHOT_GENERATION, nextGeneration.toString(), updatedAtUtc)
    return nextGeneration
  }

  /**
   * Marks the snapshot clean ONLY if no newer stock mutation incremented the generation counter
   * while `StockData.json` was being serialized to disk.
   *
   * @return `true` if marked clean, `false` if a newer mutation already advanced the generation.
   */
  fun markCleanIfGenerationMatches(
    db: OrvaDatabase,
    expectedGeneration: Long,
    writtenAtUtc: String,
  ): Boolean {
    val currentGeneration = readGeneration(db)
    if (currentGeneration != expectedGeneration) {
      return false
    }
    upsertSetting(db, OrvaSettingKeys.SNAPSHOT_DIRTY, "0", writtenAtUtc)
    upsertSetting(db, OrvaSettingKeys.SNAPSHOT_LAST_WRITTEN_UTC, writtenAtUtc, writtenAtUtc)
    return true
  }
}
