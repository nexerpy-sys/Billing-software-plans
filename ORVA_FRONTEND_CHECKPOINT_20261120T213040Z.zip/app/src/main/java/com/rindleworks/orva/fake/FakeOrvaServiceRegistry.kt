package com.rindleworks.orva.fake

import com.rindleworks.orva.BuildConfig
import com.rindleworks.orva.domain.billing.BillingService
import com.rindleworks.orva.domain.billing.InvoicePrintService
import com.rindleworks.orva.domain.common.AppVersionInfo
import com.rindleworks.orva.domain.common.OrvaDatabaseSignal
import com.rindleworks.orva.domain.inventory.InventoryRepository
import com.rindleworks.orva.domain.inventory.MedicineCatalogueImportService
import com.rindleworks.orva.domain.inventory.StockAdjustmentService
import com.rindleworks.orva.domain.inventory.StockEntryService
import com.rindleworks.orva.domain.inventory.StockSnapshotService
import com.rindleworks.orva.domain.records.ReportingService
import com.rindleworks.orva.domain.returns.InvoiceCancellationService
import com.rindleworks.orva.domain.returns.SalesReturnService
import com.rindleworks.orva.domain.settings.AppSettingsRepository
import com.rindleworks.orva.domain.settings.BackupRestoreService
import com.rindleworks.orva.domain.settings.ShopRepository
import com.rindleworks.orva.domain.settings.SubscriptionService
import com.rindleworks.orva.domain.settings.TaxSettingsRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Coherent in-memory service bundle for Stage 0 frontend development and Compose previews.
 * Replaced by production OrvaAppContainer in Stage 7 without altering UI contract imports.
 */
class FakeOrvaServiceRegistry : OrvaDatabaseSignal {
  private val mutableDatabaseGeneration = MutableStateFlow(0L)
  override val databaseGeneration: StateFlow<Long> = mutableDatabaseGeneration.asStateFlow()

  val appVersionInfo: AppVersionInfo =
    AppVersionInfo(
      versionName = BuildConfig.VERSION_NAME,
      versionCode = BuildConfig.VERSION_CODE,
    )

  private val fakeInventoryRepository = FakeInventoryRepository()
  private val fakeSalesReturnService = FakeSalesReturnService()

  val shopRepository: ShopRepository = FakeShopRepository()
  val taxSettingsRepository: TaxSettingsRepository = FakeTaxSettingsRepository()
  val appSettingsRepository: AppSettingsRepository = FakeAppSettingsRepository()
  val inventoryRepository: InventoryRepository = fakeInventoryRepository
  val billingService: BillingService = FakeBillingService()
  val invoicePrintService: InvoicePrintService = FakeInvoicePrintService()
  val stockEntryService: StockEntryService = FakeStockEntryService(fakeInventoryRepository)
  val stockAdjustmentService: StockAdjustmentService =
    FakeStockAdjustmentService(fakeInventoryRepository)
  val stockSnapshotService: StockSnapshotService = FakeStockSnapshotService()
  val medicineCatalogueImportService: MedicineCatalogueImportService =
    FakeMedicineCatalogueImportService()
  val salesReturnService: SalesReturnService = fakeSalesReturnService
  val invoiceCancellationService: InvoiceCancellationService =
    FakeInvoiceCancellationService(fakeSalesReturnService)
  val reportingService: ReportingService = FakeReportingService()
  val backupRestoreService: BackupRestoreService =
    FakeBackupRestoreService(shopRepository, mutableDatabaseGeneration)
  val subscriptionService: SubscriptionService = FakeSubscriptionService(appSettingsRepository)
}
