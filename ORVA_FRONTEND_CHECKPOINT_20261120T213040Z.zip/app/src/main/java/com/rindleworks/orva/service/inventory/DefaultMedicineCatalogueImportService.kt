package com.rindleworks.orva.service.inventory

import android.util.Xml
import com.rindleworks.orva.data.local.OrvaTransactionRunner
import com.rindleworks.orva.data.local.entity.AuditLogEntity
import com.rindleworks.orva.data.local.entity.BarcodeMappingEntity
import com.rindleworks.orva.data.local.entity.MedicineEntity
import com.rindleworks.orva.data.local.entity.StockBatchEntity
import com.rindleworks.orva.data.local.entity.StockMovementEntity
import com.rindleworks.orva.data.repository.StockSnapshotState
import com.rindleworks.orva.domain.common.OrvaFormatters
import com.rindleworks.orva.domain.common.StockMovementType
import com.rindleworks.orva.domain.engine.BillingClock
import com.rindleworks.orva.domain.engine.BillingInstant
import com.rindleworks.orva.domain.engine.CheckedMath
import com.rindleworks.orva.domain.inventory.BatchStatus
import com.rindleworks.orva.domain.inventory.CatalogueImportPreview
import com.rindleworks.orva.domain.inventory.CatalogueImportResult
import com.rindleworks.orva.domain.inventory.MedicineCatalogueImportService
import java.io.ByteArrayInputStream
import java.io.InputStream
import java.io.OutputStream
import java.math.BigDecimal
import java.math.RoundingMode
import java.util.Locale
import java.util.UUID
import java.util.zip.ZipInputStream
import org.xmlpull.v1.XmlPullParser

/**
 * Bulk Medicine Catalogue & Opening Stock importer supporting CSV and lightweight OOXML XLSX.
 * Preserves exact ORVA WPF MedicineCatalogueImporter.cs headers and validation rules.
 */
class DefaultMedicineCatalogueImportService(
  private val transactionRunner: OrvaTransactionRunner,
  private val clock: BillingClock,
  private val snapshotRefresher: (suspend () -> Result<Boolean>)? = null,
) : MedicineCatalogueImportService {

  companion object {
    val TEMPLATE_HEADERS: List<String> =
      listOf(
        "MedicineName",
        "GenericName",
        "BrandName",
        "Strength",
        "DosageForm",
        "StockUnit",
        "HsnCode",
        "GstRatePercent",
        "LowStockThreshold",
        "Barcode",
        "BatchNumber",
        "ExpiryYyyyMm",
        "OpeningQuantity",
        "PurchasePrice",
        "Mrp",
      )
  }

  override suspend fun writeTemplateCsv(output: OutputStream) {
    val bom = byteArrayOf(0xEF.toByte(), 0xBB.toByte(), 0xBF.toByte())
    output.write(bom)
    val sb = StringBuilder()
    sb.append(TEMPLATE_HEADERS.joinToString(",")).append("\r\n")
    sb.append(
      listOf(
        "Paracetamol 500mg",
        "Paracetamol",
        "Calpol",
        "500mg",
        "Tablet",
        "strip",
        "30049099",
        "12",
        "20",
        "",
        "P101",
        "2028-12",
        "50",
        "18.50",
        "25.00",
      ).joinToString(",")
    ).append("\r\n")
    output.write(sb.toString().toByteArray(Charsets.UTF_8))
    output.flush()
  }

  override suspend fun previewCatalogueImport(
    input: InputStream,
    fileName: String,
  ): CatalogueImportPreview {
    val parsed = parseRows(input, fileName)
    if (parsed.errors.isNotEmpty() || parsed.rows.isEmpty()) {
      val errs =
        if (parsed.errors.isEmpty()) listOf("File '$fileName' contains no data rows.")
        else parsed.errors
      return CatalogueImportPreview(
        isValid = false,
        sourceName = fileName,
        errors = errs,
        warnings = parsed.warnings,
      )
    }

    return transactionRunner.runRead { db ->
      val existingNorms = db.medicineDao().getAll().map { it.normalizedName }.toSet()
      val distinctImported = parsed.rows.map { it.medicineName.lowercase(Locale.ROOT) }.toSet()
      val newCount = distinctImported.count { it !in existingNorms }
      val existingCount = distinctImported.count { it in existingNorms }
      val batchRows = parsed.rows.count { !it.batchNumber.isNullOrBlank() }

      CatalogueImportPreview(
        isValid = true,
        sourceName = fileName,
        newMedicineCount = newCount,
        existingMedicineCount = existingCount,
        openingBatchRowCount = batchRows,
        errors = emptyList(),
        warnings = parsed.warnings,
      )
    }
  }

  override suspend fun executeCatalogueImport(
    input: InputStream,
    fileName: String,
    markProvidedGstRatesAsConfigured: Boolean,
  ): CatalogueImportResult {
    val parsed = parseRows(input, fileName)
    if (parsed.errors.isNotEmpty() || parsed.rows.isEmpty()) {
      return CatalogueImportResult(
        succeeded = false,
        errorMessage = parsed.errors.firstOrNull() ?: "File '$fileName' contains no valid rows.",
      )
    }

    val committed =
      try {
        transactionRunner.runWriteTransaction { db ->
          val now = BillingInstant.capture(clock)
          val utcIso = now.utcIsoText
          val localText = now.localLogText

          var createdMeds = 0
          var updatedMeds = 0
          var batchesTouched = 0
          val seenCreatedIds = HashSet<String>()
          val seenUpdatedIds = HashSet<String>()

          for (row in parsed.rows) {
            val norm = row.medicineName.lowercase(Locale.ROOT)
            val existing = db.medicineDao().getByNormalizedName(norm)
            val med: MedicineEntity

            if (existing == null) {
              val configureGst = markProvidedGstRatesAsConfigured && row.gstRateBasisPoints != null
              med =
                MedicineEntity(
                  medicineId = UUID.randomUUID().toString(),
                  displayName = row.medicineName,
                  normalizedName = norm,
                  genericName = row.genericName,
                  brandName = row.brandName,
                  strength = row.strength,
                  dosageForm = row.dosageForm,
                  stockUnitName = row.stockUnit,
                  hsnCode = row.hsnCode,
                  gstRateBasisPoints = row.gstRateBasisPoints ?: 0,
                  gstRateConfigured = if (configureGst) 1 else 0,
                  lowStockThresholdMilli = row.lowStockThresholdMilli,
                  isActive = 1,
                  createdAtUtc = utcIso,
                  updatedAtUtc = utcIso,
                )
              db.medicineDao().insert(med)
              if (seenCreatedIds.add(med.medicineId)) createdMeds++
            } else {
              val configureGst =
                if (markProvidedGstRatesAsConfigured && row.gstRateBasisPoints != null) 1
                else existing.gstRateConfigured
              med =
                existing.copy(
                  genericName = row.genericName ?: existing.genericName,
                  brandName = row.brandName ?: existing.brandName,
                  strength = row.strength ?: existing.strength,
                  dosageForm = row.dosageForm ?: existing.dosageForm,
                  stockUnitName = row.stockUnit.ifBlank { existing.stockUnitName },
                  hsnCode = row.hsnCode ?: existing.hsnCode,
                  gstRateBasisPoints = row.gstRateBasisPoints ?: existing.gstRateBasisPoints,
                  gstRateConfigured = configureGst,
                  lowStockThresholdMilli =
                    if (row.lowStockThresholdMilli > 0L) row.lowStockThresholdMilli
                    else existing.lowStockThresholdMilli,
                  isActive = 1,
                  updatedAtUtc = utcIso,
                )
              db.medicineDao().update(med)
              if (!seenCreatedIds.contains(med.medicineId) && seenUpdatedIds.add(med.medicineId)) {
                updatedMeds++
              }
            }

            if (!row.barcode.isNullOrBlank()) {
              db.barcodeMappingDao().upsert(BarcodeMappingEntity(row.barcode, med.medicineId, utcIso))
            }

            if (!row.batchNumber.isNullOrBlank() && row.expiryYyyyMm != null) {
              val existingBatch =
                db.stockBatchDao()
                  .findByNormalizedIdentity(med.medicineId, row.batchNumber, row.expiryYyyyMm)
              if (existingBatch == null) {
                val batchId = UUID.randomUUID().toString()
                db.stockBatchDao()
                  .insert(
                    StockBatchEntity(
                      batchId = batchId,
                      medicineId = med.medicineId,
                      batchNumber = row.batchNumber,
                      expiryYyyyMm = row.expiryYyyyMm,
                      stockUnitName = med.stockUnitName,
                      mrpPaise = row.mrpPaise,
                      latestPurchasePricePaise = row.purchasePricePaise,
                      quantityMilli = row.openingQuantityMilli,
                      batchStatus = BatchStatus.Active.dbValue,
                      createdAtUtc = utcIso,
                      updatedAtUtc = utcIso,
                    )
                  )
                if (row.openingQuantityMilli > 0L) {
                  db.ledgerDao()
                    .insertStockMovement(
                      StockMovementEntity(
                        movementId = UUID.randomUUID().toString(),
                        batchId = batchId,
                        medicineId = med.medicineId,
                        movementType = StockMovementType.Opening.dbValue,
                        quantityDeltaMilli = row.openingQuantityMilli,
                        referenceType = "CATALOGUE_IMPORT",
                        referenceId = fileName,
                        reason = "Opening stock from $fileName",
                        createdAtUtc = utcIso,
                        createdLocalText = localText,
                      )
                    )
                }
              } else {
                val newQty = CheckedMath.addExact(existingBatch.quantityMilli, row.openingQuantityMilli)
                db.stockBatchDao()
                  .update(
                    existingBatch.copy(
                      mrpPaise = if (row.mrpPaise > 0L) row.mrpPaise else existingBatch.mrpPaise,
                      latestPurchasePricePaise =
                        if (row.purchasePricePaise > 0L) row.purchasePricePaise
                        else existingBatch.latestPurchasePricePaise,
                      quantityMilli = newQty,
                      updatedAtUtc = utcIso,
                    )
                  )
                if (row.openingQuantityMilli > 0L) {
                  db.ledgerDao()
                    .insertStockMovement(
                      StockMovementEntity(
                        movementId = UUID.randomUUID().toString(),
                        batchId = existingBatch.batchId,
                        medicineId = med.medicineId,
                        movementType = StockMovementType.Opening.dbValue,
                        quantityDeltaMilli = row.openingQuantityMilli,
                        referenceType = "CATALOGUE_IMPORT",
                        referenceId = fileName,
                        reason = "Opening stock addition from $fileName",
                        createdAtUtc = utcIso,
                        createdLocalText = localText,
                      )
                    )
                }
              }
              batchesTouched++
            }
          }

          db.ledgerDao()
            .insertAuditLog(
              AuditLogEntity(
                auditId = UUID.randomUUID().toString(),
                actionType = "CATALOGUE_IMPORTED",
                entityType = "medicine",
                entityId = fileName,
                summary =
                  "Imported catalogue '$fileName': created=$createdMeds, updated=$updatedMeds, batches=$batchesTouched",
                beforeJson = null,
                afterJson = null,
                createdAtUtc = utcIso,
                createdLocalText = localText,
              )
            )

          StockSnapshotState.markDirtyAndIncrementGeneration(db, utcIso)

          CatalogueImportResult(
            succeeded = true,
            medicinesCreated = createdMeds,
            medicinesUpdated = updatedMeds,
            batchesUpdatedOrCreated = batchesTouched,
          )
        }
      } catch (ex: Exception) {
        return CatalogueImportResult(
          succeeded = false,
          errorMessage = ex.message ?: "Catalogue import failed.",
        )
      }

    var snapshotRefreshed = false
    var snapshotWarning: String? = null
    val refresher = snapshotRefresher
    if (refresher != null) {
      val res = runCatching { refresher.invoke() }.getOrElse { Result.failure(it) }
      if (res.isSuccess) snapshotRefreshed = true
      else snapshotWarning = "Catalogue imported, but StockData.json refresh failed: ${res.exceptionOrNull()?.message}"
    }
    return committed.copy(snapshotRefreshed = snapshotRefreshed, snapshotWarning = snapshotWarning)
  }

  private fun parseRows(input: InputStream, fileName: String): ParsedCatalogue {
    val errors = mutableListOf<String>()
    val warnings = mutableListOf<String>()
    val rawTable: List<List<String>> =
      try {
        if (fileName.lowercase(Locale.ROOT).endsWith(".xlsx")) {
          readXlsxRows(input.readBytes())
        } else {
          parseCsvTable(input.bufferedReader(Charsets.UTF_8).use { it.readText() })
        }
      } catch (ex: Exception) {
        return ParsedCatalogue(emptyList(), listOf("Failed to parse '$fileName': ${ex.message}"), warnings)
      }

    if (rawTable.isEmpty()) {
      return ParsedCatalogue(emptyList(), listOf("File '$fileName' is empty."), warnings)
    }

    val headerIndex =
      rawTable.first().mapIndexed { idx, h -> h.trim().lowercase(Locale.ROOT) to idx }.toMap()
    if (!headerIndex.containsKey("medicinename")) {
      return ParsedCatalogue(
        emptyList(),
        listOf("Missing required header column 'MedicineName'."),
        warnings,
      )
    }

    val parsedRows = mutableListOf<ParsedRow>()
    for (rIdx in 1 until rawTable.size) {
      val cells = rawTable[rIdx]
      if (cells.all { it.isBlank() }) continue
      val lineNum = rIdx + 1

      fun col(name: String): String =
        headerIndex[name.lowercase(Locale.ROOT)]?.let { cells.getOrNull(it) }?.trim().orEmpty()

      val medName = col("MedicineName")
      if (medName.isEmpty()) {
        errors += "Row $lineNum: MedicineName is required."
        continue
      }
      val stockUnit = col("StockUnit").ifEmpty { "unit" }

      val gstStr = col("GstRatePercent")
      val gstBps: Int? =
        if (gstStr.isEmpty()) {
          null
        } else {
          val parsedGst = parseGstPercentToBps(gstStr)
          if (parsedGst == null || parsedGst !in 0..10_000) {
            errors += "Row $lineNum: Invalid GstRatePercent '$gstStr'."
            null
          } else {
            parsedGst
          }
        }

      val thresholdStr = col("LowStockThreshold")
      val thresholdMilli =
        if (thresholdStr.isEmpty()) 0L
        else OrvaFormatters.parseQuantityToMilli(thresholdStr)
          ?: run {
            errors += "Row $lineNum: Invalid LowStockThreshold '$thresholdStr'."
            0L
          }

      val batchNum = col("BatchNumber").ifEmpty { null }
      val expiryStr = col("ExpiryYyyyMm")
      val expiryYm: Int? =
        if (batchNum != null) {
          val parsedExp = parseExpiryYyyyMm(expiryStr)
          if (parsedExp == null) {
            errors += "Row $lineNum: Valid ExpiryYyyyMm (e.g. 2028-12 or 202812) is required when BatchNumber is provided."
          }
          parsedExp
        } else null

      val qtyStr = col("OpeningQuantity")
      val qtyMilli =
        if (qtyStr.isEmpty()) 0L
        else OrvaFormatters.parseQuantityToMilli(qtyStr)
          ?: run {
            errors += "Row $lineNum: Invalid OpeningQuantity '$qtyStr'."
            0L
          }

      val purchaseStr = col("PurchasePrice")
      val purchasePaise =
        if (purchaseStr.isEmpty()) 0L
        else OrvaFormatters.parseRupeesToPaise(purchaseStr)
          ?: run {
            errors += "Row $lineNum: Invalid PurchasePrice '$purchaseStr'."
            0L
          }

      val mrpStr = col("Mrp")
      val mrpPaise =
        if (mrpStr.isEmpty()) 0L
        else OrvaFormatters.parseRupeesToPaise(mrpStr)
          ?: run {
            errors += "Row $lineNum: Invalid Mrp '$mrpStr'."
            0L
          }

      parsedRows +=
        ParsedRow(
          medicineName = medName,
          genericName = col("GenericName").ifEmpty { null },
          brandName = col("BrandName").ifEmpty { null },
          strength = col("Strength").ifEmpty { null },
          dosageForm = col("DosageForm").ifEmpty { null },
          stockUnit = stockUnit,
          hsnCode = col("HsnCode").ifEmpty { null },
          gstRateBasisPoints = gstBps,
          lowStockThresholdMilli = thresholdMilli,
          barcode = col("Barcode").ifEmpty { null },
          batchNumber = batchNum,
          expiryYyyyMm = expiryYm,
          openingQuantityMilli = qtyMilli,
          purchasePricePaise = purchasePaise,
          mrpPaise = mrpPaise,
        )
    }

    return ParsedCatalogue(parsedRows, errors, warnings)
  }

  private fun parseGstPercentToBps(raw: String): Int? {
    val clean = raw.trim().removeSuffix("%").trim()
    val dec = runCatching { BigDecimal(clean) }.getOrNull() ?: return null
    if (dec < BigDecimal.ZERO || dec > BigDecimal.valueOf(100)) return null
    return runCatching {
      dec.multiply(BigDecimal.valueOf(100)).setScale(0, RoundingMode.HALF_UP).intValueExact()
    }.getOrNull()
  }

  private fun parseExpiryYyyyMm(raw: String): Int? {
    val clean = raw.trim()
    if (clean.isEmpty()) return null
    val digitsOnly = clean.replace("-", "").replace("/", "")
    if (digitsOnly.length == 6 && digitsOnly.all { it.isDigit() }) {
      val ym = digitsOnly.toIntOrNull() ?: return null
      val y = ym / 100
      val m = ym % 100
      if (y in 2000..2199 && m in 1..12) return ym
      // Support MM/YYYY (e.g. 12/2028)
      val mFirst = digitsOnly.substring(0, 2).toIntOrNull() ?: return null
      val ySecond = digitsOnly.substring(2, 6).toIntOrNull() ?: return null
      if (ySecond in 2000..2199 && mFirst in 1..12) return ySecond * 100 + mFirst
    }
    return null
  }

  internal fun parseCsvTable(content: String): List<List<String>> {
    val text = content.trimStart('\uFEFF')
    val rows = mutableListOf<List<String>>()
    val currentRow = mutableListOf<String>()
    val cell = StringBuilder()
    var inQuotes = false
    var i = 0
    while (i < text.length) {
      val ch = text[i]
      if (inQuotes) {
        if (ch == '"') {
          if (i + 1 < text.length && text[i + 1] == '"') {
            cell.append('"')
            i += 2
            continue
          }
          inQuotes = false
        } else {
          cell.append(ch)
        }
      } else {
        when (ch) {
          '"' -> inQuotes = true
          ',' -> {
            currentRow += cell.toString()
            cell.setLength(0)
          }
          '\r' -> {
            if (i + 1 < text.length && text[i + 1] == '\n') i++
            currentRow += cell.toString()
            cell.setLength(0)
            rows += currentRow.toList()
            currentRow.clear()
          }
          '\n' -> {
            currentRow += cell.toString()
            cell.setLength(0)
            rows += currentRow.toList()
            currentRow.clear()
          }
          else -> cell.append(ch)
        }
      }
      i++
    }
    if (cell.isNotEmpty() || currentRow.isNotEmpty()) {
      currentRow += cell.toString()
      rows += currentRow.toList()
    }
    return rows
  }

  private fun readXlsxRows(zipBytes: ByteArray): List<List<String>> {
    var sharedStringsXml: ByteArray? = null
    var sheetXml: ByteArray? = null
    ZipInputStream(ByteArrayInputStream(zipBytes)).use { zis ->
      var entry = zis.nextEntry
      while (entry != null) {
        when (entry.name) {
          "xl/sharedStrings.xml" -> sharedStringsXml = zis.readBytes()
          "xl/worksheets/sheet1.xml" -> sheetXml = zis.readBytes()
        }
        entry = zis.nextEntry
      }
    }
    val sheetBytes = sheetXml ?: throw IllegalArgumentException("XLSX missing xl/worksheets/sheet1.xml")
    val sharedStrings = sharedStringsXml?.let { parseSharedStrings(it) }.orEmpty()
    return parseWorksheetXml(sheetBytes, sharedStrings)
  }

  private fun parseSharedStrings(xmlBytes: ByteArray): List<String> {
    val result = mutableListOf<String>()
    val parser = Xml.newPullParser()
    parser.setInput(ByteArrayInputStream(xmlBytes), "UTF-8")
    var event = parser.eventType
    var inSi = false
    val sb = StringBuilder()
    while (event != XmlPullParser.END_DOCUMENT) {
      when (event) {
        XmlPullParser.START_TAG -> {
          if (parser.name == "si") {
            inSi = true
            sb.setLength(0)
          } else if (inSi && parser.name == "t") {
            sb.append(parser.nextText())
          }
        }
        XmlPullParser.END_TAG -> {
          if (parser.name == "si") {
            result += sb.toString()
            inSi = false
          }
        }
      }
      event = parser.next()
    }
    return result
  }

  private fun parseWorksheetXml(xmlBytes: ByteArray, sharedStrings: List<String>): List<List<String>> {
    val rows = mutableListOf<List<String>>()
    val parser = Xml.newPullParser()
    parser.setInput(ByteArrayInputStream(xmlBytes), "UTF-8")
    var event = parser.eventType
    var currentRow: MutableList<String>? = null
    var currentType: String? = null
    var currentColIdx = 0
    while (event != XmlPullParser.END_DOCUMENT) {
      when (event) {
        XmlPullParser.START_TAG -> {
          when (parser.name) {
            "row" -> {
              currentRow = mutableListOf()
              currentColIdx = 0
            }
            "c" -> {
              currentType = parser.getAttributeValue(null, "t")
              val ref = parser.getAttributeValue(null, "r")
              if (!ref.isNullOrEmpty()) {
                currentColIdx = columnLettersToIndex(ref.takeWhile { it.isLetter() })
              }
            }
            "v" -> {
              val raw = parser.nextText()
              val value =
                if (currentType == "s") {
                  sharedStrings.getOrNull(raw.toIntOrNull() ?: -1).orEmpty()
                } else {
                  raw
                }
              currentRow?.let { row ->
                while (row.size <= currentColIdx) row.add("")
                row[currentColIdx] = value
                currentColIdx++
              }
            }
            "t" -> {
              if (currentType == "inlineStr") {
                val value = parser.nextText()
                currentRow?.let { row ->
                  while (row.size <= currentColIdx) row.add("")
                  row[currentColIdx] = value
                  currentColIdx++
                }
              }
            }
          }
        }
        XmlPullParser.END_TAG -> {
          if (parser.name == "row") {
            currentRow?.let { rows += it }
            currentRow = null
          }
        }
      }
      event = parser.next()
    }
    return rows
  }

  private fun columnLettersToIndex(letters: String): Int {
    var result = 0
    for (ch in letters.uppercase(Locale.ROOT)) {
      result = result * 26 + (ch - 'A' + 1)
    }
    return (result - 1).coerceAtLeast(0)
  }

  private data class ParsedRow(
    val medicineName: String,
    val genericName: String?,
    val brandName: String?,
    val strength: String?,
    val dosageForm: String?,
    val stockUnit: String,
    val hsnCode: String?,
    val gstRateBasisPoints: Int?,
    val lowStockThresholdMilli: Long,
    val barcode: String?,
    val batchNumber: String?,
    val expiryYyyyMm: Int?,
    val openingQuantityMilli: Long,
    val purchasePricePaise: Long,
    val mrpPaise: Long,
  )

  private data class ParsedCatalogue(
    val rows: List<ParsedRow>,
    val errors: List<String>,
    val warnings: List<String>,
  )
}
