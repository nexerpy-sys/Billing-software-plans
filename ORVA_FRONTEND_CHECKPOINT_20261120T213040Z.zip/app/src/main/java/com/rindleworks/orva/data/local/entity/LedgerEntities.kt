package com.rindleworks.orva.data.local.entity

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
  tableName = "purchase_receipt",
  indices = [Index(name = "ix_purchase_date", value = ["received_at_utc"])],
)
data class PurchaseReceiptEntity(
  @PrimaryKey @ColumnInfo(name = "purchase_id") val purchaseId: String,
  @ColumnInfo(name = "received_at_utc") val receivedAtUtc: String,
  @ColumnInfo(name = "supplier_name_text") val supplierNameText: String? = null,
  @ColumnInfo(name = "supplier_licence_text") val supplierLicenceText: String? = null,
  @ColumnInfo(name = "document_type") val documentType: String,
  @ColumnInfo(name = "document_reference") val documentReference: String? = null,
  @ColumnInfo(name = "notes") val notes: String? = null,
  @ColumnInfo(name = "subtotal_paise", defaultValue = "0") val subtotalPaise: Long = 0L,
  @ColumnInfo(name = "total_tax_paise", defaultValue = "0") val totalTaxPaise: Long = 0L,
  @ColumnInfo(name = "total_paise", defaultValue = "0") val totalPaise: Long = 0L,
  @ColumnInfo(name = "created_at_utc") val createdAtUtc: String,
)

@Entity(
  tableName = "purchase_line",
  foreignKeys =
    [
      ForeignKey(
        entity = PurchaseReceiptEntity::class,
        parentColumns = ["purchase_id"],
        childColumns = ["purchase_id"],
      ),
      ForeignKey(
        entity = StockBatchEntity::class,
        parentColumns = ["batch_id"],
        childColumns = ["batch_id"],
      ),
      ForeignKey(
        entity = MedicineEntity::class,
        parentColumns = ["medicine_id"],
        childColumns = ["medicine_id"],
      ),
    ],
  indices = [Index(name = "ix_purchase_line_purchase", value = ["purchase_id"])],
)
data class PurchaseLineEntity(
  @PrimaryKey @ColumnInfo(name = "purchase_line_id") val purchaseLineId: String,
  @ColumnInfo(name = "purchase_id") val purchaseId: String,
  @ColumnInfo(name = "batch_id") val batchId: String,
  @ColumnInfo(name = "medicine_id") val medicineId: String,
  @ColumnInfo(name = "quantity_milli") val quantityMilli: Long,
  @ColumnInfo(name = "unit_name_snapshot") val unitNameSnapshot: String,
  @ColumnInfo(name = "unit_purchase_price_paise") val unitPurchasePricePaise: Long,
  @ColumnInfo(name = "line_total_paise") val lineTotalPaise: Long,
  @ColumnInfo(name = "created_at_utc") val createdAtUtc: String,
)

@Entity(
  tableName = "stock_movement",
  foreignKeys =
    [
      ForeignKey(
        entity = StockBatchEntity::class,
        parentColumns = ["batch_id"],
        childColumns = ["batch_id"],
      ),
      ForeignKey(
        entity = MedicineEntity::class,
        parentColumns = ["medicine_id"],
        childColumns = ["medicine_id"],
      ),
    ],
  indices = [Index(name = "ix_stock_movement_batch_date", value = ["batch_id", "created_at_utc"])],
)
data class StockMovementEntity(
  @PrimaryKey @ColumnInfo(name = "movement_id") val movementId: String,
  @ColumnInfo(name = "batch_id") val batchId: String,
  @ColumnInfo(name = "medicine_id") val medicineId: String,
  @ColumnInfo(name = "movement_type") val movementType: String,
  @ColumnInfo(name = "quantity_delta_milli") val quantityDeltaMilli: Long,
  @ColumnInfo(name = "reference_type") val referenceType: String? = null,
  @ColumnInfo(name = "reference_id") val referenceId: String? = null,
  @ColumnInfo(name = "reason") val reason: String? = null,
  @ColumnInfo(name = "created_at_utc") val createdAtUtc: String,
  @ColumnInfo(name = "created_local_text") val createdLocalText: String,
)

@Entity(
  tableName = "stock_discrepancy",
  foreignKeys =
    [
      ForeignKey(
        entity = StockBatchEntity::class,
        parentColumns = ["batch_id"],
        childColumns = ["batch_id"],
      )
    ],
)
data class StockDiscrepancyEntity(
  @PrimaryKey @ColumnInfo(name = "discrepancy_id") val discrepancyId: String,
  @ColumnInfo(name = "batch_id") val batchId: String,
  @ColumnInfo(name = "expected_quantity_milli") val expectedQuantityMilli: Long,
  @ColumnInfo(name = "counted_quantity_milli") val countedQuantityMilli: Long,
  @ColumnInfo(name = "difference_milli") val differenceMilli: Long,
  @ColumnInfo(name = "reason") val reason: String,
  @ColumnInfo(name = "reconciled_at_utc") val reconciledAtUtc: String,
)

@Entity(
  tableName = "audit_log",
  indices =
    [Index(name = "ix_audit_entity_date", value = ["entity_type", "entity_id", "created_at_utc"])],
)
data class AuditLogEntity(
  @PrimaryKey @ColumnInfo(name = "audit_id") val auditId: String,
  @ColumnInfo(name = "action_type") val actionType: String,
  @ColumnInfo(name = "entity_type") val entityType: String,
  @ColumnInfo(name = "entity_id") val entityId: String,
  @ColumnInfo(name = "summary") val summary: String,
  @ColumnInfo(name = "before_json") val beforeJson: String? = null,
  @ColumnInfo(name = "after_json") val afterJson: String? = null,
  @ColumnInfo(name = "created_at_utc") val createdAtUtc: String,
  @ColumnInfo(name = "created_local_text") val createdLocalText: String,
)

@Entity(tableName = "expense_record")
data class ExpenseRecordEntity(
  @PrimaryKey @ColumnInfo(name = "expense_id") val expenseId: String,
  @ColumnInfo(name = "expense_date_utc") val expenseDateUtc: String,
  @ColumnInfo(name = "category") val category: String,
  @ColumnInfo(name = "description") val description: String? = null,
  @ColumnInfo(name = "amount_paise") val amountPaise: Long,
  @ColumnInfo(name = "payment_method") val paymentMethod: String? = null,
  @ColumnInfo(name = "document_reference") val documentReference: String? = null,
  @ColumnInfo(name = "created_at_utc") val createdAtUtc: String,
)
