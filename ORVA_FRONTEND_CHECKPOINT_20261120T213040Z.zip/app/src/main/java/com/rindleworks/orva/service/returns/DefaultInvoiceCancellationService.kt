package com.rindleworks.orva.service.returns

import com.rindleworks.orva.data.local.OrvaTransactionRunner
import com.rindleworks.orva.data.local.entity.AuditLogEntity
import com.rindleworks.orva.data.local.entity.StockMovementEntity
import com.rindleworks.orva.data.repository.StockSnapshotState
import com.rindleworks.orva.domain.common.InvoiceStatus
import com.rindleworks.orva.domain.common.StockMovementType
import com.rindleworks.orva.domain.engine.BillingClock
import com.rindleworks.orva.domain.engine.BillingInstant
import com.rindleworks.orva.domain.engine.InventoryAlertCalculator
import com.rindleworks.orva.domain.inventory.BatchStatus
import com.rindleworks.orva.domain.returns.InvoiceCancellationResult
import com.rindleworks.orva.domain.returns.InvoiceCancellationService
import java.util.UUID
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

class DefaultInvoiceCancellationService(
  private val transactionRunner: OrvaTransactionRunner,
  private val clock: BillingClock,
  private val snapshotRefresher: (suspend () -> Result<Boolean>)? = null,
) : InvoiceCancellationService {

  private val json = Json { encodeDefaults = true }

  override suspend fun cancelInvoice(
    invoiceId: String,
    reason: String,
    restoreStock: Boolean,
  ): InvoiceCancellationResult {
    val cleanReason = reason.trim()
    if (cleanReason.isEmpty()) {
      return InvoiceCancellationResult(
        succeeded = false,
        errorMessage = "A cancellation reason is required.",
      )
    }

    val committed =
      try {
        transactionRunner.runWriteTransaction { db ->
          val invoice =
            db.invoiceDao().getInvoiceById(invoiceId)
              ?: return@runWriteTransaction InvoiceCancellationResult(
                succeeded = false,
                errorMessage = "Invoice '$invoiceId' was not found.",
              )

          if (invoice.status == InvoiceStatus.Cancelled.dbValue) {
            return@runWriteTransaction InvoiceCancellationResult(
              succeeded = false,
              invoiceNumber = invoice.invoiceNumber,
              errorMessage = "Invoice '${invoice.invoiceNumber}' is already cancelled.",
            )
          }

          val completedReturns = db.salesReturnDao().countCompletedReturnsForInvoice(invoiceId)
          if (completedReturns > 0) {
            return@runWriteTransaction InvoiceCancellationResult(
              succeeded = false,
              invoiceNumber = invoice.invoiceNumber,
              errorMessage =
                "Invoice '${invoice.invoiceNumber}' cannot be cancelled because $completedReturns completed sales return(s) already exist against it.",
            )
          }

          val now = BillingInstant.capture(clock)
          val utcIso = now.utcIsoText
          val localText = now.localLogText

          val updatedRows =
            db.invoiceDao()
              .updateInvoiceStatus(
                invoiceId = invoiceId,
                newStatus = InvoiceStatus.Cancelled.dbValue,
                cancellationReason = cleanReason,
              )
          check(updatedRows == 1) { "Failed to update invoice status to CANCELLED." }

          val warnings = mutableListOf<String>()
          var stockActuallyRestored = false

          if (restoreStock) {
            val lines = db.invoiceDao().getLinesForInvoice(invoiceId)
            for (line in lines) {
              val batch = db.stockBatchDao().getById(line.batchId)
              if (batch != null) {
                val rows = db.stockBatchDao().addQuantity(batch.batchId, line.quantityMilli, utcIso)
                check(rows == 1) { "Failed to restore stock to batch '${batch.batchId}'." }
                stockActuallyRestored = true

                val isExpired =
                  InventoryAlertCalculator.getMonthEndExpiryDate(batch.expiryYyyyMm)
                    .isBefore(now.localBusinessDate)
                if (batch.batchStatus != BatchStatus.Active.dbValue || isExpired) {
                  warnings +=
                    "Batch '${batch.batchNumber}' (${line.medicineNameSnapshot}) is ${if (isExpired) "expired" else batch.batchStatus}; restored units remain non-sellable."
                }

                db.ledgerDao()
                  .insertStockMovement(
                    StockMovementEntity(
                      movementId = UUID.randomUUID().toString(),
                      batchId = batch.batchId,
                      medicineId = line.medicineId,
                      movementType = StockMovementType.Adjustment.dbValue,
                      quantityDeltaMilli = line.quantityMilli,
                      referenceType = "INVOICE_CANCEL",
                      referenceId = invoiceId,
                      reason = "Invoice ${invoice.invoiceNumber} cancelled: $cleanReason",
                      createdAtUtc = utcIso,
                      createdLocalText = localText,
                    )
                  )
              }
            }
            if (stockActuallyRestored) {
              StockSnapshotState.markDirtyAndIncrementGeneration(db, utcIso)
            }
          }

          db.ledgerDao()
            .insertAuditLog(
              AuditLogEntity(
                auditId = UUID.randomUUID().toString(),
                actionType = "INVOICE_CANCELLED",
                entityType = "invoice",
                entityId = invoiceId,
                summary =
                  "Cancelled invoice ${invoice.invoiceNumber} (restoreStock=$restoreStock): $cleanReason",
                beforeJson = json.encodeToString(StatusAudit(invoice.status)),
                afterJson = json.encodeToString(StatusAudit(InvoiceStatus.Cancelled.dbValue)),
                createdAtUtc = utcIso,
                createdLocalText = localText,
              )
            )

          InvoiceCancellationResult(
            succeeded = true,
            invoiceNumber = invoice.invoiceNumber,
            stockRestored = stockActuallyRestored,
            stockWarning = warnings.takeIf { it.isNotEmpty() }?.joinToString(" "),
          )
        }
      } catch (ex: Exception) {
        return InvoiceCancellationResult(
          succeeded = false,
          errorMessage = ex.message ?: "Unable to cancel invoice.",
        )
      }

    if (!committed.succeeded) return committed

    var snapshotRefreshed = false
    var snapshotWarning: String? = null
    val refresher = snapshotRefresher
    if (committed.stockRestored && refresher != null) {
      val res = runCatching { refresher.invoke() }.getOrElse { Result.failure(it) }
      if (res.isSuccess) {
        snapshotRefreshed = true
      } else {
        snapshotWarning =
          "Invoice cancelled, but StockData.json refresh failed: ${res.exceptionOrNull()?.message ?: "unknown error"}"
      }
    }

    return committed.copy(
      snapshotRefreshed = snapshotRefreshed,
      snapshotWarning = snapshotWarning,
    )
  }

  @Serializable
  private data class StatusAudit(val status: String)
}
