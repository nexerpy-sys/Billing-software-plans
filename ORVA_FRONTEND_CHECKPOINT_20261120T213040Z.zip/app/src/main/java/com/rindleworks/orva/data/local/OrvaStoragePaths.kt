package com.rindleworks.orva.data.local

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.Settings
import androidx.core.content.ContextCompat
import java.io.File
import java.util.UUID

/**
 * Centralized storage layout for ORVA Android (sideloaded APK edition).
 *
 * Crash-safety split:
 * - **App-private internal storage (`filesDir/orva/`)** ALWAYS holds the live SQLite WAL database
 *   (`orva.sqlite`), staging directory, device install ID, and anti-delete licence anchor so
 *   phone cleaner apps, MediaScanner, or USB MTP connections can never corrupt an open DB or
 *   reset an activated licence.
 * - **Portable `ORVA/` folder** resolves to `/storage/emulated/0/ORVA/` whenever All Files Access
 *   (Android 11+) or legacy external storage permission (Android 7-10) is granted, and falls back
 *   cleanly to `filesDir/orva/ORVA/` otherwise so saving NEVER crashes.
 *
 * The `ORVA/` folder is NOT pre-created on cold launch — it is auto-created on demand the moment
 * any file (`StockData.json`, `ShopBackup.shopbackup`, `Daily/`, `Safety/`, `Exports/`, or
 * `license.orvalic`) is actually saved.
 */
class OrvaStoragePaths(
  context: Context,
  customInternalRoot: File? = null,
  private val customOrvaFolder: File? = null,
) {
  companion object {
    const val ORVA_FOLDER_NAME = "ORVA"
    const val STOCK_DATA_FILE_NAME = "StockData.json"
    const val PORTABLE_BACKUP_FILE_NAME = "ShopBackup.shopbackup"
    const val LICENSE_FILE_NAME = "license.orvalic"
    const val DAILY_DIR_NAME = "Daily"
    const val SAFETY_DIR_NAME = "Safety"
    const val EXPORTS_DIR_NAME = "Exports"
    private const val DEVICE_INSTALL_ID_FILE = ".device_install_id"
    private const val LICENSE_ANCHOR_FILE = ".license_anchor"
  }

  private val appContext: Context = context.applicationContext

  /** App-private internal root holding live SQLite DB, staging files, and security anchors. */
  val internalRootDirectory: File = customInternalRoot ?: File(appContext.filesDir, "orva")

  /** Live Room SQLite database file (NEVER placed on shared external storage). */
  val databaseFile: File = File(internalRootDirectory, OrvaDatabase.DEFAULT_DB_NAME)

  /** Private temporary staging area for backup verification & restore rollbacks. */
  val stagingDirectory: File = File(internalRootDirectory, "staging")

  /** App-private anti-delete anchor preventing `ORVA/license.orvalic` deletion from resetting activation. */
  val licenseAnchorFile: File = File(internalRootDirectory, LICENSE_ANCHOR_FILE)

  /** Fallback `ORVA/` folder inside app-private storage when external storage access is not granted. */
  val internalOrvaFallbackDirectory: File = File(internalRootDirectory, ORVA_FOLDER_NAME)

  /**
   * Returns `true` when the app can directly create and atomically overwrite files inside
   * `/storage/emulated/0/ORVA/`.
   */
  fun hasExternalOrvaFolderAccess(): Boolean {
    if (customOrvaFolder != null) return true
    if (Environment.getExternalStorageState() != Environment.MEDIA_MOUNTED) return false
    return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
      runCatching { Environment.isExternalStorageManager() }.getOrDefault(false)
    } else {
      ContextCompat.checkSelfPermission(appContext, Manifest.permission.WRITE_EXTERNAL_STORAGE) ==
        PackageManager.PERMISSION_GRANTED
    }
  }

  /**
   * Dynamically resolves the active portable `ORVA/` directory:
   * - `/storage/emulated/0/ORVA` when external storage access is granted (survives uninstall/reinstall).
   * - `filesDir/orva/ORVA` fallback otherwise (zero-crash guarantee).
   */
  fun activeOrvaFolder(): File {
    if (customOrvaFolder != null) return customOrvaFolder
    if (hasExternalOrvaFolderAccess()) {
      @Suppress("DEPRECATION")
      val externalRoot = runCatching { Environment.getExternalStorageDirectory() }.getOrNull()
      if (externalRoot != null) {
        return File(externalRoot, ORVA_FOLDER_NAME)
      }
    }
    return internalOrvaFallbackDirectory
  }

  fun isUsingExternalOrvaFolder(): Boolean {
    if (customOrvaFolder != null) return true
    return activeOrvaFolder().absolutePath != internalOrvaFallbackDirectory.absolutePath
  }

  /** Portable `ORVA/StockData.json` (auto-creates `ORVA/` when written). */
  fun stockDataFile(): File = File(activeOrvaFolder(), STOCK_DATA_FILE_NAME)

  /** Rolling `ORVA/ShopBackup.shopbackup` (auto-creates `ORVA/` when written). */
  fun portableBackupFile(): File = File(activeOrvaFolder(), PORTABLE_BACKUP_FILE_NAME)

  /** Daily backups folder: `ORVA/Daily/`. */
  fun dailyBackupsDirectory(): File = File(activeOrvaFolder(), DAILY_DIR_NAME)

  /** Pre-restore & pre-import safety backups folder: `ORVA/Safety/`. */
  fun safetyBackupsDirectory(): File = File(activeOrvaFolder(), SAFETY_DIR_NAME)

  /** Exported PDF / XLSX / CSV reports folder: `ORVA/Exports/`. */
  fun exportsDirectory(): File = File(activeOrvaFolder(), EXPORTS_DIR_NAME)

  /** Sealed hardware-Keystore local licence file: `ORVA/license.orvalic`. */
  fun licenseFile(): File = File(activeOrvaFolder(), LICENSE_FILE_NAME)

  /**
   * Returns a stable, installation-scoped UUID stored in app-private storage, bound into
   * `ORVA/license.orvalic` AES-256-GCM AAD so copied licence files cannot be cloned to other devices.
   */
  @Synchronized
  fun getOrCreateDeviceInstallId(): String {
    val file = File(internalRootDirectory, DEVICE_INSTALL_ID_FILE)
    if (file.exists()) {
      val existing = runCatching { file.readText(Charsets.UTF_8).trim() }.getOrDefault("")
      if (existing.isNotEmpty()) return existing
    }
    val generated = UUID.randomUUID().toString()
    runCatching {
      internalRootDirectory.mkdirs()
      file.writeText(generated, Charsets.UTF_8)
    }
    return generated
  }

  /**
   * Builds the system Intent to open Android's "All files access" toggle for ORVA (API 30+),
   * enabling direct `/storage/emulated/0/ORVA/` creation & overwriting on sideloaded APKs.
   */
  fun createExternalStorageAccessIntent(): Intent {
    return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
      val appSpecific =
        Intent(
          Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
          Uri.parse("package:${appContext.packageName}"),
        )
      if (appSpecific.resolveActivity(appContext.packageManager) != null) {
        appSpecific
      } else {
        Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION)
      }
    } else {
      Intent(
        Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
        Uri.parse("package:${appContext.packageName}"),
      )
    }
  }
}
