package com.rindleworks.orva.data.repository

import com.rindleworks.orva.data.local.OrvaDatabaseProvider
import com.rindleworks.orva.data.local.OrvaTransactionRunner
import com.rindleworks.orva.data.local.SqlLikeEscaper
import com.rindleworks.orva.data.local.entity.AppSettingEntity
import com.rindleworks.orva.data.local.entity.AuditLogEntity
import com.rindleworks.orva.domain.common.OrvaDateTimeFormatters
import com.rindleworks.orva.domain.common.OrvaSettingKeys
import com.rindleworks.orva.domain.engine.BillingClock
import com.rindleworks.orva.domain.settings.BillingTaxSettings
import com.rindleworks.orva.domain.settings.MedicineTaxConfigItem
import com.rindleworks.orva.domain.settings.RoundOffMode
import com.rindleworks.orva.domain.settings.SupplyType
import com.rindleworks.orva.domain.settings.TaxPricingMode
import com.rindleworks.orva.domain.settings.TaxSettingsRepository
import java.util.Locale
import java.util.UUID
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.map
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

@OptIn(ExperimentalCoroutinesApi::class)
class RoomTaxSettingsRepository(
  private val databaseProvider: OrvaDatabaseProvider,
  private val transactionRunner: OrvaTransactionRunner,
  private val clock: BillingClock,
  private val snapshotRefresher: (suspend () -> Result<Boolean>)? = null,
) : TaxSettingsRepository {

  private val json = Json { encodeDefaults = true }

  override fun observeTaxSettings(): Flow<BillingTaxSettings> =
    databaseProvider.databaseGeneration.flatMapLatest {
      databaseProvider.current().appSettingDao().observeAll().map { list ->
        parseSettings(list.associate { it.settingKey to it.settingValue })
      }
    }

  override suspend fun getTaxSettings(): BillingTaxSettings =
    transactionRunner.runRead { db ->
      parseSettings(db.appSettingDao().getAll().associate { it.settingKey to it.settingValue })
    }

  override suspend fun saveTaxSettings(
    taxConfigured: Boolean,
    pricingMode: TaxPricingMode,
    defaultSupplyType: SupplyType,
    roundOffMode: RoundOffMode,
  ): Result<Unit> = runCatching {
    val now = com.rindleworks.orva.domain.engine.BillingInstant.capture(clock)
    val utcIso = now.utcIsoText
    val localText = now.localLogText

    transactionRunner.runWriteTransaction { db ->
      val before = parseSettings(db.appSettingDao().getAll().associate { it.settingKey to it.settingValue })

      db.appSettingDao()
        .upsert(AppSettingEntity(OrvaSettingKeys.TAX_CONFIGURED, if (taxConfigured) "1" else "0", utcIso))
      db.appSettingDao()
        .upsert(AppSettingEntity(OrvaSettingKeys.TAX_PRICING_MODE, pricingMode.dbValue, utcIso))
      db.appSettingDao()
        .upsert(AppSettingEntity(OrvaSettingKeys.DEFAULT_SUPPLY_TYPE, defaultSupplyType.dbValue, utcIso))
      db.appSettingDao()
        .upsert(AppSettingEntity(OrvaSettingKeys.ROUND_OFF_MODE, roundOffMode.dbValue, utcIso))

      val after =
        BillingTaxSettings(
          isConfigured = taxConfigured,
          pricingMode = pricingMode,
          defaultSupplyType = defaultSupplyType,
          roundOffMode = roundOffMode,
        )

      db.ledgerDao()
        .insertAuditLog(
          AuditLogEntity(
            auditId = UUID.randomUUID().toString(),
            actionType = "TAX_SETTINGS_SAVED",
            entityType = "app_setting",
            entityId = "billing_tax_settings",
            summary =
              "Updated billing tax settings (configured=$taxConfigured, pricing=${pricingMode.dbValue}, supply=${defaultSupplyType.dbValue}, roundOff=${roundOffMode.dbValue})",
            beforeJson = json.encodeToString(before.toAuditDto()),
            afterJson = json.encodeToString(after.toAuditDto()),
            createdAtUtc = utcIso,
            createdLocalText = localText,
          )
        )
    }
  }

  override suspend fun getMedicinesForTaxConfig(searchText: String): List<MedicineTaxConfigItem> =
    transactionRunner.runRead { db ->
      val pattern = SqlLikeEscaper.containsPattern(searchText)
      db.medicineDao().searchForTaxConfig(pattern).map { entity ->
        MedicineTaxConfigItem(
          medicineId = entity.medicineId,
          displayName = entity.displayName,
          stockUnitName = entity.stockUnitName,
          hsnCode = entity.hsnCode,
          gstRateBasisPoints = entity.gstRateBasisPoints,
          gstRateConfigured = entity.gstRateConfigured == 1,
        )
      }
    }

  override suspend fun updateMedicineTaxConfig(
    medicineId: String,
    hsnCode: String?,
    gstRateBasisPoints: Int,
    gstRateConfigured: Boolean,
  ): Result<Unit> = runCatching {
    require(gstRateBasisPoints in 0..10_000) {
      "GST rate basis points must be between 0 and 10000."
    }
    val cleanHsn = hsnCode?.trim()?.ifEmpty { null }
    val now = com.rindleworks.orva.domain.engine.BillingInstant.capture(clock)
    val utcIso = now.utcIsoText
    val localText = now.localLogText

    transactionRunner.runWriteTransaction { db ->
      val existing =
        db.medicineDao().getById(medicineId)
          ?: throw IllegalArgumentException("Medicine '$medicineId' was not found.")
      val rows =
        db.medicineDao()
          .updateTaxConfig(
            medicineId = medicineId,
            hsnCode = cleanHsn,
            gstRateBasisPoints = gstRateBasisPoints,
            gstRateConfigured = if (gstRateConfigured) 1 else 0,
            updatedAtUtc = utcIso,
          )
      check(rows == 1) { "Failed to update tax configuration for medicine '$medicineId'." }

      // v2 StockData.json includes HSN & GST configuration, so bump snapshot dirty generation.
      StockSnapshotState.markDirtyAndIncrementGeneration(db, utcIso)

      db.ledgerDao()
        .insertAuditLog(
          AuditLogEntity(
            auditId = UUID.randomUUID().toString(),
            actionType = "MEDICINE_TAX_CONFIG_UPDATED",
            entityType = "medicine",
            entityId = medicineId,
            summary =
              "Updated GST config for '${existing.displayName}' (HSN=${cleanHsn ?: "-"}, bps=$gstRateBasisPoints, configured=$gstRateConfigured)",
            beforeJson =
              json.encodeToString(
                MedicineTaxAuditDto(
                  hsnCode = existing.hsnCode,
                  gstRateBasisPoints = existing.gstRateBasisPoints,
                  gstRateConfigured = existing.gstRateConfigured == 1,
                )
              ),
            afterJson =
              json.encodeToString(
                MedicineTaxAuditDto(
                  hsnCode = cleanHsn,
                  gstRateBasisPoints = gstRateBasisPoints,
                  gstRateConfigured = gstRateConfigured,
                )
              ),
            createdAtUtc = utcIso,
            createdLocalText = localText,
          )
        )
    }
    runCatching { snapshotRefresher?.invoke() }
  }

  private fun parseSettings(map: Map<String, String>): BillingTaxSettings {
    val configured = map[OrvaSettingKeys.TAX_CONFIGURED]?.trim() == "1"
    val pricingMode = TaxPricingMode.fromDbValue(map[OrvaSettingKeys.TAX_PRICING_MODE])
    val supplyType = SupplyType.fromDbValue(map[OrvaSettingKeys.DEFAULT_SUPPLY_TYPE])
    val roundOff = RoundOffMode.fromDbValue(map[OrvaSettingKeys.ROUND_OFF_MODE])
    return BillingTaxSettings(
      isConfigured = configured && pricingMode != null && supplyType != null && roundOff != null,
      pricingMode = pricingMode,
      defaultSupplyType = supplyType,
      roundOffMode = roundOff,
    )
  }

  @Serializable
  private data class TaxSettingsAuditDto(
    val isConfigured: Boolean,
    val pricingMode: String?,
    val defaultSupplyType: String?,
    val roundOffMode: String?,
  )

  @Serializable
  private data class MedicineTaxAuditDto(
    val hsnCode: String?,
    val gstRateBasisPoints: Int,
    val gstRateConfigured: Boolean,
  )

  private fun BillingTaxSettings.toAuditDto(): TaxSettingsAuditDto =
    TaxSettingsAuditDto(
      isConfigured = isConfigured,
      pricingMode = pricingMode?.dbValue,
      defaultSupplyType = defaultSupplyType?.dbValue,
      roundOffMode = roundOffMode?.dbValue,
    )
}
