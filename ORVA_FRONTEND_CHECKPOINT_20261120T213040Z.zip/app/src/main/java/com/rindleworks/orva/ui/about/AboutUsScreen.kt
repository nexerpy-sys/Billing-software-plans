package com.rindleworks.orva.ui.about

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsFocusedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.wrapContentWidth
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.layout.positionInWindow
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.rindleworks.orva.R
import com.rindleworks.orva.domain.settings.AppLanguage
import com.rindleworks.orva.ui.about.agentic.AgenticBuildController
import com.rindleworks.orva.ui.about.gesture.AboutGestureAxis
import com.rindleworks.orva.ui.about.gesture.classifyAboutGestureAxis
import com.rindleworks.orva.ui.about.agentic.AgenticHudBar
import com.rindleworks.orva.ui.about.agentic.AgenticOverlayCanvas
import com.rindleworks.orva.ui.about.agentic.LayerKind
import com.rindleworks.orva.ui.about.agentic.LocalAgenticController
import com.rindleworks.orva.ui.about.agentic.agenticNode
import com.rindleworks.orva.ui.about.agentic.rememberAgenticTextLayoutHandler
import com.rindleworks.orva.ui.showcase.AboutShowcaseUiState
import com.rindleworks.orva.ui.showcase.OrvaCaseRailItem
import com.rindleworks.orva.ui.showcase.OrvaClosingFriezeSection
import com.rindleworks.orva.ui.showcase.OrvaShowcaseColors
import com.rindleworks.orva.ui.showcase.OrvaShowcaseCopy
import com.rindleworks.orva.ui.showcase.OrvaShowcaseFonts
import com.rindleworks.orva.ui.showcase.ShowcaseUiEvent
import com.rindleworks.orva.ui.showcase.currentShowcasePalette
import kotlinx.coroutines.launch

/**
 * Rindle Works × ORVA About Us Portfolio Screen (Master Frontend Build Directive §4 & §5).
 *
 * Nine art-directed portfolio scenes progressively constructed in place by the deterministic
 * 16-agent Purple & Vermilion Agentic Build system (zero opening ORVA text/glow splash):
 * - Scene 01: Studio Identity Hero (`THE WORK DOESN'T FIT IN A SCREEN.`)
 * - Scene 02: Point of View beside monochrome editorial photography
 * - Scene 03: Oversized Philosophy Statement (`THE SCREEN IS SMALL. / THE WORK ISN'T.`)
 * - Scene 04: Five Principles presented as ZLL-inspired dramatic chapter scenes
 * - Scene 05: Selected Work / ORVA Case 001 + interactive horizontal product rail
 * - Scene 06: Two-column Product Concerns & Engineering Commitments split
 * - Scene 07: Asymmetric Visual Field Notes image mosaic
 * - Scene 08: Deep Dive / ORVA horizontal feature row
 * - Scene 09: Settings-driven Contact + `RINDLE WORKS` film-end closing + Shared Apothecary Frieze
 */
@Composable
fun AboutUsScreen(
  state: AboutShowcaseUiState,
  reducedMotion: Boolean,
  onEvent: (ShowcaseUiEvent) -> Unit,
  modifier: Modifier = Modifier,
) {
  val scrollState = rememberScrollState()
  val scope = rememberCoroutineScope()
  val density = LocalDensity.current
  val lifecycleOwner = LocalLifecycleOwner.current

  val controller =
    remember(scrollState) {
      AgenticBuildController(scrollState = scrollState, reducedMotion = reducedMotion)
    }
  SideEffect { controller.updateReducedMotion(reducedMotion) }

  var viewportHeightPx by remember { mutableFloatStateOf(1600f) }
  var manualScrollEpoch by remember { mutableIntStateOf(0) }

  DisposableEffect(lifecycleOwner, controller) {
    controller.onLifecyclePaused(
      !lifecycleOwner.lifecycle.currentState.isAtLeast(Lifecycle.State.RESUMED),
    )
    val observer = LifecycleEventObserver { _, event ->
      when (event) {
        Lifecycle.Event.ON_PAUSE, Lifecycle.Event.ON_STOP -> controller.onLifecyclePaused(true)
        Lifecycle.Event.ON_RESUME -> controller.onLifecyclePaused(false)
        else -> Unit
      }
    }
    lifecycleOwner.lifecycle.addObserver(observer)
    onDispose {
      controller.onLifecyclePaused(true)
      lifecycleOwner.lifecycle.removeObserver(observer)
    }
  }

  LaunchedEffect(controller) {
    controller.runOrchestrator(this)
  }

  val scrollProgress =
    if (scrollState.maxValue > 0) {
      (scrollState.value.toFloat() / scrollState.maxValue.toFloat()).coerceIn(0f, 1f)
    } else {
      0f
    }

  val palette = currentShowcasePalette()
  CompositionLocalProvider(LocalAgenticController provides controller) {
    Box(
      modifier =
        modifier
          .fillMaxSize()
          .background(palette.canvasDeep)
          .onGloballyPositioned { coords ->
            controller.stageRootTopInRootPx = coords.positionInRoot().y
          }
          .onSizeChanged { size ->
            viewportHeightPx = size.height.toFloat().coerceAtLeast(1f)
            controller.onViewportSized(
              widthPx = size.width.toFloat(),
              heightPx = size.height.toFloat(),
              density = density.density,
            )
          }
          .pointerInput(controller) {
            val touchSlopPx = viewConfiguration.touchSlop
            awaitEachGesture {
              val down = awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
              var gestureAxis = AboutGestureAxis.UNDECIDED
              controller.visitorTouchContentPos =
                Offset(down.position.x, down.position.y + scrollState.value.toFloat())
              try {
                while (true) {
                  val event = awaitPointerEvent(pass = PointerEventPass.Initial)
                  val active = event.changes.firstOrNull { it.id == down.id }
                  if (active != null && active.pressed) {
                    if (gestureAxis == AboutGestureAxis.UNDECIDED) {
                      gestureAxis =
                        classifyAboutGestureAxis(
                          deltaX = active.position.x - down.position.x,
                          deltaY = active.position.y - down.position.y,
                          touchSlopPx = touchSlopPx,
                        )
                      if (gestureAxis == AboutGestureAxis.VERTICAL) {
                        controller.onUserManualScroll()
                        manualScrollEpoch++
                      }
                    }
                    controller.visitorTouchContentPos =
                      Offset(active.position.x, active.position.y + scrollState.value.toFloat())
                  } else {
                    break
                  }
                }
              } finally {
                controller.visitorTouchContentPos = null
              }
            }
          },
    ) {
      Column(
        modifier =
          Modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(bottom = 104.dp)
            .testTag("about_scroll_container"),
      ) {
        // Scene 01 — Studio Identity Hero (with zll.me scroll parallax scale-up & fade)
        Scene01StudioHero(
          state = state,
          viewportHeightPx = viewportHeightPx,
          reducedMotion = reducedMotion,
        )

        // Scene 02 — Who We Are / Point of View
        Scene02PointOfView(language = state.language)

        // ZLL-inspired -1.8° Tilted Dual-Track Kinetic Ribbon (solid left / hollow stroke right)
        TiltedDualMarqueeRibbon(language = state.language, reducedMotion = reducedMotion)

        // Scene 03 — Philosophy Statement (scroll-driven editorial word illumination)
        Scene03PhilosophyStatement(
          language = state.language,
          viewportHeightPx = viewportHeightPx,
          reducedMotion = reducedMotion,
        )

        // Scene 04 — Five Principles (scroll-scrubbed, keyboard-accessible editorial chapters)
        Scene04PrincipleChapters(
          language = state.language,
          viewportHeightPx = viewportHeightPx,
          reducedMotion = reducedMotion,
          manualScrollEpoch = manualScrollEpoch,
        )

        // Scene 05 — Selected Work / ORVA Case 001 + Horizontal Rail
        Scene05SelectedWorkOrva(language = state.language)

        // Scene 06 — Product Concerns & Engineering Commitments Split
        Scene06ProductAndEngineeringSplit(language = state.language)

        // Scene 07 — Asymmetric Field Notes Image Mosaic
        Scene07FieldNotesMosaic(language = state.language)

        // Scene 08 — Deep Dive / ORVA Feature Row
        Scene08DeepDiveOrva(
          language = state.language,
          reducedMotion = reducedMotion,
          onExploreOrva = { onEvent(ShowcaseUiEvent.StartBilling) },
        )

        // Scene 09 — Settings-Driven Contact + Film-End `RINDLE WORKS` Closing
        Scene09ContactAndFilmClosing(
          state = state,
          onStartBilling = { onEvent(ShowcaseUiEvent.StartBilling) },
          onBackToHome = { onEvent(ShowcaseUiEvent.BackToHome) },
        )

        // Shared Closing Bar + Scroll-Controlled Monochrome Apothecary Frieze
        OrvaClosingFriezeSection(
          appVersion = state.appVersion,
          language = state.language,
          isAboutScreen = true,
          reducedMotion = reducedMotion,
          viewportHeightPx = viewportHeightPx,
          onStartBilling = { onEvent(ShowcaseUiEvent.StartBilling) },
          onSecondaryNav = { onEvent(ShowcaseUiEvent.BackToHome) },
          onBackToTop = {
            scope.launch {
              controller.onUserManualScroll()
              scrollState.animateScrollTo(0)
            }
          },
          friezeModifier = Modifier.agenticNode(id = "about_frieze_media", kind = LayerKind.MEDIA),
        )
      }

      // Top 1.5dp Vermilion-to-Violet editorial scroll hairline
      Box(
        modifier =
          Modifier
            .align(Alignment.TopStart)
            .fillMaxWidth(scrollProgress)
            .height(1.5.dp)
            .background(
              Brush.horizontalGradient(
                listOf(OrvaShowcaseColors.AccentVermilion, OrvaShowcaseColors.AccentViolet),
              )
            ),
      )

      // Live Agentic Build Overlay Canvas (draw-phase only, touches pass through cleanly)
      AgenticOverlayCanvas(
        controller = controller,
        modifier = Modifier.matchParentSize(),
      )

      // Floating bottom Agentic Build HUD
      AgenticHudBar(
        controller = controller,
        language = state.language,
        modifier = Modifier.align(Alignment.BottomCenter),
      )
    }
  }
}

@Composable
private fun Scene01StudioHero(
  state: AboutShowcaseUiState,
  viewportHeightPx: Float,
  reducedMotion: Boolean,
) {
  val palette = currentShowcasePalette()
  var topInWindowPx by remember { mutableFloatStateOf(0f) }
  Column(
    modifier =
      Modifier
        .fillMaxWidth()
        .widthIn(max = 960.dp)
        .padding(horizontal = 24.dp, vertical = 32.dp)
        .onGloballyPositioned { coords -> topInWindowPx = coords.positionInWindow().y }
        .graphicsLayer {
          if (!reducedMotion && topInWindowPx < 0f && viewportHeightPx > 1f) {
            val exitP = (-topInWindowPx / (viewportHeightPx * 0.85f)).coerceIn(0f, 1f)
            val s = 1f + exitP * 0.06f
            scaleX = s
            scaleY = s
            alpha = (1f - exitP * 0.72f).coerceIn(0.28f, 1f)
          }
        }
        .agenticNode(id = "about_hero_container", kind = LayerKind.CONTAINER),
    verticalArrangement = Arrangement.spacedBy(20.dp),
  ) {
    Row(
      modifier =
        Modifier
          .fillMaxWidth()
          .agenticNode(id = "about_hero_meta", kind = LayerKind.TEXT, parentId = "about_hero_container"),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Text(
        text = OrvaShowcaseCopy.aboutMetaLeft(state.language),
        fontFamily = OrvaShowcaseFonts.mono(state.language),
        fontSize = 10.5.sp,
        letterSpacing = 1.6.sp,
        color = OrvaShowcaseColors.AccentVermilion,
        modifier = Modifier.agenticNode(
          id = "about_hero_meta_brand",
          kind = LayerKind.TEXT,
          parentId = "about_hero_meta",
        ),
      )
      Text(
        text = OrvaShowcaseCopy.aboutHeroSceneIndex(state.language),
        fontFamily = OrvaShowcaseFonts.mono(state.language),
        fontSize = 10.5.sp,
        letterSpacing = 1.0.sp,
        color = OrvaShowcaseColors.InkMuted,
        modifier = Modifier.agenticNode(
          id = "about_hero_meta_scene_index",
          kind = LayerKind.TEXT,
          parentId = "about_hero_meta",
        ).testTag("about_hero_scene_index"),
      )
    }

    BoxWithConstraints(modifier = Modifier.fillMaxWidth()) {
      val heroHeadlineSize =
        when {
          maxWidth < 380.dp -> 46.sp
          maxWidth < 440.dp -> 52.sp
          maxWidth < 640.dp -> 60.sp
          else -> 72.sp
        }
      Text(
        text = OrvaShowcaseCopy.aboutHeadline(state.language),
        onTextLayout = rememberAgenticTextLayoutHandler("about_hero_headline"),
        fontFamily = OrvaShowcaseFonts.display(state.language),
        fontWeight = FontWeight.Bold,
        fontSize = heroHeadlineSize,
        lineHeight = heroHeadlineSize,
        letterSpacing = (-1.4).sp,
        color = OrvaShowcaseColors.InkPrimary,
        modifier =
          Modifier
            .agenticNode(id = "about_hero_headline", kind = LayerKind.TEXT, parentId = "about_hero_container")
            .testTag("about_hero_headline"),
      )
    }

    Text(
      text = OrvaShowcaseCopy.aboutLead(state.language),
      onTextLayout = rememberAgenticTextLayoutHandler("about_hero_lead"),
      fontFamily = OrvaShowcaseFonts.body(state.language),
      fontSize = 17.sp,
      lineHeight = 26.sp,
      color = OrvaShowcaseColors.InkSecondary,
      modifier =
        Modifier.agenticNode(
          id = "about_hero_lead",
          kind = LayerKind.TEXT,
          parentId = "about_hero_container",
        ),
    )

    Box(
      modifier =
        Modifier
          .fillMaxWidth()
          .height(210.dp)
          .border(1.dp, OrvaShowcaseColors.Hairline)
          .agenticNode(id = "about_hero_media", kind = LayerKind.MEDIA, parentId = "about_hero_container"),
    ) {
      Image(
        painter = painterResource(id = R.drawable.editorial_studio_workbench),
        contentDescription = OrvaShowcaseCopy.aboutHeroArtworkDescription(state.language),
        contentScale = ContentScale.Crop,
        modifier = Modifier.fillMaxSize().testTag("about_hero_artwork"),
      )
      Text(
        text = OrvaShowcaseCopy.aboutHeroVersionLabel(state.appVersion, state.language),
        fontFamily = OrvaShowcaseFonts.mono(state.language),
        fontSize = 9.5.sp,
        letterSpacing = 1.0.sp,
        color = OrvaShowcaseColors.InkPrimary.copy(alpha = 0.85f),
        modifier =
          Modifier
            .align(Alignment.BottomStart)
            .background(OrvaShowcaseColors.CanvasDeep.copy(alpha = 0.78f))
            .agenticNode(
              id = "about_hero_media_version",
              kind = LayerKind.TEXT,
              parentId = "about_hero_media",
            )
            .testTag("about_hero_version_label")
            .padding(horizontal = 10.dp, vertical = 5.dp),
      )
    }
  }
}

@Composable
private fun Scene02PointOfView(language: AppLanguage) {
  Column(
    modifier =
      Modifier
        .fillMaxWidth()
        .agenticNode(id = "about_pov_container", kind = LayerKind.CONTAINER),
  ) {
    HorizontalDivider(
      thickness = 1.dp,
      color = OrvaShowcaseColors.Hairline,
      modifier = Modifier.agenticNode(id = "about_pov_rule", kind = LayerKind.LINE, parentId = "about_pov_container"),
    )

    BoxWithConstraints(
      modifier =
        Modifier
          .fillMaxWidth()
          .widthIn(max = 960.dp)
          .align(Alignment.CenterHorizontally)
          .padding(horizontal = 24.dp, vertical = 40.dp),
    ) {
      val wide = maxWidth >= 660.dp
      if (wide) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(28.dp),
          verticalAlignment = Alignment.Top,
        ) {
          PovMediaCard(language = language, modifier = Modifier.weight(0.42f))
          PovCopyColumn(language = language, modifier = Modifier.weight(0.58f))
        }
      } else {
        Column(verticalArrangement = Arrangement.spacedBy(20.dp)) {
          PovCopyColumn(language = language)
          PovMediaCard(language = language, modifier = Modifier.fillMaxWidth())
        }
      }
    }
  }
}

@Composable
private fun PovMediaCard(language: AppLanguage, modifier: Modifier = Modifier) {
  Box(
    modifier =
      modifier
        .height(230.dp)
        .border(1.dp, OrvaShowcaseColors.Hairline)
        .agenticNode(id = "about_pov_media", kind = LayerKind.MEDIA, parentId = "about_pov_container"),
  ) {
    Image(
      painter = painterResource(id = R.drawable.editorial_apothecary_shelves),
      contentDescription = OrvaShowcaseCopy.aboutPovImageDescription(language),
      contentScale = ContentScale.Crop,
      modifier = Modifier.fillMaxSize().testTag("about_pov_media_image"),
    )
    Text(
      text = OrvaShowcaseCopy.aboutPovFigureCaption(language),
      fontFamily = OrvaShowcaseFonts.mono(language),
      fontSize = 9.5.sp,
      letterSpacing = 0.8.sp,
      color = OrvaShowcaseColors.InkPrimary.copy(alpha = 0.8f),
      modifier =
        Modifier
          .align(Alignment.BottomStart)
          .background(OrvaShowcaseColors.CanvasDeep.copy(alpha = 0.78f))
          .agenticNode(id = "about_pov_media_caption", kind = LayerKind.TEXT, parentId = "about_pov_media")
          .testTag("about_pov_media_caption")
          .padding(horizontal = 8.dp, vertical = 4.dp),
    )
  }
}

@Composable
private fun PovCopyColumn(language: AppLanguage, modifier: Modifier = Modifier) {
  Column(modifier = modifier, verticalArrangement = Arrangement.spacedBy(14.dp)) {
    Text(
      text = OrvaShowcaseCopy.aboutStoryLabel(language),
      fontFamily = OrvaShowcaseFonts.mono(language),
      fontSize = 11.sp,
      letterSpacing = 1.6.sp,
      color = OrvaShowcaseColors.AccentVermilion,
      modifier =
        Modifier.agenticNode(
          id = "about_pov_label",
          kind = LayerKind.TEXT,
          parentId = "about_pov_container",
        ),
    )
    Text(
      text = OrvaShowcaseCopy.aboutStoryParagraph1(language),
      onTextLayout = rememberAgenticTextLayoutHandler("about_pov_p1"),
      fontFamily = OrvaShowcaseFonts.body(language),
      fontSize = 16.5.sp,
      lineHeight = 26.sp,
      color = OrvaShowcaseColors.InkPrimary,
      modifier =
        Modifier.agenticNode(
          id = "about_pov_p1",
          kind = LayerKind.TEXT,
          parentId = "about_pov_container",
        ),
    )
    Text(
      text = OrvaShowcaseCopy.aboutStoryParagraph2(language),
      onTextLayout = rememberAgenticTextLayoutHandler("about_pov_p2"),
      fontFamily = OrvaShowcaseFonts.body(language),
      fontSize = 15.sp,
      lineHeight = 24.sp,
      color = OrvaShowcaseColors.InkSecondary,
      modifier =
        Modifier.agenticNode(
          id = "about_pov_p2",
          kind = LayerKind.TEXT,
          parentId = "about_pov_container",
        ),
    )
  }
}

/**
 * Scene 03 — Full Editorial Philosophy Statement (Master Directive §4.1 Scene 03).
 */
@Composable
private fun Scene03PhilosophyStatement(
  language: AppLanguage,
  viewportHeightPx: Float,
  reducedMotion: Boolean,
) {
  val palette = currentShowcasePalette()
  var bandTopPx by remember { mutableFloatStateOf(viewportHeightPx) }
  var bandHeightPx by remember { mutableFloatStateOf(420f) }
  val revealProgress =
    if (reducedMotion || viewportHeightPx <= 1f) {
      1f
    } else {
      val enterStart = viewportHeightPx * 0.90f
      val enterEnd = viewportHeightPx * 0.22f
      ((enterStart - bandTopPx) / (enterStart - enterEnd + bandHeightPx * 0.35f).coerceAtLeast(1f)).coerceIn(0f, 1f)
    }

  Box(
    modifier =
      Modifier
        .fillMaxWidth()
        .background(palette.canvasSecondary)
        .clipToBounds()
        .onGloballyPositioned { coords ->
          bandTopPx = coords.positionInWindow().y
          bandHeightPx = coords.size.height.toFloat().coerceAtLeast(1f)
        }
        .agenticNode(id = "about_philosophy_container", kind = LayerKind.CONTAINER),
  ) {
    HorizontalDivider(
      thickness = 1.dp,
      color = OrvaShowcaseColors.Hairline,
      modifier = Modifier.align(Alignment.TopCenter),
    )

    // Giant low-contrast outlined backdrop lettering
    Text(
      text = OrvaShowcaseCopy.philosophyBackdrop(language),
      style =
        TextStyle(
          fontFamily = OrvaShowcaseFonts.display(language),
          fontWeight = FontWeight.Bold,
          fontSize = if (language == AppLanguage.Bengali) 88.sp else 110.sp,
          letterSpacing = if (language == AppLanguage.Bengali) 0.sp else (-3).sp,
          color = OrvaShowcaseColors.InkPrimary.copy(alpha = 0.045f),
          drawStyle = Stroke(width = 2.5f),
        ),
      maxLines = 1,
      softWrap = false,
      modifier = Modifier.align(Alignment.Center).agenticNode(
        id = "about_philosophy_backdrop",
        kind = LayerKind.TEXT,
        parentId = "about_philosophy_container",
      ),
    )

    Column(
      modifier =
        Modifier
          .fillMaxWidth()
          .widthIn(max = 960.dp)
          .align(Alignment.Center)
          .padding(horizontal = 24.dp, vertical = 56.dp),
      verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
      Text(
        text = OrvaShowcaseCopy.philosophyEyebrow(language),
        fontFamily = OrvaShowcaseFonts.mono(language),
        fontSize = 10.5.sp,
        letterSpacing = 0.8.sp,
        color = OrvaShowcaseColors.InkMuted,
        modifier = Modifier.agenticNode(
          id = "about_philosophy_eyebrow",
          kind = LayerKind.TEXT,
          parentId = "about_philosophy_container",
        ).testTag("about_philosophy_eyebrow"),
      )
      Column(
        modifier =
          Modifier.agenticNode(
            id = "about_philosophy_headline_group",
            kind = LayerKind.CONTAINER,
            parentId = "about_philosophy_container",
          ),
      ) {
        val leadText = remember(language) { OrvaShowcaseCopy.philosophyLead(language) }
        val accentText = remember(language) { OrvaShowcaseCopy.philosophyAccent(language) }
        Text(
          text = leadText,
          fontFamily = OrvaShowcaseFonts.display(language),
          fontWeight = FontWeight.Bold,
          fontSize = 36.sp,
          lineHeight = 40.sp,
          letterSpacing = (-1.1).sp,
          color = palette.inkPrimary,
          onTextLayout = rememberAgenticTextLayoutHandler("about_philosophy_lead"),
          modifier =
            Modifier
              .graphicsLayer { alpha = revealProgress }
              .agenticNode(
                id = "about_philosophy_lead",
                kind = LayerKind.TEXT,
                parentId = "about_philosophy_headline_group",
              ),
        )
        Text(
          text = accentText,
          fontFamily = OrvaShowcaseFonts.display(language),
          fontWeight = FontWeight.Bold,
          fontSize = 36.sp,
          lineHeight = 40.sp,
          letterSpacing = (-1.1).sp,
          color = OrvaShowcaseColors.AccentVermilion,
          onTextLayout = rememberAgenticTextLayoutHandler("about_philosophy_accent"),
          modifier =
            Modifier
              .graphicsLayer { alpha = revealProgress }
              .agenticNode(
                id = "about_philosophy_accent",
                kind = LayerKind.TEXT,
                parentId = "about_philosophy_headline_group",
              ),
        )
      }
      val supportText = remember(language) { OrvaShowcaseCopy.philosophySupport(language) }
      Text(
        text = supportText,
        fontFamily = OrvaShowcaseFonts.body(language),
        fontSize = 15.5.sp,
        lineHeight = 25.sp,
        color = palette.inkSecondary,
        onTextLayout = rememberAgenticTextLayoutHandler("about_philosophy_body"),
        modifier =
          Modifier
            .widthIn(max = 560.dp)
            .graphicsLayer { alpha = revealProgress }
            .agenticNode(
              id = "about_philosophy_body",
              kind = LayerKind.TEXT,
              parentId = "about_philosophy_container",
            ),
      )
    }

    HorizontalDivider(
      thickness = 1.dp,
      color = OrvaShowcaseColors.Hairline,
      modifier = Modifier.align(Alignment.BottomCenter),
    )
  }
}

/**
 * Scene 04 — Five Principles presented as ZLL-inspired Dramatic Chapter Scenes
 * (Master Directive §4.1 Scene 04 & §7.3).
 */
@Composable
private fun Scene04PrincipleChapters(
  language: AppLanguage,
  viewportHeightPx: Float,
  reducedMotion: Boolean,
  manualScrollEpoch: Int,
) {
  val palette = currentShowcasePalette()
  val principles = remember(language) { OrvaShowcaseCopy.aboutPrinciples(language) }
  val chapterStageHeight =
    with(LocalDensity.current) { viewportHeightPx.toDp() }
      .times(0.62f)
      .coerceIn(400.dp, 560.dp)
  var selectedIndex by remember { mutableStateOf(0) }
  var userPinnedChapter by remember { mutableStateOf(false) }

  // A manual finger scroll releases a chapter pinned by the selector so scroll-scrubbing resumes.
  LaunchedEffect(manualScrollEpoch) {
    if (manualScrollEpoch > 0) userPinnedChapter = false
  }

  // One stable chapter stage; only its copy changes as the reader moves between principles.
  val activePrinciple = principles[selectedIndex.coerceIn(0, principles.lastIndex)]

  Column(
    modifier =
      Modifier
        .fillMaxWidth()
        .widthIn(max = 960.dp)
        .padding(horizontal = 24.dp, vertical = 44.dp)
        .onGloballyPositioned { coords ->
          // Scroll-scrub chapters smoothly as the band travels through the viewport (yields on manual tap)
          if (!reducedMotion && !userPinnedChapter && viewportHeightPx > 1f) {
            val topY = coords.positionInWindow().y
            val heightPx = coords.size.height.toFloat().coerceAtLeast(1f)
            val scrub = ((viewportHeightPx * 0.72f - topY) / (heightPx + viewportHeightPx * 0.25f)).coerceIn(0f, 0.999f)
            val scrubbedIdx = (scrub * principles.size).toInt().coerceIn(0, principles.lastIndex)
            if (scrubbedIdx != selectedIndex) {
              selectedIndex = scrubbedIdx
            }
          }
        }
        .agenticNode(id = "about_principles_container", kind = LayerKind.CONTAINER),
    verticalArrangement = Arrangement.spacedBy(20.dp),
  ) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Text(
        text = OrvaShowcaseCopy.aboutPrinciplesLabel(language),
        fontFamily = OrvaShowcaseFonts.mono(language),
        fontSize = 11.sp,
        letterSpacing = 1.6.sp,
        color = OrvaShowcaseColors.AccentVermilion,
        modifier =
          Modifier.agenticNode(
            id = "about_principles_heading",
            kind = LayerKind.TEXT,
            parentId = "about_principles_container",
          ),
      )
      Text(
        text = OrvaShowcaseCopy.principleProgress(selectedIndex + 1, principles.size, language),
        fontFamily = OrvaShowcaseFonts.mono(language),
        fontSize = 11.sp,
        letterSpacing = 0.8.sp,
        color = OrvaShowcaseColors.InkMuted,
        modifier = Modifier.agenticNode(
          id = "about_principle_progress_top",
          kind = LayerKind.TEXT,
          parentId = "about_principles_container",
        ).testTag("about_principle_progress"),
      )
    }

    // Accessible 01..05 chapter selector strip (preserves about_wave_node_1..5 testTags)
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
    ) {
      principles.forEachIndexed { idx, principle ->
        val interaction = remember { MutableInteractionSource() }
        val focused by interaction.collectIsFocusedAsState()
        LaunchedEffect(focused) {
          if (focused) {
            userPinnedChapter = true
            selectedIndex = idx
          }
        }
        val isSelected = idx == selectedIndex
        Box(
          modifier =
            Modifier
              .minimumInteractiveComponentSize()
              .focusable(interactionSource = interaction)
              .agenticNode(
                id = "about_principle_selector_${idx + 1}",
                kind = LayerKind.CONTAINER,
                parentId = "about_principles_container",
              )
              .semantics {
                selected = isSelected
                contentDescription = principle.title
              }
              .border(
                width = 1.dp,
                color = if (isSelected) OrvaShowcaseColors.AccentVermilion else OrvaShowcaseColors.Hairline,
              )
              .background(if (isSelected) OrvaShowcaseColors.AccentVermilionWash else Color.Transparent)
              .clickable(
                interactionSource = interaction,
                indication = null,
                role = Role.Button,
                onClick = { userPinnedChapter = true; selectedIndex = idx },
              )
              .padding(horizontal = 12.dp, vertical = 8.dp)
              .testTag("about_wave_node_${idx + 1}"),
          contentAlignment = Alignment.Center,
        ) {
          Text(
            text = principle.number,
            fontFamily = OrvaShowcaseFonts.mono(language),
            fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Normal,
            fontSize = 11.5.sp,
            color = if (isSelected) OrvaShowcaseColors.AccentVermilion else OrvaShowcaseColors.InkMuted,
          )
        }
      }
    }

    // ZLL-style full-height single-focus editorial chapter stage (borderless dark/paper grid, giant 156sp hollow numeral)
    Box(
      modifier =
        Modifier
          .fillMaxWidth()
          .height(chapterStageHeight)
          .clipToBounds()
          .agenticNode(
            id = "about_principle_active_panel",
            kind = LayerKind.CONTAINER,
            parentId = "about_principles_container",
          )
          .testTag("about_principle_card_${selectedIndex + 1}"),
    ) {
      // Giant 156sp low-contrast outlined chapter numeral centered behind headline
      Text(
        text = activePrinciple.number,
        style =
          TextStyle(
            fontFamily = OrvaShowcaseFonts.display(language),
            fontWeight = FontWeight.Bold,
            fontSize = if (language == AppLanguage.Bengali) 136.sp else 156.sp,
            letterSpacing = if (language == AppLanguage.Bengali) 0.sp else (-5).sp,
            color = OrvaShowcaseColors.AccentVermilion.copy(alpha = 0.14f),
            drawStyle = Stroke(width = 2.6f),
          ),
        modifier = Modifier.align(Alignment.Center),
      )

      // Slim vertical chapter progress scrub rail on right edge
      Box(
        modifier =
          Modifier
            .align(Alignment.CenterEnd)
            .width(2.dp)
            .fillMaxHeight(0.72f)
            .background(OrvaShowcaseColors.Hairline),
      ) {
        Box(
          modifier =
            Modifier
              .align(Alignment.TopCenter)
              .fillMaxWidth()
              .fillMaxHeight((selectedIndex + 1).toFloat() / principles.size.toFloat())
              .background(OrvaShowcaseColors.AccentVermilion),
        )
      }

      Column(
        modifier = Modifier.align(Alignment.Center).padding(horizontal = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(14.dp),
      ) {
        Text(
          text = OrvaShowcaseCopy.principleLabel(activePrinciple.number, language),
          fontFamily = OrvaShowcaseFonts.mono(language),
          fontSize = 10.5.sp,
          letterSpacing = 0.8.sp,
          color = OrvaShowcaseColors.AccentVermilion,
          modifier = Modifier.agenticNode(
            id = "about_principle_active_label",
            kind = LayerKind.TEXT,
            parentId = "about_principle_active_panel",
          ).testTag("about_principle_active_label"),
        )
        Text(
          text = activePrinciple.title,
          onTextLayout = rememberAgenticTextLayoutHandler("about_principle_active_title"),
          fontFamily = OrvaShowcaseFonts.display(language),
          fontWeight = FontWeight.Bold,
          fontSize = 32.sp,
          lineHeight = 35.sp,
          letterSpacing = (-1).sp,
          textAlign = TextAlign.Center,
          color = OrvaShowcaseColors.InkPrimary,
          modifier =
            Modifier.agenticNode(
              id = "about_principle_active_title",
              kind = LayerKind.TEXT,
              parentId = "about_principle_active_panel",
            ),
        )
        Text(
          text = activePrinciple.description,
          onTextLayout = rememberAgenticTextLayoutHandler("about_principle_active_desc"),
          fontFamily = OrvaShowcaseFonts.body(language),
          fontSize = 15.sp,
          lineHeight = 23.sp,
          textAlign = TextAlign.Center,
          modifier =
            Modifier
              .widthIn(max = 420.dp)
              .agenticNode(
                id = "about_principle_active_desc",
                kind = LayerKind.TEXT,
                parentId = "about_principle_active_panel",
              ),
        )
      }

      Text(
        text = OrvaShowcaseCopy.principleProgress(selectedIndex + 1, principles.size, language),
        fontFamily = OrvaShowcaseFonts.mono(language),
        fontSize = 11.sp,
        letterSpacing = 0.8.sp,
        color = OrvaShowcaseColors.InkMuted,
        modifier = Modifier.align(Alignment.BottomStart).agenticNode(
          id = "about_principle_progress_bottom",
          kind = LayerKind.TEXT,
          parentId = "about_principle_active_panel",
        ).testTag("about_principle_progress_bottom"),
      )
    }
  }
}

@Composable
private fun Scene05SelectedWorkOrva(language: AppLanguage) {
  val railItems = remember(language) { OrvaShowcaseCopy.orvaCaseRail(language) }

  Column(
    modifier =
      Modifier
        .fillMaxWidth()
        .background(OrvaShowcaseColors.CanvasSecondary)
        .agenticNode(id = "about_selected_orva_container", kind = LayerKind.CONTAINER),
  ) {
    HorizontalDivider(thickness = 1.dp, color = OrvaShowcaseColors.Hairline)

    Column(
      modifier =
        Modifier
          .fillMaxWidth()
          .widthIn(max = 960.dp)
          .align(Alignment.CenterHorizontally)
          .padding(horizontal = 24.dp, vertical = 44.dp),
      verticalArrangement = Arrangement.spacedBy(18.dp),
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Text(
          text = OrvaShowcaseCopy.selectedWorkEyebrow(language),
          fontFamily = OrvaShowcaseFonts.mono(language),
          fontSize = 10.5.sp,
          letterSpacing = 1.6.sp,
          color = OrvaShowcaseColors.AccentVermilion,
        )
        Text(
          text = OrvaShowcaseCopy.flagshipStateLabel(language),
          fontFamily = OrvaShowcaseFonts.mono(language),
          fontSize = 10.sp,
          letterSpacing = 1.2.sp,
          color = OrvaShowcaseColors.AccentVioletSoft,
        )
      }

      Text(
        text = OrvaShowcaseCopy.selectedWorkStatement(language),
        onTextLayout = rememberAgenticTextLayoutHandler("about_selected_orva_headline"),
        fontFamily = OrvaShowcaseFonts.display(language),
        fontWeight = FontWeight.Bold,
        fontSize = 32.sp,
        lineHeight = 36.sp,
        letterSpacing = (-0.8).sp,
        color = OrvaShowcaseColors.InkPrimary,
        modifier =
          Modifier.agenticNode(
            id = "about_selected_orva_headline",
            kind = LayerKind.TEXT,
            parentId = "about_selected_orva_container",
          ),
      )

      Text(
        text = OrvaShowcaseCopy.selectedWorkBody1(language),
        onTextLayout = rememberAgenticTextLayoutHandler("about_selected_orva_p1"),
        fontFamily = OrvaShowcaseFonts.body(language),
        fontSize = 15.5.sp,
        lineHeight = 24.sp,
        color = OrvaShowcaseColors.InkSecondary,
        modifier =
          Modifier.agenticNode(
            id = "about_selected_orva_p1",
            kind = LayerKind.TEXT,
            parentId = "about_selected_orva_container",
          ),
      )

      Text(
        text = OrvaShowcaseCopy.selectedWorkBody2(language),
        fontFamily = OrvaShowcaseFonts.body(language),
        fontSize = 14.5.sp,
        lineHeight = 23.sp,
        color = OrvaShowcaseColors.InkMuted,
      )

      // Horizontal scrollable portrait rail of real ORVA product areas (ZLL §7.4 cue)
      Row(
        modifier =
          Modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState())
            .padding(top = 8.dp)
            .testTag("about_selected_work_rail"),
        horizontalArrangement = Arrangement.spacedBy(14.dp),
      ) {
        railItems.forEach { item ->
          OrvaRailCard(item = item, language = language)
        }
      }
    }

    HorizontalDivider(thickness = 1.dp, color = OrvaShowcaseColors.Hairline)
  }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun OrvaRailCard(item: OrvaCaseRailItem, language: AppLanguage) {
  Box(
    modifier =
      Modifier
        .width(264.dp)
        .height(316.dp)
        .border(1.dp, OrvaShowcaseColors.Hairline)
        .background(OrvaShowcaseColors.CanvasDeep)
        .clipToBounds()
        .agenticNode(
          id = "about_case_card_${item.index}",
          kind = LayerKind.CONTAINER,
          parentId = "about_selected_orva_container",
        ),
  ) {
    Column(modifier = Modifier.fillMaxSize()) {
      // Image-led case cover; the asset is editorial artwork, not a product screenshot.
      Box(
        modifier =
          Modifier
            .fillMaxWidth()
            .height(142.dp)
            .clipToBounds()
            .agenticNode(
              id = "about_case_art_${item.index}",
              kind = LayerKind.MEDIA,
              parentId = "about_case_card_${item.index}",
            ),
      ) {
        Image(
          painter = painterResource(id = item.imageResId),
          contentDescription = null,
          contentScale = ContentScale.Crop,
          modifier = Modifier.fillMaxSize(),
        )
        Box(
          modifier =
            Modifier
              .fillMaxSize()
              .background(
                Brush.verticalGradient(
                  0f to OrvaShowcaseColors.CanvasDeep.copy(alpha = 0.62f),
                  0.52f to Color.Transparent,
                  1f to OrvaShowcaseColors.CanvasDeep.copy(alpha = 0.78f),
                )
              ),
        )
        Text(
          text = OrvaShowcaseCopy.caseCardCode(item.code, language),
          fontFamily = OrvaShowcaseFonts.mono(language),
          fontSize = 9.5.sp,
          letterSpacing = 1.35.sp,
          color = OrvaShowcaseColors.AccentVermilion,
          modifier = Modifier.align(Alignment.TopStart).padding(12.dp).agenticNode(
            id = "about_case_code_${item.index}",
            kind = LayerKind.TEXT,
            parentId = "about_case_art_${item.index}",
          ).testTag("about_case_code_${item.index}"),
        )
        Text(
          text = OrvaShowcaseCopy.caseCardDisplayIndex(item.index, language),
          style =
            TextStyle(
              fontFamily = OrvaShowcaseFonts.display(language),
              fontWeight = FontWeight.Bold,
              fontSize = 112.sp,
              color = OrvaShowcaseColors.InkPrimary.copy(alpha = 0.13f),
              drawStyle = Stroke(width = 2.2f),
            ),
          modifier = Modifier.align(Alignment.BottomEnd).padding(end = 9.dp, bottom = (-24).dp).agenticNode(
            id = "about_case_index_${item.index}",
            kind = LayerKind.TEXT,
            parentId = "about_case_art_${item.index}",
          ).testTag("about_case_index_${item.index}"),
        )
      }

      Column(
        modifier = Modifier.weight(1f).fillMaxWidth().padding(horizontal = 15.dp, vertical = 13.dp),
        verticalArrangement = Arrangement.SpaceBetween,
      ) {
        Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
          Text(
            text = item.title,
            fontFamily = OrvaShowcaseFonts.display(language),
            fontWeight = FontWeight.SemiBold,
            onTextLayout = rememberAgenticTextLayoutHandler("about_case_title_${item.index}"),
            fontSize = 19.sp,
            lineHeight = 22.sp,
            color = OrvaShowcaseColors.InkPrimary,
            maxLines = 2,
            modifier =
              Modifier.agenticNode(
                id = "about_case_title_${item.index}",
                kind = LayerKind.TEXT,
                parentId = "about_case_card_${item.index}",
              ),
          )
          Text(
            text = item.summary,
            fontFamily = OrvaShowcaseFonts.body(language),
            onTextLayout = rememberAgenticTextLayoutHandler("about_case_summary_${item.index}"),
            fontSize = 12.5.sp,
            lineHeight = 18.sp,
            color = OrvaShowcaseColors.InkSecondary,
            maxLines = 3,
            modifier =
              Modifier.agenticNode(
                id = "about_case_summary_${item.index}",
                kind = LayerKind.TEXT,
                parentId = "about_case_card_${item.index}",
              ),
          )
        }

        FlowRow(horizontalArrangement = Arrangement.spacedBy(5.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
          item.tags.forEach { tag ->
            Text(
              text = tag,
              fontFamily = OrvaShowcaseFonts.mono(language),
              fontSize = 8.5.sp,
              letterSpacing = 0.8.sp,
              color = OrvaShowcaseColors.InkMuted,
              modifier =
                Modifier
                  .border(1.dp, OrvaShowcaseColors.Hairline)
                  .padding(horizontal = 6.dp, vertical = 3.dp),
            )
          }
        }
      }
    }
  }
}

/**
 * Scene 06 — A two-track editorial system contract: product requirements beside the rules
 * intended to protect them. Every row is its own Agentic Build task, not one opaque text block.
 */
@Composable
private fun Scene06ProductAndEngineeringSplit(language: AppLanguage) {
  val concerns = remember(language) { OrvaShowcaseCopy.productConcerns(language) }
  val commitments = remember(language) { OrvaShowcaseCopy.engineeringCommitments(language) }

  Column(
    modifier =
      Modifier
        .fillMaxWidth()
        .widthIn(max = 960.dp)
        .padding(horizontal = 24.dp, vertical = 48.dp)
        .agenticNode(id = "about_commitments_container", kind = LayerKind.CONTAINER),
    verticalArrangement = Arrangement.spacedBy(16.dp),
  ) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Text(
        text = OrvaShowcaseCopy.architectureEyebrow(language),
        fontFamily = OrvaShowcaseFonts.mono(language),
        fontSize = 10.5.sp,
        letterSpacing = 1.6.sp,
        color = OrvaShowcaseColors.AccentVermilion,
      )
      Text(
        text = OrvaShowcaseCopy.architectureMeta(language),
        fontFamily = OrvaShowcaseFonts.mono(language),
        fontSize = 9.sp,
        letterSpacing = 1.1.sp,
        color = OrvaShowcaseColors.InkMuted,
      )
    }

    Text(
      text = OrvaShowcaseCopy.architectureHeadline(language),
      fontFamily = OrvaShowcaseFonts.display(language),
      fontWeight = FontWeight.Bold,
      fontSize = if (language == AppLanguage.Bengali) 28.sp else 34.sp,
      lineHeight = if (language == AppLanguage.Bengali) 36.sp else 38.sp,
      letterSpacing = if (language == AppLanguage.Bengali) 0.sp else (-1.2).sp,
      color = OrvaShowcaseColors.InkPrimary,
      modifier =
        Modifier
          .widthIn(max = 720.dp)
          .agenticNode(
            id = "about_commitments_headline",
            kind = LayerKind.TEXT,
            parentId = "about_commitments_container",
          )
          .testTag("about_commitments_headline"),
    )

    Text(
      text = OrvaShowcaseCopy.architectureBody(language),
      fontFamily = OrvaShowcaseFonts.body(language),
      fontSize = 14.sp,
      lineHeight = 22.sp,
      color = OrvaShowcaseColors.InkSecondary,
      modifier =
        Modifier
          .widthIn(max = 640.dp)
          .agenticNode(
            id = "about_commitments_intro",
            kind = LayerKind.TEXT,
            parentId = "about_commitments_container",
          ),
    )

    HorizontalDivider(thickness = 1.dp, color = OrvaShowcaseColors.Hairline)

    BoxWithConstraints(modifier = Modifier.fillMaxWidth()) {
      val twoCols = maxWidth >= 640.dp
      if (twoCols) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(28.dp),
          verticalAlignment = Alignment.Top,
        ) {
          CommitmentColumn(
            title = if (language == AppLanguage.Bengali) "প্রোডাক্ট অগ্রাধিকার" else "PRODUCT CONCERNS",
            caption = OrvaShowcaseCopy.productConcernsCaption(language),
            items = concerns,
            accent = OrvaShowcaseColors.AccentVermilion,
            language = language,
            nodeId = "about_commitments_left",
            modifier = Modifier.weight(1f),
          )
          CommitmentColumn(
            title = if (language == AppLanguage.Bengali) "ইঞ্জিনিয়ারিং অঙ্গীকার" else "ENGINEERING COMMITMENTS",
            caption = OrvaShowcaseCopy.engineeringCommitmentsCaption(language),
            items = commitments,
            accent = OrvaShowcaseColors.AccentVioletSoft,
            language = language,
            nodeId = "about_commitments_right",
            modifier = Modifier.weight(1f),
          )
        }
      } else {
        Column(verticalArrangement = Arrangement.spacedBy(28.dp)) {
          CommitmentColumn(
            title = if (language == AppLanguage.Bengali) "প্রোডাক্ট অগ্রাধিকার" else "PRODUCT CONCERNS",
            caption = OrvaShowcaseCopy.productConcernsCaption(language),
            items = concerns,
            accent = OrvaShowcaseColors.AccentVermilion,
            language = language,
            nodeId = "about_commitments_left",
          )
          CommitmentColumn(
            title = if (language == AppLanguage.Bengali) "ইঞ্জিনিয়ারিং অঙ্গীকার" else "ENGINEERING COMMITMENTS",
            caption = OrvaShowcaseCopy.engineeringCommitmentsCaption(language),
            items = commitments,
            accent = OrvaShowcaseColors.AccentVioletSoft,
            language = language,
            nodeId = "about_commitments_right",
          )
        }
      }
    }
  }
}

@Composable
private fun CommitmentColumn(
  title: String,
  caption: String,
  items: List<String>,
  accent: Color,
  language: AppLanguage,
  nodeId: String,
  modifier: Modifier = Modifier,
) {
  Column(
    modifier =
      modifier.agenticNode(
        id = nodeId,
        kind = LayerKind.CONTAINER,
        parentId = "about_commitments_container",
      ),
  ) {
    Row(
      modifier =
        Modifier
          .fillMaxWidth()
          .padding(bottom = 14.dp)
          .agenticNode(id = "${nodeId}_header", kind = LayerKind.CONTAINER, parentId = nodeId),
      horizontalArrangement = Arrangement.spacedBy(10.dp),
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Box(
        modifier =
          Modifier
            .width(3.dp)
            .height(30.dp)
            .background(accent),
      )
      Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
        Text(
          text = title,
          fontFamily = OrvaShowcaseFonts.mono(language),
          fontWeight = FontWeight.SemiBold,
          fontSize = 11.5.sp,
          letterSpacing = 1.2.sp,
          color = accent,
          modifier =
            Modifier.agenticNode(
              id = "${nodeId}_title",
              kind = LayerKind.TEXT,
              parentId = "${nodeId}_header",
            ),
        )
        Text(
          text = caption,
          fontFamily = OrvaShowcaseFonts.mono(language),
          fontSize = 9.sp,
          letterSpacing = 0.8.sp,
          color = OrvaShowcaseColors.InkMuted,
        )
      }
    }

    items.forEachIndexed { idx, line ->
      val rowId = "${nodeId}_row_${idx + 1}"
      Column(
        modifier =
          Modifier
            .fillMaxWidth()
            .agenticNode(id = rowId, kind = LayerKind.CONTAINER, parentId = nodeId),
      ) {
        HorizontalDivider(thickness = 1.dp, color = OrvaShowcaseColors.Hairline)
        Row(
          modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp),
          horizontalArrangement = Arrangement.spacedBy(12.dp),
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Text(
            text = OrvaShowcaseCopy.commitmentRowIndex(idx + 1, language),
            fontFamily = OrvaShowcaseFonts.mono(language),
            fontSize = 17.sp,
            color = accent.copy(alpha = 0.82f),
            modifier = Modifier.width(if (language == AppLanguage.Bengali) 34.dp else 28.dp)
              .agenticNode(id = "${rowId}_index", kind = LayerKind.TEXT, parentId = rowId)
              .testTag("${rowId}_index"),
          )
          Box(
            modifier =
              Modifier
                .width(1.dp)
                .height(30.dp)
                .background(accent.copy(alpha = 0.52f)),
          )
          Text(
            text = line,
            fontFamily = OrvaShowcaseFonts.body(language),
            fontSize = 14.sp,
            lineHeight = 21.sp,
            color = OrvaShowcaseColors.InkPrimary,
            modifier =
              Modifier
                .weight(1f)
                .agenticNode(
                  id = "${rowId}_copy",
                  kind = LayerKind.TEXT,
                  parentId = rowId,
                )
                .testTag("${nodeId}_item_${idx + 1}"),
          )
        }
      }
    }
    HorizontalDivider(thickness = 1.dp, color = OrvaShowcaseColors.Hairline)
  }
}

/**
 * Scene 07 — Asymmetric Field Notes Image Mosaic (Master Directive §4.1 Scene 07 & §7.7).
 */
@Composable
private fun Scene07FieldNotesMosaic(language: AppLanguage) {
  Column(
    modifier =
      Modifier
        .fillMaxWidth()
        .background(OrvaShowcaseColors.CanvasSecondary)
        .agenticNode(id = "about_mosaic_container", kind = LayerKind.CONTAINER),
  ) {
    HorizontalDivider(thickness = 1.dp, color = OrvaShowcaseColors.Hairline)

    Column(
      modifier =
        Modifier
          .fillMaxWidth()
          .widthIn(max = 960.dp)
          .align(Alignment.CenterHorizontally)
          .padding(horizontal = 24.dp, vertical = 44.dp),
      verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Text(
          text = OrvaShowcaseCopy.fieldNotesEyebrow(language),
          fontFamily = OrvaShowcaseFonts.mono(language),
          fontSize = 10.5.sp,
          letterSpacing = 1.6.sp,
          color = OrvaShowcaseColors.AccentVermilion,
          modifier = Modifier.agenticNode(
            id = "about_mosaic_eyebrow",
            kind = LayerKind.TEXT,
            parentId = "about_mosaic_container",
          ),
        )
        Text(
          text = OrvaShowcaseCopy.fieldNotesMeta(language),
          fontFamily = OrvaShowcaseFonts.mono(language),
          fontSize = 9.sp,
          letterSpacing = 1.0.sp,
          color = OrvaShowcaseColors.InkMuted,
          modifier = Modifier.agenticNode(
            id = "about_mosaic_meta",
            kind = LayerKind.TEXT,
            parentId = "about_mosaic_container",
          ),
        )
      }

      Text(
        text = OrvaShowcaseCopy.fieldNotesHeadline(language),
        fontFamily = OrvaShowcaseFonts.display(language),
        fontWeight = FontWeight.Bold,
        fontSize = if (language == AppLanguage.Bengali) 27.sp else 30.sp,
        lineHeight = if (language == AppLanguage.Bengali) 35.sp else 34.sp,
        letterSpacing = if (language == AppLanguage.Bengali) 0.sp else (-0.8).sp,
        color = OrvaShowcaseColors.InkPrimary,
        modifier =
          Modifier
            .widthIn(max = 680.dp)
            .agenticNode(
              id = "about_mosaic_headline",
              kind = LayerKind.TEXT,
              parentId = "about_mosaic_container",
            )
            .testTag("about_mosaic_headline"),
      )

      Text(
        text = OrvaShowcaseCopy.fieldNotesBody(language),
        fontFamily = OrvaShowcaseFonts.body(language),
        fontSize = 13.5.sp,
        lineHeight = 21.sp,
        color = OrvaShowcaseColors.InkSecondary,
        modifier = Modifier.agenticNode(
          id = "about_mosaic_intro",
          kind = LayerKind.TEXT,
          parentId = "about_mosaic_container",
        ),
      )

      BoxWithConstraints(modifier = Modifier.fillMaxWidth()) {
        if (maxWidth >= 680.dp) {
          // Three-column editorial masonry on wide layouts; every image keeps a distinct crop.
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalAlignment = Alignment.Top,
          ) {
            Column(modifier = Modifier.weight(1f)) {
              MosaicTile(
                language = language,
                drawableRes = R.drawable.editorial_apothecary_shelves,
                caption = OrvaShowcaseCopy.fieldNotesBatchCaption(language),
                heightDp = 260,
                nodeId = "about_mosaic_1",
              )
            }
            Column(
              modifier = Modifier.weight(1f),
              verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
              MosaicTile(
                language = language,
                drawableRes = R.drawable.editorial_thermal_counter,
                caption = OrvaShowcaseCopy.fieldNotesBillingCaption(language),
                heightDp = 176,
                nodeId = "about_mosaic_3",
              )
              MosaicTile(
                language = language,
                drawableRes = R.drawable.editorial_studio_workbench,
                caption = OrvaShowcaseCopy.fieldNotesDetailCaption(language),
                heightDp = 184,
                nodeId = "about_mosaic_2",
              )
            }
            Column(modifier = Modifier.weight(1f)) {
              MosaicTile(
                language = language,
                drawableRes = R.drawable.editorial_architecture_light,
                caption = OrvaShowcaseCopy.fieldNotesStructureCaption(language),
                heightDp = 284,
                nodeId = "about_mosaic_4",
              )
            }
          }
        } else {
          // Two-column staggered layout retains comfortable crops at 360–430dp phone widths.
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalAlignment = Alignment.Top,
          ) {
            Column(
              modifier = Modifier.weight(1f),
              verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
              MosaicTile(
                language = language,
                drawableRes = R.drawable.editorial_apothecary_shelves,
                caption = OrvaShowcaseCopy.fieldNotesBatchCaption(language),
                heightDp = 240,
                nodeId = "about_mosaic_1",
              )
              MosaicTile(
                language = language,
                drawableRes = R.drawable.editorial_studio_workbench,
                caption = OrvaShowcaseCopy.fieldNotesDetailCaption(language),
                heightDp = 160,
                nodeId = "about_mosaic_2",
              )
            }
            Column(
              modifier = Modifier.weight(1f),
              verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
              MosaicTile(
                language = language,
                drawableRes = R.drawable.editorial_thermal_counter,
                caption = OrvaShowcaseCopy.fieldNotesBillingCaption(language),
                heightDp = 168,
                nodeId = "about_mosaic_3",
              )
              MosaicTile(
                language = language,
                drawableRes = R.drawable.editorial_architecture_light,
                caption = OrvaShowcaseCopy.fieldNotesStructureCaption(language),
                heightDp = 232,
                nodeId = "about_mosaic_4",
              )
            }
          }
        }
      }
    }

    HorizontalDivider(thickness = 1.dp, color = OrvaShowcaseColors.Hairline)
  }
}

@Composable
private fun MosaicTile(
  language: AppLanguage,
  drawableRes: Int,
  caption: String,
  heightDp: Int,
  nodeId: String,
) {
  Box(
    modifier =
      Modifier
        .fillMaxWidth()
        .height(heightDp.dp)
        .border(1.dp, OrvaShowcaseColors.Hairline)
        .agenticNode(id = nodeId, kind = LayerKind.MEDIA, parentId = "about_mosaic_container"),
  ) {
    Image(
      painter = painterResource(id = drawableRes),
      contentDescription = caption,
      contentScale = ContentScale.Crop,
      modifier = Modifier.fillMaxSize(),
    )
    Box(
      modifier =
        Modifier
          .align(Alignment.BottomCenter)
          .fillMaxWidth()
          .background(
            Brush.verticalGradient(
              listOf(Color.Transparent, OrvaShowcaseColors.CanvasDeep.copy(alpha = 0.88f)),
            )
          )
          .padding(horizontal = 10.dp, vertical = 8.dp),
    ) {
      Text(
        text = caption,
        fontFamily = OrvaShowcaseFonts.mono(language),
        fontSize = 9.5.sp,
        letterSpacing = 1.2.sp,
        color = OrvaShowcaseColors.InkPrimary,
        modifier =
          Modifier
            .agenticNode(
              id = "${nodeId}_caption",
              kind = LayerKind.TEXT,
              parentId = nodeId,
            )
            .testTag("${nodeId}_caption"),
      )
    }
  }
}

/**
 * Scene 08 — Deep Dive / ORVA Horizontal Feature Row (Master Directive §4.1 Scene 08 & §7.8).
 */
@Composable
private fun Scene08DeepDiveOrva(
  language: AppLanguage,
  reducedMotion: Boolean,
  onExploreOrva: () -> Unit,
) {
  Column(
    modifier =
      Modifier
        .fillMaxWidth()
        .widthIn(max = 960.dp)
        .padding(horizontal = 24.dp, vertical = 44.dp)
        .agenticNode(id = "about_deep_dive_container", kind = LayerKind.CONTAINER),
    verticalArrangement = Arrangement.spacedBy(18.dp),
  ) {
    Text(
      text = OrvaShowcaseCopy.deepDiveEyebrowWithScene(language),
      fontFamily = OrvaShowcaseFonts.mono(language),
      fontSize = 10.5.sp,
      letterSpacing = 1.6.sp,
      color = OrvaShowcaseColors.AccentVermilion,
      modifier = Modifier.agenticNode(
        id = "about_deep_dive_eyebrow",
        kind = LayerKind.TEXT,
        parentId = "about_deep_dive_container",
      ).testTag("about_deep_dive_eyebrow"),
    )

    BoxWithConstraints(
      modifier =
        Modifier
          .fillMaxWidth()
          .padding(vertical = 8.dp),
    ) {
      val wide = maxWidth >= 600.dp
      if (wide) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(24.dp),
          verticalAlignment = Alignment.CenterVertically,
        ) {
          DeepDiveArtwork(language = language, reducedMotion = reducedMotion, modifier = Modifier.weight(0.42f))
          DeepDiveCopy(
            language = language,
            onExploreOrva = onExploreOrva,
            modifier = Modifier.weight(0.58f),
          )
        }
      } else {
        Column(verticalArrangement = Arrangement.spacedBy(18.dp)) {
          DeepDiveArtwork(language = language, reducedMotion = reducedMotion, modifier = Modifier.fillMaxWidth())
          DeepDiveCopy(language = language, onExploreOrva = onExploreOrva)
        }
      }
    }
  }
}

@Composable
private fun DeepDiveArtwork(
  language: AppLanguage,
  reducedMotion: Boolean,
  modifier: Modifier = Modifier,
) {
  var flattened by remember { mutableStateOf(false) }
  val rotY by animateFloatAsState(
    targetValue = if (reducedMotion || flattened) 0f else -12f,
    animationSpec = tween(durationMillis = if (reducedMotion) 0 else 360),
    label = "book_rot_y",
  )
  val rotX by animateFloatAsState(
    targetValue = if (reducedMotion || flattened) 0f else 4f,
    animationSpec = tween(durationMillis = if (reducedMotion) 0 else 360),
    label = "book_rot_x",
  )
  Box(
    modifier =
      modifier
        .aspectRatio(4f / 3f)
        .graphicsLayer {
          rotationY = rotY
          rotationX = rotX
          cameraDistance = 12f * density
          shadowElevation = if (flattened) 6f else 20f
        }
        .border(1.dp, OrvaShowcaseColors.Hairline)
        .agenticNode(id = "about_deep_dive_media", kind = LayerKind.MEDIA, parentId = "about_deep_dive_container"),
  ) {
    Image(
      painter = painterResource(id = R.drawable.editorial_thermal_counter),
      contentDescription = OrvaShowcaseCopy.deepDiveArtworkDescription(language),
      contentScale = ContentScale.Crop,
      modifier = Modifier.fillMaxSize(),
    )
    // Subtle 3D book spine lighting highlight along the left edge.
    Box(
      modifier =
        Modifier
          .align(Alignment.CenterStart)
          .fillMaxHeight()
          .width(12.dp)
          .background(
            Brush.horizontalGradient(
              listOf(
                Color.White.copy(alpha = 0.22f),
                Color.Black.copy(alpha = 0.35f),
                Color.Transparent,
              )
            )
          ),
    )

    Text(
      text = OrvaShowcaseCopy.deepDivePlateMeta(language),
      fontFamily = OrvaShowcaseFonts.mono(language),
      fontSize = 9.sp,
      letterSpacing = 1.1.sp,
      color = OrvaShowcaseColors.InkPrimary,
      modifier =
        Modifier
          .align(Alignment.TopStart)
          .padding(10.dp)
          .background(OrvaShowcaseColors.CanvasDeep.copy(alpha = 0.84f))
          .padding(horizontal = 8.dp, vertical = 5.dp)
          .agenticNode(
            id = "about_deep_dive_plate_meta",
            kind = LayerKind.TEXT,
            parentId = "about_deep_dive_media",
          ),
    )

    Box(
      modifier =
        Modifier
          .align(Alignment.TopEnd)
          .padding(10.dp)
          .background(OrvaShowcaseColors.CanvasDeep.copy(alpha = 0.9f))
          .clickable(
            enabled = !reducedMotion,
            role = Role.Button,
            onClickLabel = OrvaShowcaseCopy.deepDivePerspectiveHint(language, flattened, reducedMotion),
            onClick = { flattened = !flattened },
          )
          .agenticNode(
            id = "about_deep_dive_perspective_hint",
            kind = LayerKind.CONTAINER,
            parentId = "about_deep_dive_media",
          )
          .testTag("about_deep_dive_perspective_hint")
          .padding(horizontal = 8.dp, vertical = 6.dp),
    ) {
      Text(
        text = OrvaShowcaseCopy.deepDivePerspectiveHint(language, flattened, reducedMotion),
        fontFamily = OrvaShowcaseFonts.mono(language),
        fontSize = 8.sp,
        letterSpacing = 0.8.sp,
        color = OrvaShowcaseColors.InkPrimary,
        modifier = Modifier.agenticNode(
          id = "about_deep_dive_perspective_hint_text",
          kind = LayerKind.TEXT,
          parentId = "about_deep_dive_perspective_hint",
        ),
      )
    }

    Column(
      modifier =
        Modifier
          .align(Alignment.BottomCenter)
          .fillMaxWidth()
          .background(OrvaShowcaseColors.CanvasDeep.copy(alpha = 0.9f))
          .padding(horizontal = 12.dp, vertical = 10.dp)
          .agenticNode(
            id = "about_deep_dive_specs",
            kind = LayerKind.CONTAINER,
            parentId = "about_deep_dive_media",
          ),
      verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Text(
          text = OrvaShowcaseCopy.deepDivePlateSection(language),
          fontFamily = OrvaShowcaseFonts.mono(language),
          fontSize = 8.sp,
          letterSpacing = 1.0.sp,
          color = OrvaShowcaseColors.InkMuted,
          modifier = Modifier.agenticNode(
            id = "about_deep_dive_specs_label",
            kind = LayerKind.TEXT,
            parentId = "about_deep_dive_specs",
          ),
        )
        Spacer(Modifier.weight(1f))
        Text(
          text = if (language == AppLanguage.Bengali) "ORVA / ০৮" else "ORVA / 08",
          fontFamily = OrvaShowcaseFonts.mono(language),
          fontSize = 8.sp,
          letterSpacing = 0.8.sp,
          color = OrvaShowcaseColors.AccentVermilion,
          modifier = Modifier.agenticNode(
            id = "about_deep_dive_specs_index",
            kind = LayerKind.TEXT,
            parentId = "about_deep_dive_specs",
          ),
        )
      }
      HorizontalDivider(thickness = 1.dp, color = OrvaShowcaseColors.Hairline)
      val rules = OrvaShowcaseCopy.deepDiveRules(language)
      Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
      ) {
        DeepDiveSpecCell(
          label = rules[0].first,
          value = rules[0].second,
          language = language,
          nodeId = "about_deep_dive_spec_money",
          modifier = Modifier.weight(1f),
        )
        Box(Modifier.width(1.dp).height(32.dp).background(OrvaShowcaseColors.Hairline))
        DeepDiveSpecCell(
          label = rules[1].first,
          value = rules[1].second,
          language = language,
          nodeId = "about_deep_dive_spec_quantity",
          modifier = Modifier.weight(1f),
        )
      }
      HorizontalDivider(thickness = 1.dp, color = OrvaShowcaseColors.Hairline)
      Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
      ) {
        DeepDiveSpecCell(
          label = rules[2].first,
          value = rules[2].second,
          language = language,
          nodeId = "about_deep_dive_spec_stock",
          modifier = Modifier.weight(1f),
        )
        Box(Modifier.width(1.dp).height(32.dp).background(OrvaShowcaseColors.Hairline))
        DeepDiveSpecCell(
          label = rules[3].first,
          value = rules[3].second,
          language = language,
          nodeId = "about_deep_dive_spec_invoice",
          modifier = Modifier.weight(1f),
        )
      }
    }
  }
}

@Composable
private fun DeepDiveSpecCell(
  label: String,
  value: String,
  language: AppLanguage,
  nodeId: String,
  modifier: Modifier = Modifier,
) {
  Column(
    modifier = modifier
      .agenticNode(id = nodeId, kind = LayerKind.CONTAINER, parentId = "about_deep_dive_specs")
      .padding(horizontal = 8.dp, vertical = 2.dp),
    verticalArrangement = Arrangement.spacedBy(3.dp),
  ) {
    Text(
      text = label,
      fontFamily = OrvaShowcaseFonts.mono(language),
      fontSize = 7.5.sp,
      letterSpacing = 0.8.sp,
      color = OrvaShowcaseColors.InkMuted,
      modifier = Modifier.agenticNode(
        id = "${nodeId}_label",
        kind = LayerKind.TEXT,
        parentId = nodeId,
      ),
    )
    Text(
      text = value,
      fontFamily = OrvaShowcaseFonts.body(language),
      fontSize = 9.5.sp,
      fontWeight = FontWeight.SemiBold,
      lineHeight = 12.sp,
      color = OrvaShowcaseColors.InkPrimary,
      modifier = Modifier
        .agenticNode(
          id = "${nodeId}_value",
          kind = LayerKind.TEXT,
          parentId = nodeId,
        )
        .testTag("${nodeId}_value"),
    )
  }
}

@Composable
private fun DeepDiveCopy(
  language: AppLanguage,
  onExploreOrva: () -> Unit,
  modifier: Modifier = Modifier,
) {
  Column(modifier = modifier, verticalArrangement = Arrangement.spacedBy(12.dp)) {
    Text(
      text = OrvaShowcaseCopy.deepDiveTitle(language),
      onTextLayout = rememberAgenticTextLayoutHandler("about_deep_dive_title"),
      fontFamily = OrvaShowcaseFonts.display(language),
      fontWeight = FontWeight.Bold,
      fontSize = 24.sp,
      lineHeight = 28.sp,
      letterSpacing = (-0.5).sp,
      color = OrvaShowcaseColors.InkPrimary,
      modifier =
        Modifier.agenticNode(
          id = "about_deep_dive_title",
          kind = LayerKind.TEXT,
          parentId = "about_deep_dive_container",
        ).testTag("about_deep_dive_title"),
    )
    Text(
      text = OrvaShowcaseCopy.deepDiveBody(language),
      fontFamily = OrvaShowcaseFonts.body(language),
      fontSize = 14.5.sp,
      lineHeight = 22.sp,
      color = OrvaShowcaseColors.InkSecondary,
      modifier = Modifier.agenticNode(
        id = "about_deep_dive_body",
        kind = LayerKind.TEXT,
        parentId = "about_deep_dive_container",
      ),
    )
    Button(
      onClick = onExploreOrva,
      colors =
        ButtonDefaults.buttonColors(
          containerColor = OrvaShowcaseColors.InkPrimary,
          contentColor = OrvaShowcaseColors.CanvasDeep,
        ),
      shape = RoundedCornerShape(2.dp),
      contentPadding = PaddingValues(horizontal = 18.dp, vertical = 12.dp),
      modifier = Modifier
        .minimumInteractiveComponentSize()
        .agenticNode(
          id = "about_deep_dive_action",
          kind = LayerKind.CONTAINER,
          parentId = "about_deep_dive_container",
        )
        .testTag("about_deep_dive_action"),
    ) {
      Text(
        text = OrvaShowcaseCopy.flagshipAction(language),
        fontFamily = OrvaShowcaseFonts.mono(language),
        fontWeight = FontWeight.SemiBold,
        fontSize = 11.5.sp,
        letterSpacing = 1.1.sp,
        modifier = Modifier.agenticNode(
          id = "about_deep_dive_action_label",
          kind = LayerKind.TEXT,
          parentId = "about_deep_dive_action",
        ),
      )
    }
  }
}

/**
 * Scene 09 — Settings-Driven Contact & `RINDLE WORKS` Film-End Closing (Master Directive §4.1 Scene 09 & §7.9–7.10).
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun Scene09ContactAndFilmClosing(
  state: AboutShowcaseUiState,
  onStartBilling: () -> Unit,
  onBackToHome: () -> Unit,
) {
  Column(
    modifier =
      Modifier
        .fillMaxWidth()
        .widthIn(max = 960.dp)
        .padding(horizontal = 24.dp, vertical = 44.dp)
        .agenticNode(id = "about_meta_container", kind = LayerKind.CONTAINER),
    verticalArrangement = Arrangement.spacedBy(32.dp),
  ) {
    HorizontalDivider(thickness = 1.dp, color = OrvaShowcaseColors.Hairline)

    BoxWithConstraints(modifier = Modifier.fillMaxWidth()) {
      val twoColumns = maxWidth >= 660.dp
      if (twoColumns) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(36.dp),
          verticalAlignment = Alignment.Top,
        ) {
          SupportContactColumn(state = state, modifier = Modifier.weight(1f))
          ProductOwnershipColumn(state = state, modifier = Modifier.weight(1f))
        }
      } else {
        Column(verticalArrangement = Arrangement.spacedBy(32.dp)) {
          SupportContactColumn(state = state)
          HorizontalDivider(thickness = 1.dp, color = OrvaShowcaseColors.Hairline)
          ProductOwnershipColumn(state = state)
        }
      }
    }

    FlowRow(
      horizontalArrangement = Arrangement.spacedBy(12.dp),
      verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
      Button(
        onClick = onStartBilling,
        colors =
          ButtonDefaults.buttonColors(
            containerColor = OrvaShowcaseColors.AccentVermilion,
            contentColor = OrvaShowcaseColors.CanvasDeep,
          ),
        shape = RoundedCornerShape(2.dp),
        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 14.dp),
        modifier = Modifier
          .minimumInteractiveComponentSize()
          .agenticNode(
            id = "about_start_billing_action",
            kind = LayerKind.CONTAINER,
            parentId = "about_meta_container",
          )
          .testTag("about_start_billing_btn"),
      ) {
        Text(
          text = OrvaShowcaseCopy.startBillingCta(state.language),
          fontFamily = OrvaShowcaseFonts.mono(state.language),
          fontWeight = FontWeight.SemiBold,
          fontSize = 12.sp,
          letterSpacing = 1.1.sp,
          modifier = Modifier.agenticNode(
            id = "about_start_billing_label",
            kind = LayerKind.TEXT,
            parentId = "about_start_billing_action",
          ),
        )
      }

      OutlinedButton(
        onClick = onBackToHome,
        border = BorderStroke(1.dp, OrvaShowcaseColors.Hairline),
        colors = ButtonDefaults.outlinedButtonColors(contentColor = OrvaShowcaseColors.InkPrimary),
        shape = RoundedCornerShape(2.dp),
        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 14.dp),
        modifier = Modifier
          .minimumInteractiveComponentSize()
          .agenticNode(
            id = "about_back_home_action",
            kind = LayerKind.CONTAINER,
            parentId = "about_meta_container",
          )
          .testTag("about_back_home_btn"),
      ) {
        Text(
          text = OrvaShowcaseCopy.linkBackToHome(state.language),
          fontFamily = OrvaShowcaseFonts.mono(state.language),
          fontWeight = FontWeight.Medium,
          fontSize = 12.sp,
          letterSpacing = 1.1.sp,
          modifier = Modifier.agenticNode(
            id = "about_back_home_label",
            kind = LayerKind.TEXT,
            parentId = "about_back_home_action",
          ),
        )
      }
    }

    // Film-end closing lock-up: RINDLE (solid) WORKS (outlined)
    Column(
      modifier =
        Modifier
          .fillMaxWidth()
          .padding(top = 24.dp, bottom = 12.dp)
          .agenticNode(id = "about_film_end_mark", kind = LayerKind.CONTAINER, parentId = "about_meta_container"),
      horizontalAlignment = Alignment.CenterHorizontally,
      verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
      Row(
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Text(
          text = "RINDLE",
          fontFamily = OrvaShowcaseFonts.SpaceGrotesk,
          fontWeight = FontWeight.Bold,
          fontSize = 42.sp,
          letterSpacing = (-1.2).sp,
          color = OrvaShowcaseColors.InkPrimary,
          modifier = Modifier.agenticNode(
            id = "about_film_end_rindle",
            kind = LayerKind.TEXT,
            parentId = "about_film_end_mark",
          ),
        )
        Text(
          text = "WORKS",
          style =
            TextStyle(
              fontFamily = OrvaShowcaseFonts.SpaceGrotesk,
              fontWeight = FontWeight.Bold,
              fontSize = 42.sp,
              letterSpacing = (-1.2).sp,
              color = OrvaShowcaseColors.AccentVermilion,
              drawStyle = Stroke(width = 2.6f),
            ),
          modifier = Modifier.agenticNode(
            id = "about_film_end_works",
            kind = LayerKind.TEXT,
            parentId = "about_film_end_mark",
          ),
        )
      }
      Text(
        text = OrvaShowcaseCopy.filmEndTagline(state.language),
        fontFamily = OrvaShowcaseFonts.mono(state.language),
        fontSize = 10.5.sp,
        letterSpacing = 2.sp,
        color = OrvaShowcaseColors.InkMuted,
        textAlign = TextAlign.Center,
        modifier = Modifier
          .agenticNode(
            id = "about_film_end_tagline",
            kind = LayerKind.TEXT,
            parentId = "about_film_end_mark",
          )
          .testTag("about_film_end_tagline"),
      )
    }
  }
}

@Composable
private fun SupportContactColumn(
  state: AboutShowcaseUiState,
  modifier: Modifier = Modifier,
) {
  val phone = state.supportPhone?.takeIf { it.isNotBlank() }
  val email = state.supportEmail?.takeIf { it.isNotBlank() }

  Column(
    modifier =
      modifier.agenticNode(
        id = "about_support_block",
        kind = LayerKind.CONTAINER,
        parentId = "about_meta_container",
      ),
    verticalArrangement = Arrangement.spacedBy(12.dp),
  ) {
    Text(
      text = OrvaShowcaseCopy.supportSectionLabel(state.language),
      fontFamily = OrvaShowcaseFonts.mono(state.language),
      fontSize = 11.sp,
      letterSpacing = 1.6.sp,
      color = OrvaShowcaseColors.AccentVermilion,
      modifier = Modifier.agenticNode(
        id = "about_support_section_label",
        kind = LayerKind.TEXT,
        parentId = "about_support_block",
      ),
    )
    Text(
      text = OrvaShowcaseCopy.supportHeading(state.language),
      fontFamily = OrvaShowcaseFonts.display(state.language),
      fontWeight = FontWeight.Bold,
      fontSize = 28.sp,
      lineHeight = 32.sp,
      color = OrvaShowcaseColors.InkPrimary,
      modifier = Modifier.agenticNode(
        id = "about_support_heading",
        kind = LayerKind.TEXT,
        parentId = "about_support_block",
      ).testTag("about_support_heading"),
    )
    Text(
      text = OrvaShowcaseCopy.supportSubline(state.language),
      fontFamily = OrvaShowcaseFonts.body(state.language),
      fontSize = 14.5.sp,
      lineHeight = 22.sp,
      color = OrvaShowcaseColors.InkSecondary,
      modifier = Modifier.agenticNode(
        id = "about_support_subline",
        kind = LayerKind.TEXT,
        parentId = "about_support_block",
      ),
    )

    if (phone == null && email == null) {
      Text(
        text = OrvaShowcaseCopy.supportEmptyState(state.language),
        fontFamily = OrvaShowcaseFonts.body(state.language),
        fontSize = 13.5.sp,
        lineHeight = 21.sp,
        color = OrvaShowcaseColors.InkMuted,
        modifier = Modifier
          .agenticNode(
            id = "about_support_empty_state",
            kind = LayerKind.TEXT,
            parentId = "about_support_block",
          )
          .testTag("about_support_empty_state"),
      )
    } else {
      if (phone != null) {
        MetadataKeyValueRow(
          label = OrvaShowcaseCopy.supportPhoneLabel(state.language),
          value = phone,
          language = state.language,
          testTag = "about_support_phone",
          nodeId = "about_support_phone_row",
          parentId = "about_support_block",
        )
      }
      if (email != null) {
        MetadataKeyValueRow(
          label = OrvaShowcaseCopy.supportEmailLabel(state.language),
          value = email,
          language = state.language,
          testTag = "about_support_email",
          nodeId = "about_support_email_row",
          parentId = "about_support_block",
        )
      }
    }
  }
}

@Composable
private fun ProductOwnershipColumn(
  state: AboutShowcaseUiState,
  modifier: Modifier = Modifier,
) {
  Column(
    modifier =
      modifier.agenticNode(
        id = "about_ownership_block",
        kind = LayerKind.CONTAINER,
        parentId = "about_meta_container",
      ),
    verticalArrangement = Arrangement.spacedBy(12.dp),
  ) {
    Text(
      text = OrvaShowcaseCopy.ownershipSectionLabel(state.language),
      fontFamily = OrvaShowcaseFonts.mono(state.language),
      fontSize = 11.sp,
      letterSpacing = 1.6.sp,
      color = OrvaShowcaseColors.InkMuted,
      modifier = Modifier.agenticNode(
        id = "about_ownership_section_label",
        kind = LayerKind.TEXT,
        parentId = "about_ownership_block",
      ),
    )
    MetadataKeyValueRow(
      label = OrvaShowcaseCopy.productLabel(state.language),
      value = OrvaShowcaseCopy.productValue(state.language),
      language = state.language,
      nodeId = "about_ownership_product_row",
      parentId = "about_ownership_block",
    )
    MetadataKeyValueRow(
      label = OrvaShowcaseCopy.developedByLabel(state.language),
      value = "Rindle Works",
      language = state.language,
      nodeId = "about_ownership_publisher_row",
      parentId = "about_ownership_block",
    )
    MetadataKeyValueRow(
      label = OrvaShowcaseCopy.versionLabel(state.language),
      value = state.appVersion,
      language = state.language,
      testTag = "about_version_value",
      nodeId = "about_ownership_version_row",
      parentId = "about_ownership_block",
    )
    MetadataKeyValueRow(
      label = OrvaShowcaseCopy.buildLabel(state.language),
      value = state.buildNumber,
      language = state.language,
      testTag = "about_build_value",
      nodeId = "about_ownership_build_row",
      parentId = "about_ownership_block",
    )
    Text(
      text = OrvaShowcaseCopy.studioStatusNote(state.language),
      fontFamily = OrvaShowcaseFonts.mono(state.language),
      fontSize = 11.sp,
      lineHeight = 18.sp,
      color = OrvaShowcaseColors.InkMuted,
      modifier = Modifier
        .agenticNode(
          id = "about_ownership_provisional_status",
          kind = LayerKind.TEXT,
          parentId = "about_ownership_block",
        )
        .testTag("about_provisional_status"),
    )
    Text(
      text = OrvaShowcaseCopy.ownershipReassurance(state.language),
      fontFamily = OrvaShowcaseFonts.body(state.language),
      fontSize = 13.5.sp,
      lineHeight = 20.sp,
      color = OrvaShowcaseColors.InkSecondary,
      modifier = Modifier.agenticNode(
        id = "about_ownership_reassurance",
        kind = LayerKind.TEXT,
        parentId = "about_ownership_block",
      ),
    )
  }
}

@Composable
private fun MetadataKeyValueRow(
  label: String,
  value: String,
  language: AppLanguage,
  nodeId: String,
  parentId: String,
  testTag: String? = null,
) {
  Column(
    modifier = Modifier
      .agenticNode(id = nodeId, kind = LayerKind.CONTAINER, parentId = parentId)
      .semantics(mergeDescendants = true) {}
      .then(if (testTag != null) Modifier.testTag(testTag) else Modifier),
    verticalArrangement = Arrangement.spacedBy(2.dp),
  ) {
    Text(
      text = label.uppercase(),
      fontFamily = OrvaShowcaseFonts.mono(language),
      fontSize = 10.sp,
      letterSpacing = 1.2.sp,
      color = OrvaShowcaseColors.InkMuted,
      modifier = Modifier.agenticNode(
        id = "${nodeId}_label",
        kind = LayerKind.TEXT,
        parentId = nodeId,
      ),
    )
    Text(
      text = value,
      fontFamily = OrvaShowcaseFonts.body(language),
      fontSize = 14.5.sp,
      color = OrvaShowcaseColors.InkPrimary,
      modifier = Modifier.agenticNode(
        id = "${nodeId}_value",
        kind = LayerKind.TEXT,
        parentId = nodeId,
      ),
    )
  }
}

/**
 * `zll.me`-inspired tilted dual-track kinetic marquee band between Scene 02 and Scene 03.
 */
@Composable
private fun TiltedDualMarqueeRibbon(language: AppLanguage, reducedMotion: Boolean) {
  var primaryTextWidthPx by remember(language) { mutableFloatStateOf(0f) }
  var secondaryTextWidthPx by remember(language) { mutableFloatStateOf(0f) }
  // Reduced motion omits the animation clock entirely. Normal motion travels exactly one
  // repeated text cycle, so the reset lands on identical content instead of visibly jumping.
  val marqueeTransition =
    if (reducedMotion) null else rememberInfiniteTransition(label = "marquee")
  val primaryTranslationX =
    if (marqueeTransition == null) {
      0f
    } else {
      val phase by marqueeTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec =
          infiniteRepeatable(
            animation = tween(durationMillis = 9000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart,
          ),
        label = "marquee_primary_phase",
      )
      -phase * (primaryTextWidthPx / 2f)
    }
  val secondaryTranslationX =
    if (marqueeTransition == null) {
      0f
    } else {
      val phase by marqueeTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec =
          infiniteRepeatable(
            animation = tween(durationMillis = 12000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart,
          ),
        label = "marquee_secondary_phase",
      )
      -(1f - phase) * (secondaryTextWidthPx / 2f)
    }

  val palette = currentShowcasePalette()
  Column(
    modifier =
      Modifier
        .fillMaxWidth()
        .padding(vertical = 18.dp)
        .clipToBounds()
        .graphicsLayer { rotationZ = -1.8f },
    verticalArrangement = Arrangement.spacedBy(4.dp),
  ) {
    // Track 1: Solid bold left-scrolling ribbon. Two identical cycles make the seam invisible.
    Box(
      modifier =
        Modifier
          .fillMaxWidth()
          .background(palette.inkPrimary)
          .padding(vertical = 8.dp)
          .clipToBounds()
          .agenticNode(id = "about_marquee_primary_track", kind = LayerKind.CONTAINER),
    ) {
      Text(
        text = OrvaShowcaseCopy.aboutMarqueePrimary(language),
        fontFamily = OrvaShowcaseFonts.display(language),
        fontWeight = FontWeight.Bold,
        fontSize = if (language == AppLanguage.Bengali) 12.sp else 14.sp,
        letterSpacing = if (language == AppLanguage.Bengali) 0.2.sp else 1.6.sp,
        color = palette.canvasDeep,
        maxLines = 1,
        softWrap = false,
        modifier =
          Modifier
            .wrapContentWidth(unbounded = true)
            .onSizeChanged { primaryTextWidthPx = it.width.toFloat() }
            .graphicsLayer { translationX = primaryTranslationX }
            .agenticNode(
              id = "about_marquee_primary_text",
              kind = LayerKind.TEXT,
              parentId = "about_marquee_primary_track",
            ).testTag("about_marquee_primary_text"),
      )
    }
    // Track 2: Hollow outline, travelling in the opposite direction at a slower rate.
    Box(
      modifier =
        Modifier
          .fillMaxWidth()
          .background(palette.canvasSecondary)
          .border(1.dp, palette.hairline)
          .padding(vertical = 7.dp)
          .clipToBounds()
          .agenticNode(id = "about_marquee_secondary_track", kind = LayerKind.CONTAINER),
    ) {
      Text(
        text = OrvaShowcaseCopy.aboutMarqueeSecondary(language),
        style =
          TextStyle(
            fontFamily = OrvaShowcaseFonts.display(language),
            fontWeight = FontWeight.Bold,
            fontSize = if (language == AppLanguage.Bengali) 13.sp else 15.sp,
            letterSpacing = if (language == AppLanguage.Bengali) 0.2.sp else 1.8.sp,
            color = palette.inkPrimary.copy(alpha = 0.72f),
            drawStyle = Stroke(width = 1.8f),
          ),
        maxLines = 1,
        softWrap = false,
        modifier =
          Modifier
            .wrapContentWidth(unbounded = true)
            .onSizeChanged { secondaryTextWidthPx = it.width.toFloat() }
            .graphicsLayer { translationX = secondaryTranslationX }
            .agenticNode(
              id = "about_marquee_secondary_text",
              kind = LayerKind.TEXT,
              parentId = "about_marquee_secondary_track",
            ).testTag("about_marquee_secondary_text"),
      )
    }
  }
}
