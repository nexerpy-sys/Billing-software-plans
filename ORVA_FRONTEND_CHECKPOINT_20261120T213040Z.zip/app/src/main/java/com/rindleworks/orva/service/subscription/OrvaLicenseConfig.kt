package com.rindleworks.orva.service.subscription

/**
 * Compile-time vendor public key configuration for ORVA `licenses.csv` ECDSA P-256 verification.
 *
 * Setup workflow (run offline on Rindle Works' workstation — NEVER commit the private key):
 * 1. `python3 tools/orva_license_signer.py keygen --out-dir ./rindle_keys`
 * 2. Paste the printed Base64 X.509/SPKI public key into [VENDOR_PUBLIC_KEY_SPKI_BASE64] below.
 * 3. Sign customer rows with:
 *    `python3 tools/orva_license_signer.py sign-row --key ./rindle_keys/rindle_private.pem ...`
 *
 * When [VENDOR_PUBLIC_KEY_SPKI_BASE64] is blank, ORVA stays backward-compatible with legacy
 * 6-column WPF `licenses.csv` files while still enforcing AndroidKeyStore AES-256-GCM sealing,
 * dual anti-delete anchors, SQLite cross-checks, and monotonic uptime rollback protection.
 */
object OrvaLicenseConfig {
  const val VENDOR_PUBLIC_KEY_SPKI_BASE64: String = ""
}
