package com.rindleworks.orva.ui.showcase

import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import com.rindleworks.orva.R
import com.rindleworks.orva.domain.settings.AppLanguage

/**
 * Dynamic showcase surface palette supporting instant Obsidian Dark ↔ Warm Chalk Paper Mode
 * (`#F3F1EC`, inspired by `zll.me` `data-mode="paper"`).
 */
@Immutable
data class ShowcasePalette(
  val isPaperMode: Boolean,
  val canvasDeep: Color,
  val canvasSecondary: Color,
  val surfaceRaised: Color,
  val inkPrimary: Color,
  val inkSecondary: Color,
  val inkMuted: Color,
  val hairline: Color,
  val agentTagSurface: Color,
)

val DarkShowcasePalette =
  ShowcasePalette(
    isPaperMode = false,
    canvasDeep = Color(0xFF08090B),
    canvasSecondary = Color(0xFF111318),
    surfaceRaised = Color(0xFF181B21),
    inkPrimary = Color(0xFFF1EFE9),
    inkSecondary = Color(0xFFA1A3AA),
    inkMuted = Color(0xFF6E727D),
    hairline = Color(0xFF2A2D34),
    agentTagSurface = Color(0xED0C0E13),
  )

val PaperShowcasePalette =
  ShowcasePalette(
    isPaperMode = true,
    canvasDeep = Color(0xFFF3F1EC),
    canvasSecondary = Color(0xFFE9E6DE),
    surfaceRaised = Color(0xFFDFDBD2),
    inkPrimary = Color(0xFF111318),
    inkSecondary = Color(0xFF4B4F5B),
    inkMuted = Color(0xFF6E727D),
    hairline = Color(0xFFCECAC0),
    agentTagSurface = Color(0xF2EAE7DF),
  )

val LocalShowcasePalette = compositionLocalOf { DarkShowcasePalette }
val LocalPaperModeToggle = compositionLocalOf<() -> Unit> { {} }

@Composable
fun currentShowcasePalette(): ShowcasePalette = LocalShowcasePalette.current

/**
 * Authoritative Rindle Works × ORVA Showcase visual tokens
 * (Master Frontend Build Directive §2.1 & §5.4).
 *
 * Dark editorial palette: near-black obsidian (`#08090B`), graphite panels (`#111318`, `#181B21`),
 * warm chalk (`#F1EFE9`), muted slate (`#A1A3AA`), hairline rules (`#2A2D34`), editorial vermilion
 * (`#F45A43`), secondary violet (`#9A78F5`), and strictly dual-tone Violet (`#A78BFA`) + Vermilion
 * (`#FF604A`) Agentic Build cursor identities.
 *
 * Operational billing/inventory theme remains isolated in `ui/theme/`.
 */
object OrvaShowcaseColors {
  val CanvasDeep = Color(0xFF08090B)
  val CanvasSecondary = Color(0xFF111318)
  val SurfaceRaised = Color(0xFF181B21)
  val FolderBackplate = Color(0xFF13161D)
  val FolderPocket = Color(0xFF181B21)

  val PaperSheetRear = Color(0xFFDCDAD2)
  val PaperSheetMid = Color(0xFFE7E5DE)
  val PaperSheetFront = Color(0xFFF1EFE9)
  val PaperInk = Color(0xFF111318)
  val PaperInkMuted = Color(0xFF4F5360)

  val InkPrimary = Color(0xFFF1EFE9)
  val InkSecondary = Color(0xFFA1A3AA)
  val InkMuted = Color(0xFF6E727D)
  val Hairline = Color(0xFF2A2D34)

  // Editorial accents (restrained vermilion primary + violet secondary)
  val AccentVermilion = Color(0xFFF45A43)
  val AccentVermilionWash = Color(0x1AF45A43)
  val AccentViolet = Color(0xFF9A78F5)
  val AccentVioletSoft = Color(0xFFBBA6FF)
  val AccentVioletWash = Color(0x1A9A78F5)

  // Agentic Build visual grammar (About Us construction overlay)
  val FigmaBlue = Color(0xFF0D99FF)
  val FigmaBlueFill = Color(0x1E0D99FF)
  val SmartGuideRed = Color(0xFFF45A43)

  // Strictly two cursor identities: Violet & Vermilion (zero rainbow palette)
  val CursorPurpleCore = Color(0xFFA78BFA)
  val CursorPurpleBright = Color(0xFFC4B5FD)
  val CursorPurpleDeep = Color(0xFF8B5CF6)
  val CursorVermilionCore = Color(0xFFFF604A)
  val CursorVermilionBright = Color(0xFFFF8370)
  val CursorVermilionDeep = Color(0xFFF45A43)

  // Architectural drafting chrome (agent micro-tags & precision ruler ticks)
  val AgentTagSurface = Color(0xED0C0E13)
  val DraftingRulerTick = Color(0x45A1A3AA)

  val AgentCursorPalette: List<Color> =
    listOf(
      CursorPurpleCore,
      CursorVermilionCore,
      CursorPurpleBright,
      CursorVermilionBright,
      CursorPurpleDeep,
      CursorVermilionDeep,
    )
}

/** Locally bundled Google Fonts in res/font with automatic Bengali glyph fallback. */
object OrvaShowcaseFonts {
  val SpaceGrotesk =
    FontFamily(
      Font(R.font.space_grotesk, FontWeight.Normal),
      Font(R.font.space_grotesk, FontWeight.Medium),
      Font(R.font.space_grotesk, FontWeight.SemiBold),
      Font(R.font.space_grotesk, FontWeight.Bold),
    )

  val InstrumentSerif =
    FontFamily(
      Font(R.font.instrument_serif, FontWeight.Normal, FontStyle.Normal),
      Font(R.font.instrument_serif, FontWeight.Normal, FontStyle.Italic),
    )

  val PlusJakartaSans =
    FontFamily(
      Font(R.font.plus_jakarta_sans, FontWeight.Normal),
      Font(R.font.plus_jakarta_sans, FontWeight.Medium),
      Font(R.font.plus_jakarta_sans, FontWeight.SemiBold),
    )

  val IbmPlexMono =
    FontFamily(
      Font(R.font.ibm_plex_mono, FontWeight.Normal),
      Font(R.font.ibm_plex_mono, FontWeight.Medium),
      Font(R.font.ibm_plex_mono, FontWeight.SemiBold),
    )

  val NotoSansBengali =
    FontFamily(
      Font(R.font.noto_sans_bengali, FontWeight.Normal),
      Font(R.font.noto_sans_bengali, FontWeight.Medium),
      Font(R.font.noto_sans_bengali, FontWeight.SemiBold),
      Font(R.font.noto_sans_bengali, FontWeight.Bold),
    )

  fun display(language: AppLanguage): FontFamily =
    if (language == AppLanguage.Bengali) NotoSansBengali else SpaceGrotesk

  fun editorialSerif(language: AppLanguage): FontFamily =
    if (language == AppLanguage.Bengali) NotoSansBengali else InstrumentSerif

  fun body(language: AppLanguage): FontFamily =
    if (language == AppLanguage.Bengali) NotoSansBengali else PlusJakartaSans

  fun mono(language: AppLanguage): FontFamily =
    if (language == AppLanguage.Bengali) NotoSansBengali else IbmPlexMono
}
