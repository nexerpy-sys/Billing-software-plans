package com.rindleworks.orva.domain.engine

import com.rindleworks.orva.domain.settings.RoundOffMode
import com.rindleworks.orva.domain.settings.SupplyType
import com.rindleworks.orva.domain.settings.TaxPricingMode
import java.math.BigDecimal
import java.time.LocalDate
import java.util.Locale
import java.util.UUID

data class BillingMedicineRecord(
  val medicineId: String,
  val displayName: String,
  val genericName: String? = null,
  val brandName: String? = null,
  val strength: String? = null,
  val dosageForm: String? = null,
  val stockUnitName: String,
  val hsnCode: String? = null,
  val gstRateBasisPoints: Int,
  val gstRateConfigured: Boolean,
  val lowStockThresholdMilli: Long = 0L,
  val isActive: Boolean = true,
)

data class ResolvedTaxPolicy(
  val pricingMode: TaxPricingMode,
  val supplyType: SupplyType,
  val roundOffMode: RoundOffMode,
  val placeOfSupplyStateCode: String,
)

data class InvoiceLineCalculationInput(
  val medicine: BillingMedicineRecord,
  val requestedQuantityMilli: Long,
  val allocations: List<FefoBatchAllocation>,
)

data class CalculatedBatchLine(
  val batchId: String,
  val batchNumber: String,
  val expiryYyyyMm: Int,
  val quantityMilli: Long,
  val stockUnitName: String,
  val unitPricePaise: Long,
  val gstRateBasisPoints: Int,
  val hsnCode: String?,
  val previousQuantityMilli: Long,
  val subtotalPaise: Long,
  val discountPaise: Long,
  val taxableValuePaise: Long,
  val cgstPaise: Long,
  val sgstPaise: Long,
  val igstPaise: Long,
  val lineTotalPaise: Long,
)

data class CalculatedMedicineLine(
  val lineGroupId: String,
  val medicineId: String,
  val medicineName: String,
  val stockUnitName: String,
  val quantityMilli: Long,
  val batchLines: List<CalculatedBatchLine>,
  val subtotalPaise: Long,
  val discountPaise: Long,
  val taxableValuePaise: Long,
  val cgstPaise: Long,
  val sgstPaise: Long,
  val igstPaise: Long,
  val lineTotalPaise: Long,
)

data class CalculatedInvoice(
  val lines: List<CalculatedMedicineLine>,
  val subtotalPaise: Long,
  val discountPaise: Long,
  val taxableValuePaise: Long,
  val cgstPaise: Long,
  val sgstPaise: Long,
  val igstPaise: Long,
  val roundOffPaise: Long,
  val grandTotalPaise: Long,
)

/**
 * Pure integer money, GST tax, round-off, and financial-year calculator.
 * Uses overflow-checked integer arithmetic and exact base-10 HALF_UP rounding.
 * Exact parity with ORVA WPF InvoiceCalculator.cs.
 */
class InvoiceCalculator {

  fun calculate(
    lineInputs: List<InvoiceLineCalculationInput>,
    taxPolicy: ResolvedTaxPolicy,
  ): CalculatedInvoice {
    val calculatedLines = mutableListOf<CalculatedMedicineLine>()
    var subtotalTotal = 0L
    var discountTotal = 0L
    var taxableTotal = 0L
    var cgstTotal = 0L
    var sgstTotal = 0L
    var igstTotal = 0L

    // Alternates odd paise across intra-state batch allocations so CGST & SGST stay within +/- 1 paise.
    var nextOddPaiseToCgst = true

    for (input in lineInputs) {
      val batchLines = mutableListOf<CalculatedBatchLine>()
      var lineSubtotal = 0L
      var lineDiscount = 0L
      var lineTaxable = 0L
      var lineCgst = 0L
      var lineSgst = 0L
      var lineIgst = 0L
      var lineTotal = 0L

      for (alloc in input.allocations) {
        val (batchLine, updatedParity) =
          calculateBatchLine(
            allocation = alloc,
            gstRateBasisPoints = input.medicine.gstRateBasisPoints,
            hsnCode = input.medicine.hsnCode,
            pricingMode = taxPolicy.pricingMode,
            supplyType = taxPolicy.supplyType,
            nextOddPaiseToCgst = nextOddPaiseToCgst,
          )
        nextOddPaiseToCgst = updatedParity
        batchLines += batchLine

        lineSubtotal = CheckedMath.addExact(lineSubtotal, batchLine.subtotalPaise)
        lineDiscount = CheckedMath.addExact(lineDiscount, batchLine.discountPaise)
        lineTaxable = CheckedMath.addExact(lineTaxable, batchLine.taxableValuePaise)
        lineCgst = CheckedMath.addExact(lineCgst, batchLine.cgstPaise)
        lineSgst = CheckedMath.addExact(lineSgst, batchLine.sgstPaise)
        lineIgst = CheckedMath.addExact(lineIgst, batchLine.igstPaise)
        lineTotal = CheckedMath.addExact(lineTotal, batchLine.lineTotalPaise)
      }

      calculatedLines +=
        CalculatedMedicineLine(
          lineGroupId = UUID.randomUUID().toString().replace("-", ""),
          medicineId = input.medicine.medicineId,
          medicineName = input.medicine.displayName,
          stockUnitName = input.medicine.stockUnitName,
          quantityMilli = input.requestedQuantityMilli,
          batchLines = batchLines,
          subtotalPaise = lineSubtotal,
          discountPaise = lineDiscount,
          taxableValuePaise = lineTaxable,
          cgstPaise = lineCgst,
          sgstPaise = lineSgst,
          igstPaise = lineIgst,
          lineTotalPaise = lineTotal,
        )

      subtotalTotal = CheckedMath.addExact(subtotalTotal, lineSubtotal)
      discountTotal = CheckedMath.addExact(discountTotal, lineDiscount)
      taxableTotal = CheckedMath.addExact(taxableTotal, lineTaxable)
      cgstTotal = CheckedMath.addExact(cgstTotal, lineCgst)
      sgstTotal = CheckedMath.addExact(sgstTotal, lineSgst)
      igstTotal = CheckedMath.addExact(igstTotal, lineIgst)
    }

    val rawTotal =
      CheckedMath.addExact(
        CheckedMath.addExact(taxableTotal, cgstTotal),
        CheckedMath.addExact(sgstTotal, igstTotal),
      )
    val grandTotal = applyRoundOff(rawTotal, taxPolicy.roundOffMode)
    val roundOff = CheckedMath.subtractExact(grandTotal, rawTotal)

    return CalculatedInvoice(
      lines = calculatedLines,
      subtotalPaise = subtotalTotal,
      discountPaise = discountTotal,
      taxableValuePaise = taxableTotal,
      cgstPaise = cgstTotal,
      sgstPaise = sgstTotal,
      igstPaise = igstTotal,
      roundOffPaise = roundOff,
      grandTotalPaise = grandTotal,
    )
  }

  private fun calculateBatchLine(
    allocation: FefoBatchAllocation,
    gstRateBasisPoints: Int,
    hsnCode: String?,
    pricingMode: TaxPricingMode,
    supplyType: SupplyType,
    nextOddPaiseToCgst: Boolean,
  ): Pair<CalculatedBatchLine, Boolean> {
    require(gstRateBasisPoints in 0..10_000) {
      "GST rate basis points must be between 0 and 10000."
    }

    val grossPaise = calculateGrossPaise(allocation.quantityMilli, allocation.unitPricePaise)
    val discountPaise = 0L // Discounts disabled in V1

    val taxableValuePaise: Long
    val totalTaxPaise: Long
    val lineTotalPaise: Long

    if (pricingMode == TaxPricingMode.TaxInclusive) {
      lineTotalPaise = grossPaise
      if (gstRateBasisPoints == 0) {
        taxableValuePaise = grossPaise
        totalTaxPaise = 0L
      } else {
        val numerator = BigDecimal.valueOf(grossPaise).multiply(BigDecimal.valueOf(BASIS_POINTS_SCALE))
        val denominator = BigDecimal.valueOf(BASIS_POINTS_SCALE + gstRateBasisPoints.toLong())
        taxableValuePaise = CheckedMath.divideRoundHalfAwayFromZero(numerator, denominator)
        totalTaxPaise = CheckedMath.subtractExact(grossPaise, taxableValuePaise)
      }
    } else {
      taxableValuePaise = grossPaise
      totalTaxPaise =
        if (gstRateBasisPoints == 0) {
          0L
        } else {
          val numerator =
            BigDecimal.valueOf(taxableValuePaise).multiply(BigDecimal.valueOf(gstRateBasisPoints.toLong()))
          CheckedMath.divideRoundHalfAwayFromZero(numerator, BASIS_POINTS_SCALE)
        }
      lineTotalPaise = CheckedMath.addExact(taxableValuePaise, totalTaxPaise)
    }

    var cgstPaise = 0L
    var sgstPaise = 0L
    var igstPaise = 0L
    var parity = nextOddPaiseToCgst

    if (supplyType == SupplyType.InterState) {
      igstPaise = totalTaxPaise
    } else {
      val half = totalTaxPaise / 2L
      val remainder = totalTaxPaise % 2L
      when {
        remainder == 0L -> {
          cgstPaise = half
          sgstPaise = half
        }
        parity -> {
          cgstPaise = CheckedMath.addExact(half, 1L)
          sgstPaise = half
          parity = false
        }
        else -> {
          cgstPaise = half
          sgstPaise = CheckedMath.addExact(half, 1L)
          parity = true
        }
      }
    }

    val line =
      CalculatedBatchLine(
        batchId = allocation.batchId,
        batchNumber = allocation.batchNumber,
        expiryYyyyMm = allocation.expiryYyyyMm,
        quantityMilli = allocation.quantityMilli,
        stockUnitName = allocation.stockUnitName,
        unitPricePaise = allocation.unitPricePaise,
        gstRateBasisPoints = gstRateBasisPoints,
        hsnCode = hsnCode,
        previousQuantityMilli = allocation.previousQuantityMilli,
        subtotalPaise = grossPaise,
        discountPaise = discountPaise,
        taxableValuePaise = taxableValuePaise,
        cgstPaise = cgstPaise,
        sgstPaise = sgstPaise,
        igstPaise = igstPaise,
        lineTotalPaise = lineTotalPaise,
      )
    return line to parity
  }

  companion object {
    const val QUANTITY_SCALE: Long = 1_000L
    const val BASIS_POINTS_SCALE: Long = 10_000L
    const val PAISE_PER_RUPEE: Long = 100L
    const val MAX_INVOICE_NUMBER_LENGTH: Int = 16
    const val MAX_INVOICE_PREFIX_LENGTH: Int = 3

    fun calculateGrossPaise(quantityMilli: Long, unitPricePaise: Long): Long {
      require(quantityMilli >= 0L) { "Quantity cannot be negative." }
      require(unitPricePaise >= 0L) { "Unit price cannot be negative." }
      val numerator = BigDecimal.valueOf(quantityMilli).multiply(BigDecimal.valueOf(unitPricePaise))
      return CheckedMath.divideRoundHalfAwayFromZero(numerator, QUANTITY_SCALE)
    }

    fun applyRoundOff(rawTotalPaise: Long, mode: RoundOffMode): Long =
      when (mode) {
        RoundOffMode.None -> rawTotalPaise
        RoundOffMode.NearestRupee -> {
          val rupees =
            CheckedMath.divideRoundHalfAwayFromZero(
              BigDecimal.valueOf(rawTotalPaise),
              PAISE_PER_RUPEE,
            )
          CheckedMath.multiplyExact(rupees, PAISE_PER_RUPEE)
        }
      }

    fun getFinancialYearLabel(localDate: LocalDate, financialYearStartMonth: Int): String {
      require(financialYearStartMonth in 1..12) {
        "Financial year start month must be between 1 and 12."
      }
      if (financialYearStartMonth == 1) {
        return String.format(Locale.ROOT, "%04d", localDate.year)
      }
      val startYear =
        if (localDate.monthValue >= financialYearStartMonth) localDate.year else localDate.year - 1
      val endYear = startYear + 1
      return String.format(Locale.ROOT, "%02d-%02d", startYear % 100, endYear % 100)
    }

    fun isValidInvoicePrefix(prefix: String?): Boolean {
      val clean = prefix?.trim().orEmpty()
      if (clean.length !in 1..MAX_INVOICE_PREFIX_LENGTH) return false
      return clean.all { c -> (c in 'A'..'Z') || (c in 'a'..'z') || (c in '0'..'9') || c == '-' }
    }

    fun formatInvoiceNumber(prefix: String?, financialYear: String, sequenceNumber: Long): String {
      require(sequenceNumber > 0L) { "Invoice sequence number must be positive." }
      val cleanPrefix = prefix?.trim()?.ifEmpty { "INV" }?.uppercase(Locale.ROOT) ?: "INV"
      val formatted =
        String.format(Locale.ROOT, "%s/%s/%06d", cleanPrefix, financialYear, sequenceNumber)
      check(formatted.length <= MAX_INVOICE_NUMBER_LENGTH) {
        "Generated invoice number '$formatted' exceeds the 16-character GST Rule 46 limit. Update the invoice prefix in Settings."
      }
      return formatted
    }
  }
}
