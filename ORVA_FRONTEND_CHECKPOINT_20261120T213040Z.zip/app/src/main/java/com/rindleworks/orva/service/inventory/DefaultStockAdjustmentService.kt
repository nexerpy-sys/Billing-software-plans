package com.rindleworks.orva.service.inventory

import com.rindleworks.orva.data.local.OrvaTransactionRunner
import com.rindleworks.orva.data.local.entity.AuditLogEntity
import com.rindleworks.orva.data.local.entity.StockDiscrepancyEntity
import com.rindleworks.orva.data.local.entity.StockMovementEntity
import com.rindleworks.orva.data.repository.StockSnapshotState
import com.rindleworks.orva.domain.common.OrvaFormatters
import com.rindleworks.orva.domain.common.StockMovementType
import com.rindleworks.orva.domain.engine.BillingClock
import com.rindleworks.orva.domain.engine.BillingInstant
import com.rindleworks.orva.domain.engine.CheckedMath
import com.rindleworks.orva.domain.inventory.StockAdjustmentInput
import com.rindleworks.orva.domain.inventory.StockAdjustmentResult
import com.rindleworks.orva.domain.inventory.StockAdjustmentService
import java.util.UUID
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

class DefaultStockAdjustmentService(
  private val transactionRunner: OrvaTransactionRunner,
  private val clock: BillingClock,
  private val snapshotRefresher: (suspend () -> Result<Boolean>)? = null,
) : StockAdjustmentService {

  private val json = Json { encodeDefaults = true }

  override suspend fun adjustBatchQuantity(input: StockAdjustmentInput): StockAdjustmentResult {
    val cleanReason = input.reason.trim()
    if (input.batchId.isBlank()) {
      return StockAdjustmentResult(succeeded = false, errorMessage = "Batch selection is required.")
    }
    if (input.countedQuantityMilli < 0L) {
      return StockAdjustmentResult(
        succeeded = false,
        errorMessage = "Counted quantity cannot be negative.",
      )
    }
    if (cleanReason.isEmpty()) {
      return StockAdjustmentResult(
        succeeded = false,
        errorMessage = "An adjustment reason is required for stock reconciliation.",
      )
    }

    val committed =
      try {
        transactionRunner.runWriteTransaction { db ->
          val batch =
            db.stockBatchDao().getById(input.batchId)
              ?: return@runWriteTransaction StockAdjustmentResult(
                succeeded = false,
                errorMessage = "Stock batch '${input.batchId}' was not found.",
              )
          val medicine =
            db.medicineDao().getById(batch.medicineId)
              ?: return@runWriteTransaction StockAdjustmentResult(
                succeeded = false,
                errorMessage = "Parent medicine for batch '${batch.batchNumber}' was not found.",
              )

          val differenceMilli = CheckedMath.subtractExact(input.countedQuantityMilli, batch.quantityMilli)
          if (differenceMilli == 0L) {
            return@runWriteTransaction StockAdjustmentResult(
              succeeded = false,
              medicineName = medicine.displayName,
              batchNumber = batch.batchNumber,
              previousQuantityMilli = batch.quantityMilli,
              newQuantityMilli = input.countedQuantityMilli,
              differenceMilli = 0L,
              errorMessage = "Counted quantity matches current stock; no adjustment is needed.",
            )
          }

          val now = BillingInstant.capture(clock)
          val utcIso = now.utcIsoText
          val localText = now.localLogText

          val rows = db.stockBatchDao().setQuantity(batch.batchId, input.countedQuantityMilli, utcIso)
          check(rows == 1) { "Failed to update batch quantity for '${batch.batchId}'." }

          val discrepancyId = UUID.randomUUID().toString()
          db.ledgerDao()
            .insertStockDiscrepancy(
              StockDiscrepancyEntity(
                discrepancyId = discrepancyId,
                batchId = batch.batchId,
                expectedQuantityMilli = batch.quantityMilli,
                countedQuantityMilli = input.countedQuantityMilli,
                differenceMilli = differenceMilli,
                reason = cleanReason,
                reconciledAtUtc = utcIso,
              )
            )

          db.ledgerDao()
            .insertStockMovement(
              StockMovementEntity(
                movementId = UUID.randomUUID().toString(),
                batchId = batch.batchId,
                medicineId = batch.medicineId,
                movementType = StockMovementType.Adjustment.dbValue,
                quantityDeltaMilli = differenceMilli,
                referenceType = "STOCK_DISCREPANCY",
                referenceId = discrepancyId,
                reason = cleanReason,
                createdAtUtc = utcIso,
                createdLocalText = localText,
              )
            )

          db.ledgerDao()
            .insertAuditLog(
              AuditLogEntity(
                auditId = UUID.randomUUID().toString(),
                actionType = "STOCK_ADJUSTED",
                entityType = "stock_batch",
                entityId = batch.batchId,
                summary =
                  "Adjusted '${medicine.displayName}' batch '${batch.batchNumber}' from ${OrvaFormatters.formatQuantity(batch.quantityMilli)} to ${OrvaFormatters.formatQuantity(input.countedQuantityMilli)}: $cleanReason",
                beforeJson = json.encodeToString(QtyAudit(batch.quantityMilli)),
                afterJson = json.encodeToString(QtyAudit(input.countedQuantityMilli)),
                createdAtUtc = utcIso,
                createdLocalText = localText,
              )
            )

          StockSnapshotState.markDirtyAndIncrementGeneration(db, utcIso)

          StockAdjustmentResult(
            succeeded = true,
            medicineName = medicine.displayName,
            batchNumber = batch.batchNumber,
            previousQuantityMilli = batch.quantityMilli,
            newQuantityMilli = input.countedQuantityMilli,
            differenceMilli = differenceMilli,
          )
        }
      } catch (ex: Exception) {
        return StockAdjustmentResult(
          succeeded = false,
          errorMessage = ex.message ?: "Unable to adjust stock quantity.",
        )
      }

    if (!committed.succeeded) return committed

    var snapshotUpdated = false
    var snapshotWarning: String? = null
    val refresher = snapshotRefresher
    if (refresher != null) {
      val res = runCatching { refresher.invoke() }.getOrElse { Result.failure(it) }
      if (res.isSuccess) {
        snapshotUpdated = true
      } else {
        snapshotWarning =
          "Adjustment saved, but StockData.json refresh failed: ${res.exceptionOrNull()?.message ?: "unknown error"}"
      }
    }

    return committed.copy(snapshotUpdated = snapshotUpdated, snapshotWarning = snapshotWarning)
  }

  @Serializable
  private data class QtyAudit(val quantityMilli: Long)
}
