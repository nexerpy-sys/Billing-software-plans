package com.rindleworks.orva.service.snapshot

import com.rindleworks.orva.data.local.OrvaDatabase
import com.rindleworks.orva.data.local.OrvaTransactionRunner
import com.rindleworks.orva.data.local.entity.AuditLogEntity
import com.rindleworks.orva.data.local.entity.BarcodeMappingEntity
import com.rindleworks.orva.data.local.entity.MedicineEntity
import com.rindleworks.orva.data.local.entity.StockBatchEntity
import com.rindleworks.orva.data.local.entity.StockMovementEntity
import com.rindleworks.orva.data.repository.StockSnapshotState
import com.rindleworks.orva.domain.common.AppVersionInfo
import com.rindleworks.orva.domain.common.OrvaSchemaInteropContract
import com.rindleworks.orva.domain.common.StockMovementType
import com.rindleworks.orva.domain.engine.BillingClock
import com.rindleworks.orva.domain.engine.BillingInstant
import com.rindleworks.orva.domain.engine.CheckedMath
import com.rindleworks.orva.domain.inventory.BatchStatus
import com.rindleworks.orva.domain.inventory.StockImportPreview
import com.rindleworks.orva.domain.inventory.StockImportResult
import com.rindleworks.orva.domain.inventory.StockSnapshotService
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import java.io.OutputStream
import java.util.Locale
import java.util.UUID
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

// Exact WPF PascalCase JSON wire DTOs for bidirectional StockData.json v1/v2 compatibility.
@Serializable
data class StockSnapshotJson(
  @SerialName("Format") val format: String = OrvaSchemaInteropContract.STOCK_DATA_FORMAT_NAME,
  @SerialName("FormatVersion") val formatVersion: Int = OrvaSchemaInteropContract.STOCK_DATA_FORMAT_VERSION,
  @SerialName("ShopId") val shopId: String? = null,
  @SerialName("ShopName") val shopName: String? = null,
  @SerialName("GeneratedAtUtc") val generatedAtUtc: String? = null,
  @SerialName("ApplicationVersion") val applicationVersion: String? = null,
  @SerialName("SnapshotGeneration") val snapshotGeneration: Long = 0L,
  @SerialName("Medicines") val medicines: List<StockSnapshotMedicineJson> = emptyList(),
)

@Serializable
data class StockSnapshotMedicineJson(
  @SerialName("MedicineId") val medicineId: String? = null,
  @SerialName("Name") val name: String = "",
  @SerialName("NormalizedName") val normalizedName: String? = null,
  @SerialName("GenericName") val genericName: String? = null,
  @SerialName("BrandName") val brandName: String? = null,
  @SerialName("Strength") val strength: String? = null,
  @SerialName("DosageForm") val dosageForm: String? = null,
  @SerialName("StockUnit") val stockUnit: String = "unit",
  @SerialName("HsnCode") val hsnCode: String? = null,
  @SerialName("GstRateBasisPoints") val gstRateBasisPoints: Int = 0,
  @SerialName("GstRateConfigured") val gstRateConfigured: Boolean? = null,
  @SerialName("LowStockThresholdMilli") val lowStockThresholdMilli: Long = 0L,
  @SerialName("IsActive") val isActive: Boolean? = null,
  @SerialName("Barcodes") val barcodes: List<String> = emptyList(),
  @SerialName("Batches") val batches: List<StockSnapshotBatchJson> = emptyList(),
)

@Serializable
data class StockSnapshotBatchJson(
  @SerialName("BatchId") val batchId: String? = null,
  @SerialName("MedicineId") val medicineId: String? = null,
  @SerialName("BatchNumber") val batchNumber: String = "",
  @SerialName("ExpiryYearMonth") val expiryYearMonth: Int = 0,
  @SerialName("MrpPaise") val mrpPaise: Long = 0L,
  @SerialName("LatestPurchasePricePaise") val latestPurchasePricePaise: Long = 0L,
  @SerialName("QuantityMilli") val quantityMilli: Long = 0L,
  @SerialName("Status") val status: String = "ACTIVE",
  @SerialName("UpdatedAtUtc") val updatedAtUtc: String? = null,
)

/**
 * Generation-safe `StockData.json` v2 writer & v1/v2 importer with exact WPF parity.
 */
class DefaultStockSnapshotService(
  private val transactionRunner: OrvaTransactionRunner,
  private val clock: BillingClock,
  private val snapshotDirectoryProvider: () -> File,
  private val appVersionInfo: AppVersionInfo,
  private val safetyBackupCreator: (suspend () -> String?)? = null,
) : StockSnapshotService {

  constructor(
    transactionRunner: OrvaTransactionRunner,
    clock: BillingClock,
    snapshotDirectory: File,
    appVersionInfo: AppVersionInfo,
    safetyBackupCreator: (suspend () -> String?)? = null,
  ) : this(
    transactionRunner = transactionRunner,
    clock = clock,
    snapshotDirectoryProvider = { snapshotDirectory },
    appVersionInfo = appVersionInfo,
    safetyBackupCreator = safetyBackupCreator,
  )

  private val writeMutex = Mutex()
  private val json = Json {
    encodeDefaults = true
    ignoreUnknownKeys = true
    prettyPrint = false
  }

  /** Test-only hook invoked after writing StockData.json but BEFORE marking dirty=0. */
  internal var beforeMarkCleanHook: (suspend () -> Unit)? = null

  /** Test-only hook invoked mid-transaction during executeStockDataImport to verify atomic rollback. */
  internal var importMidpointFailureHook: (() -> Unit)? = null

  fun snapshotFile(): File = File(snapshotDirectoryProvider(), "StockData.json")

  override suspend fun refreshSnapshot(): Result<Boolean> =
    writeMutex.withLock {
      runCatching {
        val (snapshot, capturedGeneration) = readConsistentSnapshot()
        val snapshotDirectory = snapshotDirectoryProvider()
        snapshotDirectory.mkdirs()

        val target = File(snapshotDirectory, "StockData.json")
        val temp = File(snapshotDirectory, "StockData.json.tmp")
        val previous = File(snapshotDirectory, "StockData.json.previous")

        val encoded = json.encodeToString(snapshot)
        val bytes = encoded.toByteArray(Charsets.UTF_8)

        try {
          FileOutputStream(temp).use { fos ->
            fos.write(bytes)
            fos.flush()
            runCatching { fos.fd.sync() }
          }

          // Parse and verify exact written file before replacing the previous good snapshot.
          val verified = json.decodeFromString<StockSnapshotJson>(temp.readText(Charsets.UTF_8))
          check(
            verified.format == OrvaSchemaInteropContract.STOCK_DATA_FORMAT_NAME &&
              verified.formatVersion == OrvaSchemaInteropContract.STOCK_DATA_FORMAT_VERSION &&
              verified.shopId == snapshot.shopId &&
              verified.snapshotGeneration == capturedGeneration
          ) {
            "Written StockData.json failed post-write verification."
          }

          if (target.exists()) {
            previous.delete()
            target.copyTo(previous, overwrite = true)
          }
          if (!temp.renameTo(target)) {
            temp.copyTo(target, overwrite = true)
            temp.delete()
          }
        } catch (ex: Exception) {
          temp.delete()
          throw ex
        }

        // Allow generation-race tests to inject a stock mutation right before marking clean.
        beforeMarkCleanHook?.invoke()

        val nowUtc = BillingInstant.capture(clock).utcIsoText
        transactionRunner.runWriteTransaction { db ->
          StockSnapshotState.markCleanIfGenerationMatches(db, capturedGeneration, nowUtc)
        }
      }
    }

  override suspend fun exportSnapshotTo(output: OutputStream): Result<Unit> = runCatching {
    val (snapshot, _) = readConsistentSnapshot()
    val bytes = json.encodeToString(snapshot).toByteArray(Charsets.UTF_8)
    output.write(bytes)
    output.flush()
  }

  override suspend fun previewStockDataImport(
    input: InputStream,
    sourceName: String,
  ): StockImportPreview {
    val parsed = parseAndValidateInput(input, sourceName)
    if (parsed.snapshot == null || parsed.errors.isNotEmpty()) {
      return StockImportPreview(
        isValid = false,
        sourceName = sourceName,
        formatVersion = parsed.snapshot?.formatVersion ?: 0,
        sourceShopId = parsed.snapshot?.shopId,
        sourceShopName = parsed.snapshot?.shopName,
        errors = parsed.errors,
        warnings = parsed.warnings,
      )
    }

    val snapshot = parsed.snapshot
    return transactionRunner.runRead { db ->
      buildPreviewAgainstDatabase(db, snapshot, sourceName, parsed.warnings)
    }
  }

  override suspend fun executeStockDataImport(
    input: InputStream,
    sourceName: String,
    confirmDifferentShop: Boolean,
  ): StockImportResult {
    val rawBytes =
      try {
        input.readBytes()
      } catch (ex: Exception) {
        return StockImportResult(
          succeeded = false,
          errorMessage = "Unable to read '$sourceName': ${ex.message}",
        )
      }

    val parsed = parseAndValidateInput(rawBytes.inputStream(), sourceName)
    if (parsed.snapshot == null || parsed.errors.isNotEmpty()) {
      return StockImportResult(
        succeeded = false,
        errorMessage = parsed.errors.firstOrNull() ?: "Invalid StockData.json file.",
      )
    }
    val snapshot = parsed.snapshot

    val preCheck =
      transactionRunner.runRead { db ->
        buildPreviewAgainstDatabase(db, snapshot, sourceName, parsed.warnings)
      }
    if (!preCheck.isValid) {
      return StockImportResult(
        succeeded = false,
        errorMessage = preCheck.errors.firstOrNull() ?: "StockData.json failed validation.",
      )
    }
    if (preCheck.isDifferentShop && !confirmDifferentShop) {
      return StockImportResult(
        succeeded = false,
        errorMessage =
          "This StockData.json belongs to a different shop ('${preCheck.sourceShopName ?: preCheck.sourceShopId}'). Explicit confirmation is required.",
      )
    }

    val safetyBackupPath = runCatching { safetyBackupCreator?.invoke() }.getOrNull()

    val committed =
      try {
        transactionRunner.runWriteTransaction { db ->
          val now = BillingInstant.capture(clock)
          val utcIso = now.utcIsoText
          val localText = now.localLogText

          val existingMeds = db.medicineDao().getAll()
          val existingById = existingMeds.associateBy { it.medicineId }.toMutableMap()
          val existingByNormalized = existingMeds.associateBy { it.normalizedName }.toMutableMap()
          val allExistingBatches = db.stockBatchDao().getAll()
          val existingBatchIds = allExistingBatches.map { it.batchId }.toHashSet()
          val existingBatchesByMed =
            allExistingBatches.groupBy { it.medicineId }.mapValues { it.value.toMutableList() }

          val importedMedicineIds = HashSet<String>()
          val importedBatchIds = HashSet<String>()

          var medsImported = 0
          var batchesImported = 0
          var movementsRecorded = 0
          var batchesZeroed = 0

          for (snapMed in snapshot.medicines) {
            val cleanName = snapMed.name.trim()
            val normName = cleanName.lowercase(Locale.ROOT)
            val cleanUnit = snapMed.stockUnit.trim().ifEmpty { "unit" }
            val existing =
              snapMed.medicineId?.trim()?.takeIf { it.isNotEmpty() }?.let { existingById[it] }
                ?: existingByNormalized[normName]
            if (existing != null && !existing.stockUnitName.equals(cleanUnit, ignoreCase = true)) {
              throw IllegalStateException(
                "Unit conflict for '$cleanName': existing unit is '${existing.stockUnitName}' but file has '$cleanUnit'."
              )
            }
            val medId =
              existing?.medicineId
                ?: snapMed.medicineId?.trim()?.takeIf { it.isNotEmpty() && !existingById.containsKey(it) }
                ?: UUID.randomUUID().toString()
            importedMedicineIds.add(medId)

            // Format v1 compatibility: never falsely mark unconfigured GST rates as configured.
            val resolvedGstConfigured: Int =
              when {
                snapshot.formatVersion >= 2 && snapMed.gstRateConfigured != null ->
                  if (snapMed.gstRateConfigured) 1 else 0
                existing != null -> existing.gstRateConfigured
                else -> 0
              }
            val resolvedGstBps: Int =
              when {
                snapshot.formatVersion >= 2 && snapMed.gstRateConfigured != null ->
                  snapMed.gstRateBasisPoints.coerceIn(0, 10_000)
                existing != null && existing.gstRateConfigured == 1 -> existing.gstRateBasisPoints
                else -> snapMed.gstRateBasisPoints.coerceIn(0, 10_000)
              }
            val resolvedHsn: String? =
              if (snapshot.formatVersion >= 2) {
                snapMed.hsnCode?.trim()?.ifEmpty { null }
              } else {
                existing?.hsnCode ?: snapMed.hsnCode?.trim()?.ifEmpty { null }
              }
            val resolvedActive = if (snapMed.isActive ?: true) 1 else 0

            if (existing == null) {
              val created =
                MedicineEntity(
                  medicineId = medId,
                  displayName = cleanName,
                  normalizedName = normName,
                  genericName = snapMed.genericName?.trim()?.ifEmpty { null },
                  brandName = snapMed.brandName?.trim()?.ifEmpty { null },
                  strength = snapMed.strength?.trim()?.ifEmpty { null },
                  dosageForm = snapMed.dosageForm?.trim()?.ifEmpty { null },
                  stockUnitName = cleanUnit,
                  hsnCode = resolvedHsn,
                  gstRateBasisPoints = resolvedGstBps,
                  gstRateConfigured = resolvedGstConfigured,
                  lowStockThresholdMilli = maxOf(0L, snapMed.lowStockThresholdMilli),
                  isActive = resolvedActive,
                  createdAtUtc = utcIso,
                  updatedAtUtc = utcIso,
                )
              db.medicineDao().insert(created)
              existingById[medId] = created
              existingByNormalized[normName] = created
            } else {
              val updated =
                existing.copy(
                  displayName = cleanName,
                  normalizedName = normName,
                  genericName = snapMed.genericName?.trim()?.ifEmpty { null } ?: existing.genericName,
                  brandName = snapMed.brandName?.trim()?.ifEmpty { null } ?: existing.brandName,
                  strength = snapMed.strength?.trim()?.ifEmpty { null } ?: existing.strength,
                  dosageForm = snapMed.dosageForm?.trim()?.ifEmpty { null } ?: existing.dosageForm,
                  stockUnitName = existing.stockUnitName,
                  hsnCode = resolvedHsn,
                  gstRateBasisPoints = resolvedGstBps,
                  gstRateConfigured = resolvedGstConfigured,
                  lowStockThresholdMilli = maxOf(0L, snapMed.lowStockThresholdMilli),
                  isActive = resolvedActive,
                  updatedAtUtc = utcIso,
                )
              db.medicineDao().update(updated)
              existingById[medId] = updated
              existingByNormalized[normName] = updated
            }
            medsImported++

            if (snapshot.formatVersion >= 2) {
              for (rawBarcode in snapMed.barcodes) {
                val code = rawBarcode.trim()
                if (code.isNotEmpty()) {
                  // INSERT OR IGNORE matching WPF StockDataImporter: never hijack another medicine's barcode.
                  db.barcodeMappingDao().insertIgnore(BarcodeMappingEntity(code, medId, utcIso))
                }
              }
            }

            val currentMedBatches = existingBatchesByMed[medId].orEmpty()
            for (snapBatch in snapMed.batches) {
              val cleanBatchNum = snapBatch.batchNumber.trim()
              val normBatchKey = cleanBatchNum.uppercase(Locale.ROOT)
              val existingBatch =
                snapBatch.batchId?.trim()?.takeIf { it.isNotEmpty() }?.let { bid ->
                  currentMedBatches.firstOrNull { it.batchId == bid }
                }
                  ?: currentMedBatches.firstOrNull {
                    it.batchNumber.trim().uppercase(Locale.ROOT) == normBatchKey &&
                      it.expiryYyyyMm == snapBatch.expiryYearMonth
                  }
              val validStatus =
                BatchStatus.fromDbValue(snapBatch.status)?.dbValue ?: BatchStatus.Active.dbValue

              if (existingBatch == null) {
                val newBatchId =
                  snapBatch.batchId?.trim()?.takeIf { it.isNotEmpty() && !existingBatchIds.contains(it) }
                    ?: UUID.randomUUID().toString()
                existingBatchIds.add(newBatchId)
                importedBatchIds.add(newBatchId)
                db.stockBatchDao()
                  .insert(
                    StockBatchEntity(
                      batchId = newBatchId,
                      medicineId = medId,
                      batchNumber = cleanBatchNum,
                      expiryYyyyMm = snapBatch.expiryYearMonth,
                      stockUnitName = existing?.stockUnitName ?: cleanUnit,
                      mrpPaise = snapBatch.mrpPaise,
                      latestPurchasePricePaise = snapBatch.latestPurchasePricePaise,
                      quantityMilli = snapBatch.quantityMilli,
                      batchStatus = validStatus,
                      createdAtUtc = utcIso,
                      updatedAtUtc = utcIso,
                    )
                  )
                if (snapBatch.quantityMilli > 0L) {
                  db.ledgerDao()
                    .insertStockMovement(
                      StockMovementEntity(
                        movementId = UUID.randomUUID().toString(),
                        batchId = newBatchId,
                        medicineId = medId,
                        movementType = StockMovementType.Import.dbValue,
                        quantityDeltaMilli = snapBatch.quantityMilli,
                        referenceType = "STOCK_DATA_IMPORT",
                        referenceId = sourceName,
                        reason = "Imported from $sourceName",
                        createdAtUtc = utcIso,
                        createdLocalText = localText,
                      )
                    )
                  movementsRecorded++
                }
              } else {
                importedBatchIds.add(existingBatch.batchId)
                val delta = CheckedMath.subtractExact(snapBatch.quantityMilli, existingBatch.quantityMilli)
                db.stockBatchDao()
                  .update(
                    existingBatch.copy(
                      stockUnitName = existing?.stockUnitName ?: existingBatch.stockUnitName,
                      mrpPaise = snapBatch.mrpPaise,
                      latestPurchasePricePaise = snapBatch.latestPurchasePricePaise,
                      quantityMilli = snapBatch.quantityMilli,
                      batchStatus = validStatus,
                      updatedAtUtc = utcIso,
                    )
                  )
                if (delta != 0L) {
                  db.ledgerDao()
                    .insertStockMovement(
                      StockMovementEntity(
                        movementId = UUID.randomUUID().toString(),
                        batchId = existingBatch.batchId,
                        medicineId = medId,
                        movementType = StockMovementType.Import.dbValue,
                        quantityDeltaMilli = delta,
                        referenceType = "STOCK_DATA_IMPORT",
                        referenceId = sourceName,
                        reason = "StockData import delta from $sourceName",
                        createdAtUtc = utcIso,
                        createdLocalText = localText,
                      )
                    )
                  movementsRecorded++
                }
              }
              batchesImported++
            }
          }

          // Test hook to verify atomic transaction rollback on mid-import failure.
          importMidpointFailureHook?.invoke()

          // Soft-inactivate medicines missing from snapshot (never hard-delete historical records).
          for (med in existingMeds) {
            if (med.isActive == 1 && !importedMedicineIds.contains(med.medicineId)) {
              db.medicineDao().updateActiveFlag(med.medicineId, 0, utcIso)
            }
          }

          // Zero any positive batches not present in snapshot with negative IMPORT movements.
          for (batch in db.stockBatchDao().getAll()) {
            if (!importedBatchIds.contains(batch.batchId) && batch.quantityMilli > 0L) {
              db.stockBatchDao().setQuantity(batch.batchId, 0L, utcIso)
              db.ledgerDao()
                .insertStockMovement(
                  StockMovementEntity(
                    movementId = UUID.randomUUID().toString(),
                    batchId = batch.batchId,
                    medicineId = batch.medicineId,
                    movementType = StockMovementType.Import.dbValue,
                    quantityDeltaMilli = CheckedMath.negateExact(batch.quantityMilli),
                    referenceType = "STOCK_DATA_IMPORT",
                    referenceId = sourceName,
                    reason = "Zeroed batch absent from $sourceName",
                    createdAtUtc = utcIso,
                    createdLocalText = localText,
                  )
                )
              movementsRecorded++
              batchesZeroed++
            }
          }

          db.ledgerDao()
            .insertAuditLog(
              AuditLogEntity(
                auditId = UUID.randomUUID().toString(),
                actionType = "STOCK_DATA_IMPORTED",
                entityType = "stock_snapshot",
                entityId = sourceName,
                summary =
                  "Imported $medsImported medicines and $batchesImported batches from '$sourceName' (zeroed $batchesZeroed)",
                beforeJson = null,
                afterJson = null,
                createdAtUtc = utcIso,
                createdLocalText = localText,
              )
            )

          StockSnapshotState.markDirtyAndIncrementGeneration(db, utcIso)

          StockImportResult(
            succeeded = true,
            medicinesImported = medsImported,
            batchesImported = batchesImported,
            stockMovementsRecorded = movementsRecorded,
            batchesZeroed = batchesZeroed,
            safetyBackupPath = safetyBackupPath,
          )
        }
      } catch (ex: Exception) {
        return StockImportResult(
          succeeded = false,
          safetyBackupPath = safetyBackupPath,
          errorMessage = ex.message ?: "StockData import failed and was rolled back.",
        )
      }

    val refresh = refreshSnapshot()
    return committed.copy(
      snapshotUpdated = refresh.isSuccess,
      snapshotWarning =
        refresh.exceptionOrNull()?.let {
          "Import succeeded, but refreshing local StockData.json failed: ${it.message}"
        },
    )
  }

  private suspend fun readConsistentSnapshot(): Pair<StockSnapshotJson, Long> =
    transactionRunner.runRead { db ->
      val shop =
        db.shopProfileDao().getProfile()
          ?: throw IllegalStateException("Shop setup must be completed before writing StockData.json.")
      val generation = StockSnapshotState.readGeneration(db)
      val activeMedicines = db.medicineDao().getActiveMedicines()
      val batchesByMed = db.stockBatchDao().getAll().groupBy { it.medicineId }
      val barcodesByMed = db.barcodeMappingDao().getAll().groupBy { it.medicineId }

      val medDtos =
        activeMedicines.map { med ->
          val batches =
            batchesByMed[med.medicineId].orEmpty().map { b ->
              StockSnapshotBatchJson(
                batchId = b.batchId,
                medicineId = med.medicineId,
                batchNumber = b.batchNumber,
                expiryYearMonth = b.expiryYyyyMm,
                mrpPaise = b.mrpPaise,
                latestPurchasePricePaise = b.latestPurchasePricePaise,
                quantityMilli = b.quantityMilli,
                status = b.batchStatus,
                updatedAtUtc = b.updatedAtUtc,
              )
            }
          val barcodes = barcodesByMed[med.medicineId].orEmpty().map { it.barcode }.sorted()

          StockSnapshotMedicineJson(
            medicineId = med.medicineId,
            name = med.displayName,
            normalizedName = med.normalizedName,
            genericName = med.genericName,
            brandName = med.brandName,
            strength = med.strength,
            dosageForm = med.dosageForm,
            stockUnit = med.stockUnitName,
            hsnCode = med.hsnCode,
            gstRateBasisPoints = med.gstRateBasisPoints,
            gstRateConfigured = med.gstRateConfigured == 1,
            lowStockThresholdMilli = med.lowStockThresholdMilli,
            isActive = med.isActive == 1,
            barcodes = barcodes,
            batches = batches,
          )
        }

      val snapshot =
        StockSnapshotJson(
          format = OrvaSchemaInteropContract.STOCK_DATA_FORMAT_NAME,
          formatVersion = OrvaSchemaInteropContract.STOCK_DATA_FORMAT_VERSION,
          shopId = shop.shopId,
          shopName = shop.shopName,
          generatedAtUtc = BillingInstant.capture(clock).utcIsoText,
          applicationVersion = appVersionInfo.versionName,
          snapshotGeneration = generation,
          medicines = medDtos,
        )
      snapshot to generation
    }

  private fun parseAndValidateInput(input: InputStream, sourceName: String): ParsedSnapshot {
    val errors = mutableListOf<String>()
    val warnings = mutableListOf<String>()

    val text =
      try {
        input.bufferedReader(Charsets.UTF_8).use { it.readText() }.trimStart('\uFEFF')
      } catch (ex: Exception) {
        return ParsedSnapshot(null, listOf("Cannot read '$sourceName': ${ex.message}"), warnings)
      }

    val snapshot =
      try {
        json.decodeFromString<StockSnapshotJson>(text)
      } catch (ex: Exception) {
        return ParsedSnapshot(
          null,
          listOf("Invalid JSON in '$sourceName': ${ex.message}"),
          warnings,
        )
      }

    if (snapshot.format != OrvaSchemaInteropContract.STOCK_DATA_FORMAT_NAME) {
      errors += "Unsupported stock file format '${snapshot.format}' (expected '${OrvaSchemaInteropContract.STOCK_DATA_FORMAT_NAME}')."
    }
    if (snapshot.formatVersion !in 1..OrvaSchemaInteropContract.STOCK_DATA_FORMAT_VERSION) {
      errors +=
        "Unsupported StockData format version ${snapshot.formatVersion} (this version of ORVA supports v1 and v2)."
    }
    if (snapshot.formatVersion == 1) {
      warnings += "Legacy Format Version 1 StockData file: unconfigured medicine GST rates will remain unconfigured."
    }

    val seenMeds = HashSet<String>()
    for ((mIdx, med) in snapshot.medicines.withIndex()) {
      val cleanName = med.name.trim()
      if (cleanName.isEmpty()) {
        errors += "Medicine entry #${mIdx + 1} is missing a name."
        continue
      }
      val norm = cleanName.lowercase(Locale.ROOT)
      if (!seenMeds.add(norm)) {
        errors += "Duplicate medicine '$cleanName' found in StockData file."
      }
      if (med.gstRateBasisPoints !in 0..10_000) {
        errors += "Invalid GST rate (${med.gstRateBasisPoints} bps) for '$cleanName'."
      }
      if (med.lowStockThresholdMilli < 0L) {
        errors += "Negative low-stock threshold for '$cleanName'."
      }

      val seenBatches = HashSet<String>()
      for (b in med.batches) {
        val bn = b.batchNumber.trim()
        if (bn.isEmpty()) {
          errors += "Empty batch number for '$cleanName'."
          continue
        }
        val year = b.expiryYearMonth / 100
        val month = b.expiryYearMonth % 100
        if (year !in 2000..2199 || month !in 1..12) {
          errors += "Invalid expiry (${b.expiryYearMonth}) for '$cleanName' batch '$bn'."
        }
        if (b.quantityMilli < 0L || b.mrpPaise < 0L || b.latestPurchasePricePaise < 0L) {
          errors += "Negative quantity or price for '$cleanName' batch '$bn'."
        }
        if (BatchStatus.fromDbValue(b.status) == null) {
          errors += "Invalid batch status '${b.status}' for '$cleanName' batch '$bn'."
        }
        val bKey = "${bn.uppercase(Locale.ROOT)}|${b.expiryYearMonth}"
        if (!seenBatches.add(bKey)) {
          errors += "Duplicate batch '$bn' (${b.expiryYearMonth}) for '$cleanName'."
        }
      }
    }

    return ParsedSnapshot(snapshot, errors, warnings)
  }

  private fun buildPreviewAgainstDatabase(
    db: OrvaDatabase,
    snapshot: StockSnapshotJson,
    sourceName: String,
    warnings: List<String>,
  ): StockImportPreview {
    val targetShop = db.shopProfileDao().getProfile()
    val isDifferentShop =
      !targetShop?.shopId.isNullOrBlank() &&
        !snapshot.shopId.isNullOrBlank() &&
        targetShop.shopId != snapshot.shopId

    val existingMeds = db.medicineDao().getAll()
    val existingById = existingMeds.associateBy { it.medicineId }
    val existingByNorm = existingMeds.associateBy { it.normalizedName }
    val existingBatches = db.stockBatchDao().getAll()
    val existingBatchesByMed = existingBatches.groupBy { it.medicineId }

    val matchedMedIds = HashSet<String>()
    val matchedBatchIds = HashSet<String>()
    val previewErrors = mutableListOf<String>()

    var newMeds = 0
    var matchedMeds = 0
    var newBatches = 0
    var changedBatches = 0
    var totalQty = 0L
    var totalBatchCount = 0

    for (med in snapshot.medicines) {
      val cleanName = med.name.trim()
      val norm = cleanName.lowercase(Locale.ROOT)
      val cleanUnit = med.stockUnit.trim().ifEmpty { "unit" }
      val existing =
        med.medicineId?.trim()?.takeIf { it.isNotEmpty() }?.let { existingById[it] }
          ?: existingByNorm[norm]
      if (existing == null) {
        newMeds++
      } else {
        matchedMeds++
        matchedMedIds.add(existing.medicineId)
        if (!existing.stockUnitName.equals(cleanUnit, ignoreCase = true)) {
          previewErrors +=
            "Unit conflict for '$cleanName': existing unit is '${existing.stockUnitName}' but file has '$cleanUnit'."
        }
      }

      val existingForMed = existing?.let { existingBatchesByMed[it.medicineId] }.orEmpty()
      for (b in med.batches) {
        totalBatchCount++
        totalQty = CheckedMath.addExact(totalQty, b.quantityMilli)
        val existingBatch =
          b.batchId?.trim()?.takeIf { it.isNotEmpty() }?.let { bid ->
            existingForMed.firstOrNull { it.batchId == bid }
          }
            ?: existingForMed.firstOrNull {
              it.batchNumber.trim().uppercase(Locale.ROOT) == b.batchNumber.trim().uppercase(Locale.ROOT) &&
                it.expiryYyyyMm == b.expiryYearMonth
            }
        if (existingBatch == null) {
          newBatches++
        } else {
          matchedBatchIds.add(existingBatch.batchId)
          if (existingBatch.quantityMilli != b.quantityMilli || existingBatch.mrpPaise != b.mrpPaise) {
            changedBatches++
          }
        }
      }
    }

    val softInactivated =
      existingMeds.count { it.isActive == 1 && !matchedMedIds.contains(it.medicineId) }
    val zeroedBatches =
      existingBatches.count { it.quantityMilli > 0L && !matchedBatchIds.contains(it.batchId) }

    val combinedWarnings = warnings.toMutableList()
    if (isDifferentShop) {
      combinedWarnings +=
        "This StockData.json comes from shop '${snapshot.shopName ?: snapshot.shopId}', which differs from your current shop '${targetShop.shopName}'."
    }

    return StockImportPreview(
      isValid = previewErrors.isEmpty(),
      sourceName = sourceName,
      formatVersion = snapshot.formatVersion,
      sourceShopId = snapshot.shopId,
      sourceShopName = snapshot.shopName,
      targetShopId = targetShop?.shopId,
      targetShopName = targetShop?.shopName,
      isDifferentShop = isDifferentShop,
      generatedAtUtc = snapshot.generatedAtUtc,
      medicineCount = snapshot.medicines.size,
      batchCount = totalBatchCount,
      totalImportedQuantityMilli = totalQty,
      newMedicineCount = newMeds,
      matchedMedicineCount = matchedMeds,
      softInactivatedMedicineCount = softInactivated,
      newBatchCount = newBatches,
      changedBatchCount = changedBatches,
      zeroedBatchCount = zeroedBatches,
      errors = previewErrors,
      warnings = combinedWarnings,
    )
  }

  private data class ParsedSnapshot(
    val snapshot: StockSnapshotJson?,
    val errors: List<String>,
    val warnings: List<String>,
  )
}
