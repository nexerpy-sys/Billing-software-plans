package com.rindleworks.orva.domain.engine

import java.util.Locale

data class GstinValidationResult(
  val isValid: Boolean,
  val normalizedGstin: String? = null,
  val stateCode: String? = null,
  val errorMessage: String? = null,
)

/**
 * Indian 15-character GSTIN validator with official Mod-36 checksum verification.
 * Exact parity with ORVA WPF GstinValidator.cs.
 */
object GstinValidator {
  private const val CHECKSUM_ALPHABET = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ"

  fun validate(rawGstin: String?): GstinValidationResult {
    val gstin = rawGstin?.trim()?.uppercase(Locale.ROOT).orEmpty()
    if (gstin.length != 15) {
      return invalid("GSTIN must be exactly 15 characters long.")
    }

    val stateCode = gstin.substring(0, 2)
    if (!stateCode[0].isDigit() || !stateCode[1].isDigit() ||
      !IndianGstStateCatalog.isValidGstinStateCode(stateCode)
    ) {
      return invalid("GSTIN state code '$stateCode' is not a valid Indian GST state code.")
    }

    // Characters 3-7 (indices 2..6): uppercase ASCII letters (PAN part 1)
    for (i in 2..6) {
      if (!isAsciiUpperLetter(gstin[i])) {
        return invalid("GSTIN structure is invalid (characters 3-7 must be letters).")
      }
    }
    // Characters 8-11 (indices 7..10): digits (PAN part 2)
    for (i in 7..10) {
      if (!gstin[i].isDigit()) {
        return invalid("GSTIN structure is invalid (characters 8-11 must be digits).")
      }
    }
    // Character 12 (index 11): uppercase ASCII letter (PAN check letter)
    if (!isAsciiUpperLetter(gstin[11])) {
      return invalid("GSTIN structure is invalid (character 12 must be a letter).")
    }
    // Character 13 (index 12): entity number (1-9 or A-Z, cannot be '0')
    val entityChar = gstin[12]
    if (entityChar !in '1'..'9' && !isAsciiUpperLetter(entityChar)) {
      return invalid("GSTIN structure is invalid (character 13 must be 1-9 or A-Z).")
    }
    // Character 14 (index 13): default 'Z'
    if (gstin[13] != 'Z') {
      return invalid("GSTIN structure is invalid (character 14 must be 'Z').")
    }
    // Character 15 (index 14): official Mod-36 checksum
    val expectedChecksum = computeChecksumCharacter(gstin.substring(0, 14))
    if (gstin[14] != expectedChecksum) {
      return invalid("GSTIN checksum is invalid. Please re-check the 15-character GSTIN.")
    }

    return GstinValidationResult(
      isValid = true,
      normalizedGstin = gstin,
      stateCode = stateCode,
      errorMessage = null,
    )
  }

  fun computeChecksumCharacter(first14Characters: String): Char {
    require(first14Characters.length == 14) {
      "Exactly 14 characters are required to compute the GSTIN checksum."
    }
    var sum = 0
    for (i in 0 until 14) {
      val codePoint = CHECKSUM_ALPHABET.indexOf(first14Characters[i])
      require(codePoint >= 0) { "Invalid character in GSTIN prefix: ${first14Characters[i]}" }
      val factor = if (i % 2 == 0) 1 else 2
      val product = codePoint * factor
      val digit = (product / 36) + (product % 36)
      sum += digit
    }
    val remainder = sum % 36
    val checkCodePoint = (36 - remainder) % 36
    return CHECKSUM_ALPHABET[checkCodePoint]
  }

  private fun isAsciiUpperLetter(c: Char): Boolean = c in 'A'..'Z'

  private fun invalid(message: String): GstinValidationResult =
    GstinValidationResult(isValid = false, errorMessage = message)
}
