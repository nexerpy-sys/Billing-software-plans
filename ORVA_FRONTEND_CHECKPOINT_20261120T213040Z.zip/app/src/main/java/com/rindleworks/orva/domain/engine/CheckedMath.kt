package com.rindleworks.orva.domain.engine

import java.math.BigDecimal
import java.math.RoundingMode

/**
 * Overflow-safe integer arithmetic and exact base-10 rounding helpers.
 * Never uses binary floating-point (Float/Double).
 */
object CheckedMath {
  fun addExact(a: Long, b: Long): Long = Math.addExact(a, b)

  fun subtractExact(a: Long, b: Long): Long = Math.subtractExact(a, b)

  fun multiplyExact(a: Long, b: Long): Long = Math.multiplyExact(a, b)

  fun negateExact(value: Long): Long = Math.negateExact(value)

  /**
   * Divides [numerator] by positive [denominator] using exact base-10 round-half-away-from-zero
   * (Java/Kotlin [RoundingMode.HALF_UP], equivalent to .NET MidpointRounding.AwayFromZero).
   */
  fun divideRoundHalfAwayFromZero(numerator: BigDecimal, denominator: BigDecimal): Long {
    require(denominator > BigDecimal.ZERO) { "Denominator must be positive." }
    val rounded = numerator.divide(denominator, 0, RoundingMode.HALF_UP)
    return rounded.longValueExact()
  }

  fun divideRoundHalfAwayFromZero(numerator: BigDecimal, denominator: Long): Long =
    divideRoundHalfAwayFromZero(numerator, BigDecimal.valueOf(denominator))
}
