package com.rindleworks.orva.ui.about.agentic

import java.text.BreakIterator
import java.util.Locale

/**
 * UTF-16 offsets at user-perceived character boundaries for Agentic Build text reveals.
 *
 * BreakIterator supplies the Unicode character boundaries. Android/JDK versions predating the
 * modern Indic-conjunct grapheme rule can still expose a boundary immediately after a virama;
 * merge that boundary when the next code point is a letter so Bengali and related scripts are
 * never revealed halfway through a conjunct. ZWNJ is deliberately not merged because it can
 * intentionally break shaping.
 */
internal object AgenticGraphemeBoundaries {
  private const val ZERO_WIDTH_JOINER = 0x200D
  private const val ZERO_WIDTH_NON_JOINER = 0x200C

  private val viramas = setOf(
    0x094D, // Devanagari
    0x09CD, // Bengali
    0x0A4D, // Gurmukhi
    0x0ACD, // Gujarati
    0x0B4D, // Odia
    0x0BCD, // Tamil
    0x0C4D, // Telugu
    0x0CCD, // Kannada
    0x0D4D, // Malayalam
    0x0DCA, // Sinhala
    0x1039, // Myanmar
    0x17D2, // Khmer
  )

  fun boundaries(text: String): List<Int> {
    if (text.isEmpty()) return listOf(0)

    val iterator = BreakIterator.getCharacterInstance(Locale.ROOT)
    iterator.setText(text)

    val output = ArrayList<Int>(text.length + 1)
    var boundary = iterator.first()
    while (boundary != BreakIterator.DONE) {
      if (boundary == 0 || boundary == text.length || !continuesIndicConjunct(text, boundary)) {
        if (output.lastOrNull() != boundary) output += boundary
      }
      boundary = iterator.next()
    }

    if (output.firstOrNull() != 0) output.add(0, 0)
    if (output.lastOrNull() != text.length) output += text.length
    return output
  }

  fun offsetAtProgress(boundaries: List<Int>, progress: Float): Int {
    val graphemeCount = (boundaries.size - 1).coerceAtLeast(0)
    if (graphemeCount == 0) return 0
    val index = (progress.coerceIn(0f, 1f) * graphemeCount).toInt().coerceIn(0, graphemeCount)
    return boundaries[index]
  }

  private fun continuesIndicConjunct(text: String, boundary: Int): Boolean {
    if (boundary <= 0 || boundary >= text.length) return false

    val nextCodePoint = text.codePointAt(boundary)
    if (!Character.isLetter(nextCodePoint)) return false

    val previousCodePoint = text.codePointBefore(boundary)
    if (previousCodePoint == ZERO_WIDTH_NON_JOINER) return false

    val linkerCodePoint =
      if (previousCodePoint == ZERO_WIDTH_JOINER) {
        val beforeJoinerOffset = boundary - Character.charCount(previousCodePoint)
        if (beforeJoinerOffset <= 0) return false
        text.codePointBefore(beforeJoinerOffset)
      } else {
        previousCodePoint
      }

    return linkerCodePoint in viramas
  }
}
