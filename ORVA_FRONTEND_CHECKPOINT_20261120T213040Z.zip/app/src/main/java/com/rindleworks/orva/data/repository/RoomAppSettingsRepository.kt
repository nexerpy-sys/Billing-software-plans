package com.rindleworks.orva.data.repository

import com.rindleworks.orva.data.local.OrvaDatabaseProvider
import com.rindleworks.orva.data.local.OrvaTransactionRunner
import com.rindleworks.orva.data.local.entity.AppSettingEntity
import com.rindleworks.orva.domain.common.OrvaDateTimeFormatters
import com.rindleworks.orva.domain.common.OrvaSettingKeys
import com.rindleworks.orva.domain.engine.BillingClock
import com.rindleworks.orva.domain.engine.BillingInstant
import com.rindleworks.orva.domain.settings.AppLanguage
import com.rindleworks.orva.domain.settings.AppSettingsRepository
import com.rindleworks.orva.domain.settings.OperationalSupportPrefs
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.map

@OptIn(ExperimentalCoroutinesApi::class)
class RoomAppSettingsRepository(
  private val databaseProvider: OrvaDatabaseProvider,
  private val transactionRunner: OrvaTransactionRunner,
  private val clock: BillingClock,
) : AppSettingsRepository {

  override fun observe(key: String, defaultValue: String): Flow<String> =
    databaseProvider.databaseGeneration.flatMapLatest {
      databaseProvider.current().appSettingDao().observeValue(key).map { it ?: defaultValue }
    }

  override suspend fun get(key: String, defaultValue: String): String =
    transactionRunner.runRead { db -> db.appSettingDao().getValue(key) ?: defaultValue }

  override suspend fun set(key: String, value: String) {
    val utcIso = BillingInstant.capture(clock).utcIsoText
    transactionRunner.runWriteTransaction { db ->
      db.appSettingDao().upsert(AppSettingEntity(key, value, utcIso))
    }
  }

  override suspend fun getLanguage(): AppLanguage =
    AppLanguage.fromCode(get(OrvaSettingKeys.DISPLAY_LANGUAGE, AppLanguage.English.code))

  override suspend fun setLanguage(language: AppLanguage) {
    set(OrvaSettingKeys.DISPLAY_LANGUAGE, language.code)
  }

  override suspend fun getOperationalSupportPrefs(): OperationalSupportPrefs =
    transactionRunner.runRead { db ->
      val dao = db.appSettingDao()
      OperationalSupportPrefs(
        supportPhones = dao.getValue(OrvaSettingKeys.SUPPORT_PHONES).orEmpty(),
        supportWhatsapp = dao.getValue(OrvaSettingKeys.SUPPORT_WHATSAPP).orEmpty(),
        supportEmail = dao.getValue(OrvaSettingKeys.SUPPORT_EMAIL).orEmpty(),
        upiId = dao.getValue(OrvaSettingKeys.UPI_ID).orEmpty(),
        upiPayeeName = dao.getValue(OrvaSettingKeys.UPI_PAYEE_NAME).orEmpty(),
      )
    }
}
