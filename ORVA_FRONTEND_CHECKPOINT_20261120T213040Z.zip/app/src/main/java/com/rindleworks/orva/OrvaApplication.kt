package com.rindleworks.orva

import android.app.Application
import com.rindleworks.orva.di.OrvaAppContainer
import com.rindleworks.orva.domain.settings.BackupRestoreService
import com.rindleworks.orva.service.backup.BackupServiceHolder
import com.rindleworks.orva.service.backup.DailyBackupScheduler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

/**
 * Android Application entry point hosting the singleton production [OrvaAppContainer],
 * scheduling WorkManager's automatic daily `.shopbackup` task, and running non-blocking
 * startup maintenance (dirty `StockData.json` recovery, due daily backup, 12h subscription refresh).
 */
class OrvaApplication : Application(), BackupServiceHolder {

  val container: OrvaAppContainer by lazy { OrvaAppContainer(this) }

  private val applicationScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

  override val backupRestoreService: BackupRestoreService
    get() = container.backupRestoreService

  override fun onCreate() {
    super.onCreate()
    // Schedule automatic daily local backup via WorkManager (safe no-op if WorkManager is uninitialized in unit tests).
    runCatching { DailyBackupScheduler.schedulePeriodic(this) }
    // Run non-blocking startup maintenance (matches WPF App.xaml.cs startup lifecycle).
    applicationScope.launch {
      runCatching { container.runStartupMaintenance() }
    }
  }
}
