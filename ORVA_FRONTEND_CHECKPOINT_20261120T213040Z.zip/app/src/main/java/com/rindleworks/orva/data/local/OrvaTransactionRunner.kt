package com.rindleworks.orva.data.local

import androidx.room.InvalidationTracker
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext

/**
 * Serialized, BEGIN IMMEDIATE SQLite write-transaction coordinator for ORVA.
 *
 * Under WAL mode, `SupportSQLiteDatabase.beginTransactionNonExclusive()` issues SQLite's
 * `BEGIN IMMEDIATE`, acquiring the reserved write lock upfront before reading stock/sequences.
 * Combined with an in-process [writeMutex] (shared with backup/restore via [withMaintenanceLock]),
 * concurrent invoice finalisations, stock entries, returns, and backup snapshots can never
 * interleave, oversell stock, duplicate invoice numbers, or leak partial commits.
 */
class OrvaTransactionRunner(
  private val databaseProvider: OrvaDatabaseProvider,
  private val ioDispatcher: CoroutineDispatcher = Dispatchers.IO,
) {
  private val writeMutex = Mutex()

  /**
   * Executes [block] inside a serialized SQLite `BEGIN IMMEDIATE` transaction on [ioDispatcher].
   * Any exception thrown inside [block] rolls back the entire SQLite transaction atomically.
   */
  suspend fun <T> runWriteTransaction(block: (OrvaDatabase) -> T): T =
    writeMutex.withLock {
      withContext(ioDispatcher) {
        val db = databaseProvider.current()
        val sqlite = db.openHelper.writableDatabase
        // Android's beginTransactionNonExclusive() maps directly to SQLite BEGIN IMMEDIATE.
        sqlite.beginTransactionNonExclusive()
        var committed = false
        try {
          val result = block(db)
          sqlite.setTransactionSuccessful()
          committed = true
          result
        } finally {
          sqlite.endTransaction()
          if (committed) {
            // Manually notify Room's InvalidationTracker so Flow observers update immediately
            // even though we used low-level BEGIN IMMEDIATE instead of Room's beginTransaction().
            runCatching { db.invalidationTracker.refreshVersionsAsync() }
          }
        }
      }
    }

  /**
   * Executes a read-only database operation on [ioDispatcher].
   */
  suspend fun <T> runRead(block: (OrvaDatabase) -> T): T =
    withContext(ioDispatcher) {
      val db = databaseProvider.current()
      block(db)
    }

  /**
   * Acquires the exclusive write lock without starting a SQLite transaction.
   * Used by backup checkpointing and live `.shopbackup` restore (which closes and replaces
   * the SQLite file safely while blocking all concurrent writes).
   */
  suspend fun <T> withMaintenanceLock(block: suspend () -> T): T =
    writeMutex.withLock {
      withContext(ioDispatcher) {
        block()
      }
    }
}
