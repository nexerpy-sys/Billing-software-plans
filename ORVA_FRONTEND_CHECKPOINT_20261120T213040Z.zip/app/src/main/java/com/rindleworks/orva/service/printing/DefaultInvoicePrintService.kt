package com.rindleworks.orva.service.printing

import com.rindleworks.orva.domain.billing.InvoicePaperFormat
import com.rindleworks.orva.domain.billing.InvoicePrintRequest
import com.rindleworks.orva.domain.billing.InvoicePrintResult
import com.rindleworks.orva.domain.billing.InvoicePrintService
import com.rindleworks.orva.domain.billing.ThermalPrinterTransport
import com.rindleworks.orva.domain.common.OrvaDateTimeFormatters
import com.rindleworks.orva.domain.common.OrvaFormatters
import com.rindleworks.orva.domain.common.OrvaSettingKeys
import com.rindleworks.orva.domain.settings.AppSettingsRepository
import com.rindleworks.orva.service.export.PdfExportHelper
import java.io.ByteArrayOutputStream
import java.io.OutputStream

/**
 * Pure ESC/POS byte encoder for 58mm (32 chars / 384 dots) and 80mm (48 chars / 576 dots)
 * Bluetooth SPP and USB-OTG thermal receipt printers.
 */
object EscPosInvoiceEncoder {
  const val WIDTH_DOTS_58MM = 384
  const val WIDTH_DOTS_80MM = 576

  private val CMD_INIT = byteArrayOf(0x1B, 0x40) // ESC @
  private val CMD_ALIGN_LEFT = byteArrayOf(0x1B, 0x61, 0x00)
  private val CMD_ALIGN_CENTER = byteArrayOf(0x1B, 0x61, 0x01)
  private val CMD_BOLD_ON = byteArrayOf(0x1B, 0x45, 0x01)
  private val CMD_BOLD_OFF = byteArrayOf(0x1B, 0x45, 0x00)
  private val CMD_FEED_3 = byteArrayOf(0x1B, 0x64, 0x03)
  private val CMD_PARTIAL_CUT = byteArrayOf(0x1D, 0x56, 0x42, 0x00) // GS V 66 0

  fun encodeReceipt(request: InvoicePrintRequest): ByteArray {
    val cols = if (request.paperFormat == InvoicePaperFormat.Thermal58) 32 else 48
    val divider = "-".repeat(cols)
    val out = ByteArrayOutputStream(1024)

    fun writeLine(text: String) {
      val ascii = text.replace("₹", "Rs.").map { if (it.code in 32..126) it else '?' }.joinToString("")
      out.write(ascii.toByteArray(Charsets.US_ASCII))
      out.write('\n'.code)
    }

    fun writeTwoCol(left: String, right: String) {
      val avail = (cols - right.length - 1).coerceAtLeast(1)
      val trimmedLeft = if (left.length > avail) left.take(avail) else left
      val pad = (cols - trimmedLeft.length - right.length).coerceAtLeast(1)
      writeLine(trimmedLeft + " ".repeat(pad) + right)
    }

    out.write(CMD_INIT)
    out.write(CMD_ALIGN_CENTER)
    out.write(CMD_BOLD_ON)
    writeLine(request.shopProfile.shopName.take(cols))
    out.write(CMD_BOLD_OFF)

    request.shopProfile.address?.takeIf { it.isNotBlank() }?.let { writeLine(it.take(cols)) }
    request.shopProfile.phone?.takeIf { it.isNotBlank() }?.let { writeLine("Ph: $it".take(cols)) }
    request.shopProfile.gstin?.takeIf { it.isNotBlank() }?.let { writeLine("GSTIN: $it".take(cols)) }
    request.shopProfile.drugLicenceNumber?.takeIf { it.isNotBlank() }?.let {
      writeLine("DL No: $it".take(cols))
    }
    writeLine("TAX INVOICE")
    writeLine(divider)

    out.write(CMD_ALIGN_LEFT)
    writeLine("Inv: ${request.committedInvoice.invoiceNumber.orEmpty()}")
    writeLine("Date: ${OrvaDateTimeFormatters.formatUtcToLocalDisplay(request.committedInvoice.issuedAtUtc)}")
    request.customer.name?.takeIf { it.isNotBlank() }?.let { writeLine("Cust: ${it.take(cols - 6)}") }
    request.customer.gstin?.takeIf { it.isNotBlank() }?.let { writeLine("Cust GSTIN: $it") }
    writeLine(divider)

    for (line in request.preview.lines) {
      out.write(CMD_BOLD_ON)
      writeLine(line.medicineName.take(cols))
      out.write(CMD_BOLD_OFF)
      for (b in line.batchAllocations) {
        val left =
          " ${b.batchNumber} ${OrvaFormatters.formatExpiry(b.expiryYyyyMm)} x${OrvaFormatters.formatQuantity(b.quantityMilli)}"
        val right = "Rs.${OrvaFormatters.formatRupees(b.lineTotalPaise)}"
        writeTwoCol(left, right)
      }
    }

    writeLine(divider)
    val p = request.preview
    writeTwoCol("Taxable:", "Rs.${OrvaFormatters.formatRupees(p.taxableValuePaise)}")
    if (p.cgstPaise > 0L || p.sgstPaise > 0L) {
      writeTwoCol("CGST:", "Rs.${OrvaFormatters.formatRupees(p.cgstPaise)}")
      writeTwoCol("SGST:", "Rs.${OrvaFormatters.formatRupees(p.sgstPaise)}")
    }
    if (p.igstPaise > 0L) {
      writeTwoCol("IGST:", "Rs.${OrvaFormatters.formatRupees(p.igstPaise)}")
    }
    if (p.roundOffPaise != 0L) {
      writeTwoCol("Round-Off:", "Rs.${OrvaFormatters.formatRupees(p.roundOffPaise)}")
    }
    out.write(CMD_BOLD_ON)
    writeTwoCol("GRAND TOTAL:", "Rs.${OrvaFormatters.formatRupees(p.grandTotalPaise)}")
    out.write(CMD_BOLD_OFF)
    writeLine(divider)

    for (t in request.tenders) {
      writeTwoCol("Paid (${t.method.dbValue}):", "Rs.${OrvaFormatters.formatRupees(t.amountPaise)}")
    }
    writeLine(divider)
    out.write(CMD_ALIGN_CENTER)
    writeLine("Thank you! Get well soon.")
    out.write(CMD_FEED_3)
    out.write(CMD_PARTIAL_CUT)
    return out.toByteArray()
  }

  /**
   * Encodes a 1-bit monochrome raster bitmap into ESC/POS `GS v 0` format for
   * high-clarity Unicode/Bengali thermal printing (384 dots for 58mm, 576 dots for 80mm).
   */
  fun encodeRasterImage(widthPixels: Int, heightPixels: Int, packedMonoBytes: ByteArray): ByteArray {
    require(widthPixels > 0 && widthPixels % 8 == 0) { "Raster width must be a positive multiple of 8." }
    require(heightPixels > 0) { "Raster height must be positive." }
    val widthBytes = widthPixels / 8
    require(packedMonoBytes.size == widthBytes * heightPixels) {
      "Expected ${widthBytes * heightPixels} packed raster bytes, got ${packedMonoBytes.size}."
    }

    val out = ByteArrayOutputStream(packedMonoBytes.size + 16)
    out.write(CMD_INIT)
    // GS v 0 m xL xH yL yH d1...dk
    out.write(0x1D)
    out.write(0x76)
    out.write(0x30)
    out.write(0x00) // normal mode
    out.write(widthBytes and 0xFF)
    out.write((widthBytes shr 8) and 0xFF)
    out.write(heightPixels and 0xFF)
    out.write((heightPixels shr 8) and 0xFF)
    out.write(packedMonoBytes)
    out.write(CMD_FEED_3)
    out.write(CMD_PARTIAL_CUT)
    return out.toByteArray()
  }
}

class DefaultInvoicePrintService(
  private val appSettingsRepository: AppSettingsRepository,
) : InvoicePrintService {

  override suspend fun getDefaultPaperFormat(): InvoicePaperFormat =
    InvoicePaperFormat.fromPersistedKey(
      appSettingsRepository.get(
        OrvaSettingKeys.DEFAULT_PAPER_FORMAT,
        InvoicePaperFormat.Thermal80.persistedKey,
      )
    )

  override suspend fun setDefaultPaperFormat(format: InvoicePaperFormat) {
    appSettingsRepository.set(OrvaSettingKeys.DEFAULT_PAPER_FORMAT, format.persistedKey)
  }

  override suspend fun getLastPrinterName(): String =
    appSettingsRepository.get(OrvaSettingKeys.LAST_PRINTER_NAME, "")

  override suspend fun renderInvoicePdf(request: InvoicePrintRequest, output: OutputStream) {
    val (w, h, fontSize) =
      when (request.paperFormat) {
        InvoicePaperFormat.A4 -> Triple(595, 842, 10)
        InvoicePaperFormat.A5 -> Triple(420, 595, 9)
        InvoicePaperFormat.Thermal80 -> Triple(226, 620, 8)
        InvoicePaperFormat.Thermal58 -> Triple(164, 620, 7)
      }

    val lines = mutableListOf<PdfExportHelper.PdfTextLine>()
    val shop = request.shopProfile
    lines += PdfExportHelper.PdfTextLine(shop.shopName, fontSize + 3, bold = true)
    shop.legalName?.takeIf { it.isNotBlank() }?.let {
      lines += PdfExportHelper.PdfTextLine(it, fontSize)
    }
    shop.address?.takeIf { it.isNotBlank() }?.let {
      lines += PdfExportHelper.PdfTextLine(it, fontSize - 1)
    }
    val regLine =
      listOfNotNull(
          shop.gstin?.takeIf { it.isNotBlank() }?.let { "GSTIN: $it" },
          shop.drugLicenceNumber?.takeIf { it.isNotBlank() }?.let { "DL: $it" },
        )
        .joinToString("  |  ")
    if (regLine.isNotEmpty()) lines += PdfExportHelper.PdfTextLine(regLine, fontSize - 1)
    lines += PdfExportHelper.PdfTextLine("", isRule = true)

    lines +=
      PdfExportHelper.PdfTextLine(
        "TAX INVOICE: ${request.committedInvoice.invoiceNumber.orEmpty()}",
        fontSize + 1,
        bold = true,
      )
    lines +=
      PdfExportHelper.PdfTextLine(
        "Date: ${OrvaDateTimeFormatters.formatUtcToLocalDisplay(request.committedInvoice.issuedAtUtc)}",
        fontSize - 1,
      )
    request.customer.name?.takeIf { it.isNotBlank() }?.let {
      lines += PdfExportHelper.PdfTextLine("Customer: $it", fontSize - 1)
    }
    request.customer.gstin?.takeIf { it.isNotBlank() }?.let {
      lines += PdfExportHelper.PdfTextLine("Customer GSTIN: $it", fontSize - 1)
    }
    lines += PdfExportHelper.PdfTextLine("", isRule = true)

    for (line in request.preview.lines) {
      lines += PdfExportHelper.PdfTextLine(line.medicineName, fontSize, bold = true)
      for (b in line.batchAllocations) {
        lines +=
          PdfExportHelper.PdfTextLine(
            "  Batch ${b.batchNumber} | Exp ${OrvaFormatters.formatExpiry(b.expiryYyyyMm)} | Qty ${OrvaFormatters.formatQuantity(b.quantityMilli)} ${line.stockUnitName} @ Rs.${OrvaFormatters.formatRupees(b.unitPricePaise)} = Rs.${OrvaFormatters.formatRupees(b.lineTotalPaise)}",
            fontSize - 1,
          )
      }
    }

    lines += PdfExportHelper.PdfTextLine("", isRule = true)
    val p = request.preview
    lines += PdfExportHelper.PdfTextLine("Taxable Value: Rs.${OrvaFormatters.formatRupees(p.taxableValuePaise)}", fontSize)
    if (p.cgstPaise > 0L || p.sgstPaise > 0L) {
      lines +=
        PdfExportHelper.PdfTextLine(
          "CGST: Rs.${OrvaFormatters.formatRupees(p.cgstPaise)}  |  SGST: Rs.${OrvaFormatters.formatRupees(p.sgstPaise)}",
          fontSize,
        )
    }
    if (p.igstPaise > 0L) {
      lines += PdfExportHelper.PdfTextLine("IGST: Rs.${OrvaFormatters.formatRupees(p.igstPaise)}", fontSize)
    }
    if (p.roundOffPaise != 0L) {
      lines += PdfExportHelper.PdfTextLine("Round-Off: Rs.${OrvaFormatters.formatRupees(p.roundOffPaise)}", fontSize)
    }
    lines +=
      PdfExportHelper.PdfTextLine(
        "GRAND TOTAL: Rs.${OrvaFormatters.formatRupees(p.grandTotalPaise)}",
        fontSize + 2,
        bold = true,
      )
    lines += PdfExportHelper.PdfTextLine("", isRule = true)
    for (t in request.tenders) {
      val ref = t.referenceText?.takeIf { it.isNotBlank() }?.let { " ($it)" }.orEmpty()
      lines +=
        PdfExportHelper.PdfTextLine(
          "Payment ${t.method.dbValue}$ref: Rs.${OrvaFormatters.formatRupees(t.amountPaise)}",
          fontSize - 1,
        )
    }

    PdfExportHelper.writeLinesDocumentPdf(output, w, h, lines)
  }

  override suspend fun printViaThermalTransport(
    request: InvoicePrintRequest,
    transport: ThermalPrinterTransport,
  ): InvoicePrintResult {
    val bytes = EscPosInvoiceEncoder.encodeReceipt(request)
    val writeResult = transport.write(bytes)
    return writeResult.fold(
      onSuccess = {
        appSettingsRepository.set(OrvaSettingKeys.LAST_PRINTER_NAME, transport.displayName)
        InvoicePrintResult(printed = true, printerName = transport.displayName)
      },
      onFailure = { ex ->
        InvoicePrintResult(
          printed = false,
          printerName = transport.displayName,
          errorMessage = ex.message ?: "Thermal printer communication failed.",
        )
      },
    )
  }
}
