package com.rindleworks.orva.domain.engine

import com.rindleworks.orva.domain.common.OrvaDateTimeFormatters
import java.time.Instant
import java.time.LocalDate
import java.time.LocalDateTime
import java.time.ZoneId
import java.time.ZoneOffset

data class BillingInstant(
  val utcNow: Instant,
  val localNow: LocalDateTime,
  val localOffsetMinutes: Int,
) {
  val currentExpiryYearMonth: Int
    get() = localNow.year * 100 + localNow.monthValue

  val localBusinessDate: LocalDate
    get() = localNow.toLocalDate()

  val utcIsoText: String
    get() = OrvaDateTimeFormatters.formatUtcRoundTrip(utcNow)

  val localLogText: String
    get() = OrvaDateTimeFormatters.formatLocalLogText(localNow)

  companion object {
    fun capture(clock: BillingClock?): BillingInstant {
      if (clock == null) {
        val zone = ZoneId.systemDefault()
        val now = Instant.now()
        val zoned = now.atZone(zone)
        val offsetMinutes = zoned.offset.totalSeconds / 60
        return BillingInstant(
          utcNow = now,
          localNow = zoned.toLocalDateTime(),
          localOffsetMinutes = offsetMinutes,
        )
      }
      if (clock is SystemBillingClock) {
        val zone = clock.zoneId
        val now = Instant.now()
        val zoned = now.atZone(zone)
        val offsetMinutes = zoned.offset.totalSeconds / 60
        return BillingInstant(
          utcNow = now,
          localNow = zoned.toLocalDateTime(),
          localOffsetMinutes = offsetMinutes,
        )
      }
      return clock.capture()
    }
  }
}

interface BillingClock {
  val utcNow: Instant
  val localNow: LocalDateTime
  val localOffsetMinutes: Int
  val currentExpiryYearMonth: Int
    get() = localNow.year * 100 + localNow.monthValue

  fun capture(): BillingInstant =
    BillingInstant(
      utcNow = utcNow,
      localNow = localNow,
      localOffsetMinutes = localOffsetMinutes,
    )
}

class SystemBillingClock(
  internal val zoneId: ZoneId = ZoneId.systemDefault(),
) : BillingClock {
  override val utcNow: Instant
    get() = Instant.now()

  override val localNow: LocalDateTime
    get() = LocalDateTime.now(zoneId)

  override val localOffsetMinutes: Int
    get() = zoneId.rules.getOffset(Instant.now()).totalSeconds / 60
}

/** Deterministic clock for unit and Robolectric tests. */
class FixedBillingClock(
  override var utcNow: Instant,
  override var localOffsetMinutes: Int = 330,
) : BillingClock {
  override val localNow: LocalDateTime
    get() = LocalDateTime.ofInstant(utcNow, ZoneOffset.ofTotalSeconds(localOffsetMinutes * 60))
}
