package com.rindleworks.orva.ui.navigation

import android.content.Context
import android.database.ContentObserver
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.rindleworks.orva.di.OrvaAppContainer
import com.rindleworks.orva.domain.settings.AppLanguage
import com.rindleworks.orva.ui.about.AboutUsScreen
import com.rindleworks.orva.ui.home.HomeScreen
import com.rindleworks.orva.ui.showcase.DarkShowcasePalette
import com.rindleworks.orva.ui.showcase.HomeShowcaseUiState
import com.rindleworks.orva.ui.showcase.LocalPaperModeToggle
import com.rindleworks.orva.ui.showcase.LocalShowcasePalette
import com.rindleworks.orva.ui.showcase.OrvaShowcaseColors
import com.rindleworks.orva.ui.showcase.OrvaShowcaseCopy
import com.rindleworks.orva.ui.showcase.OrvaShowcaseFonts
import com.rindleworks.orva.ui.showcase.OrvaShowcaseViewModel
import com.rindleworks.orva.ui.showcase.PaperShowcasePalette
import com.rindleworks.orva.ui.showcase.ReadinessBackupState
import com.rindleworks.orva.ui.showcase.ShowcaseUiEvent
import com.rindleworks.orva.ui.showcase.currentShowcasePalette
import kotlinx.coroutines.launch
import kotlinx.serialization.Serializable

@Serializable data object HomeRoute
@Serializable data object AboutRoute
@Serializable data class OperationalWorkspaceRoute(val destinationKey: String)

private data class DrawerNavItem(
  val key: String,
  val labelEn: String,
  val labelBn: String,
  val icon: ImageVector,
  val badge: String? = null,
  val badgeAccent: Color = OrvaShowcaseColors.AccentViolet,
)

/**
 * Root Compose shell hosting ORVA's Home, About Us, and full Windows-WPF-parity Hamburger
 * Navigation Drawer with 21st.dev thin-stroke architectural icons, type-safe Navigation Compose,
 * English/Bengali switcher, instant Obsidian Dark ↔ Paper Mode toggle, and reduced-motion support.
 */
@Composable
fun OrvaShowcaseApp(
  container: OrvaAppContainer,
  modifier: Modifier = Modifier,
) {
  val context = LocalContext.current
  val navController = rememberNavController()
  val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
  val scope = rememberCoroutineScope()
  val viewModel: OrvaShowcaseViewModel =
    viewModel(factory = remember(container) { OrvaShowcaseViewModel.Factory(container) })

  val homeState by viewModel.homeState.collectAsStateWithLifecycle()
  val aboutState by viewModel.aboutState.collectAsStateWithLifecycle()
  val backStackEntry by navController.currentBackStackEntryAsState()
  val currentRoute = backStackEntry?.destination?.route.orEmpty()
  val activeOperationalKey = backStackEntry?.arguments?.getString("destinationKey")

  val activeNavKey =
    when {
      currentRoute.contains("AboutRoute") -> "about"
      currentRoute.contains("OperationalWorkspaceRoute") -> activeOperationalKey ?: "billing"
      else -> "home"
    }

  val reducedMotion = rememberSystemReducedMotion(context)
  var isPaperMode by remember { mutableStateOf(false) }
  val activePalette = if (isPaperMode) PaperShowcasePalette else DarkShowcasePalette
  val togglePaperMode = remember { { isPaperMode = !isPaperMode } }

  fun navigateByKey(key: String) {
    when (key) {
      "home" ->
        navController.navigate(HomeRoute) {
          popUpTo(HomeRoute) { inclusive = false }
          launchSingleTop = true
        }
      "about" -> navController.navigate(AboutRoute) { launchSingleTop = true }
      else -> navController.navigate(OperationalWorkspaceRoute(key)) { launchSingleTop = true }
    }
  }

  val handleEvent: (ShowcaseUiEvent) -> Unit = { event ->
    when (event) {
      ShowcaseUiEvent.StartBilling -> navigateByKey("billing")
      ShowcaseUiEvent.AddStock -> navigateByKey("add_stock")
      ShowcaseUiEvent.OpenInventory -> navigateByKey("inventory")
      ShowcaseUiEvent.OpenSettings -> navigateByKey("settings")
      ShowcaseUiEvent.OpenAboutUs -> navigateByKey("about")
      ShowcaseUiEvent.BackToHome -> navigateByKey("home")
      ShowcaseUiEvent.ToggleLanguage -> viewModel.toggleLanguage()
    }
  }

  CompositionLocalProvider(
    LocalShowcasePalette provides activePalette,
    LocalPaperModeToggle provides togglePaperMode,
  ) {
    ModalNavigationDrawer(
      drawerState = drawerState,
      scrimColor = Color.Black.copy(alpha = 0.62f),
      drawerContent = {
        OrvaHamburgerDrawerSheet(
          homeState = homeState,
          activeNavKey = activeNavKey,
          isPaperMode = isPaperMode,
          onSelectDestination = { key ->
            scope.launch { drawerState.close() }
            navigateByKey(key)
          },
          onToggleLanguage = { handleEvent(ShowcaseUiEvent.ToggleLanguage) },
          onTogglePaperMode = togglePaperMode,
          onCloseDrawer = { scope.launch { drawerState.close() } },
        )
      },
      modifier = modifier.fillMaxSize(),
    ) {
      Scaffold(
        modifier = Modifier.fillMaxSize(),
        containerColor = activePalette.canvasDeep,
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        topBar = {
          ShowcaseTopBar(
            language = homeState.language,
            isPaperMode = isPaperMode,
            onOpenMenu = { scope.launch { drawerState.open() } },
            onNavigateHome = { navigateByKey("home") },
            onToggleLanguage = { handleEvent(ShowcaseUiEvent.ToggleLanguage) },
            onTogglePaperMode = togglePaperMode,
          )
        },
      ) { innerPadding ->
        NavHost(
          navController = navController,
          startDestination = HomeRoute,
          modifier = Modifier.fillMaxSize().padding(innerPadding),
        ) {
          composable<HomeRoute> {
            HomeScreen(
              state = homeState,
              reducedMotion = reducedMotion,
              onEvent = handleEvent,
            )
          }
          composable<AboutRoute> {
            AboutUsScreen(
              state = aboutState,
              reducedMotion = reducedMotion,
              onEvent = handleEvent,
            )
          }
          composable<OperationalWorkspaceRoute> { entry ->
            val key = entry.arguments?.getString("destinationKey") ?: "billing"
            OperationalDestinationHandoffScreen(
              destinationKey = key,
              container = container,
              homeState = homeState,
              onBackToHome = { navigateByKey("home") },
              onOpenMenu = { scope.launch { drawerState.open() } },
            )
          }
        }
      }
    }
  }
}

@Composable
private fun ShowcaseTopBar(
  language: AppLanguage,
  isPaperMode: Boolean,
  onOpenMenu: () -> Unit,
  onNavigateHome: () -> Unit,
  onToggleLanguage: () -> Unit,
  onTogglePaperMode: () -> Unit,
) {
  val palette = currentShowcasePalette()
  Column(
    modifier =
      Modifier
        .fillMaxWidth()
        .background(palette.canvasDeep)
        .windowInsetsPadding(WindowInsets.statusBars),
  ) {
    Row(
      modifier =
        Modifier
          .fillMaxWidth()
          .padding(horizontal = 14.dp, vertical = 8.dp),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically,
    ) {
      // Left cluster: 21st.dev Hamburger Menu trigger + Brand wordmark
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp),
      ) {
        Box(
          modifier =
            Modifier
              .minimumInteractiveComponentSize()
              .clip(RoundedCornerShape(8.dp))
              .background(palette.surfaceRaised)
              .border(1.dp, palette.hairline, RoundedCornerShape(8.dp))
              .clickable(role = Role.Button, onClick = onOpenMenu)
              .padding(10.dp)
              .testTag("topbar_menu_btn"),
          contentAlignment = Alignment.Center,
        ) {
          Icon(
            imageVector = OrvaNavIcons.MenuHamburger,
            contentDescription = if (language == AppLanguage.Bengali) "মেনু খুলুন" else "Open navigation menu",
            tint = palette.inkPrimary,
            modifier = Modifier.size(18.dp),
          )
        }

        Row(
          modifier =
            Modifier
              .minimumInteractiveComponentSize()
              .clickable(role = Role.Button, onClick = onNavigateHome)
              .padding(horizontal = 2.dp)
              .testTag("topbar_brand_home"),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
          Box(
            modifier =
              Modifier
                .size(7.dp)
                .clip(CircleShape)
                .background(OrvaShowcaseColors.AccentVermilion),
          )
          Text(
            text = "RINDLE WORKS",
            fontFamily = OrvaShowcaseFonts.SpaceGrotesk,
            fontWeight = FontWeight.Bold,
            fontSize = 13.5.sp,
            letterSpacing = 2.sp,
            color = palette.inkPrimary,
            maxLines = 1,
          )
        }
      }

      // Right cluster: Paper/Dark studio icon pill + EN/বাং switcher
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp),
      ) {
        Row(
          modifier =
            Modifier
              .minimumInteractiveComponentSize()
              .clip(RoundedCornerShape(8.dp))
              .background(palette.surfaceRaised)
              .border(1.dp, palette.hairline, RoundedCornerShape(8.dp))
              .clickable(role = Role.Button, onClick = onTogglePaperMode)
              .padding(horizontal = 9.dp, vertical = 7.dp)
              .testTag("topbar_paper_toggle"),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(5.dp),
        ) {
          Icon(
            imageVector = if (isPaperMode) OrvaNavIcons.MoonObsidian else OrvaNavIcons.SunPaper,
            contentDescription = if (isPaperMode) "Switch to Dark mode" else "Switch to Paper mode",
            tint = if (isPaperMode) OrvaShowcaseColors.AccentVermilion else palette.inkSecondary,
            modifier = Modifier.size(14.dp),
          )
          Text(
            text = if (isPaperMode) "DARK" else "PAPER",
            fontFamily = OrvaShowcaseFonts.IbmPlexMono,
            fontWeight = FontWeight.SemiBold,
            fontSize = 10.sp,
            letterSpacing = 0.8.sp,
            color = if (isPaperMode) OrvaShowcaseColors.AccentVermilion else palette.inkSecondary,
          )
        }

        Box(
          modifier =
            Modifier
              .minimumInteractiveComponentSize()
              .clip(RoundedCornerShape(8.dp))
              .background(palette.surfaceRaised)
              .border(1.dp, palette.hairline, RoundedCornerShape(8.dp))
              .clickable(role = Role.Button, onClick = onToggleLanguage)
              .padding(horizontal = 10.dp, vertical = 7.dp)
              .testTag("topbar_language_toggle"),
          contentAlignment = Alignment.Center,
        ) {
          Text(
            text = if (language == AppLanguage.Bengali) "EN" else "বাং",
            fontFamily = OrvaShowcaseFonts.NotoSansBengali,
            fontWeight = FontWeight.Medium,
            fontSize = 12.sp,
            color = if (isPaperMode) OrvaShowcaseColors.AccentViolet else OrvaShowcaseColors.AccentVioletSoft,
          )
        }
      }
    }
    HorizontalDivider(thickness = 1.dp, color = palette.hairline)
  }
}

/**
 * 21st.dev-styled architectural Navigation Drawer mirroring ORVA's Windows WPF sidebar structure:
 * - COUNTER: Home, New Billing, Stock Entry
 * - INVENTORY & LEDGER: Inventory & Expiry, Sales Returns, Invoices & History, Reports & GST
 * - SYSTEM & STUDIO: Backup & Restore, Settings & License, About Us
 */
@Composable
private fun OrvaHamburgerDrawerSheet(
  homeState: HomeShowcaseUiState,
  activeNavKey: String,
  isPaperMode: Boolean,
  onSelectDestination: (String) -> Unit,
  onToggleLanguage: () -> Unit,
  onTogglePaperMode: () -> Unit,
  onCloseDrawer: () -> Unit,
) {
  val palette = currentShowcasePalette()
  val lang = homeState.language

  val counterItems =
    remember(lang) {
      listOf(
        DrawerNavItem(
          key = "home",
          labelEn = "Home",
          labelBn = "হোম",
          icon = OrvaNavIcons.Home,
        ),
        DrawerNavItem(
          key = "billing",
          labelEn = "New Billing",
          labelBn = "নতুন বিলিং",
          icon = OrvaNavIcons.NewBilling,
          badge = "POS",
          badgeAccent = OrvaShowcaseColors.AccentVermilion,
        ),
        DrawerNavItem(
          key = "add_stock",
          labelEn = "Stock Entry",
          labelBn = "স্টক এন্ট্রি",
          icon = OrvaNavIcons.StockEntry,
        ),
      )
    }

  val inventoryItems =
    remember(lang, homeState.expiringSoonCount) {
      listOf(
        DrawerNavItem(
          key = "inventory",
          labelEn = "Inventory & Expiry",
          labelBn = "স্টক ও মেয়াদ",
          icon = OrvaNavIcons.Inventory,
          badge = if (homeState.expiringSoonCount > 0) "${homeState.expiringSoonCount} EXP" else null,
          badgeAccent = OrvaShowcaseColors.AccentVermilion,
        ),
        DrawerNavItem(
          key = "returns",
          labelEn = "Sales Returns",
          labelBn = "সেলস রিটার্ন",
          icon = OrvaNavIcons.Returns,
        ),
        DrawerNavItem(
          key = "invoices",
          labelEn = "Invoices & History",
          labelBn = "ইনভয়েস ও ইতিহাস",
          icon = OrvaNavIcons.Invoices,
        ),
        DrawerNavItem(
          key = "reports",
          labelEn = "Reports & GST",
          labelBn = "রিপোর্ট ও GST",
          icon = OrvaNavIcons.Reports,
        ),
      )
    }

  val systemItems =
    remember(lang, homeState.backupStatus) {
      val backupBadge =
        when (homeState.backupStatus) {
          ReadinessBackupState.Saved -> "OK"
          ReadinessBackupState.DueToday -> "DUE"
          ReadinessBackupState.NotYetBackedUp -> "NEW"
        }
      val backupColor =
        if (homeState.backupStatus == ReadinessBackupState.Saved) {
          OrvaShowcaseColors.AccentViolet
        } else {
          OrvaShowcaseColors.AccentVermilion
        }
      listOf(
        DrawerNavItem(
          key = "backup",
          labelEn = "Backup & Restore",
          labelBn = "ব্যাকআপ ও পুনরুদ্ধার",
          icon = OrvaNavIcons.BackupVault,
          badge = backupBadge,
          badgeAccent = backupColor,
        ),
        DrawerNavItem(
          key = "settings",
          labelEn = "Settings & License",
          labelBn = "সেটিংস ও লাইসেন্স",
          icon = OrvaNavIcons.SettingsSliders,
        ),
        DrawerNavItem(
          key = "about",
          labelEn = "About Us",
          labelBn = "আমাদের কথা",
          icon = OrvaNavIcons.AboutStudio,
          badge = "STUDIO",
          badgeAccent = OrvaShowcaseColors.AccentViolet,
        ),
      )
    }

  ModalDrawerSheet(
    drawerContainerColor = palette.canvasDeep,
    drawerContentColor = palette.inkPrimary,
    drawerShape = RoundedCornerShape(topEnd = 16.dp, bottomEnd = 16.dp),
    windowInsets = WindowInsets(0, 0, 0, 0),
    modifier =
      Modifier
        .widthIn(min = 292.dp, max = 324.dp)
        .fillMaxHeight()
        .border(
          width = 1.dp,
          color = palette.hairline,
          shape = RoundedCornerShape(topEnd = 16.dp, bottomEnd = 16.dp),
        )
        .testTag("orva_hamburger_drawer"),
  ) {
    Column(
      modifier =
        Modifier
          .fillMaxSize()
          .windowInsetsPadding(WindowInsets.statusBars)
          .windowInsetsPadding(WindowInsets.navigationBars),
    ) {
      // Drawer Header
      Column(
        modifier =
          Modifier
            .fillMaxWidth()
            .background(palette.canvasSecondary)
            .padding(horizontal = 18.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
          ) {
            Box(
              modifier =
                Modifier
                  .size(8.dp)
                  .clip(CircleShape)
                  .background(OrvaShowcaseColors.AccentVermilion),
            )
            Text(
              text = "ORVA",
              fontFamily = OrvaShowcaseFonts.SpaceGrotesk,
              fontWeight = FontWeight.Bold,
              fontSize = 18.sp,
              letterSpacing = 2.4.sp,
              color = palette.inkPrimary,
            )
            Box(
              modifier =
                Modifier
                  .clip(RoundedCornerShape(4.dp))
                  .background(palette.surfaceRaised)
                  .border(1.dp, palette.hairline, RoundedCornerShape(4.dp))
                  .padding(horizontal = 6.dp, vertical = 2.dp),
            ) {
              Text(
                text = "v${homeState.appVersion}",
                fontFamily = OrvaShowcaseFonts.IbmPlexMono,
                fontSize = 9.5.sp,
                color = palette.inkMuted,
              )
            }
          }

          Box(
            modifier =
              Modifier
                .minimumInteractiveComponentSize()
                .clip(RoundedCornerShape(8.dp))
                .background(palette.surfaceRaised)
                .border(1.dp, palette.hairline, RoundedCornerShape(8.dp))
                .clickable(role = Role.Button, onClick = onCloseDrawer)
                .padding(8.dp)
                .testTag("drawer_close_btn"),
            contentAlignment = Alignment.Center,
          ) {
            Icon(
              imageVector = OrvaNavIcons.Close,
              contentDescription = if (lang == AppLanguage.Bengali) "মেনু বন্ধ করুন" else "Close navigation menu",
              tint = palette.inkSecondary,
              modifier = Modifier.size(16.dp),
            )
          }
        }

        // Real local shop readiness pill inside header
        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
          Text(
            text = homeState.shopName.uppercase(),
            fontFamily = OrvaShowcaseFonts.mono(lang),
            fontWeight = FontWeight.SemiBold,
            fontSize = 11.sp,
            letterSpacing = 1.2.sp,
            color = palette.inkPrimary,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
          )
          Text(
            text =
              if (lang == AppLanguage.Bengali) {
                "${OrvaShowcaseCopy.toBengaliDigits(homeState.usableMedicineCount)}টি ওষুধ প্রস্তুত · ব্যাকআপ: ${OrvaShowcaseCopy.backupStatusLabel(homeState.backupStatus, lang)}"
              } else {
                "${homeState.usableMedicineCount} medicines ready · Backup: ${OrvaShowcaseCopy.backupStatusLabel(homeState.backupStatus, lang)}"
              },
            fontFamily = OrvaShowcaseFonts.mono(lang),
            fontSize = 10.sp,
            color = palette.inkMuted,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
          )
        }
      }

      HorizontalDivider(thickness = 1.dp, color = palette.hairline)

      // Scrollable WPF-parity menu groups
      Column(
        modifier =
          Modifier
            .weight(1f)
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 12.dp, vertical = 14.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp),
      ) {
        DrawerSectionHeading(
          label = if (lang == AppLanguage.Bengali) "কাউন্টার" else "COUNTER",
          language = lang,
        )
        counterItems.forEach { item ->
          DrawerNavRow(
            item = item,
            selected = activeNavKey == item.key,
            language = lang,
            onClick = { onSelectDestination(item.key) },
          )
        }

        Spacer(Modifier.height(10.dp))
        HorizontalDivider(thickness = 1.dp, color = palette.hairline.copy(alpha = 0.65f))
        Spacer(Modifier.height(10.dp))

        DrawerSectionHeading(
          label = if (lang == AppLanguage.Bengali) "স্টক ও হিসাব" else "INVENTORY & LEDGER",
          language = lang,
        )
        inventoryItems.forEach { item ->
          DrawerNavRow(
            item = item,
            selected = activeNavKey == item.key,
            language = lang,
            onClick = { onSelectDestination(item.key) },
          )
        }

        Spacer(Modifier.height(10.dp))
        HorizontalDivider(thickness = 1.dp, color = palette.hairline.copy(alpha = 0.65f))
        Spacer(Modifier.height(10.dp))

        DrawerSectionHeading(
          label = if (lang == AppLanguage.Bengali) "সিস্টেম ও স্টুডিও" else "SYSTEM & STUDIO",
          language = lang,
        )
        systemItems.forEach { item ->
          DrawerNavRow(
            item = item,
            selected = activeNavKey == item.key,
            language = lang,
            onClick = { onSelectDestination(item.key) },
          )
        }
      }

      HorizontalDivider(thickness = 1.dp, color = palette.hairline)

      // Compact footer utility strip (Paper/Dark + Language + Rindle Works credit)
      Row(
        modifier =
          Modifier
            .fillMaxWidth()
            .background(palette.canvasSecondary)
            .padding(horizontal = 14.dp, vertical = 10.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Text(
          text = "RINDLE WORKS · LOCAL",
          fontFamily = OrvaShowcaseFonts.IbmPlexMono,
          fontSize = 9.5.sp,
          letterSpacing = 1.1.sp,
          color = palette.inkMuted,
        )
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
          Box(
            modifier =
              Modifier
                .clip(RoundedCornerShape(6.dp))
                .background(palette.surfaceRaised)
                .border(1.dp, palette.hairline, RoundedCornerShape(6.dp))
                .clickable(role = Role.Button, onClick = onTogglePaperMode)
                .padding(horizontal = 8.dp, vertical = 5.dp),
          ) {
            Icon(
              imageVector = if (isPaperMode) OrvaNavIcons.MoonObsidian else OrvaNavIcons.SunPaper,
              contentDescription = "Toggle theme mode",
              tint = palette.inkSecondary,
              modifier = Modifier.size(14.dp),
            )
          }
          Box(
            modifier =
              Modifier
                .clip(RoundedCornerShape(6.dp))
                .background(palette.surfaceRaised)
                .border(1.dp, palette.hairline, RoundedCornerShape(6.dp))
                .clickable(role = Role.Button, onClick = onToggleLanguage)
                .padding(horizontal = 8.dp, vertical = 4.dp),
          ) {
            Text(
              text = if (lang == AppLanguage.Bengali) "EN" else "বাং",
              fontFamily = OrvaShowcaseFonts.NotoSansBengali,
              fontSize = 11.sp,
              color = if (isPaperMode) OrvaShowcaseColors.AccentViolet else OrvaShowcaseColors.AccentVioletSoft,
            )
          }
        }
      }
    }
  }
}

@Composable
private fun DrawerSectionHeading(label: String, language: AppLanguage) {
  val palette = currentShowcasePalette()
  Text(
    text = label,
    fontFamily = OrvaShowcaseFonts.mono(language),
    fontWeight = FontWeight.SemiBold,
    fontSize = 10.sp,
    letterSpacing = 1.5.sp,
    color = palette.inkMuted,
    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
  )
}

@Composable
private fun DrawerNavRow(
  item: DrawerNavItem,
  selected: Boolean,
  language: AppLanguage,
  onClick: () -> Unit,
) {
  val palette = currentShowcasePalette()
  val label = if (language == AppLanguage.Bengali) item.labelBn else item.labelEn
  val activeBg =
    if (selected) {
      if (palette.isPaperMode) OrvaShowcaseColors.AccentVioletWash else palette.surfaceRaised
    } else {
      Color.Transparent
    }
  val activeBorder =
    if (selected) OrvaShowcaseColors.AccentViolet.copy(alpha = 0.50f) else Color.Transparent

  Row(
    modifier =
      Modifier
        .fillMaxWidth()
        .minimumInteractiveComponentSize()
        .clip(RoundedCornerShape(10.dp))
        .background(activeBg)
        .border(1.dp, activeBorder, RoundedCornerShape(10.dp))
        .clickable(role = Role.Button, onClick = onClick)
        .padding(horizontal = 10.dp, vertical = 9.dp)
        .testTag("drawer_item_${item.key}"),
    verticalAlignment = Alignment.CenterVertically,
    horizontalArrangement = Arrangement.spacedBy(12.dp),
  ) {
    // Subtle 21st.dev vertical accent bar on active route
    Box(
      modifier =
        Modifier
          .width(2.5.dp)
          .height(18.dp)
          .clip(RoundedCornerShape(99.dp))
          .background(
            if (selected) {
              Brush.verticalGradient(
                listOf(OrvaShowcaseColors.AccentVermilion, OrvaShowcaseColors.AccentViolet),
              )
            } else {
              Brush.verticalGradient(listOf(Color.Transparent, Color.Transparent))
            },
          ),
    )

    // 21st.dev bordered icon well
    Box(
      modifier =
        Modifier
          .size(30.dp)
          .clip(RoundedCornerShape(7.dp))
          .background(
            if (selected) OrvaShowcaseColors.AccentVermilionWash else palette.canvasSecondary,
          )
          .border(
            width = 1.dp,
            color = if (selected) OrvaShowcaseColors.AccentVermilion.copy(alpha = 0.55f) else palette.hairline,
            shape = RoundedCornerShape(7.dp),
          ),
      contentAlignment = Alignment.Center,
    ) {
      Icon(
        imageVector = item.icon,
        contentDescription = null,
        tint =
          if (selected) {
            if (palette.isPaperMode) OrvaShowcaseColors.AccentVermilion else OrvaShowcaseColors.InkPrimary
          } else {
            palette.inkSecondary
          },
        modifier = Modifier.size(16.dp),
      )
    }

    Text(
      text = label,
      fontFamily = OrvaShowcaseFonts.body(language),
      fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Medium,
      fontSize = 14.sp,
      color = if (selected) palette.inkPrimary else palette.inkSecondary,
      maxLines = 1,
      overflow = TextOverflow.Ellipsis,
      modifier = Modifier.weight(1f),
    )

    if (!item.badge.isNullOrBlank()) {
      Box(
        modifier =
          Modifier
            .clip(RoundedCornerShape(4.dp))
            .background(item.badgeAccent.copy(alpha = 0.14f))
            .border(0.75.dp, item.badgeAccent.copy(alpha = 0.45f), RoundedCornerShape(4.dp))
            .padding(horizontal = 6.dp, vertical = 2.dp),
      ) {
        Text(
          text = item.badge,
          fontFamily = OrvaShowcaseFonts.IbmPlexMono,
          fontWeight = FontWeight.SemiBold,
          fontSize = 9.sp,
          letterSpacing = 0.7.sp,
          color = item.badgeAccent,
        )
      }
    } else if (selected) {
      Icon(
        imageVector = OrvaNavIcons.ChevronRight,
        contentDescription = null,
        tint = palette.inkMuted,
        modifier = Modifier.size(14.dp),
      )
    }
  }
}

/**
 * Operational workspace bridge supporting all Windows-WPF-parity drawer destinations,
 * styled cleanly for both Obsidian Dark and Warm Chalk Paper modes.
 */
@Composable
private fun OperationalDestinationHandoffScreen(
  destinationKey: String,
  container: OrvaAppContainer,
  homeState: HomeShowcaseUiState,
  onBackToHome: () -> Unit,
  onOpenMenu: () -> Unit,
) {
  val context = LocalContext.current
  val palette = currentShowcasePalette()
  val language = homeState.language
  val hasExternalOrva = container.storagePaths.hasExternalOrvaFolderAccess()

  val (title, moduleTag, detailEn, detailBn) =
    when (destinationKey) {
      "billing" ->
        Quadruple(
          if (language == AppLanguage.Bengali) "নতুন বিলিং" else "New Billing",
          "ORVA · COUNTER POS",
          "Integer-paise GST billing engine, earliest-expiry FEFO batch allocation, barcode lookup, and ESC/POS receipt printing are wired and ready.",
          "পূর্ণ পয়সার GST বিলিং ইঞ্জিন, আগে মেয়াদ শেষ হওয়া ব্যাচ (FEFO) বাছাই, বারকোড লুকআপ এবং ESC/POS রসিদ প্রিন্টিং সংযুক্ত ও প্রস্তুত।",
        )
      "add_stock" ->
        Quadruple(
          if (language == AppLanguage.Bengali) "স্টক এন্ট্রি" else "Stock Entry",
          "ORVA · STOCK INBOUND",
          "Add medicine batches with expiry dates, MRP, purchase rates, GST slab, and automatic StockData.json synchronization.",
          "মেয়াদ, MRP, ক্রয়মূল্য ও GST স্ল্যাবসহ নতুন ওষুধের ব্যাচ যোগ করুন—স্বয়ংক্রিয়ভাবে StockData.json আপডেট হবে।",
        )
      "inventory" ->
        Quadruple(
          if (language == AppLanguage.Bengali) "স্টক ও মেয়াদ" else "Inventory & Expiry",
          "ORVA · FEFO LEDGER",
          "${homeState.usableMedicineCount} usable medicines tracked locally · ${homeState.expiringSoonCount} expiring within 30 days. Expired batches stay excluded from regular sales.",
          "${OrvaShowcaseCopy.toBengaliDigits(homeState.usableMedicineCount)}টি ওষুধ স্থানীয়ভাবে ট্র্যাক করা হচ্ছে · ৩০ দিনের মধ্যে মেয়াদ শেষ: ${OrvaShowcaseCopy.toBengaliDigits(homeState.expiringSoonCount)}।",
        )
      "returns" ->
        Quadruple(
          if (language == AppLanguage.Bengali) "সেলস রিটার্ন ও বাতিলকরণ" else "Sales Returns & Cancellations",
          "ORVA · RETURNS LEDGER",
          "Process partial or full sales returns, restock intact batches atomically, and audit cancelled invoices.",
          "আংশিক বা সম্পূর্ণ সেলস রিটার্ন, ব্যাচ রিস্টক এবং বাতিল ইনভয়েসের সম্পূর্ণ অডিট রেকর্ড পরিচালনা করুন।",
        )
      "invoices" ->
        Quadruple(
          if (language == AppLanguage.Bengali) "ইনভয়েস ও ইতিহাস" else "Invoices & History",
          "ORVA · BILLING ARCHIVE",
          "Search finalized invoices, inspect line-by-line GST splits, and reprint customer receipts on thermal or PDF printers.",
          "চূড়ান্ত ইনভয়েস খুঁজুন, GST বিভাজন দেখুন এবং থার্মাল বা PDF প্রিন্টারে রসিদ পুনরায় প্রিন্ট করুন।",
        )
      "reports" ->
        Quadruple(
          if (language == AppLanguage.Bengali) "রিপোর্ট ও GST এক্সপোর্ট" else "Reports & GST Export",
          "ORVA · ANALYTICS & EXPORTS",
          "Generate daily sales summaries, GST breakdowns, and CSV / XLSX / PDF exports inside ${container.storagePaths.exportsDirectory().absolutePath}.",
          "দৈনিক বিক্রয়, GST সারসংক্ষেপ এবং CSV / XLSX / PDF এক্সপোর্ট তৈরি করুন (${container.storagePaths.exportsDirectory().absolutePath})।",
        )
      "backup" ->
        Quadruple(
          if (language == AppLanguage.Bengali) "ব্যাকআপ ও পুনরুদ্ধার" else "Backup & Restore",
          "ORVA · PORTABLE .SHOPBACKUP",
          "Backup status: ${OrvaShowcaseCopy.backupStatusLabel(homeState.backupStatus, language)}. Portable .shopbackup and StockData.json live under ${container.storagePaths.activeOrvaFolder().absolutePath}.",
          "ব্যাকআপ অবস্থা: ${OrvaShowcaseCopy.backupStatusLabel(homeState.backupStatus, language)}। স্থানীয় .shopbackup ও StockData.json ফোল্ডার: ${container.storagePaths.activeOrvaFolder().absolutePath}।",
        )
      else ->
        Quadruple(
          if (language == AppLanguage.Bengali) "সেটিংস ও লাইসেন্স" else "Settings & License",
          "ORVA · CONFIGURATION",
          "Configure shop profile, GSTIN, support contact details, thermal printer settings, and hardware-sealed ORVA license.",
          "দোকানের প্রোফাইল, GSTIN, সহায়তার যোগাযোগের তথ্য, প্রিন্টার এবং স্থানীয় ORVA লাইসেন্স কনফিগার করুন।",
        )
    }

  Box(
    modifier =
      Modifier
        .fillMaxSize()
        .background(palette.canvasDeep)
        .padding(24.dp),
    contentAlignment = Alignment.Center,
  ) {
    Column(
      modifier =
        Modifier
          .widthIn(max = 520.dp)
          .fillMaxWidth()
          .clip(RoundedCornerShape(10.dp))
          .background(palette.canvasSecondary)
          .border(1.dp, palette.hairline, RoundedCornerShape(10.dp))
          .padding(24.dp),
      verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
      Text(
        text = moduleTag,
        fontFamily = OrvaShowcaseFonts.IbmPlexMono,
        fontSize = 10.5.sp,
        letterSpacing = 1.5.sp,
        color = OrvaShowcaseColors.AccentVermilion,
      )
      Text(
        text = title,
        fontFamily = OrvaShowcaseFonts.display(language),
        fontWeight = FontWeight.SemiBold,
        fontSize = 26.sp,
        color = palette.inkPrimary,
        modifier = Modifier.testTag("workspace_screen_title"),
      )
      Text(
        text = if (language == AppLanguage.Bengali) detailBn else detailEn,
        fontFamily = OrvaShowcaseFonts.body(language),
        fontSize = 14.sp,
        lineHeight = 22.sp,
        color = palette.inkSecondary,
      )

      if (!hasExternalOrva) {
        Button(
          onClick = {
            runCatching {
              context.startActivity(container.storagePaths.createExternalStorageAccessIntent())
            }
          },
          colors =
            ButtonDefaults.buttonColors(
              containerColor = OrvaShowcaseColors.AccentViolet,
              contentColor = OrvaShowcaseColors.CanvasDeep,
            ),
          shape = RoundedCornerShape(6.dp),
          modifier = Modifier.minimumInteractiveComponentSize().testTag("enable_orva_folder_btn"),
        ) {
          Text(
            text =
              if (language == AppLanguage.Bengali) "ORVA ফোল্ডার অ্যাক্সেস চালু করুন"
              else "Enable /ORVA Folder Access",
            fontFamily = OrvaShowcaseFonts.display(language),
            fontWeight = FontWeight.SemiBold,
          )
        }
      }

      Spacer(Modifier.height(4.dp))
      Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        OutlinedButton(
          onClick = onBackToHome,
          border = BorderStroke(1.dp, palette.hairline),
          colors = ButtonDefaults.outlinedButtonColors(contentColor = palette.inkPrimary),
          shape = RoundedCornerShape(6.dp),
          modifier = Modifier.minimumInteractiveComponentSize().testTag("workspace_back_home_btn"),
        ) {
          Text(
            text = if (language == AppLanguage.Bengali) "← হোমে ফিরে যান" else "← Back to Home",
            fontFamily = OrvaShowcaseFonts.display(language),
          )
        }
        OutlinedButton(
          onClick = onOpenMenu,
          border = BorderStroke(1.dp, palette.hairline),
          colors = ButtonDefaults.outlinedButtonColors(contentColor = palette.inkSecondary),
          shape = RoundedCornerShape(6.dp),
          modifier = Modifier.minimumInteractiveComponentSize().testTag("workspace_open_menu_btn"),
        ) {
          Text(
            text = if (language == AppLanguage.Bengali) "মেনু" else "Menu",
            fontFamily = OrvaShowcaseFonts.display(language),
          )
        }
      }
    }
  }
}

private data class Quadruple<A, B, C, D>(val first: A, val second: B, val third: C, val fourth: D)

@Composable
internal fun rememberSystemReducedMotion(context: Context): Boolean {
  val reducedMotionState = remember(context) { mutableStateOf(isSystemReducedMotion(context)) }

  DisposableEffect(context) {
    val resolver = context.contentResolver
    val observer =
      object : ContentObserver(Handler(Looper.getMainLooper())) {
        override fun onChange(selfChange: Boolean) {
          reducedMotionState.value = isSystemReducedMotion(context)
        }
      }
    val settingNames =
      listOf(
        Settings.Global.ANIMATOR_DURATION_SCALE,
        Settings.Global.TRANSITION_ANIMATION_SCALE,
        Settings.Global.WINDOW_ANIMATION_SCALE,
      )
    settingNames.forEach { settingName ->
      resolver.registerContentObserver(Settings.Global.getUriFor(settingName), false, observer)
    }
    // Re-read after registration to avoid missing a settings change during composition.
    reducedMotionState.value = isSystemReducedMotion(context)

    onDispose { resolver.unregisterContentObserver(observer) }
  }

  return reducedMotionState.value
}

internal fun isSystemReducedMotion(context: Context): Boolean =
  runCatching {
    val resolver = context.contentResolver
    listOf(
      Settings.Global.ANIMATOR_DURATION_SCALE,
      Settings.Global.TRANSITION_ANIMATION_SCALE,
      Settings.Global.WINDOW_ANIMATION_SCALE,
    ).any { settingName -> Settings.Global.getFloat(resolver, settingName, 1f) <= 0f }
  }.getOrDefault(false)
