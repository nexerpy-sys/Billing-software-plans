package com.rindleworks.orva.data.local

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import com.rindleworks.orva.domain.common.OrvaSchemaInteropContract
import java.io.File

class UnsupportedSchemaVersionException(
  val foundVersion: Int,
  val supportedVersion: Int = OrvaSchemaInteropContract.CURRENT_SCHEMA_VERSION,
  message: String =
    "Database schema version $foundVersion is newer than this version of ORVA (supports up to schema version $supportedVersion).",
) : IllegalStateException(message)

data class SqliteValidationReport(
  val isValid: Boolean,
  val schemaVersion: Int = 0,
  val shopId: String? = null,
  val shopName: String? = null,
  val medicineCount: Long = 0L,
  val batchCount: Long = 0L,
  val invoiceCount: Long = 0L,
  val purchaseCount: Long = 0L,
  val returnCount: Long = 0L,
  val errors: List<String> = emptyList(),
)

/**
 * Bootstraps fresh SQLite databases from the verbatim ORVA WPF SQL migrations (001 -> 002 -> 003)
 * and performs forward-only, non-destructive upgrades for v1/v2 databases before Room opens them.
 *
 * This guarantees exact schema parity with ORVA WPF: all 18 tables, 30+ SQLite CHECK constraints,
 * all 15 indexes (including expression unique index ux_batch_normalized_identity), PRAGMA user_version = 3,
 * and app_meta.schema_version = '3'.
 */
object OrvaSchemaBootstrapper {

  private const val ASSET_DIR = "db"
  private const val MIGRATION_001 = "001_InitialSchema.sql"
  private const val MIGRATION_002 = "002_BillingTaxConfig.sql"
  private const val MIGRATION_003 = "003_PerformanceIndexes.sql"

  val REQUIRED_TABLES: Set<String> =
    setOf(
      "app_meta",
      "shop_profile",
      "app_setting",
      "medicine",
      "barcode_mapping",
      "stock_batch",
      "purchase_receipt",
      "purchase_line",
      "invoice_sequence",
      "invoice",
      "invoice_line",
      "payment",
      "sales_return",
      "sales_return_line",
      "stock_movement",
      "stock_discrepancy",
      "audit_log",
      "expense_record",
    )

  val REQUIRED_INDEXES: Set<String> =
    setOf(
      "ix_medicine_name",
      "ux_batch_normalized_identity",
      "ix_batch_medicine_expiry",
      "ix_purchase_date",
      "ix_invoice_date",
      "ix_invoice_financial_year",
      "ix_return_date",
      "ix_stock_movement_batch_date",
      "ix_audit_entity_date",
      "ix_invoice_line_invoice",
      "ix_payment_invoice",
      "ix_sales_return_invoice",
      "ix_sales_return_line_return",
      "ix_sales_return_line_invoice_line",
      "ix_purchase_line_purchase",
    )

  fun bootstrapOrMigrate(
    context: Context,
    dbFile: File,
    roomIdentityHash: String? = null,
  ) {
    bootstrapOrMigrate(
      dbFile = dbFile,
      sqlLoader = { fileName ->
        context.assets.open("$ASSET_DIR/$fileName").bufferedReader(Charsets.UTF_8).use { it.readText() }
      },
      roomIdentityHash = roomIdentityHash,
    )
  }

  fun bootstrapOrMigrate(
    dbFile: File,
    sqlLoader: (String) -> String,
    roomIdentityHash: String? = null,
  ) {
    dbFile.parentFile?.mkdirs()
    val db = SQLiteDatabase.openOrCreateDatabase(dbFile, null)
    try {
      db.rawQuery("PRAGMA busy_timeout = 5000;", null).use { it.moveToFirst() }
      db.execSQL("PRAGMA foreign_keys = ON;")

      val userVersion = readUserVersion(db)
      val appMetaExists = tableExists(db, "app_meta")
      val appMetaVersion = if (appMetaExists) readAppMetaSchemaVersion(db) else null

      val maxObservedVersion = maxOf(userVersion, appMetaVersion ?: 0)
      if (maxObservedVersion > OrvaSchemaInteropContract.CURRENT_SCHEMA_VERSION) {
        throw UnsupportedSchemaVersionException(foundVersion = maxObservedVersion)
      }

      if (!appMetaExists && userVersion == 0) {
        val existingTables = readUserTableNames(db)
        if (existingTables.isNotEmpty()) {
          throw IllegalStateException(
            "Database file contains unversioned tables without app_meta: $existingTables"
          )
        }
        // Fresh database: apply verbatim 001 -> 002 -> 003 inside a single transaction.
        db.beginTransaction()
        try {
          executeSqlScript(db, sqlLoader(MIGRATION_001))
          executeSqlScript(db, sqlLoader(MIGRATION_002))
          executeSqlScript(db, sqlLoader(MIGRATION_003))
          upsertSchemaVersionMeta(db, OrvaSchemaInteropContract.CURRENT_SCHEMA_VERSION)
          db.setTransactionSuccessful()
        } finally {
          db.endTransaction()
        }
        db.execSQL("PRAGMA user_version = ${OrvaSchemaInteropContract.CURRENT_SCHEMA_VERSION};")
      } else {
        // Existing database: upgrade non-destructively from v1 or v2 -> v3.
        val currentVersion = maxObservedVersion
        if (currentVersion < 1) {
          throw IllegalStateException("Corrupt ORVA database: missing schema_version metadata.")
        }

        if (currentVersion < 2) {
          db.beginTransaction()
          try {
            if (!columnExists(db, "medicine", "gst_rate_configured")) {
              db.execSQL(
                "ALTER TABLE medicine ADD COLUMN gst_rate_configured INTEGER NOT NULL DEFAULT 0 CHECK (gst_rate_configured IN (0, 1));"
              )
            }
            if (!columnExists(db, "invoice_line", "hsn_code_snapshot")) {
              db.execSQL("ALTER TABLE invoice_line ADD COLUMN hsn_code_snapshot TEXT;")
            }
            upsertSchemaVersionMeta(db, 2)
            db.setTransactionSuccessful()
          } finally {
            db.endTransaction()
          }
        }

        if (currentVersion < 3) {
          db.beginTransaction()
          try {
            executeSqlScript(db, sqlLoader(MIGRATION_003))
            upsertSchemaVersionMeta(db, 3)
            db.setTransactionSuccessful()
          } finally {
            db.endTransaction()
          }
        }

        // Always verify expression unique index & version headers are synchronized at v3.
        db.beginTransaction()
        try {
          db.execSQL(
            "CREATE UNIQUE INDEX IF NOT EXISTS ${OrvaSchemaInteropContract.EXPRESSION_BATCH_UNIQUE_INDEX} " +
              "ON stock_batch(medicine_id, UPPER(TRIM(batch_number)), expiry_yyyymm);"
          )
          if (appMetaVersion != OrvaSchemaInteropContract.CURRENT_SCHEMA_VERSION) {
            upsertSchemaVersionMeta(db, OrvaSchemaInteropContract.CURRENT_SCHEMA_VERSION)
          }
          db.setTransactionSuccessful()
        } finally {
          db.endTransaction()
        }

        if (userVersion != OrvaSchemaInteropContract.CURRENT_SCHEMA_VERSION) {
          db.execSQL("PRAGMA user_version = ${OrvaSchemaInteropContract.CURRENT_SCHEMA_VERSION};")
        }
      }

      // Verify exact ORVA v3 schema integrity (all 18 tables, key migration columns, all 15 indexes)
      verifySchemaV3Integrity(db)

      // Synchronize room_master_table only after strict ORVA v3 verification succeeds.
      // WPF 001_InitialSchema.sql defines TEXT/INTEGER PRIMARY KEY without explicit NOT NULL,
      // which SQLite PRAGMA table_info reports as notnull=0 while Room expects notNull=true.
      // Writing Room's compiled identity hash after our own strict validator preserves exact
      // WPF tables, CHECK constraints, and expression index without rebuilding the database.
      if (!roomIdentityHash.isNullOrBlank()) {
        db.execSQL(
          "CREATE TABLE IF NOT EXISTS ${OrvaSchemaInteropContract.ROOM_MASTER_TABLE} (id INTEGER PRIMARY KEY, identity_hash TEXT);"
        )
        db.execSQL(
          "INSERT OR REPLACE INTO ${OrvaSchemaInteropContract.ROOM_MASTER_TABLE} (id, identity_hash) VALUES (42, ?);",
          arrayOf(roomIdentityHash),
        )
      }

      // Configure WAL & durability pragmas for runtime usage.
      db.rawQuery("PRAGMA journal_mode = WAL;", null).use { it.moveToFirst() }
      db.execSQL("PRAGMA synchronous = FULL;")
      db.execSQL("PRAGMA foreign_keys = ON;")
    } finally {
      db.close()
    }
  }

  private fun verifySchemaV3Integrity(db: SQLiteDatabase) {
    val existingTables = readUserTableNames(db)
    val missingTables = REQUIRED_TABLES - existingTables
    if (missingTables.isNotEmpty()) {
      throw IllegalStateException(
        "ORVA schema v3 validation failed; missing tables: ${missingTables.sorted().joinToString(", ")}"
      )
    }
    if (!columnExists(db, "medicine", "gst_rate_configured")) {
      throw IllegalStateException("ORVA schema v3 validation failed; missing medicine.gst_rate_configured")
    }
    if (!columnExists(db, "invoice_line", "hsn_code_snapshot")) {
      throw IllegalStateException("ORVA schema v3 validation failed; missing invoice_line.hsn_code_snapshot")
    }
    val existingIndexes = readUserIndexNames(db)
    val missingIndexes = REQUIRED_INDEXES - existingIndexes
    if (missingIndexes.isNotEmpty()) {
      throw IllegalStateException(
        "ORVA schema v3 validation failed; missing indexes: ${missingIndexes.sorted().joinToString(", ")}"
      )
    }
  }

  /**
   * Strips Room's internal room_master_table and android_metadata and switches journal_mode to DELETE
   * on a staged portable backup copy ONLY (never call on the live Room database).
   * Guarantees clean Android -> WPF .shopbackup interoperability.
   */
  fun prepareStagedCopyForPortableExport(stagedSqliteFile: File) {
    val db = SQLiteDatabase.openDatabase(stagedSqliteFile.absolutePath, null, SQLiteDatabase.OPEN_READWRITE)
    try {
      db.rawQuery("PRAGMA busy_timeout = 5000;", null).use { it.moveToFirst() }
      db.execSQL("DROP TABLE IF EXISTS ${OrvaSchemaInteropContract.ROOM_MASTER_TABLE};")
      db.execSQL("DROP TABLE IF EXISTS android_metadata;")
      upsertSchemaVersionMeta(db, OrvaSchemaInteropContract.CURRENT_SCHEMA_VERSION)
      db.execSQL("PRAGMA user_version = ${OrvaSchemaInteropContract.CURRENT_SCHEMA_VERSION};")
      db.rawQuery("PRAGMA journal_mode = DELETE;", null).use { it.moveToFirst() }
    } finally {
      db.close()
    }
    File(stagedSqliteFile.absolutePath + "-wal").delete()
    File(stagedSqliteFile.absolutePath + "-shm").delete()
  }

  /**
   * Validates a standalone SQLite file (e.g. extracted from a .shopbackup archive) without
   * mutating it. Verifies integrity_check, foreign_key_check, schema version <= 3, and
   * extracts manifest summary counts.
   */
  fun validateStandaloneSqliteFile(sqliteFile: File): SqliteValidationReport {
    if (!sqliteFile.exists() || sqliteFile.length() <= 0L) {
      return SqliteValidationReport(isValid = false, errors = listOf("SQLite file is missing or empty."))
    }

    val errors = mutableListOf<String>()
    var db: SQLiteDatabase? = null
    return try {
      db = SQLiteDatabase.openDatabase(sqliteFile.absolutePath, null, SQLiteDatabase.OPEN_READONLY)

      val integrityResult =
        db.rawQuery("PRAGMA integrity_check;", null).use { cursor ->
          if (cursor.moveToFirst()) cursor.getString(0) else "empty"
        }
      if (!integrityResult.equals("ok", ignoreCase = true)) {
        errors.add("SQLite integrity check failed: $integrityResult")
      }

      val fkViolations =
        db.rawQuery("PRAGMA foreign_key_check;", null).use { cursor ->
          var count = 0
          while (cursor.moveToNext()) count++
          count
        }
      if (fkViolations > 0) {
        errors.add("SQLite foreign key check found $fkViolations violation(s).")
      }

      val existingTables = readUserTableNames(db)
      val missingTables = REQUIRED_TABLES - existingTables
      if (missingTables.isNotEmpty()) {
        errors.add("Database is missing required ORVA tables: ${missingTables.sorted().joinToString(", ")}.")
      }

      val userVersion = readUserVersion(db)
      val metaVersion = if (existingTables.contains("app_meta")) readAppMetaSchemaVersion(db) else null
      val schemaVersion = maxOf(userVersion, metaVersion ?: 0)
      if (schemaVersion < 1) {
        errors.add("Database has invalid schema version ($schemaVersion).")
      } else if (schemaVersion > OrvaSchemaInteropContract.CURRENT_SCHEMA_VERSION) {
        errors.add(
          "Backup uses newer database schema version $schemaVersion (this app supports up to version ${OrvaSchemaInteropContract.CURRENT_SCHEMA_VERSION})."
        )
      }

      if (errors.isNotEmpty()) {
        return SqliteValidationReport(isValid = false, schemaVersion = schemaVersion, errors = errors)
      }

      var shopId: String? = null
      var shopName: String? = null
      db.rawQuery("SELECT shop_id, shop_name FROM shop_profile WHERE profile_id = 1 LIMIT 1;", null).use { c ->
        if (c.moveToFirst()) {
          shopId = c.getString(0)
          shopName = c.getString(1)
        }
      }

      SqliteValidationReport(
        isValid = true,
        schemaVersion = schemaVersion,
        shopId = shopId,
        shopName = shopName,
        medicineCount = queryCount(db, "medicine"),
        batchCount = queryCount(db, "stock_batch"),
        invoiceCount = queryCount(db, "invoice"),
        purchaseCount = queryCount(db, "purchase_receipt"),
        returnCount = queryCount(db, "sales_return"),
      )
    } catch (ex: Exception) {
      SqliteValidationReport(
        isValid = false,
        errors = listOf("Unable to inspect SQLite database: ${ex.message ?: ex.javaClass.simpleName}"),
      )
    } finally {
      runCatching { db?.close() }
    }
  }

  internal fun splitSqlStatements(script: String): List<String> {
    val statements = mutableListOf<String>()
    val current = StringBuilder()
    var i = 0
    var inSingleQuote = false
    while (i < script.length) {
      val ch = script[i]
      if (inSingleQuote) {
        current.append(ch)
        if (ch == '\'') {
          if (i + 1 < script.length && script[i + 1] == '\'') {
            current.append('\'')
            i += 2
            continue
          }
          inSingleQuote = false
        }
        i++
        continue
      }

      if (ch == '-' && i + 1 < script.length && script[i + 1] == '-') {
        // Skip SQL line comment until newline.
        i += 2
        while (i < script.length && script[i] != '\n') {
          i++
        }
        continue
      }

      if (ch == '\'') {
        inSingleQuote = true
        current.append(ch)
        i++
        continue
      }

      if (ch == ';') {
        val stmt = current.toString().trim()
        if (stmt.isNotEmpty()) {
          statements.add(stmt)
        }
        current.setLength(0)
        i++
        continue
      }

      current.append(ch)
      i++
    }
    val tail = current.toString().trim()
    if (tail.isNotEmpty()) {
      statements.add(tail)
    }
    return statements
  }

  private fun executeSqlScript(db: SQLiteDatabase, script: String) {
    for (stmt in splitSqlStatements(script)) {
      // PRAGMA foreign_keys cannot be toggled inside a transaction; already enabled outside.
      if (stmt.startsWith("PRAGMA ", ignoreCase = true)) {
        continue
      }
      db.execSQL(stmt)
    }
  }

  private fun upsertSchemaVersionMeta(db: SQLiteDatabase, version: Int) {
    db.execSQL(
      "INSERT OR REPLACE INTO app_meta(meta_key, meta_value) VALUES ('schema_version', ?);",
      arrayOf(version.toString()),
    )
  }

  private fun readUserVersion(db: SQLiteDatabase): Int =
    db.rawQuery("PRAGMA user_version;", null).use { cursor ->
      if (cursor.moveToFirst()) cursor.getInt(0) else 0
    }

  private fun readAppMetaSchemaVersion(db: SQLiteDatabase): Int? =
    db.rawQuery("SELECT meta_value FROM app_meta WHERE meta_key = 'schema_version' LIMIT 1;", null)
      .use { cursor ->
        if (cursor.moveToFirst()) cursor.getString(0)?.trim()?.toIntOrNull() else null
      }

  private fun tableExists(db: SQLiteDatabase, tableName: String): Boolean =
    db.rawQuery(
        "SELECT 1 FROM sqlite_master WHERE type = 'table' AND name = ? LIMIT 1;",
        arrayOf(tableName),
      )
      .use { cursor -> cursor.moveToFirst() }

  private fun columnExists(db: SQLiteDatabase, tableName: String, columnName: String): Boolean =
    db.rawQuery("PRAGMA table_info($tableName);", null).use { cursor ->
      val nameIndex = cursor.getColumnIndex("name")
      while (cursor.moveToNext()) {
        if (nameIndex >= 0 && cursor.getString(nameIndex).equals(columnName, ignoreCase = true)) {
          return true
        }
      }
      false
    }

  private fun readUserTableNames(db: SQLiteDatabase): Set<String> {
    val result = mutableSetOf<String>()
    db.rawQuery(
        "SELECT name FROM sqlite_master WHERE type = 'table' AND name NOT LIKE 'sqlite_%' AND name <> ? AND name <> 'android_metadata';",
        arrayOf(OrvaSchemaInteropContract.ROOM_MASTER_TABLE),
      )
      .use { cursor ->
        while (cursor.moveToNext()) {
          result.add(cursor.getString(0))
        }
      }
    return result
  }

  private fun readUserIndexNames(db: SQLiteDatabase): Set<String> {
    val result = mutableSetOf<String>()
    db.rawQuery(
        "SELECT name FROM sqlite_master WHERE type = 'index' AND name NOT LIKE 'sqlite_%';",
        null,
      )
      .use { cursor ->
        while (cursor.moveToNext()) {
          result.add(cursor.getString(0))
        }
      }
    return result
  }

  private fun queryCount(db: SQLiteDatabase, tableName: String): Long =
    db.rawQuery("SELECT COUNT(*) FROM $tableName;", null).use { cursor ->
      if (cursor.moveToFirst()) cursor.getLong(0) else 0L
    }
}
