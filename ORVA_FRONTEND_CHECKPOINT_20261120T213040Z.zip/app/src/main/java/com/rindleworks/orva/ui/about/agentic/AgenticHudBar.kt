package com.rindleworks.orva.ui.about.agentic

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Replay
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.rindleworks.orva.domain.settings.AppLanguage
import com.rindleworks.orva.ui.showcase.LocalPaperModeToggle
import com.rindleworks.orva.ui.showcase.OrvaShowcaseColors
import com.rindleworks.orva.ui.showcase.OrvaShowcaseFonts
import com.rindleworks.orva.ui.showcase.currentShowcasePalette

/**
 * Razor-thin single-row floating obsidian/paper capsule HUD.
 * Preserves every accessible hit target and Robolectric `testTag`, plus instant Paper Mode toggle.
 */
@Composable
fun AgenticHudBar(
  controller: AgenticBuildController,
  language: AppLanguage,
  modifier: Modifier = Modifier,
) {
  val palette = currentShowcasePalette()
  val togglePaperMode = LocalPaperModeToggle.current
  val completed = controller.completedCount
  val total = controller.totalCount.coerceAtLeast(1)
  val progress = (completed.toFloat() / total.toFloat()).coerceIn(0f, 1f)
  val isDone = controller.act == BuildAct.COMPLETED

  val compactStatus =
    when (controller.act) {
      BuildAct.ORBITAL_SCAN -> if (language == AppLanguage.Bengali) "ইন্ট্রো" else "INTRO"
      BuildAct.STRUCTURAL_BUILD, BuildAct.SCROLL_ASSEMBLY ->
        "${controller.activeBuilderCount}/16 · $completed/$total"
      BuildAct.CONVERGENCE -> if (language == AppLanguage.Bengali) "সমাপ্তি" else "SETTLING"
      BuildAct.COMPLETED -> if (language == AppLanguage.Bengali) "সম্পন্ন" else "BUILT · $completed/$total"
    }

  val progressBrush =
    Brush.horizontalGradient(
      colors = listOf(OrvaShowcaseColors.CursorPurpleCore, OrvaShowcaseColors.CursorVermilionCore),
    )

  Box(
    modifier =
      modifier
        .fillMaxWidth()
        .navigationBarsPadding()
        .padding(horizontal = 14.dp, vertical = 10.dp),
    contentAlignment = Alignment.Center,
  ) {
    Column(
      modifier =
        Modifier
          .widthIn(max = 580.dp)
          .clip(RoundedCornerShape(999.dp))
          .background(palette.agentTagSurface)
          .border(1.dp, palette.hairline, RoundedCornerShape(999.dp))
          .testTag("agentic_hud_bar"),
    ) {
      Row(
        modifier =
          Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 2.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(4.dp),
      ) {
        Box(
          modifier =
            Modifier
              .size(6.dp)
              .clip(CircleShape)
              .background(
                if (isDone) OrvaShowcaseColors.CursorPurpleCore
                else OrvaShowcaseColors.CursorVermilionCore,
              ),
        )
        Text(
          text = compactStatus,
          fontFamily = OrvaShowcaseFonts.mono(language),
          fontSize = 10.sp,
          letterSpacing = 0.6.sp,
          color = palette.inkPrimary,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis,
          modifier = Modifier.weight(1f).padding(start = 4.dp).testTag("agentic_hud_status"),
        )

        CapsuleTextAction(
          label = if (palette.isPaperMode) "DARK" else "PAPER",
          active = palette.isPaperMode,
          testTag = "hud_paper_toggle",
          onClick = togglePaperMode,
        )

        if (!isDone) {
          CapsuleTextAction(
            label = if (controller.touringEnabled) "TOUR" else "FREE",
            active = controller.touringEnabled,
            testTag = "hud_tour_btn",
            onClick = { controller.toggleTouring() },
          )
          CapsuleTextAction(
            label = "${controller.speedMultiplier.toString().removeSuffix(".0")}×",
            active = controller.speedMultiplier > 1f,
            testTag = "hud_speed_btn",
            onClick = { controller.cycleSpeed() },
          )
          CapsuleIconAction(
            icon = if (controller.paused) Icons.Filled.PlayArrow else Icons.Filled.Pause,
            contentDescription = if (controller.paused) "Resume build" else "Pause build",
            active = controller.paused,
            testTag = "hud_pause_btn",
            onClick = { controller.togglePause() },
          )
          CapsuleTextAction(
            label = if (language == AppLanguage.Bengali) "সম্পূর্ণ" else "FINISH",
            active = false,
            accentColor = OrvaShowcaseColors.CursorVermilionBright,
            testTag = "hud_skip_btn",
            onClick = { controller.skipToFinish() },
          )
        } else {
          CapsuleTextAction(
            label = if (language == AppLanguage.Bengali) "পুনরায়" else "REPLAY",
            active = true,
            leadingIcon = Icons.Filled.Replay,
            testTag = "hud_replay_btn",
            onClick = { controller.replay() },
          )
        }
      }

      // Ultra-slim 2dp Purple->Vermilion hairline progress track along bottom edge of capsule
      Box(
        modifier =
          Modifier
            .fillMaxWidth()
            .height(2.dp)
            .background(Color.Transparent),
      ) {
        Box(
          modifier =
            Modifier
              .fillMaxWidth(progress)
              .height(2.dp)
              .background(progressBrush),
        )
      }
    }
  }
}

@Composable
private fun CapsuleTextAction(
  label: String,
  active: Boolean,
  testTag: String,
  onClick: () -> Unit,
  accentColor: Color? = null,
  leadingIcon: androidx.compose.ui.graphics.vector.ImageVector? = null,
) {
  val palette = currentShowcasePalette()
  val tint =
    when {
      accentColor != null -> accentColor
      active -> if (palette.isPaperMode) OrvaShowcaseColors.AccentViolet else OrvaShowcaseColors.CursorPurpleBright
      else -> palette.inkSecondary
    }
  Row(
    modifier =
      Modifier
        .minimumInteractiveComponentSize()
        .clickable(role = Role.Button, onClick = onClick)
        .padding(horizontal = 6.dp)
        .testTag(testTag),
    verticalAlignment = Alignment.CenterVertically,
    horizontalArrangement = Arrangement.spacedBy(4.dp),
  ) {
    if (leadingIcon != null) {
      Icon(imageVector = leadingIcon, contentDescription = null, tint = tint, modifier = Modifier.size(13.dp))
    }
    Text(
      text = label,
      fontFamily = OrvaShowcaseFonts.IbmPlexMono,
      fontWeight = FontWeight.SemiBold,
      fontSize = 10.sp,
      letterSpacing = 0.8.sp,
      color = tint,
    )
  }
}

@Composable
private fun CapsuleIconAction(
  icon: androidx.compose.ui.graphics.vector.ImageVector,
  contentDescription: String,
  active: Boolean,
  testTag: String,
  onClick: () -> Unit,
) {
  val palette = currentShowcasePalette()
  Box(
    modifier =
      Modifier
        .minimumInteractiveComponentSize()
        .clickable(role = Role.Button, onClick = onClick)
        .padding(horizontal = 4.dp)
        .testTag(testTag),
    contentAlignment = Alignment.Center,
  ) {
    Icon(
      imageVector = icon,
      contentDescription = contentDescription,
      tint =
        if (active) {
          if (palette.isPaperMode) OrvaShowcaseColors.AccentViolet else OrvaShowcaseColors.CursorPurpleBright
        } else {
          palette.inkSecondary
        },
      modifier = Modifier.size(15.dp),
    )
  }
}
