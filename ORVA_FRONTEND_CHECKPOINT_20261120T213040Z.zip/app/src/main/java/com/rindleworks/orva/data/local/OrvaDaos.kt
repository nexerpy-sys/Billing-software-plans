package com.rindleworks.orva.data.local

import androidx.room.ColumnInfo
import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.rindleworks.orva.data.local.entity.AppMetaEntity
import com.rindleworks.orva.data.local.entity.AppSettingEntity
import com.rindleworks.orva.data.local.entity.AuditLogEntity
import com.rindleworks.orva.data.local.entity.BarcodeMappingEntity
import com.rindleworks.orva.data.local.entity.ExpenseRecordEntity
import com.rindleworks.orva.data.local.entity.InvoiceEntity
import com.rindleworks.orva.data.local.entity.InvoiceLineEntity
import com.rindleworks.orva.data.local.entity.InvoiceSequenceEntity
import com.rindleworks.orva.data.local.entity.MedicineEntity
import com.rindleworks.orva.data.local.entity.PaymentEntity
import com.rindleworks.orva.data.local.entity.PurchaseLineEntity
import com.rindleworks.orva.data.local.entity.PurchaseReceiptEntity
import com.rindleworks.orva.data.local.entity.SalesReturnEntity
import com.rindleworks.orva.data.local.entity.SalesReturnLineEntity
import com.rindleworks.orva.data.local.entity.ShopProfileEntity
import com.rindleworks.orva.data.local.entity.StockBatchEntity
import com.rindleworks.orva.data.local.entity.StockDiscrepancyEntity
import com.rindleworks.orva.data.local.entity.StockMovementEntity
import kotlinx.coroutines.flow.Flow

// --- Query Projection Models ---

data class MedicineWithBatchJoinRow(
  @ColumnInfo(name = "medicine_id") val medicineId: String,
  @ColumnInfo(name = "display_name") val displayName: String,
  @ColumnInfo(name = "generic_name") val genericName: String?,
  @ColumnInfo(name = "brand_name") val brandName: String?,
  @ColumnInfo(name = "strength") val strength: String?,
  @ColumnInfo(name = "dosage_form") val dosageForm: String?,
  @ColumnInfo(name = "medicine_stock_unit_name") val medicineStockUnitName: String,
  @ColumnInfo(name = "low_stock_threshold_milli") val lowStockThresholdMilli: Long,
  @ColumnInfo(name = "is_active") val isActive: Int,
  @ColumnInfo(name = "batch_id") val batchId: String,
  @ColumnInfo(name = "batch_number") val batchNumber: String,
  @ColumnInfo(name = "expiry_yyyymm") val expiryYyyyMm: Int,
  @ColumnInfo(name = "batch_stock_unit_name") val batchStockUnitName: String,
  @ColumnInfo(name = "mrp_paise") val mrpPaise: Long,
  @ColumnInfo(name = "latest_purchase_price_paise") val latestPurchasePricePaise: Long,
  @ColumnInfo(name = "quantity_milli") val quantityMilli: Long,
  @ColumnInfo(name = "batch_status") val batchStatus: String,
)

data class SalesRegisterJoinRow(
  @ColumnInfo(name = "invoice_id") val invoiceId: String,
  @ColumnInfo(name = "invoice_number") val invoiceNumber: String,
  @ColumnInfo(name = "issued_at_utc") val issuedAtUtc: String,
  @ColumnInfo(name = "customer_name") val customerName: String?,
  @ColumnInfo(name = "customer_gstin") val customerGstin: String?,
  @ColumnInfo(name = "taxable_value_paise") val taxableValuePaise: Long,
  @ColumnInfo(name = "cgst_paise") val cgstPaise: Long,
  @ColumnInfo(name = "sgst_paise") val sgstPaise: Long,
  @ColumnInfo(name = "igst_paise") val igstPaise: Long,
  @ColumnInfo(name = "round_off_paise") val roundOffPaise: Long,
  @ColumnInfo(name = "grand_total_paise") val grandTotalPaise: Long,
  @ColumnInfo(name = "paid_total_paise") val paidTotalPaise: Long,
  @ColumnInfo(name = "status") val status: String,
  @ColumnInfo(name = "cancellation_reason") val cancellationReason: String?,
)

/** Escapes SQLite LIKE metacharacters (`\`, `%`, `_`) for use with `ESCAPE '\'`. */
object SqlLikeEscaper {
  fun escape(raw: String): String =
    raw.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")

  fun containsPattern(raw: String?): String {
    val clean = raw?.trim()?.lowercase(java.util.Locale.ROOT).orEmpty()
    return if (clean.isEmpty()) "" else "%${escape(clean)}%"
  }

  fun prefixPattern(raw: String): String {
    val clean = raw.trim().lowercase(java.util.Locale.ROOT)
    return if (clean.isEmpty()) "" else "${escape(clean)}%"
  }
}

data class GstSummaryLineQueryRow(
  @ColumnInfo(name = "hsn_code") val hsnCode: String?,
  @ColumnInfo(name = "gst_rate_basis_points") val gstRateBasisPoints: Int,
  @ColumnInfo(name = "quantity_milli") val quantityMilli: Long,
  @ColumnInfo(name = "taxable_value_paise") val taxableValuePaise: Long,
  @ColumnInfo(name = "cgst_paise") val cgstPaise: Long,
  @ColumnInfo(name = "sgst_paise") val sgstPaise: Long,
  @ColumnInfo(name = "igst_paise") val igstPaise: Long,
  @ColumnInfo(name = "line_total_paise") val lineTotalPaise: Long,
  @ColumnInfo(name = "returned_qty_milli") val returnedQtyMilli: Long,
)

data class SalesReturnRegisterJoinRow(
  @ColumnInfo(name = "return_id") val returnId: String,
  @ColumnInfo(name = "return_number") val returnNumber: String,
  @ColumnInfo(name = "invoice_number") val invoiceNumber: String,
  @ColumnInfo(name = "returned_at_utc") val returnedAtUtc: String,
  @ColumnInfo(name = "reason") val reason: String,
  @ColumnInfo(name = "refund_method") val refundMethod: String?,
  @ColumnInfo(name = "refund_amount_paise") val refundAmountPaise: Long,
  @ColumnInfo(name = "status") val status: String,
)

data class ReturnLineSummaryAggregate(
  @ColumnInfo(name = "invoice_line_id") val invoiceLineId: String,
  @ColumnInfo(name = "returned_qty_milli") val returnedQtyMilli: Long,
  @ColumnInfo(name = "refunded_paise") val refundedPaise: Long,
)

// --- DAOs ---

@Dao
interface AppMetaDao {
  @Query("SELECT meta_value FROM app_meta WHERE meta_key = :key LIMIT 1")
  fun getValue(key: String): String?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  fun upsert(meta: AppMetaEntity)
}

@Dao
interface ShopProfileDao {
  @Query("SELECT * FROM shop_profile WHERE profile_id = 1 LIMIT 1")
  fun observeProfile(): Flow<ShopProfileEntity?>

  @Query("SELECT * FROM shop_profile WHERE profile_id = 1 LIMIT 1")
  fun getProfile(): ShopProfileEntity?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  fun upsert(profile: ShopProfileEntity)
}

@Dao
interface AppSettingDao {
  @Query("SELECT setting_value FROM app_setting WHERE setting_key = :key LIMIT 1")
  fun observeValue(key: String): Flow<String?>

  @Query("SELECT * FROM app_setting")
  fun observeAll(): Flow<List<AppSettingEntity>>

  @Query("SELECT * FROM app_setting")
  fun getAll(): List<AppSettingEntity>

  @Query("SELECT setting_value FROM app_setting WHERE setting_key = :key LIMIT 1")
  fun getValue(key: String): String?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  fun upsert(setting: AppSettingEntity)

  @Query("DELETE FROM app_setting WHERE setting_key = :key")
  fun delete(key: String)
}

@Dao
interface MedicineDao {
  @Query("SELECT * FROM medicine WHERE medicine_id = :medicineId LIMIT 1")
  fun getById(medicineId: String): MedicineEntity?

  @Query("SELECT * FROM medicine WHERE normalized_name = :normalizedName LIMIT 1")
  fun getByNormalizedName(normalizedName: String): MedicineEntity?

  @Query("SELECT * FROM medicine ORDER BY display_name COLLATE NOCASE ASC")
  fun getAll(): List<MedicineEntity>

  @Query("SELECT * FROM medicine ORDER BY display_name COLLATE NOCASE ASC")
  fun observeAll(): Flow<List<MedicineEntity>>

  @Query("SELECT * FROM medicine WHERE is_active = 1 ORDER BY display_name COLLATE NOCASE ASC")
  fun getActiveMedicines(): List<MedicineEntity>

  @Query(
    """
    SELECT * FROM medicine
    WHERE is_active = 1
      AND (
        LOWER(display_name) LIKE :likePattern ESCAPE '\'
        OR LOWER(COALESCE(generic_name, '')) LIKE :likePattern ESCAPE '\'
        OR LOWER(COALESCE(brand_name, '')) LIKE :likePattern ESCAPE '\'
        OR medicine_id IN (SELECT medicine_id FROM barcode_mapping WHERE LOWER(barcode) = :exactLower)
      )
    ORDER BY
      CASE WHEN medicine_id IN (SELECT medicine_id FROM barcode_mapping WHERE LOWER(barcode) = :exactLower) THEN 0
           WHEN LOWER(display_name) = :exactLower THEN 1
           WHEN LOWER(display_name) LIKE :prefixPattern ESCAPE '\' THEN 2
           ELSE 3 END,
      display_name COLLATE NOCASE ASC
    LIMIT :limit
    """
  )
  fun searchActiveMedicines(
    likePattern: String,
    prefixPattern: String,
    exactLower: String,
    limit: Int,
  ): List<MedicineEntity>

  @Query(
    """
    SELECT * FROM medicine
    WHERE (:searchPattern = '' OR LOWER(display_name) LIKE :searchPattern ESCAPE '\' OR LOWER(COALESCE(hsn_code, '')) LIKE :searchPattern ESCAPE '\')
    ORDER BY gst_rate_configured ASC, display_name COLLATE NOCASE ASC
    """
  )
  fun searchForTaxConfig(searchPattern: String): List<MedicineEntity>

  @Query("SELECT COUNT(*) FROM medicine")
  fun countAll(): Int

  @Insert(onConflict = OnConflictStrategy.ABORT)
  fun insert(medicine: MedicineEntity)

  @Update
  fun update(medicine: MedicineEntity)

  @Query(
    """
    UPDATE medicine
    SET hsn_code = :hsnCode,
        gst_rate_basis_points = :gstRateBasisPoints,
        gst_rate_configured = :gstRateConfigured,
        updated_at_utc = :updatedAtUtc
    WHERE medicine_id = :medicineId
    """
  )
  fun updateTaxConfig(
    medicineId: String,
    hsnCode: String?,
    gstRateBasisPoints: Int,
    gstRateConfigured: Int,
    updatedAtUtc: String,
  ): Int

  @Query(
    """
    UPDATE medicine
    SET is_active = :isActive,
        updated_at_utc = :updatedAtUtc
    WHERE medicine_id = :medicineId
    """
  )
  fun updateActiveFlag(medicineId: String, isActive: Int, updatedAtUtc: String): Int
}

@Dao
interface BarcodeMappingDao {
  @Query("SELECT * FROM barcode_mapping WHERE barcode = :barcode LIMIT 1")
  fun getByBarcode(barcode: String): BarcodeMappingEntity?

  @Query("SELECT * FROM barcode_mapping WHERE medicine_id = :medicineId")
  fun getByMedicineId(medicineId: String): List<BarcodeMappingEntity>

  @Query("SELECT * FROM barcode_mapping")
  fun getAll(): List<BarcodeMappingEntity>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  fun upsert(mapping: BarcodeMappingEntity)

  @Insert(onConflict = OnConflictStrategy.IGNORE)
  fun insertIgnore(mapping: BarcodeMappingEntity)

  @Query("DELETE FROM barcode_mapping WHERE barcode = :barcode")
  fun delete(barcode: String)
}

@Dao
interface StockBatchDao {
  @Query("SELECT * FROM stock_batch WHERE batch_id = :batchId LIMIT 1")
  fun getById(batchId: String): StockBatchEntity?

  @Query("SELECT * FROM stock_batch ORDER BY medicine_id ASC, expiry_yyyymm ASC, UPPER(TRIM(batch_number)) ASC, batch_id ASC")
  fun getAll(): List<StockBatchEntity>

  @Query("SELECT * FROM stock_batch WHERE medicine_id = :medicineId ORDER BY expiry_yyyymm ASC, UPPER(TRIM(batch_number)) ASC, batch_id ASC")
  fun getByMedicineId(medicineId: String): List<StockBatchEntity>

  @Query(
    """
    SELECT * FROM stock_batch
    WHERE medicine_id = :medicineId
      AND UPPER(TRIM(batch_number)) = UPPER(TRIM(:batchNumber))
      AND expiry_yyyymm = :expiryYyyyMm
    LIMIT 1
    """
  )
  fun findByNormalizedIdentity(
    medicineId: String,
    batchNumber: String,
    expiryYyyyMm: Int,
  ): StockBatchEntity?

  @Query(
    """
    SELECT
      m.medicine_id AS medicine_id,
      m.display_name AS display_name,
      m.generic_name AS generic_name,
      m.brand_name AS brand_name,
      m.strength AS strength,
      m.dosage_form AS dosage_form,
      m.stock_unit_name AS medicine_stock_unit_name,
      m.low_stock_threshold_milli AS low_stock_threshold_milli,
      m.is_active AS is_active,
      b.batch_id AS batch_id,
      b.batch_number AS batch_number,
      b.expiry_yyyymm AS expiry_yyyymm,
      b.stock_unit_name AS batch_stock_unit_name,
      b.mrp_paise AS mrp_paise,
      b.latest_purchase_price_paise AS latest_purchase_price_paise,
      b.quantity_milli AS quantity_milli,
      b.batch_status AS batch_status
    FROM stock_batch b
    INNER JOIN medicine m ON m.medicine_id = b.medicine_id
    ORDER BY m.display_name COLLATE NOCASE ASC, b.expiry_yyyymm ASC, UPPER(TRIM(b.batch_number)) ASC, b.batch_id ASC
    """
  )
  fun observeAllWithMedicine(): Flow<List<MedicineWithBatchJoinRow>>

  @Query(
    """
    SELECT
      m.medicine_id AS medicine_id,
      m.display_name AS display_name,
      m.generic_name AS generic_name,
      m.brand_name AS brand_name,
      m.strength AS strength,
      m.dosage_form AS dosage_form,
      m.stock_unit_name AS medicine_stock_unit_name,
      m.low_stock_threshold_milli AS low_stock_threshold_milli,
      m.is_active AS is_active,
      b.batch_id AS batch_id,
      b.batch_number AS batch_number,
      b.expiry_yyyymm AS expiry_yyyymm,
      b.stock_unit_name AS batch_stock_unit_name,
      b.mrp_paise AS mrp_paise,
      b.latest_purchase_price_paise AS latest_purchase_price_paise,
      b.quantity_milli AS quantity_milli,
      b.batch_status AS batch_status
    FROM stock_batch b
    INNER JOIN medicine m ON m.medicine_id = b.medicine_id
    ORDER BY m.display_name COLLATE NOCASE ASC, b.expiry_yyyymm ASC, UPPER(TRIM(b.batch_number)) ASC, b.batch_id ASC
    """
  )
  fun getAllWithMedicine(): List<MedicineWithBatchJoinRow>

  @Query("SELECT COUNT(*) FROM stock_batch")
  fun countAll(): Int

  @Insert(onConflict = OnConflictStrategy.ABORT)
  fun insert(batch: StockBatchEntity)

  @Update
  fun update(batch: StockBatchEntity)

  /**
   * Guarded atomic stock deduction: enforces batch_status = 'ACTIVE' and quantity_milli >= deductMilli.
   * Caller MUST verify rowsAffected == 1 inside the BEGIN IMMEDIATE write transaction.
   */
  @Query(
    """
    UPDATE stock_batch
    SET quantity_milli = quantity_milli - :deductMilli,
        updated_at_utc = :updatedAtUtc
    WHERE batch_id = :batchId
      AND batch_status = 'ACTIVE'
      AND quantity_milli >= :deductMilli
    """
  )
  fun deductQuantityGuarded(batchId: String, deductMilli: Long, updatedAtUtc: String): Int

  @Query(
    """
    UPDATE stock_batch
    SET quantity_milli = quantity_milli + :addMilli,
        updated_at_utc = :updatedAtUtc
    WHERE batch_id = :batchId
    """
  )
  fun addQuantity(batchId: String, addMilli: Long, updatedAtUtc: String): Int

  @Query(
    """
    UPDATE stock_batch
    SET quantity_milli = :newQuantityMilli,
        updated_at_utc = :updatedAtUtc
    WHERE batch_id = :batchId
    """
  )
  fun setQuantity(batchId: String, newQuantityMilli: Long, updatedAtUtc: String): Int

  @Query(
    """
    UPDATE stock_batch
    SET batch_status = :newStatus,
        updated_at_utc = :updatedAtUtc
    WHERE batch_id = :batchId
    """
  )
  fun updateStatus(batchId: String, newStatus: String, updatedAtUtc: String): Int
}

@Dao
interface InvoiceDao {
  @Query("SELECT * FROM invoice_sequence WHERE financial_year = :financialYear LIMIT 1")
  fun getSequence(financialYear: String): InvoiceSequenceEntity?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  fun upsertSequence(sequence: InvoiceSequenceEntity)

  @Insert(onConflict = OnConflictStrategy.ABORT)
  fun insertInvoice(invoice: InvoiceEntity)

  @Insert(onConflict = OnConflictStrategy.ABORT)
  fun insertInvoiceLine(line: InvoiceLineEntity)

  @Insert(onConflict = OnConflictStrategy.ABORT)
  fun insertPayment(payment: PaymentEntity)

  @Query("SELECT * FROM invoice WHERE invoice_id = :invoiceId LIMIT 1")
  fun getInvoiceById(invoiceId: String): InvoiceEntity?

  @Query("SELECT * FROM invoice WHERE invoice_number = :invoiceNumber LIMIT 1")
  fun getInvoiceByNumber(invoiceNumber: String): InvoiceEntity?

  @Query("SELECT * FROM invoice_line WHERE invoice_id = :invoiceId ORDER BY rowid ASC")
  fun getLinesForInvoice(invoiceId: String): List<InvoiceLineEntity>

  @Query("SELECT * FROM payment WHERE invoice_id = :invoiceId ORDER BY paid_at_utc ASC, rowid ASC")
  fun getPaymentsForInvoice(invoiceId: String): List<PaymentEntity>

  @Query(
    """
    SELECT * FROM invoice
    WHERE status IN ('ISSUED', 'CREDIT_NOTE_ISSUED')
      AND (
        :searchPattern = ''
        OR LOWER(invoice_number) LIKE :searchPattern ESCAPE '\'
        OR LOWER(COALESCE(customer_name, '')) LIKE :searchPattern ESCAPE '\'
        OR LOWER(COALESCE(customer_phone, '')) LIKE :searchPattern ESCAPE '\'
      )
    ORDER BY issued_at_utc DESC
    LIMIT :limit
    """
  )
  fun searchReturnableInvoices(searchPattern: String, limit: Int): List<InvoiceEntity>

  @Query(
    """
    UPDATE invoice
    SET status = :newStatus,
        cancellation_reason = :cancellationReason
    WHERE invoice_id = :invoiceId
    """
  )
  fun updateInvoiceStatus(invoiceId: String, newStatus: String, cancellationReason: String?): Int

  @Query("SELECT COUNT(*) FROM invoice")
  fun countInvoices(): Int

  @Query(
    """
    SELECT
      i.invoice_id AS invoice_id,
      i.invoice_number AS invoice_number,
      i.issued_at_utc AS issued_at_utc,
      i.customer_name AS customer_name,
      i.customer_gstin AS customer_gstin,
      i.taxable_value_paise AS taxable_value_paise,
      i.cgst_paise AS cgst_paise,
      i.sgst_paise AS sgst_paise,
      i.igst_paise AS igst_paise,
      i.round_off_paise AS round_off_paise,
      i.grand_total_paise AS grand_total_paise,
      COALESCE((SELECT SUM(p.amount_paise) FROM payment p WHERE p.invoice_id = i.invoice_id), 0) AS paid_total_paise,
      i.status AS status,
      i.cancellation_reason AS cancellation_reason
    FROM invoice i
    WHERE (:fromUtc IS NULL OR i.issued_at_utc >= :fromUtc)
      AND (:toUtcExclusive IS NULL OR i.issued_at_utc < :toUtcExclusive)
      AND (:statusFilter IS NULL OR i.status = :statusFilter)
      AND (
        :searchPattern = ''
        OR LOWER(i.invoice_number) LIKE :searchPattern ESCAPE '\'
        OR LOWER(COALESCE(i.customer_name, '')) LIKE :searchPattern ESCAPE '\'
        OR LOWER(COALESCE(i.customer_gstin, '')) LIKE :searchPattern ESCAPE '\'
      )
    ORDER BY i.issued_at_utc DESC, i.invoice_number DESC
    """
  )
  fun querySalesRegister(
    fromUtc: String?,
    toUtcExclusive: String?,
    statusFilter: String?,
    searchPattern: String,
  ): List<SalesRegisterJoinRow>

  @Query(
    """
    SELECT
      COALESCE(NULLIF(TRIM(l.hsn_code_snapshot), ''), 'UNSPECIFIED') AS hsn_code,
      l.gst_rate_basis_points AS gst_rate_basis_points,
      l.quantity_milli AS quantity_milli,
      l.taxable_value_paise AS taxable_value_paise,
      l.cgst_paise AS cgst_paise,
      l.sgst_paise AS sgst_paise,
      l.igst_paise AS igst_paise,
      l.line_total_paise AS line_total_paise,
      COALESCE((
        SELECT SUM(srl.quantity_milli)
        FROM sales_return_line srl
        INNER JOIN sales_return sr ON sr.return_id = srl.return_id
        WHERE srl.invoice_line_id = l.invoice_line_id
          AND sr.status = 'COMPLETED'
          AND (:fromUtc IS NULL OR sr.returned_at_utc >= :fromUtc)
          AND (:toUtcExclusive IS NULL OR sr.returned_at_utc < :toUtcExclusive)
      ), 0) AS returned_qty_milli
    FROM invoice_line l
    INNER JOIN invoice i ON i.invoice_id = l.invoice_id
    WHERE i.status <> 'CANCELLED'
      AND (:fromUtc IS NULL OR i.issued_at_utc >= :fromUtc)
      AND (:toUtcExclusive IS NULL OR i.issued_at_utc < :toUtcExclusive)
    ORDER BY hsn_code ASC, l.gst_rate_basis_points ASC
    """
  )
  fun queryGstSummaryLines(fromUtc: String?, toUtcExclusive: String?): List<GstSummaryLineQueryRow>
}

@Dao
interface SalesReturnDao {
  @Insert(onConflict = OnConflictStrategy.ABORT)
  fun insertReturn(salesReturn: SalesReturnEntity)

  @Insert(onConflict = OnConflictStrategy.ABORT)
  fun insertReturnLine(line: SalesReturnLineEntity)

  @Query("SELECT COUNT(*) FROM sales_return WHERE invoice_id = :invoiceId AND status = 'COMPLETED'")
  fun countCompletedReturnsForInvoice(invoiceId: String): Int

  @Query(
    """
    SELECT
      rl.invoice_line_id AS invoice_line_id,
      SUM(rl.quantity_milli) AS returned_qty_milli,
      SUM(rl.line_refund_paise) AS refunded_paise
    FROM sales_return_line rl
    INNER JOIN sales_return r ON r.return_id = rl.return_id
    WHERE r.invoice_id = :invoiceId
      AND r.status = 'COMPLETED'
    GROUP BY rl.invoice_line_id
    """
  )
  fun getCompletedReturnAggregatesForInvoice(invoiceId: String): List<ReturnLineSummaryAggregate>

  @Query(
    """
    SELECT COALESCE(SUM(r.refund_amount_paise), 0)
    FROM sales_return r
    WHERE r.invoice_id = :invoiceId
      AND r.status = 'COMPLETED'
    """
  )
  fun getTotalCompletedRefundForInvoice(invoiceId: String): Long

  @Query(
    """
    SELECT
      r.return_id AS return_id,
      r.return_number AS return_number,
      i.invoice_number AS invoice_number,
      r.returned_at_utc AS returned_at_utc,
      r.reason AS reason,
      r.refund_method AS refund_method,
      r.refund_amount_paise AS refund_amount_paise,
      r.status AS status
    FROM sales_return r
    INNER JOIN invoice i ON i.invoice_id = r.invoice_id
    WHERE (:fromUtc IS NULL OR r.returned_at_utc >= :fromUtc)
      AND (:toUtcExclusive IS NULL OR r.returned_at_utc < :toUtcExclusive)
      AND (
        :searchPattern = ''
        OR LOWER(r.return_number) LIKE :searchPattern ESCAPE '\'
        OR LOWER(i.invoice_number) LIKE :searchPattern ESCAPE '\'
        OR LOWER(r.reason) LIKE :searchPattern ESCAPE '\'
      )
    ORDER BY r.returned_at_utc DESC, r.return_number DESC
    """
  )
  fun querySalesReturnsRegister(
    fromUtc: String?,
    toUtcExclusive: String?,
    searchPattern: String,
  ): List<SalesReturnRegisterJoinRow>
}

@Dao
interface PurchaseDao {
  @Insert(onConflict = OnConflictStrategy.ABORT)
  fun insertReceipt(receipt: PurchaseReceiptEntity)

  @Insert(onConflict = OnConflictStrategy.ABORT)
  fun insertLine(line: PurchaseLineEntity)

  @Query(
    """
    SELECT * FROM purchase_receipt
    WHERE (:fromUtc IS NULL OR received_at_utc >= :fromUtc)
      AND (:toUtcExclusive IS NULL OR received_at_utc < :toUtcExclusive)
      AND (
        :supplierPattern = ''
        OR LOWER(COALESCE(supplier_name_text, '')) LIKE :supplierPattern ESCAPE '\'
        OR LOWER(COALESCE(document_reference, '')) LIKE :supplierPattern ESCAPE '\'
      )
    ORDER BY received_at_utc DESC
    """
  )
  fun queryPurchaseRegister(
    fromUtc: String?,
    toUtcExclusive: String?,
    supplierPattern: String,
  ): List<PurchaseReceiptEntity>
}

@Dao
interface LedgerDao {
  @Insert(onConflict = OnConflictStrategy.ABORT)
  fun insertStockMovement(movement: StockMovementEntity)

  @Query("SELECT * FROM stock_movement WHERE batch_id = :batchId ORDER BY created_at_utc ASC")
  fun getMovementsForBatch(batchId: String): List<StockMovementEntity>

  @Query("SELECT * FROM stock_movement WHERE reference_type = :refType AND reference_id = :refId ORDER BY created_at_utc ASC")
  fun getMovementsForReference(refType: String, refId: String): List<StockMovementEntity>

  @Insert(onConflict = OnConflictStrategy.ABORT)
  fun insertStockDiscrepancy(discrepancy: StockDiscrepancyEntity)

  @Query("SELECT * FROM stock_discrepancy WHERE batch_id = :batchId ORDER BY reconciled_at_utc DESC")
  fun getDiscrepanciesForBatch(batchId: String): List<StockDiscrepancyEntity>

  @Insert(onConflict = OnConflictStrategy.ABORT)
  fun insertAuditLog(auditLog: AuditLogEntity)

  @Query("SELECT * FROM audit_log WHERE entity_type = :entityType AND entity_id = :entityId ORDER BY created_at_utc DESC")
  fun getAuditLogsForEntity(entityType: String, entityId: String): List<AuditLogEntity>

  @Query("SELECT * FROM audit_log ORDER BY created_at_utc DESC LIMIT :limit")
  fun getRecentAuditLogs(limit: Int = 100): List<AuditLogEntity>

  @Insert(onConflict = OnConflictStrategy.ABORT)
  fun insertExpense(expense: ExpenseRecordEntity)

  @Query(
    """
    SELECT * FROM expense_record
    WHERE (:fromUtc IS NULL OR expense_date_utc >= :fromUtc)
      AND (:toUtcExclusive IS NULL OR expense_date_utc < :toUtcExclusive)
    ORDER BY expense_date_utc DESC, created_at_utc DESC
    """
  )
  fun queryExpenses(fromUtc: String?, toUtcExclusive: String?): List<ExpenseRecordEntity>
}
