package com.rindleworks.orva.domain.settings

import java.io.InputStream
import java.io.OutputStream
import kotlinx.coroutines.flow.Flow

enum class TaxPricingMode(val dbValue: String) {
  TaxInclusive("INCLUSIVE"),
  TaxExclusive("EXCLUSIVE");

  companion object {
    fun fromDbValue(raw: String?): TaxPricingMode? =
      entries.firstOrNull { it.dbValue.equals(raw?.trim(), ignoreCase = true) }
  }
}

enum class SupplyType(val dbValue: String) {
  IntraState("INTRA_STATE"),
  InterState("INTER_STATE");

  companion object {
    fun fromDbValue(raw: String?): SupplyType? =
      entries.firstOrNull { it.dbValue.equals(raw?.trim(), ignoreCase = true) }
  }
}

enum class RoundOffMode(val dbValue: String) {
  None("NONE"),
  NearestRupee("NEAREST_RUPEE");

  companion object {
    fun fromDbValue(raw: String?): RoundOffMode? =
      entries.firstOrNull { it.dbValue.equals(raw?.trim(), ignoreCase = true) }
  }
}

enum class AppLanguage(val code: String) {
  English("en"),
  Bengali("bn");

  companion object {
    fun fromCode(raw: String?): AppLanguage =
      entries.firstOrNull { it.code.equals(raw?.trim(), ignoreCase = true) } ?: English
  }
}

data class ShopProfile(
  val shopId: String,
  val shopName: String,
  val legalName: String? = null,
  val address: String? = null,
  val phone: String? = null,
  val email: String? = null,
  val stateName: String? = null,
  val stateCode: String? = null,
  val gstin: String? = null,
  val drugLicenceNumber: String? = null,
  val invoicePrefix: String = "INV",
  val financialYearStartMonth: Int = 4,
)

data class IndianGstState(
  val code: String,
  val name: String,
)

data class BillingTaxSettings(
  val isConfigured: Boolean = false,
  val pricingMode: TaxPricingMode? = null,
  val defaultSupplyType: SupplyType? = null,
  val roundOffMode: RoundOffMode? = null,
)

data class MedicineTaxConfigItem(
  val medicineId: String,
  val displayName: String,
  val stockUnitName: String,
  val hsnCode: String?,
  val gstRateBasisPoints: Int,
  val gstRateConfigured: Boolean,
)

data class ShopBackupManifest(
  val backupFormat: String,
  val formatVersion: Int,
  val applicationName: String,
  val applicationVersion: String,
  val databaseSchemaVersion: Int,
  val shopId: String?,
  val shopName: String?,
  val backupUtc: String,
  val backupLocalText: String,
  val databaseFileName: String,
  val databaseLengthBytes: Long,
  val databaseSha256: String,
  val medicineCount: Long,
  val batchCount: Long,
  val invoiceCount: Long,
  val purchaseCount: Long,
  val returnCount: Long,
)

data class ShopBackupPreview(
  val isValid: Boolean,
  val sourceName: String,
  val manifest: ShopBackupManifest? = null,
  val targetShopId: String? = null,
  val targetShopName: String? = null,
  val isDifferentShop: Boolean = false,
  val errors: List<String> = emptyList(),
)

data class ShopBackupCreateResult(
  val succeeded: Boolean,
  val backupPathOrUri: String? = null,
  val manifest: ShopBackupManifest? = null,
  val errorMessage: String? = null,
)

data class ShopRestoreResult(
  val succeeded: Boolean,
  val restoredShopName: String? = null,
  val safetyBackupPath: String? = null,
  val snapshotRefreshed: Boolean = false,
  val snapshotWarning: String? = null,
  val originalDatabaseRecovered: Boolean = false,
  val errorMessage: String? = null,
)

data class BackupStatusSummary(
  val lastSuccessUtc: String?,
  val lastSuccessLocalDate: String?,
  val lastBackupPath: String?,
  val lastError: String?,
  val retentionDays: Int,
  val isDueToday: Boolean,
)

data class SubscriptionStatus(
  val username: String?,
  val plan: String?,
  val startDateIso: String?,
  val expiryDateIso: String?,
  val status: String,
  val lastVerifiedUtc: String?,
  val isConfigured: Boolean,
  val isActive: Boolean,
  val isInGracePeriod: Boolean,
  val graceDaysRemaining: Int,
  val isRenewalReminderDue: Boolean,
  val daysUntilExpiry: Int?,
  val allowNewBilling: Boolean,
  val message: String,
)

data class OperationalSupportPrefs(
  val supportPhones: String = "",
  val supportWhatsapp: String = "",
  val supportEmail: String = "",
  val upiId: String = "",
  val upiPayeeName: String = "",
)

interface ShopRepository {
  fun observeProfile(): Flow<ShopProfile?>
  suspend fun getProfile(): ShopProfile?
  suspend fun saveProfileWithAudit(profile: ShopProfile): Result<Unit>
  fun getIndianGstStates(): List<IndianGstState>
}

interface TaxSettingsRepository {
  fun observeTaxSettings(): Flow<BillingTaxSettings>
  suspend fun getTaxSettings(): BillingTaxSettings
  suspend fun saveTaxSettings(
    taxConfigured: Boolean,
    pricingMode: TaxPricingMode,
    defaultSupplyType: SupplyType,
    roundOffMode: RoundOffMode,
  ): Result<Unit>

  suspend fun getMedicinesForTaxConfig(searchText: String): List<MedicineTaxConfigItem>
  suspend fun updateMedicineTaxConfig(
    medicineId: String,
    hsnCode: String?,
    gstRateBasisPoints: Int,
    gstRateConfigured: Boolean,
  ): Result<Unit>
}

interface AppSettingsRepository {
  fun observe(key: String, defaultValue: String = ""): Flow<String>
  suspend fun get(key: String, defaultValue: String = ""): String
  suspend fun set(key: String, value: String)
  suspend fun getLanguage(): AppLanguage
  suspend fun setLanguage(language: AppLanguage)
  suspend fun getOperationalSupportPrefs(): OperationalSupportPrefs
}

interface BackupRestoreService {
  suspend fun createBackupToStream(
    output: OutputStream,
    displayTargetName: String,
  ): ShopBackupCreateResult

  suspend fun runBackupNow(): ShopBackupCreateResult
  suspend fun runDailyBackupIfDue(): ShopBackupCreateResult?
  suspend fun getBackupStatus(): BackupStatusSummary
  suspend fun setRetentionDays(days: Int)
  suspend fun previewRestore(input: InputStream, sourceName: String): ShopBackupPreview
  suspend fun executeRestore(input: InputStream, sourceName: String): ShopRestoreResult
}

interface SubscriptionService {
  suspend fun saveCredentials(username: String, activationCode: String, registryUrl: String)
  suspend fun saveSupportAndUpiSettings(prefs: OperationalSupportPrefs)
  suspend fun evaluateLocalStatus(): SubscriptionStatus
  suspend fun refreshFromRegistry(): SubscriptionStatus
  fun buildUpiPaymentUri(
    upiId: String,
    payeeName: String,
    amountRupees: String,
    note: String,
  ): String

  fun buildWhatsAppClickToChatUrl(phone: String, message: String): String
}
