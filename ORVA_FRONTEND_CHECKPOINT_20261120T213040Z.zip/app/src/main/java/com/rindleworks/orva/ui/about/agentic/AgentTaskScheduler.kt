package com.rindleworks.orva.ui.about.agentic

import kotlin.math.abs

/**
 * Five specialized roles across the 16-agent About Us construction roster.
 */
enum class AgentRole {
  LAYOUT_ARCHITECT,
  COMPONENT_DUPLICATOR,
  TYPOGRAPHER,
  ART_DIRECTOR,
  IDLE_SCOUT,
}

enum class LayerKind {
  CONTAINER,
  MEDIA,
  TEXT,
  LINE,
}

enum class LayerPhase {
  HIDDEN,
  BUILDING,
  CLONED_MASTER_TEXT,
  REVEALED,
}

enum class BuildAct {
  ORBITAL_SCAN,
  STRUCTURAL_BUILD,
  SCROLL_ASSEMBLY,
  CONVERGENCE,
  COMPLETED,
}

/** Platform-independent rectangle in unified root/content coordinates (pixels). */
data class SceneBounds(
  val left: Float,
  val top: Float,
  val right: Float,
  val bottom: Float,
) {
  val width: Float get() = (right - left).coerceAtLeast(0f)
  val height: Float get() = (bottom - top).coerceAtLeast(0f)
  val centerX: Float get() = (left + right) * 0.5f
  val centerY: Float get() = (top + bottom) * 0.5f
  val isValid: Boolean get() = width > 0.5f && height > 0.5f

  fun intersectsVerticalWindow(windowTop: Float, windowBottom: Float): Boolean =
    isValid && bottom >= windowTop && top <= windowBottom

  companion object {
    val Empty = SceneBounds(0f, 0f, 0f, 0f)
  }
}

/**
 * Node registered by an actual Compose composable inside the About Us component tree.
 */
data class RegisteredSceneNode(
  val id: String,
  val kind: LayerKind,
  val orderIndex: Int,
  val parentId: String? = null,
  val cloneGroupId: String? = null,
  val cloneIndex: Int = 0, // 0 = Master, >0 = Alt-Drag Clone sibling
  val bounds: SceneBounds = SceneBounds.Empty,
  val phase: LayerPhase = LayerPhase.HIDDEN,
  val claimedByAgentId: Int? = null,
  val boundsGeneration: Int = 0,
)

data class AgentTaskClaim(
  val agentId: Int,
  val role: AgentRole,
  val nodeId: String,
  val kind: LayerKind,
  val isCloneFromMaster: Boolean,
  val masterNodeId: String?,
  val boundsGeneration: Int,
)

/**
 * Pure-Kotlin deterministic DAG task scheduler for ORVA's About Us Agentic Build experience.
 *
 * Enforced invariants:
 * 1. Parent-before-child ordering (`parentId` MUST be `REVEALED` before any child is eligible).
 * 2. Master-before-clone ordering (`cloneIndex == 0` MUST be `REVEALED` before `cloneIndex > 0` in the same `cloneGroupId`).
 * 3. Bounded concurrency: maximum [maxConcurrentBuilders] (default 8) active builders out of [totalAgents] (default 16).
 * 4. Viewport + prefetch gating so off-screen sections wait until scrolled/toured into range.
 * 5. Atomic claim / commit / release semantics so cancellation restores tasks cleanly without stranding.
 * 6. Responsive layout resize invalidation clears stale geometry and pending claims safely.
 * 7. Deterministic ordering (top-to-bottom + registration `orderIndex`) so Replay reproduces the same choreography.
 */
class AgentTaskScheduler(
  val totalAgents: Int = 16,
  val maxConcurrentBuilders: Int = 8,
  val prefetchMarginPx: Float = 260f,
) {
  private val nodes = LinkedHashMap<String, RegisteredSceneNode>()
  private val activeClaimsByAgent = LinkedHashMap<Int, AgentTaskClaim>()
  private var nextOrderCounter = 0
  private var currentBoundsGeneration = 0
  private var lastViewportWidthPx: Float = -1f
  private var lastViewportHeightPx: Float = -1f
  private var lastDensityScale: Float = -1f
  private var dependencyGraphVersion = 0L
  private var validatedGraphVersion = -1L
  private var cachedGraphIssues: List<String> = emptyList()

  @Synchronized
  fun registerOrUpdateNode(
    id: String,
    kind: LayerKind,
    parentId: String? = null,
    cloneGroupId: String? = null,
    cloneIndex: Int = 0,
    bounds: SceneBounds,
  ) {
    val existing = nodes[id]
    if (existing == null) {
      dependencyGraphVersion++
      nodes[id] =
        RegisteredSceneNode(
          id = id,
          kind = kind,
          orderIndex = nextOrderCounter++,
          parentId = parentId,
          cloneGroupId = cloneGroupId,
          cloneIndex = cloneIndex,
          bounds = bounds,
          phase = LayerPhase.HIDDEN,
          claimedByAgentId = null,
          boundsGeneration = currentBoundsGeneration,
        )
    } else {
      if (existing.parentId != parentId ||
        existing.cloneGroupId != cloneGroupId ||
        existing.cloneIndex != cloneIndex
      ) {
        dependencyGraphVersion++
      }
      val movedSignificantly =
        abs(existing.bounds.left - bounds.left) > 4f ||
          abs(existing.bounds.top - bounds.top) > 4f ||
          abs(existing.bounds.width - bounds.width) > 4f ||
          abs(existing.bounds.height - bounds.height) > 4f
      nodes[id] =
        existing.copy(
          parentId = parentId,
          cloneGroupId = cloneGroupId,
          cloneIndex = cloneIndex,
          bounds = bounds,
          // Node-local version: a significant re-measure invalidates only this node's old claim.
          // A viewport epoch also forces stale nodes to adopt the new global baseline.
          boundsGeneration =
            when {
              existing.boundsGeneration < currentBoundsGeneration -> currentBoundsGeneration
              movedSignificantly -> existing.boundsGeneration + 1
              else -> existing.boundsGeneration
            },
        )
    }
  }

  /**
   * Invalidates geometry when the usable viewport or display density changes. Width alone is not
   * sufficient: height/insets can move the scroll frontier, while density changes every px bound.
   */
  @Synchronized
  fun onViewportGeometryChanged(
    newWidthPx: Float,
    newHeightPx: Float,
    newDensityScale: Float,
  ): Boolean {
    if (newWidthPx <= 0f || newHeightPx <= 0f || newDensityScale <= 0f) return false

    val widthChanged = lastViewportWidthPx > 0f && abs(newWidthPx - lastViewportWidthPx) >= 8f
    val heightChanged = lastViewportHeightPx > 0f && abs(newHeightPx - lastViewportHeightPx) >= 8f
    val densityChanged = lastDensityScale > 0f && abs(newDensityScale - lastDensityScale) >= 0.01f
    val hasBaseline = lastViewportWidthPx > 0f && lastViewportHeightPx > 0f && lastDensityScale > 0f

    lastViewportWidthPx = newWidthPx
    lastViewportHeightPx = newHeightPx
    lastDensityScale = newDensityScale
    if (hasBaseline && !widthChanged && !heightChanged && !densityChanged) return false

    currentBoundsGeneration++
    // Release in-flight work. Existing bounds remain available until Compose publishes its next
    // LayoutCoordinates; each re-registration advances that node into the new geometry epoch.
    val claimList = activeClaimsByAgent.values.toList()
    for (claim in claimList) releaseClaim(claim.agentId, claim.nodeId)
    return hasBaseline
  }

  /** Compatibility helper retained for the standalone scheduler tests and older callers. */
  @Synchronized
  fun onViewportWidthChanged(newWidthPx: Float): Boolean {
    val h = if (lastViewportHeightPx > 0f) lastViewportHeightPx else 1f
    val d = if (lastDensityScale > 0f) lastDensityScale else 1f
    return onViewportGeometryChanged(newWidthPx, h, d)
  }

  @Synchronized
  fun resetForReplay() {
    activeClaimsByAgent.clear()
    currentBoundsGeneration++
    val updated = LinkedHashMap<String, RegisteredSceneNode>(nodes.size)
    for ((id, node) in nodes) {
      updated[id] =
        node.copy(
          phase = LayerPhase.HIDDEN,
          claimedByAgentId = null,
          boundsGeneration = currentBoundsGeneration,
        )
    }
    nodes.clear()
    nodes.putAll(updated)
  }

  @Synchronized
  fun markAllRevealed() {
    activeClaimsByAgent.clear()
    val updated = LinkedHashMap<String, RegisteredSceneNode>(nodes.size)
    for ((id, node) in nodes) {
      updated[id] = node.copy(phase = LayerPhase.REVEALED, claimedByAgentId = null)
    }
    nodes.clear()
    nodes.putAll(updated)
  }

  @Synchronized
  fun getNode(id: String): RegisteredSceneNode? = nodes[id]

  @Synchronized
  fun allNodesSnapshot(): List<RegisteredSceneNode> = nodes.values.toList()

  @Synchronized
  fun totalCount(): Int = nodes.size

  /**
   * Validates the registered construction graph. Missing dependencies and cycles are reported
   * explicitly instead of leaving a scene that can never finish. Results are cached until a node
   * is added or one of its dependency relationships changes.
   */
  @Synchronized
  fun validateSceneGraph(): List<String> {
    if (validatedGraphVersion == dependencyGraphVersion) return cachedGraphIssues

    val issues = linkedSetOf<String>()
    val mastersByGroup = nodes.values
      .filter { it.cloneGroupId != null && it.cloneIndex == 0 }
      .groupBy { it.cloneGroupId!! }

    for (node in nodes.values) {
      node.parentId?.let { parentId ->
        if (parentId == node.id) {
          issues += "Node '${node.id}' cannot be its own parent."
        } else if (parentId !in nodes) {
          issues += "Node '${node.id}' references missing parent '$parentId'."
        }
      }
      if (node.cloneGroupId == null && node.cloneIndex != 0) {
        issues += "Node '${node.id}' has cloneIndex ${node.cloneIndex} without a cloneGroupId."
      }
      if (node.cloneIndex < 0) {
        issues += "Node '${node.id}' has a negative cloneIndex."
      }
      node.cloneGroupId?.let { group ->
        if (node.cloneIndex > 0 && mastersByGroup[group].isNullOrEmpty()) {
          issues += "Clone '${node.id}' has no master in group '$group'."
        }
      }
    }
    mastersByGroup.filterValues { it.size > 1 }.forEach { (group, masters) ->
      issues += "Clone group '$group' has multiple masters: ${masters.joinToString { it.id }}."
    }

    // Directed edges point from a task to the prerequisite that must finish before it.
    // A grey/black DFS detects cycles across both parent and clone-master relationships.
    val visitState = HashMap<String, Int>()
    val stack = ArrayList<String>()
    fun visit(nodeId: String) {
      when (visitState[nodeId]) {
        1 -> {
          val start = stack.indexOf(nodeId).coerceAtLeast(0)
          issues += "Dependency cycle: ${(stack.subList(start, stack.size) + nodeId).joinToString(" -> ")}."
          return
        }
        2 -> return
      }
      visitState[nodeId] = 1
      stack += nodeId
      val node = nodes[nodeId]
      if (node != null) {
        node.parentId?.takeIf { it in nodes }?.let(::visit)
        val group = node.cloneGroupId
        if (group != null && node.cloneIndex > 0) {
          mastersByGroup[group]?.singleOrNull()?.id?.let(::visit)
        }
      }
      stack.removeAt(stack.lastIndex)
      visitState[nodeId] = 2
    }
    nodes.keys.forEach(::visit)

    cachedGraphIssues = issues.toList()
    validatedGraphVersion = dependencyGraphVersion
    return cachedGraphIssues
  }

  @Synchronized
  fun completedCount(): Int = nodes.values.count { it.phase == LayerPhase.REVEALED }

  @Synchronized
  fun activeBuilderCount(): Int = activeClaimsByAgent.size

  @Synchronized
  fun isAllCompleted(): Boolean = nodes.isNotEmpty() && completedCount() == nodes.size

  /**
   * Atomically claims the next eligible task for [agentId] with [role] inside the current
   * visible viewport `[viewportTopPx, viewportBottomPx]` (expanded by [prefetchMarginPx]).
   */
  @Synchronized
  fun tryClaimNextTask(
    agentId: Int,
    role: AgentRole,
    viewportTopPx: Float,
    viewportBottomPx: Float,
    ignoreViewportGate: Boolean = false,
  ): AgentTaskClaim? {
    if (role == AgentRole.IDLE_SCOUT) return null
    if (validateSceneGraph().isNotEmpty()) return null
    if (activeClaimsByAgent.containsKey(agentId)) return null
    if (activeClaimsByAgent.size >= maxConcurrentBuilders) return null

    val windowTop = viewportTopPx - prefetchMarginPx
    val windowBottom = viewportBottomPx + prefetchMarginPx

    val allReady =
      nodes.values
        .asSequence()
        .filter { node ->
          node.phase == LayerPhase.HIDDEN &&
            node.claimedByAgentId == null &&
            node.bounds.isValid &&
            node.boundsGeneration >= currentBoundsGeneration &&
            (ignoreViewportGate || node.bounds.intersectsVerticalWindow(windowTop, windowBottom)) &&
            isParentSatisfied(node) &&
            isCloneMasterSatisfied(node)
        }
        .sortedWith(
          compareBy<RegisteredSceneNode>(
            { if (isRoleCompatible(role, it)) 0 else 1 },
            { it.kind.priorityRank() },
            { it.bounds.top },
            { it.orderIndex },
          )
        )
        .toList()

    val chosen = allReady.firstOrNull() ?: return null
    val cloneGroup = chosen.cloneGroupId
    val isClone = cloneGroup != null && chosen.cloneIndex > 0
    val masterId = if (isClone) findMasterNodeId(requireNotNull(cloneGroup)) else null

    nodes[chosen.id] =
      chosen.copy(
        phase = LayerPhase.BUILDING,
        claimedByAgentId = agentId,
      )

    val claim =
      AgentTaskClaim(
        agentId = agentId,
        role = role,
        nodeId = chosen.id,
        kind = chosen.kind,
        isCloneFromMaster = isClone,
        masterNodeId = masterId,
        boundsGeneration = chosen.boundsGeneration,
      )
    activeClaimsByAgent[agentId] = claim
    return claim
  }

  @Synchronized
  fun markCloneMasterTextVisible(nodeId: String) {
    val existing = nodes[nodeId] ?: return
    if (existing.phase == LayerPhase.BUILDING) {
      nodes[nodeId] = existing.copy(phase = LayerPhase.CLONED_MASTER_TEXT)
    }
  }

  /** Atomically completes a claimed task and releases the agent's active slot. */
  @Synchronized
  fun completeTask(agentId: Int, nodeId: String): Boolean {
    val claim = activeClaimsByAgent[agentId]
    if (claim == null || claim.nodeId != nodeId) return false
    activeClaimsByAgent.remove(agentId)
    val node = nodes[nodeId] ?: return false
    // A task measured against an old layout must never reveal content at stale coordinates.
    if (claim.boundsGeneration != node.boundsGeneration) {
      if (node.claimedByAgentId == agentId) {
        nodes[nodeId] = node.copy(phase = LayerPhase.HIDDEN, claimedByAgentId = null)
      }
      return false
    }
    nodes[nodeId] = node.copy(phase = LayerPhase.REVEALED, claimedByAgentId = null)
    return true
  }

  /**
   * Restores a claimed node back to `HIDDEN` so another builder can pick it up.
   * Always called inside `finally` if an agent coroutine is cancelled mid-task.
   */
  @Synchronized
  fun releaseClaim(agentId: Int, nodeId: String) {
    val claim = activeClaimsByAgent[agentId]
    if (claim != null && claim.nodeId == nodeId) {
      activeClaimsByAgent.remove(agentId)
    }
    val node = nodes[nodeId] ?: return
    if (node.claimedByAgentId == agentId && node.phase != LayerPhase.REVEALED) {
      nodes[nodeId] = node.copy(phase = LayerPhase.HIDDEN, claimedByAgentId = null)
    }
  }

  /** Returns the lowest `top` coordinate of the next unbuilt node below the viewport for guided Touring. */
  @Synchronized
  fun nextUnbuiltTargetTopY(afterY: Float): Float? {
    if (validateSceneGraph().isNotEmpty()) return null
    return nodes.values
      .asSequence()
      .filter {
        it.phase == LayerPhase.HIDDEN &&
          it.claimedByAgentId == null &&
          it.bounds.isValid &&
          it.boundsGeneration >= currentBoundsGeneration &&
          it.bounds.top >= afterY &&
          isParentSatisfied(it) &&
          isCloneMasterSatisfied(it)
      }
      .minByOrNull { it.bounds.top }
      ?.bounds
      ?.top
  }

  @Synchronized
  fun hasEligibleWorkInViewport(viewportTopPx: Float, viewportBottomPx: Float): Boolean {
    if (validateSceneGraph().isNotEmpty()) return false
    val windowTop = viewportTopPx - prefetchMarginPx
    val windowBottom = viewportBottomPx + prefetchMarginPx
    return nodes.values.any { node ->
      node.phase == LayerPhase.HIDDEN &&
        node.claimedByAgentId == null &&
        node.bounds.isValid &&
        node.boundsGeneration >= currentBoundsGeneration &&
        node.bounds.intersectsVerticalWindow(windowTop, windowBottom) &&
        isParentSatisfied(node) &&
        isCloneMasterSatisfied(node)
    }
  }

  private fun isParentSatisfied(node: RegisteredSceneNode): Boolean {
    val pid = node.parentId ?: return true
    // A missing parent is a broken scene graph, not permission to skip the dependency.
    val parent = nodes[pid] ?: return false
    return parent.phase == LayerPhase.REVEALED
  }

  private fun isCloneMasterSatisfied(node: RegisteredSceneNode): Boolean {
    val group = node.cloneGroupId ?: return true
    if (node.cloneIndex == 0) return true
    // A clone without a registered master remains locked rather than being silently built alone.
    val master =
      nodes.values.firstOrNull { it.cloneGroupId == group && it.cloneIndex == 0 } ?: return false
    return master.phase == LayerPhase.REVEALED
  }

  private fun findMasterNodeId(groupId: String): String? =
    nodes.values.firstOrNull { it.cloneGroupId == groupId && it.cloneIndex == 0 }?.id

  private fun isRoleCompatible(role: AgentRole, node: RegisteredSceneNode): Boolean {
    val isClone = node.cloneGroupId != null && node.cloneIndex > 0
    return when (role) {
      AgentRole.LAYOUT_ARCHITECT ->
        !isClone && (node.kind == LayerKind.CONTAINER || node.kind == LayerKind.LINE)
      AgentRole.COMPONENT_DUPLICATOR ->
        isClone || node.kind == LayerKind.CONTAINER
      AgentRole.TYPOGRAPHER ->
        node.kind == LayerKind.TEXT
      AgentRole.ART_DIRECTOR ->
        node.kind == LayerKind.MEDIA || node.kind == LayerKind.LINE
      AgentRole.IDLE_SCOUT -> false
    }
  }

  private fun LayerKind.priorityRank(): Int =
    when (this) {
      LayerKind.CONTAINER -> 0
      LayerKind.LINE -> 1
      LayerKind.MEDIA -> 2
      LayerKind.TEXT -> 3
    }
}
