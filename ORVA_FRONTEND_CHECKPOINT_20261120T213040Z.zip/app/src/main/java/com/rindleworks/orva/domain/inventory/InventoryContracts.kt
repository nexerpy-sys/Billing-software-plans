package com.rindleworks.orva.domain.inventory

import java.io.InputStream
import java.io.OutputStream
import kotlinx.coroutines.flow.Flow

enum class BatchStatus(val dbValue: String) {
  Active("ACTIVE"),
  Quarantined("QUARANTINED"),
  Expired("EXPIRED"),
  Blocked("BLOCKED");

  companion object {
    fun fromDbValue(raw: String?): BatchStatus? =
      entries.firstOrNull { it.dbValue.equals(raw?.trim(), ignoreCase = true) }
  }
}

enum class PurchaseDocumentType(val dbValue: String) {
  TaxInvoice("TAX_INVOICE"),
  CashCreditMemo("CASH_CREDIT_MEMO"),
  NoDocument("NO_DOCUMENT"),
  Other("OTHER");

  companion object {
    fun fromDbValue(raw: String?): PurchaseDocumentType? =
      entries.firstOrNull { it.dbValue.equals(raw?.trim(), ignoreCase = true) }
  }
}

enum class ExpiryAlertLevel(val wireValue: Int, val label: String, val colourHex: String) {
  None(0, "Available", "#16845B"),
  EarlyWarning90Days(1, "Expiring (<=90d)", "#1E3FA6"),
  Warning60Days(2, "Expiring (<=60d)", "#FF7A57"),
  UrgentWarning30Days(3, "Expiring (<=30d)", "#FF4B1F"),
  Expired(4, "Expired", "#C9362B"),
}

enum class InventoryFilterMode(val dbValue: String) {
  All("ALL"),
  LowStock("LOW_STOCK"),
  Expiring("EXPIRING"),
  Expired("EXPIRED");

  companion object {
    fun fromDbValue(raw: String?): InventoryFilterMode =
      entries.firstOrNull { it.dbValue.equals(raw?.trim(), ignoreCase = true) } ?: All
  }
}

data class InventoryRow(
  val medicineId: String,
  val batchId: String,
  val medicineName: String,
  val batchNumber: String,
  val expiryText: String,
  val expiryYearMonth: Int,
  val quantityText: String,
  val quantityMilli: Long,
  val unit: String,
  val mrpPaise: Long,
  val mrpText: String,
  val statusLabel: String,
  val statusColourHex: String,
  val batchStatus: BatchStatus,
  val expiryLevel: ExpiryAlertLevel,
  val isLowStock: Boolean,
  val lowStockThresholdMilli: Long,
  val usableMedicineTotalMilli: Long,
)

data class LowStockAlertItem(
  val medicineId: String,
  val medicineName: String,
  val stockUnitName: String,
  val usableQuantityMilli: Long,
  val thresholdMilli: Long,
)

data class ExpiryAlertItem(
  val medicineId: String,
  val batchId: String,
  val medicineName: String,
  val batchNumber: String,
  val expiryYearMonth: Int,
  val expiryDateIso: String,
  val daysRemaining: Int,
  val quantityMilli: Long,
  val stockUnitName: String,
  val alertLevel: ExpiryAlertLevel,
  val alertLabel: String,
)

data class StockEntryInput(
  val medicineName: String,
  val stockUnitName: String,
  val batchNumber: String,
  val expiryYearMonth: Int,
  val quantityMilli: Long,
  val purchasePricePaise: Long,
  val mrpPaise: Long,
  val supplierName: String? = null,
  val supplierLicence: String? = null,
  val documentType: PurchaseDocumentType = PurchaseDocumentType.TaxInvoice,
  val documentReference: String? = null,
)

data class StockEntryResult(
  val succeeded: Boolean,
  val medicineName: String = "",
  val batchNumber: String = "",
  val newQuantityMilli: Long = 0L,
  val snapshotUpdated: Boolean = false,
  val snapshotWarning: String? = null,
  val errorMessage: String? = null,
)

data class MedicineDetailsInput(
  val medicineId: String,
  val displayName: String,
  val genericName: String?,
  val brandName: String?,
  val strength: String?,
  val dosageForm: String?,
  val stockUnitName: String,
  val lowStockThresholdMilli: Long,
  val isActive: Boolean,
)

data class StockAdjustmentInput(
  val batchId: String,
  val countedQuantityMilli: Long,
  val reason: String,
)

data class StockAdjustmentResult(
  val succeeded: Boolean,
  val medicineName: String = "",
  val batchNumber: String = "",
  val previousQuantityMilli: Long = 0L,
  val newQuantityMilli: Long = 0L,
  val differenceMilli: Long = 0L,
  val snapshotUpdated: Boolean = false,
  val snapshotWarning: String? = null,
  val errorMessage: String? = null,
)

data class StockImportPreview(
  val isValid: Boolean,
  val sourceName: String,
  val formatVersion: Int = 0,
  val sourceShopId: String? = null,
  val sourceShopName: String? = null,
  val targetShopId: String? = null,
  val targetShopName: String? = null,
  val isDifferentShop: Boolean = false,
  val generatedAtUtc: String? = null,
  val medicineCount: Int = 0,
  val batchCount: Int = 0,
  val totalImportedQuantityMilli: Long = 0L,
  val newMedicineCount: Int = 0,
  val matchedMedicineCount: Int = 0,
  val softInactivatedMedicineCount: Int = 0,
  val newBatchCount: Int = 0,
  val changedBatchCount: Int = 0,
  val zeroedBatchCount: Int = 0,
  val errors: List<String> = emptyList(),
  val warnings: List<String> = emptyList(),
)

data class StockImportResult(
  val succeeded: Boolean,
  val medicinesImported: Int = 0,
  val batchesImported: Int = 0,
  val stockMovementsRecorded: Int = 0,
  val batchesZeroed: Int = 0,
  val snapshotUpdated: Boolean = false,
  val snapshotWarning: String? = null,
  val safetyBackupPath: String? = null,
  val errorMessage: String? = null,
)

data class CatalogueImportPreview(
  val isValid: Boolean,
  val sourceName: String,
  val newMedicineCount: Int = 0,
  val existingMedicineCount: Int = 0,
  val openingBatchRowCount: Int = 0,
  val errors: List<String> = emptyList(),
  val warnings: List<String> = emptyList(),
)

data class CatalogueImportResult(
  val succeeded: Boolean,
  val medicinesCreated: Int = 0,
  val medicinesUpdated: Int = 0,
  val batchesUpdatedOrCreated: Int = 0,
  val snapshotRefreshed: Boolean = false,
  val snapshotWarning: String? = null,
  val errorMessage: String? = null,
)

interface InventoryRepository {
  fun observeInventoryRows(
    searchText: String,
    filterMode: InventoryFilterMode,
  ): Flow<List<InventoryRow>>

  fun observeLowStockAlerts(): Flow<List<LowStockAlertItem>>
  fun observeExpiryAlerts(): Flow<List<ExpiryAlertItem>>
  suspend fun getMedicineDetails(medicineId: String): MedicineDetailsInput?
  suspend fun updateMedicineDetails(input: MedicineDetailsInput): Result<Unit>
  suspend fun updateBatchStatus(batchId: String, newStatus: BatchStatus, reason: String): Result<Unit>
  suspend fun getStockUnitForMedicine(medicineName: String): String?
  suspend fun getCounts(): Pair<Int, Int> // (medicineCount, batchCount)
}

interface StockEntryService {
  suspend fun receiveStock(input: StockEntryInput): StockEntryResult
}

interface StockAdjustmentService {
  suspend fun adjustBatchQuantity(input: StockAdjustmentInput): StockAdjustmentResult
}

interface StockSnapshotService {
  suspend fun refreshSnapshot(): Result<Boolean> // true = clean, false = newer mutation queued
  suspend fun exportSnapshotTo(output: OutputStream): Result<Unit>
  suspend fun previewStockDataImport(input: InputStream, sourceName: String): StockImportPreview
  suspend fun executeStockDataImport(
    input: InputStream,
    sourceName: String,
    confirmDifferentShop: Boolean,
  ): StockImportResult
}

interface MedicineCatalogueImportService {
  suspend fun writeTemplateCsv(output: OutputStream)
  suspend fun previewCatalogueImport(input: InputStream, fileName: String): CatalogueImportPreview
  suspend fun executeCatalogueImport(
    input: InputStream,
    fileName: String,
    markProvidedGstRatesAsConfigured: Boolean,
  ): CatalogueImportResult
}
