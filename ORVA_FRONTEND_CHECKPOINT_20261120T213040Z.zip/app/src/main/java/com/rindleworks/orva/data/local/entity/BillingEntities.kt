package com.rindleworks.orva.data.local.entity

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName = "invoice_sequence")
data class InvoiceSequenceEntity(
  @PrimaryKey @ColumnInfo(name = "financial_year") val financialYear: String,
  @ColumnInfo(name = "last_number", defaultValue = "0") val lastNumber: Long = 0L,
)

@Entity(
  tableName = "invoice",
  indices =
    [
      Index(name = "ix_invoice_date", value = ["issued_at_utc"]),
      Index(name = "ix_invoice_financial_year", value = ["financial_year", "invoice_number"]),
    ],
)
data class InvoiceEntity(
  @PrimaryKey @ColumnInfo(name = "invoice_id") val invoiceId: String,
  @ColumnInfo(name = "invoice_number") val invoiceNumber: String,
  @ColumnInfo(name = "financial_year") val financialYear: String,
  @ColumnInfo(name = "issued_at_utc") val issuedAtUtc: String,
  @ColumnInfo(name = "issued_local_offset_minutes") val issuedLocalOffsetMinutes: Int,
  @ColumnInfo(name = "customer_name") val customerName: String? = null,
  @ColumnInfo(name = "customer_phone") val customerPhone: String? = null,
  @ColumnInfo(name = "customer_address") val customerAddress: String? = null,
  @ColumnInfo(name = "customer_gstin") val customerGstin: String? = null,
  @ColumnInfo(name = "place_of_supply_state_code") val placeOfSupplyStateCode: String? = null,
  @ColumnInfo(name = "subtotal_paise") val subtotalPaise: Long,
  @ColumnInfo(name = "discount_paise", defaultValue = "0") val discountPaise: Long = 0L,
  @ColumnInfo(name = "taxable_value_paise") val taxableValuePaise: Long,
  @ColumnInfo(name = "cgst_paise", defaultValue = "0") val cgstPaise: Long = 0L,
  @ColumnInfo(name = "sgst_paise", defaultValue = "0") val sgstPaise: Long = 0L,
  @ColumnInfo(name = "igst_paise", defaultValue = "0") val igstPaise: Long = 0L,
  @ColumnInfo(name = "round_off_paise", defaultValue = "0") val roundOffPaise: Long = 0L,
  @ColumnInfo(name = "grand_total_paise") val grandTotalPaise: Long,
  @ColumnInfo(name = "status", defaultValue = "'ISSUED'") val status: String = "ISSUED",
  @ColumnInfo(name = "cancellation_reason") val cancellationReason: String? = null,
  @ColumnInfo(name = "created_at_utc") val createdAtUtc: String,
)

@Entity(
  tableName = "invoice_line",
  foreignKeys =
    [
      ForeignKey(
        entity = InvoiceEntity::class,
        parentColumns = ["invoice_id"],
        childColumns = ["invoice_id"],
      ),
      ForeignKey(
        entity = MedicineEntity::class,
        parentColumns = ["medicine_id"],
        childColumns = ["medicine_id"],
      ),
      ForeignKey(
        entity = StockBatchEntity::class,
        parentColumns = ["batch_id"],
        childColumns = ["batch_id"],
      ),
    ],
  indices = [Index(name = "ix_invoice_line_invoice", value = ["invoice_id"])],
)
data class InvoiceLineEntity(
  @PrimaryKey @ColumnInfo(name = "invoice_line_id") val invoiceLineId: String,
  @ColumnInfo(name = "invoice_id") val invoiceId: String,
  @ColumnInfo(name = "line_group_id") val lineGroupId: String,
  @ColumnInfo(name = "medicine_id") val medicineId: String,
  @ColumnInfo(name = "batch_id") val batchId: String,
  @ColumnInfo(name = "medicine_name_snapshot") val medicineNameSnapshot: String,
  @ColumnInfo(name = "batch_number_snapshot") val batchNumberSnapshot: String,
  @ColumnInfo(name = "expiry_yyyymm_snapshot") val expiryYyyyMmSnapshot: Int,
  @ColumnInfo(name = "quantity_milli") val quantityMilli: Long,
  @ColumnInfo(name = "unit_name_snapshot") val unitNameSnapshot: String,
  @ColumnInfo(name = "unit_price_paise") val unitPricePaise: Long,
  @ColumnInfo(name = "discount_paise", defaultValue = "0") val discountPaise: Long = 0L,
  @ColumnInfo(name = "taxable_value_paise") val taxableValuePaise: Long,
  @ColumnInfo(name = "gst_rate_basis_points", defaultValue = "0") val gstRateBasisPoints: Int = 0,
  @ColumnInfo(name = "hsn_code_snapshot") val hsnCodeSnapshot: String? = null,
  @ColumnInfo(name = "cgst_paise", defaultValue = "0") val cgstPaise: Long = 0L,
  @ColumnInfo(name = "sgst_paise", defaultValue = "0") val sgstPaise: Long = 0L,
  @ColumnInfo(name = "igst_paise", defaultValue = "0") val igstPaise: Long = 0L,
  @ColumnInfo(name = "line_total_paise") val lineTotalPaise: Long,
  @ColumnInfo(name = "created_at_utc") val createdAtUtc: String,
)

@Entity(
  tableName = "payment",
  foreignKeys =
    [
      ForeignKey(
        entity = InvoiceEntity::class,
        parentColumns = ["invoice_id"],
        childColumns = ["invoice_id"],
      )
    ],
  indices = [Index(name = "ix_payment_invoice", value = ["invoice_id"])],
)
data class PaymentEntity(
  @PrimaryKey @ColumnInfo(name = "payment_id") val paymentId: String,
  @ColumnInfo(name = "invoice_id") val invoiceId: String,
  @ColumnInfo(name = "method") val method: String,
  @ColumnInfo(name = "amount_paise") val amountPaise: Long,
  @ColumnInfo(name = "reference_text") val referenceText: String? = null,
  @ColumnInfo(name = "paid_at_utc") val paidAtUtc: String,
)

@Entity(
  tableName = "sales_return",
  foreignKeys =
    [
      ForeignKey(
        entity = InvoiceEntity::class,
        parentColumns = ["invoice_id"],
        childColumns = ["invoice_id"],
      )
    ],
  indices =
    [
      Index(name = "ix_return_date", value = ["returned_at_utc"]),
      Index(name = "ix_sales_return_invoice", value = ["invoice_id"]),
    ],
)
data class SalesReturnEntity(
  @PrimaryKey @ColumnInfo(name = "return_id") val returnId: String,
  @ColumnInfo(name = "return_number") val returnNumber: String,
  @ColumnInfo(name = "invoice_id") val invoiceId: String,
  @ColumnInfo(name = "returned_at_utc") val returnedAtUtc: String,
  @ColumnInfo(name = "reason") val reason: String,
  @ColumnInfo(name = "refund_method") val refundMethod: String? = null,
  @ColumnInfo(name = "refund_amount_paise", defaultValue = "0") val refundAmountPaise: Long = 0L,
  @ColumnInfo(name = "status", defaultValue = "'COMPLETED'") val status: String = "COMPLETED",
  @ColumnInfo(name = "created_at_utc") val createdAtUtc: String,
)

@Entity(
  tableName = "sales_return_line",
  foreignKeys =
    [
      ForeignKey(
        entity = SalesReturnEntity::class,
        parentColumns = ["return_id"],
        childColumns = ["return_id"],
      ),
      ForeignKey(
        entity = InvoiceLineEntity::class,
        parentColumns = ["invoice_line_id"],
        childColumns = ["invoice_line_id"],
      ),
      ForeignKey(
        entity = StockBatchEntity::class,
        parentColumns = ["batch_id"],
        childColumns = ["batch_id"],
      ),
    ],
  indices =
    [
      Index(name = "ix_sales_return_line_return", value = ["return_id"]),
      Index(name = "ix_sales_return_line_invoice_line", value = ["invoice_line_id"]),
    ],
)
data class SalesReturnLineEntity(
  @PrimaryKey @ColumnInfo(name = "return_line_id") val returnLineId: String,
  @ColumnInfo(name = "return_id") val returnId: String,
  @ColumnInfo(name = "invoice_line_id") val invoiceLineId: String,
  @ColumnInfo(name = "batch_id") val batchId: String,
  @ColumnInfo(name = "quantity_milli") val quantityMilli: Long,
  @ColumnInfo(name = "resale_disposition") val resaleDisposition: String,
  @ColumnInfo(name = "line_refund_paise", defaultValue = "0") val lineRefundPaise: Long = 0L,
)
