package com.rindleworks.orva.ui.navigation

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathFillType
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.path
import androidx.compose.ui.unit.dp

/**
 * Architectural thin-stroke (`1.65f` on 24×24 grid) vector icon set styled after 21st.dev / Lucide
 * studio navigation primitives. Keeps ORVA's hamburger drawer crisp, geometric, and cohesive in
 * both Obsidian Dark and Warm Chalk Paper modes.
 */
object OrvaNavIcons {
  private val stroke = SolidColor(Color.White)
  private const val STROKE_W = 1.65f

  /** Asymmetric studio 3-bar hamburger menu icon (21st.dev aesthetic). */
  val MenuHamburger: ImageVector by lazy {
    icon("orva_menu_hamburger") {
      path(stroke = stroke, strokeLineWidth = STROKE_W, strokeLineCap = StrokeCap.Round) {
        moveTo(3.5f, 6.5f)
        lineTo(20.5f, 6.5f)
        moveTo(3.5f, 12f)
        lineTo(15.5f, 12f)
        moveTo(3.5f, 17.5f)
        lineTo(20.5f, 17.5f)
      }
    }
  }

  /** Crisp geometric close cross (`X`). */
  val Close: ImageVector by lazy {
    icon("orva_close") {
      path(stroke = stroke, strokeLineWidth = STROKE_W, strokeLineCap = StrokeCap.Round) {
        moveTo(6f, 6f)
        lineTo(18f, 18f)
        moveTo(18f, 6f)
        lineTo(6f, 18f)
      }
    }
  }

  /** Architectural Home / Counter Overview icon. */
  val Home: ImageVector by lazy {
    icon("orva_home") {
      path(
        stroke = stroke,
        strokeLineWidth = STROKE_W,
        strokeLineCap = StrokeCap.Round,
        strokeLineJoin = StrokeJoin.Round,
      ) {
        moveTo(3.5f, 10.5f)
        lineTo(12f, 3.5f)
        lineTo(20.5f, 10.5f)
        moveTo(5.5f, 9.5f)
        lineTo(5.5f, 19.5f)
        arcTo(1f, 1f, 0f, false, false, 6.5f, 20.5f)
        lineTo(17.5f, 20.5f)
        arcTo(1f, 1f, 0f, false, false, 18.5f, 19.5f)
        lineTo(18.5f, 9.5f)
        moveTo(9.5f, 20.5f)
        lineTo(9.5f, 14.5f)
        lineTo(14.5f, 14.5f)
        lineTo(14.5f, 20.5f)
      }
    }
  }

  /** New Billing — thermal receipt slip with precision plus glyph. */
  val NewBilling: ImageVector by lazy {
    icon("orva_new_billing") {
      path(
        stroke = stroke,
        strokeLineWidth = STROKE_W,
        strokeLineCap = StrokeCap.Round,
        strokeLineJoin = StrokeJoin.Round,
      ) {
        moveTo(5f, 3.5f)
        lineTo(19f, 3.5f)
        lineTo(19f, 20.5f)
        lineTo(16f, 18.5f)
        lineTo(13.5f, 20.5f)
        lineTo(10.5f, 18.5f)
        lineTo(8f, 20.5f)
        lineTo(5f, 18.5f)
        close()
        moveTo(12f, 8f)
        lineTo(12f, 14f)
        moveTo(9f, 11f)
        lineTo(15f, 11f)
      }
    }
  }

  /** Stock Entry — isometric package crate with inbound arrow. */
  val StockEntry: ImageVector by lazy {
    icon("orva_stock_entry") {
      path(
        stroke = stroke,
        strokeLineWidth = STROKE_W,
        strokeLineCap = StrokeCap.Round,
        strokeLineJoin = StrokeJoin.Round,
      ) {
        moveTo(12f, 3f)
        lineTo(20f, 7.5f)
        lineTo(20f, 16.5f)
        lineTo(12f, 21f)
        lineTo(4f, 16.5f)
        lineTo(4f, 7.5f)
        close()
        moveTo(4f, 7.5f)
        lineTo(12f, 12f)
        lineTo(20f, 7.5f)
        moveTo(12f, 12f)
        lineTo(12f, 21f)
        moveTo(8f, 5.25f)
        lineTo(16f, 9.75f)
      }
    }
  }

  /** Inventory & Expiry — stacked batch layers. */
  val Inventory: ImageVector by lazy {
    icon("orva_inventory") {
      path(
        stroke = stroke,
        strokeLineWidth = STROKE_W,
        strokeLineCap = StrokeCap.Round,
        strokeLineJoin = StrokeJoin.Round,
      ) {
        moveTo(12f, 3.5f)
        lineTo(20.5f, 8f)
        lineTo(12f, 12.5f)
        lineTo(3.5f, 8f)
        close()
        moveTo(3.5f, 12.5f)
        lineTo(12f, 17f)
        lineTo(20.5f, 12.5f)
        moveTo(3.5f, 16.5f)
        lineTo(12f, 21f)
        lineTo(20.5f, 16.5f)
      }
    }
  }

  /** Sales Returns & Cancellations — precision curved undo arrow. */
  val Returns: ImageVector by lazy {
    icon("orva_returns") {
      path(
        stroke = stroke,
        strokeLineWidth = STROKE_W,
        strokeLineCap = StrokeCap.Round,
        strokeLineJoin = StrokeJoin.Round,
      ) {
        moveTo(9f, 5f)
        lineTo(4.5f, 9.5f)
        lineTo(9f, 14f)
        moveTo(5f, 9.5f)
        lineTo(14.5f, 9.5f)
        arcTo(5f, 5f, 0f, false, true, 14.5f, 19.5f)
        lineTo(10f, 19.5f)
      }
    }
  }

  /** Invoices & History — architectural ledger document. */
  val Invoices: ImageVector by lazy {
    icon("orva_invoices") {
      path(
        stroke = stroke,
        strokeLineWidth = STROKE_W,
        strokeLineCap = StrokeCap.Round,
        strokeLineJoin = StrokeJoin.Round,
      ) {
        moveTo(6.5f, 3.5f)
        lineTo(14.5f, 3.5f)
        lineTo(18.5f, 7.5f)
        lineTo(18.5f, 20.5f)
        lineTo(6.5f, 20.5f)
        close()
        moveTo(14f, 3.5f)
        lineTo(14f, 8f)
        lineTo(18.5f, 8f)
        moveTo(9.5f, 12f)
        lineTo(15.5f, 12f)
        moveTo(9.5f, 16f)
        lineTo(13.5f, 16f)
      }
    }
  }

  /** Reports & GST Export — minimalist vertical telemetry bars. */
  val Reports: ImageVector by lazy {
    icon("orva_reports") {
      path(
        stroke = stroke,
        strokeLineWidth = STROKE_W,
        strokeLineCap = StrokeCap.Round,
        strokeLineJoin = StrokeJoin.Round,
      ) {
        moveTo(4f, 20f)
        lineTo(20f, 20f)
        moveTo(7f, 20f)
        lineTo(7f, 13f)
        moveTo(12f, 20f)
        lineTo(12f, 7f)
        moveTo(17f, 20f)
        lineTo(17f, 10.5f)
      }
    }
  }

  /** Backup & Restore — local-first vault shield. */
  val BackupVault: ImageVector by lazy {
    icon("orva_backup_vault") {
      path(
        stroke = stroke,
        strokeLineWidth = STROKE_W,
        strokeLineCap = StrokeCap.Round,
        strokeLineJoin = StrokeJoin.Round,
      ) {
        moveTo(12f, 3f)
        lineTo(19.5f, 6f)
        lineTo(19.5f, 12f)
        curveTo(19.5f, 16.5f, 16.2f, 19.6f, 12f, 21f)
        curveTo(7.8f, 19.6f, 4.5f, 16.5f, 4.5f, 12f)
        lineTo(4.5f, 6f)
        close()
        moveTo(9.2f, 12.2f)
        lineTo(11.1f, 14.1f)
        lineTo(15.2f, 9.8f)
      }
    }
  }

  /** Settings & License — precision studio horizontal sliders (21st.dev style). */
  val SettingsSliders: ImageVector by lazy {
    icon("orva_settings_sliders") {
      path(
        stroke = stroke,
        strokeLineWidth = STROKE_W,
        strokeLineCap = StrokeCap.Round,
        strokeLineJoin = StrokeJoin.Round,
      ) {
        moveTo(4f, 7f)
        lineTo(10f, 7f)
        moveTo(14f, 7f)
        lineTo(20f, 7f)
        moveTo(4f, 12f)
        lineTo(14f, 12f)
        moveTo(18f, 12f)
        lineTo(20f, 12f)
        moveTo(4f, 17f)
        lineTo(8f, 17f)
        moveTo(12f, 17f)
        lineTo(20f, 17f)
        // Slider knobs
        moveTo(12f, 5.2f)
        arcTo(1.8f, 1.8f, 0f, true, false, 12f, 8.8f)
        arcTo(1.8f, 1.8f, 0f, true, false, 12f, 5.2f)
        moveTo(16f, 10.2f)
        arcTo(1.8f, 1.8f, 0f, true, false, 16f, 13.8f)
        arcTo(1.8f, 1.8f, 0f, true, false, 16f, 10.2f)
        moveTo(10f, 15.2f)
        arcTo(1.8f, 1.8f, 0f, true, false, 10f, 18.8f)
        arcTo(1.8f, 1.8f, 0f, true, false, 10f, 15.2f)
      }
    }
  }

  /** About Us / Rindle Works Studio — four-point precision studio star. */
  val AboutStudio: ImageVector by lazy {
    icon("orva_about_studio") {
      path(
        stroke = stroke,
        strokeLineWidth = STROKE_W,
        strokeLineCap = StrokeCap.Round,
        strokeLineJoin = StrokeJoin.Round,
        pathFillType = PathFillType.NonZero,
      ) {
        moveTo(12f, 3f)
        lineTo(14.4f, 9.6f)
        lineTo(21f, 12f)
        lineTo(14.4f, 14.4f)
        lineTo(12f, 21f)
        lineTo(9.6f, 14.4f)
        lineTo(3f, 12f)
        lineTo(9.6f, 9.6f)
        close()
      }
    }
  }

  /** Sun icon for Paper Mode toggle. */
  val SunPaper: ImageVector by lazy {
    icon("orva_sun_paper") {
      path(
        stroke = stroke,
        strokeLineWidth = STROKE_W,
        strokeLineCap = StrokeCap.Round,
      ) {
        moveTo(12f, 8.5f)
        arcTo(3.5f, 3.5f, 0f, true, false, 12f, 15.5f)
        arcTo(3.5f, 3.5f, 0f, true, false, 12f, 8.5f)
        moveTo(12f, 3.2f)
        lineTo(12f, 5.2f)
        moveTo(12f, 18.8f)
        lineTo(12f, 20.8f)
        moveTo(3.2f, 12f)
        lineTo(5.2f, 12f)
        moveTo(18.8f, 12f)
        lineTo(20.8f, 12f)
        moveTo(5.8f, 5.8f)
        lineTo(7.2f, 7.2f)
        moveTo(16.8f, 16.8f)
        lineTo(18.2f, 18.2f)
        moveTo(18.2f, 5.8f)
        lineTo(16.8f, 7.2f)
        moveTo(7.2f, 16.8f)
        lineTo(5.8f, 18.2f)
      }
    }
  }

  /** Crescent moon icon for Dark Obsidian Mode toggle. */
  val MoonObsidian: ImageVector by lazy {
    icon("orva_moon_obsidian") {
      path(
        stroke = stroke,
        strokeLineWidth = STROKE_W,
        strokeLineCap = StrokeCap.Round,
        strokeLineJoin = StrokeJoin.Round,
      ) {
        moveTo(19.5f, 14.2f)
        arcTo(7.5f, 7.5f, 0f, true, true, 9.8f, 4.5f)
        arcTo(6f, 6f, 0f, false, false, 19.5f, 14.2f)
        close()
      }
    }
  }

  /** Subtle right chevron for interactive drawer rows. */
  val ChevronRight: ImageVector by lazy {
    icon("orva_chevron_right") {
      path(
        stroke = stroke,
        strokeLineWidth = STROKE_W,
        strokeLineCap = StrokeCap.Round,
        strokeLineJoin = StrokeJoin.Round,
      ) {
        moveTo(9.5f, 6.5f)
        lineTo(15f, 12f)
        lineTo(9.5f, 17.5f)
      }
    }
  }

  private inline fun icon(name: String, block: ImageVector.Builder.() -> Unit): ImageVector =
    ImageVector.Builder(
      name = name,
      defaultWidth = 24.dp,
      defaultHeight = 24.dp,
      viewportWidth = 24f,
      viewportHeight = 24f,
    ).apply(block).build()
}
