# ORVA Android Frontend — Asset Manifest

All showcase visual assets and fonts are bundled locally inside `app/src/main/res/` so Home and About Us render 100% offline with zero external CDN dependencies.

The About Scene 07 mosaic is labelled **CONCEPTUAL IMAGE STUDIES** and Scene 08 treats its cover as a **CONCEPT / DOMAIN RULES** study. These generated visual studies are atmospheric editorial artwork, not real pharmacy photography, ORVA interface screenshots or evidence of a deployed workspace. Scene 08 overlays verified domain constraints as editorial annotations; the background image itself is illustrative. The intended final photography swap remains pending local acquisition of the verified Pexels candidates below.

## Bundled Drawable Imagery (`app/src/main/res/drawable/`)

| Local Filename | Origin / Source | Creator / License | Date Added | Planned Use in ORVA | Model / Property / Trademark Notes |
|---|---|---|---|---|---|
| `apothecary_frieze_bw.jpg` | Existing ORVA project asset | ORVA / Rindle Works owned asset | Pre-existing | Shared Home & About closing monochrome scroll frieze (`OrvaScrollFrieze.kt`) | None — original project asset |
| `editorial_architecture_light.jpg` | Studio-generated monochrome architectural photography (offline sandbox) | Generated for Rindle Works × ORVA showcase; replaceable with licensed Pexels ([license](https://www.pexels.com/license/)) or Unsplash ([license](https://unsplash.com/license)) photography | 2026-11-20 | Home H1 Hero background (`HomeScreen.kt`) & About Scene 07 Field Notes tile (`SYSTEM / STRUCTURE`) | Text-free, unbranded architectural geometry; zero identifiable people or trademarks |
| `editorial_apothecary_shelves.jpg` | Studio-generated monochrome apothecary glass shelving (offline sandbox) | Generated for Rindle Works × ORVA showcase; replaceable with licensed Pexels/Unsplash photography | 2026-11-20 | Home H2 Lantern reveal surface (`HomeScreen.kt`), About Scene 02 POV media, Scene 05 Batch & FEFO rail card & Scene 07 Field Notes tile (`BATCH / INVENTORY`) | Text-free, unbranded glass bottles; zero third-party pharmacy branding. Atmospheric artwork only; not a real ORVA shop photograph |
| `editorial_thermal_counter.jpg` | Studio-generated monochrome macro counter paper/hardware (offline sandbox) | Generated for Rindle Works × ORVA showcase; replaceable with licensed Pexels/Unsplash photography | 2026-11-20 | Home H3 Cinematic scroll section (`HomeScreen.kt`), About Scene 05 Counter Billing rail card, Scene 07 Field Notes tile (`BILLING / WORKFLOW`) & Scene 08 conceptual domain-rules plate background | Text-free, unbranded hardware detail; zero trademarks. Atmospheric artwork only; not a real ORVA interface screenshot |
| `editorial_studio_workbench.jpg` | Studio-generated monochrome overhead drafting workbench (offline sandbox) | Generated for Rindle Works × ORVA showcase; replaceable with licensed Pexels/Unsplash photography | 2026-11-20 | About Scene 01 Studio Hero (`AboutUsScreen.kt`), Scene 07 Field Notes tile (`SYSTEM / DETAIL`), Home H4 ORVA case-study cover and About Scene 05 Returns & Ledger rail card | Text-free, unbranded studio tools; zero identifiable people or logos. Atmospheric artwork only; not a real ORVA workspace or product screenshot |

## Bundled Local Fonts (`app/src/main/res/font/`)

| Local Filename | Family | License | Planned Use |
|---|---|---|---|
| `space_grotesk.ttf` | Space Grotesk | SIL OFL 1.1 | Display headlines, scene titles, wordmarks |
| `instrument_serif.ttf` | Instrument Serif | SIL OFL 1.1 | Editorial serif accents & closing lines |
| `plus_jakarta_sans.ttf` | Plus Jakarta Sans | SIL OFL 1.1 | Body prose and supporting descriptions |
| `ibm_plex_mono.ttf` | IBM Plex Mono | SIL OFL 1.1 | Scene index metadata, HUD telemetry, technical tags |
| `noto_sans_bengali.ttf` | Noto Sans Bengali | SIL OFL 1.1 | Native Bengali display, body, and mono fallback |


## Verified External Photo Sources — Candidate Bundle Set (21 Nov 2026)

These individual Pexels pages were opened and checked for creator attribution and Pexels' "Free to use" designation. They are selected candidates for Rindle Works' locally bundled portfolio imagery. **They are not yet present in `res/drawable/`**; the current app still references the four existing generated monochrome images until the source files can be placed in the project and optimised. Do not replace local resource references with remote URLs.

| Candidate local filename | Original photo page | Creator | Direct download source | Intended composition | Status |
|---|---|---|---|---|---|
| `pexels_apothecary_shelves.jpg` | https://www.pexels.com/photo/pharmacy-shelves-and-ladder-6074000/ | Eva Bronzini | https://images.pexels.com/photos/6074000/pexels-photo-6074000.jpeg?cs=srgb&dl=pexels-eva-bronzini-6074000.jpg&fm=jpg | Home lantern reveal, About point-of-view scene and field-notes mosaic. Strong dark shelf image; consider monochrome grade and tight crop. | Verified source/licence; binary not bundled |
| `pexels_industrial_corridor.jpg` | https://www.pexels.com/photo/industrial-building-corridor-with-metal-grating-34112019/ | David Nestorov | https://images.pexels.com/photos/34112019/pexels-photo-34112019.jpeg?cs=srgb&dl=pexels-david-nestorov-2153481354-34112019.jpg&fm=jpg | Architectural full-bleed scene / background for Rindle Works hero or scene transition. Tall perspective composition. | Verified source/licence; binary not bundled |
| `pexels_workbench_blueprints.jpg` | https://www.pexels.com/photo/a-laptop-on-a-work-table-5846172/ | Tima Miroshnichenko | https://images.pexels.com/photos/5846172/pexels-photo-5846172.jpeg?cs=srgb&dl=pexels-tima-miroshnichenko-5846172.jpg&fm=jpg | Studio process / engineering field-note image. Crop to remove distracting screen text and colour-grade to the showcase palette. | Verified source/licence; binary not bundled |
| `pexels_pos_thermal_paper.jpg` | https://www.pexels.com/photo/a-pos-terminal-with-thermal-paper-9755391/ | Towfiqu barbhuiya | https://images.pexels.com/photos/9755391/pexels-photo-9755391.jpeg?cs=srgb&dl=pexels-towfiqu-barbhuiya-3440682-9755391.jpg&fm=jpg | ORVA billing/product case-study scene and receipt/transaction detail. Monochrome or restrained grade to remove blue clash. | Verified source/licence; binary not bundled |

Pexels licence: https://www.pexels.com/license/ — Pexels states that photos/videos can be used for free and modified; attribution is not required but is appreciated. It prohibits implying endorsement, redistributing unmodified stock as stock, and using photos as part of a trademark, design mark, trade name, business name or service mark. Keep creator and source attribution in this manifest even though attribution is optional. Avoid implying that any photographed person or brand endorses ORVA.

**Packaging rule:** once files are locally available, resize/crop for their specific layouts, preserve each original creator/source/licence entry, optimise JPEG quality and inspect the resulting crops on 360dp, 390dp and 412dp layouts. Never hotlink these CDN URLs at runtime.
