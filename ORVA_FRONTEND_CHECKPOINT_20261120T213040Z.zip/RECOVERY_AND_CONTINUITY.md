# ORVA Android — Source Recovery & Continuity

## Why this file exists

Chat conversations and Notion notes do not preserve the actual Android source workspace. The ChatGPT execution workspace may be reset between sessions. The persistent ChatGPT File Library is currently the verified cross-chat source recovery point; Dropbox remains the intended shared mirror when its connected upload route accepts the actual archive file.

## Source of truth

- Current frontend working project: this complete Android project folder.
- Verified persistent recovery location: `/ORVA_FRONTEND_CHECKPOINTS/` in the ChatGPT File Library. A timestamped source ZIP has been uploaded and successfully materialized back into a clean directory; the restored ZIP was byte-for-byte identical. This is the active cross-chat recovery mechanism.
- Intended shared handoff location: `/ORVA-WORKSPACE/04-INTEGRATION/ANDROID-FRONTEND/` in Dropbox. The Dropbox folder currently contains only the old placeholder; no Dropbox source snapshot has been written yet because the connected Dropbox upload action requires a file-parameter object and does not accept the local sandbox path or Library file ID directly. Do not claim a Dropbox upload until verified.
- Notion page: `https://app.notion.com/p/41dbaca0691681a7837cf353c026ac76` — decisions, architecture, change logs and handoff context only. Not a substitute for source files.
- No GitHub remote is required or used. A local Git history is retained inside checkpoint archives for file-level recovery and change comparison.

## Checkpoint policy

1. At the beginning of a new ChatGPT session, list the persistent ChatGPT File Library folder `/ORVA_FRONTEND_CHECKPOINTS/`, materialize the newest `ORVA_FRONTEND_CHECKPOINT_*.zip`, verify it, and restore it into `/mnt/data/orva_frontend_work/`. Use Dropbox as a secondary copy when an upload is available.
2. Verify the archive checksum before extraction when a `.sha256` sidecar is available.
3. Inspect `RECOVERY_AND_CONTINUITY.md`, `BUILD_REPORT.md`, and the latest Notion checkpoint before changing source.
4. Make frontend changes in this working tree only. Keep backend contracts stable and do not change billing, inventory, tax, stock, returns or financial rules without an explicit coordinated task.
5. After every substantial implementation/review milestone, create a new timestamped ZIP checkpoint and upload it to `/ORVA_FRONTEND_CHECKPOINTS/` in the persistent ChatGPT File Library. Never overwrite an earlier checkpoint. Retain the history. Mirror it to Dropbox when the connected file-upload path accepts the exact file artifact.
6. Record the checkpoint filename, persistent Library path, Dropbox path if mirrored, changed files, test results and next action in Notion.
7. At the end of a session, create a checkpoint even if the implementation is incomplete, clearly labelling it as a work-in-progress snapshot.

## Restore procedure for a new chat

1. List the ChatGPT File Library folder `/ORVA_FRONTEND_CHECKPOINTS/` using the Files tool. This folder is persistent across chats.
2. Select the newest timestamped \`ORVA_FRONTEND_CHECKPOINT_*.zip\`; do not rely solely on chat memory.
3. Materialize the exact Library file ID to the new session's working storage and extract the archive. No user re-upload should be needed.
4. Verify the sidecar SHA-256 when available. (The current ZIP includes the local `.git` repository and complete source tree.)
5. Run `git status`; compare `BUILD_REPORT.md`, `ASSET_MANIFEST.md` and the latest Notion checkpoint.
6. Run `./tools/run_pure_kotlin_tests.sh` for the repeatable scheduler, grapheme and gesture JVM tests. This uses an isolated minimal JUnit-compatible runner and does not run Android, Compose or Robolectric tests.
7. Continue editing the recovered project. Do not reconstruct Kotlin files from summaries if the archive is available.
8. When the Dropbox upload path is available, mirror each accepted source checkpoint to `/ORVA-WORKSPACE/04-INTEGRATION/ANDROID-FRONTEND/` as an additional shared copy.

## Snapshot exclusions

Do not include local signing keys, `.env` files, `local.properties`, machine-specific SDK paths, Gradle caches, or generated build directories in source snapshots. Include source, tests, Gradle configuration, wrapper files when present, assets, manifests, build reports and this recovery guide.

## Current environment verification boundary

A source snapshot is not an APK and is not proof of a successful Android build. Build/test status must be reported separately and only when actually run in an environment with the Android SDK and resolved dependencies.


## Latest verified checkpoint pointer

- Persistent Library folder: `/ORVA_FRONTEND_CHECKPOINTS/`
- Checkpoints use the filename pattern: `ORVA_FRONTEND_CHECKPOINT_YYYYMMDDTHHMMSSZ.zip`.
- Latest snapshot: inspect the Library folder for the newest timestamp; never hardcode this pointer when a newer snapshot may exist.
- The archive contains the source tree, local `.git` commit history, asset/build manifests, tests, and this recovery guide.
