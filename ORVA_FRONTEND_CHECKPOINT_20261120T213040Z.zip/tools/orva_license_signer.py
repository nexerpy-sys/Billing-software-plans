#!/usr/bin/env python3
"""
ORVA Offline Licence CSV Signer (ECDSA P-256 / SHA256withECDSA)
===============================================================

Runs offline on Rindle Works' workstation to:
1. Generate an ECDSA P-256 keypair (private key stays offline — NEVER commit it):
     python3 tools/orva_license_signer.py keygen --out-dir ./rindle_keys

2. Hash an activation code + sign a pharmacy licence row for GitHub `licenses.csv`:
     python3 tools/orva_license_signer.py sign-row \
       --key ./rindle_keys/rindle_private.pem \
       --username arogya_kol_01 \
       --plan Annual \
       --start 01-06-2026 \
       --expiry 01-06-2027 \
       --status Active \
       --code ORVA-8492-KX71 \
       --csv ./licenses.csv

3. Verify every row in `licenses.csv` against your embedded public key before pushing:
     python3 tools/orva_license_signer.py verify-csv \
       --pubkey-b64 "<BASE64_SPKI_PUBLIC_KEY>" \
       --csv ./licenses.csv

Works with either Python's `cryptography` package OR the standard `openssl` CLI.
Produces DER-encoded SHA256withECDSA signatures and X.509/SPKI Base64 public keys
that match Android's `VendorSignatureVerifier.kt` byte-for-byte.
"""

from __future__ import annotations

import argparse
import base64
import csv
import hashlib
import os
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path
from typing import Optional

try:
    from cryptography.hazmat.primitives import hashes, serialization
    from cryptography.hazmat.primitives.asymmetric import ec

    HAS_CRYPTOGRAPHY = True
except ImportError:
    HAS_CRYPTOGRAPHY = False


CSV_HEADERS = [
    "username",
    "plan",
    "start_date",
    "expiry_date",
    "status",
    "activation_code_sha256",
    "signature",
]


def sha256_hex(raw: str) -> str:
    return hashlib.sha256(raw.strip().encode("utf-8")).hexdigest().lower()


def canonical_message(
    username: str,
    plan: str,
    start_date: str,
    expiry_date: str,
    status: str,
    activation_code_sha256: str,
) -> bytes:
    """Matches VendorSignatureVerifier.canonicalMessage() in Kotlin byte-for-byte."""
    parts = [
        username.strip().lower(),
        plan.strip(),
        start_date.strip(),
        expiry_date.strip(),
        status.strip().lower(),
        activation_code_sha256.strip().lower(),
    ]
    return "|".join(parts).encode("utf-8")


def _require_openssl() -> str:
    exe = shutil.which("openssl")
    if not exe:
        sys.exit(
            "Error: Neither Python `cryptography` nor `openssl` CLI is installed. "
            "Install one (`pip install cryptography` or `openssl`)."
        )
    return exe


def cmd_keygen(args: argparse.Namespace) -> None:
    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    priv_path = out_dir / "rindle_private.pem"
    pub_path = out_dir / "rindle_public.pem"

    if priv_path.exists() and not args.force:
        sys.exit(
            f"Refusing to overwrite existing private key at {priv_path}. "
            "Pass --force only if you intentionally want to replace it."
        )

    if HAS_CRYPTOGRAPHY:
        private_key = ec.generate_private_key(ec.SECP256R1())
        priv_pem = private_key.private_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PrivateFormat.PKCS8,
            encryption_algorithm=serialization.NoEncryption(),
        )
        public_key = private_key.public_key()
        pub_pem = public_key.public_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PublicFormat.SubjectPublicKeyInfo,
        )
        pub_der = public_key.public_bytes(
            encoding=serialization.Encoding.DER,
            format=serialization.PublicFormat.SubjectPublicKeyInfo,
        )
        priv_path.write_bytes(priv_pem)
        pub_path.write_bytes(pub_pem)
    else:
        openssl = _require_openssl()
        subprocess.run(
            [
                openssl,
                "ecparam",
                "-name",
                "prime256v1",
                "-genkey",
                "-noout",
                "-out",
                str(priv_path),
            ],
            check=True,
        )
        subprocess.run(
            [openssl, "ec", "-in", str(priv_path), "-pubout", "-out", str(pub_path)],
            check=True,
        )
        pub_der = subprocess.check_output(
            [openssl, "ec", "-in", str(priv_path), "-pubout", "-outform", "DER"],
            stderr=subprocess.DEVNULL,
        )

    try:
        os.chmod(priv_path, 0o600)
    except OSError:
        pass

    pub_b64 = base64.b64encode(pub_der).decode("ascii")
    print(f"Private key saved (KEEP OFFLINE!): {priv_path}")
    print(f"Public key PEM saved:              {pub_path}")
    print()
    print("Paste this Base64 SPKI public key into OrvaLicenseConfig.VENDOR_PUBLIC_KEY_SPKI_BASE64:")
    print(pub_b64)


def sign_bytes(private_key_path: Path, payload: bytes) -> str:
    if HAS_CRYPTOGRAPHY:
        private_key = serialization.load_pem_private_key(
            private_key_path.read_bytes(), password=None
        )
        sig_der = private_key.sign(payload, ec.ECDSA(hashes.SHA256()))
        return base64.b64encode(sig_der).decode("ascii")

    openssl = _require_openssl()
    with tempfile.NamedTemporaryFile(delete=False) as msg_file:
        msg_file.write(payload)
        msg_path = Path(msg_file.name)
    try:
        sig_der = subprocess.check_output(
            [
                openssl,
                "dgst",
                "-sha256",
                "-sign",
                str(private_key_path),
                str(msg_path),
            ]
        )
        return base64.b64encode(sig_der).decode("ascii")
    finally:
        msg_path.unlink(missing_ok=True)


def verify_bytes(pubkey_spki_b64: str, payload: bytes, signature_b64: str) -> bool:
    try:
        pub_der = base64.b64decode(pubkey_spki_b64.strip())
        sig_der = base64.b64decode(signature_b64.strip())
    except Exception:
        return False

    if HAS_CRYPTOGRAPHY:
        try:
            public_key = serialization.load_der_public_key(pub_der)
            public_key.verify(sig_der, payload, ec.ECDSA(hashes.SHA256()))
            return True
        except Exception:
            return False

    openssl = _require_openssl()
    with tempfile.NamedTemporaryFile(delete=False) as pub_f, tempfile.NamedTemporaryFile(
        delete=False
    ) as msg_f, tempfile.NamedTemporaryFile(delete=False) as sig_f:
        pub_f.write(pub_der)
        msg_f.write(payload)
        sig_f.write(sig_der)
        pub_p, msg_p, sig_p = Path(pub_f.name), Path(msg_f.name), Path(sig_f.name)
    try:
        res = subprocess.run(
            [
                openssl,
                "dgst",
                "-sha256",
                "-verify",
                str(pub_p),
                "-keyform",
                "DER",
                "-signature",
                str(sig_p),
                str(msg_p),
            ],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        return res.returncode == 0
    finally:
        pub_p.unlink(missing_ok=True)
        msg_p.unlink(missing_ok=True)
        sig_p.unlink(missing_ok=True)


def cmd_sign_row(args: argparse.Namespace) -> None:
    key_path = Path(args.key)
    if not key_path.exists():
        sys.exit(f"Private key not found: {key_path}")

    code_hash = args.code_sha256.strip().lower() if args.code_sha256 else sha256_hex(args.code)
    payload = canonical_message(
        username=args.username,
        plan=args.plan,
        start_date=args.start,
        expiry_date=args.expiry,
        status=args.status,
        activation_code_sha256=code_hash,
    )
    signature_b64 = sign_bytes(key_path, payload)

    row = {
        "username": args.username.strip(),
        "plan": args.plan.strip(),
        "start_date": args.start.strip(),
        "expiry_date": args.expiry.strip(),
        "status": args.status.strip(),
        "activation_code_sha256": code_hash,
        "signature": signature_b64,
    }

    if args.csv:
        csv_path = Path(args.csv)
        existing_rows = []
        replaced = False
        if csv_path.exists():
            with csv_path.open("r", encoding="utf-8-sig", newline="") as f:
                reader = csv.DictReader(f)
                for r in reader:
                    if (r.get("username") or "").strip().lower() == row["username"].lower():
                        existing_rows.append(row)
                        replaced = True
                    else:
                        existing_rows.append({h: (r.get(h) or "").strip() for h in CSV_HEADERS})
        if not replaced:
            existing_rows.append(row)
        csv_path.parent.mkdir(parents=True, exist_ok=True)
        with csv_path.open("w", encoding="utf-8", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=CSV_HEADERS)
            writer.writeheader()
            writer.writerows(existing_rows)
        action = "Updated" if replaced else "Added"
        print(f"{action} signed row for '{row['username']}' in {csv_path}")

    print(
        ",".join(
            [
                row["username"],
                row["plan"],
                row["start_date"],
                row["expiry_date"],
                row["status"],
                row["activation_code_sha256"],
                row["signature"],
            ]
        )
    )


def cmd_verify_csv(args: argparse.Namespace) -> None:
    csv_path = Path(args.csv)
    if not csv_path.exists():
        sys.exit(f"CSV file not found: {csv_path}")

    pubkey_b64: Optional[str] = args.pubkey_b64
    if not pubkey_b64 and args.pubkey_pem:
        pem_text = Path(args.pubkey_pem).read_text(encoding="utf-8")
        lines = [ln.strip() for ln in pem_text.splitlines() if not ln.startswith("-----")]
        pubkey_b64 = "".join(lines)
    if not pubkey_b64:
        sys.exit("Provide --pubkey-b64 or --pubkey-pem.")

    total = 0
    failed = 0
    with csv_path.open("r", encoding="utf-8-sig", newline="") as f:
        reader = csv.DictReader(f)
        for idx, r in enumerate(reader, start=2):
            username = (r.get("username") or "").strip()
            if not username:
                continue
            total += 1
            payload = canonical_message(
                username=username,
                plan=r.get("plan") or "",
                start_date=r.get("start_date") or "",
                expiry_date=r.get("expiry_date") or "",
                status=r.get("status") or "",
                activation_code_sha256=r.get("activation_code_sha256") or "",
            )
            sig = (r.get("signature") or "").strip()
            ok = bool(sig) and verify_bytes(pubkey_b64, payload, sig)
            status_label = "OK" if ok else "INVALID"
            print(f"Row {idx} ({username}): {status_label}")
            if not ok:
                failed += 1

    print(f"Verified {total} row(s): {total - failed} valid, {failed} invalid.")
    if failed > 0:
        sys.exit(1)


def main() -> None:
    parser = argparse.ArgumentParser(description="ORVA Offline Licence CSV Signer (ECDSA P-256)")
    sub = parser.add_subparsers(dest="command", required=True)

    p_gen = sub.add_parser("keygen", help="Generate offline ECDSA P-256 keypair")
    p_gen.add_argument("--out-dir", default="./rindle_keys", help="Output directory for PEM files")
    p_gen.add_argument("--force", action="store_true", help="Overwrite existing private key")
    p_gen.set_defaults(func=cmd_keygen)

    p_sign = sub.add_parser("sign-row", help="Sign a pharmacy licence row for licenses.csv")
    p_sign.add_argument("--key", required=True, help="Path to offline rindle_private.pem")
    p_sign.add_argument("--username", required=True, help="Unique shop username (e.g. arogya_kol_01)")
    p_sign.add_argument("--plan", required=True, help="Plan name (e.g. Annual, Monthly, One-Time)")
    p_sign.add_argument("--start", required=True, help="Start date (dd-MM-yyyy or yyyy-MM-dd)")
    p_sign.add_argument("--expiry", default="", help="Expiry date (blank for One-Time)")
    p_sign.add_argument("--status", default="Active", help="Status (Active, Suspended, Expired)")
    code_group = p_sign.add_mutually_exclusive_group(required=True)
    code_group.add_argument("--code", help="Plaintext activation code (will be SHA-256 hashed)")
    code_group.add_argument("--code-sha256", help="Pre-computed 64-char SHA-256 hex hash")
    p_sign.add_argument("--csv", help="Optional licenses.csv file to upsert this signed row into")
    p_sign.set_defaults(func=cmd_sign_row)

    p_ver = sub.add_parser("verify-csv", help="Verify all rows in licenses.csv before publishing")
    p_ver.add_argument("--csv", required=True, help="Path to licenses.csv")
    p_ver.add_argument("--pubkey-b64", help="Base64 SPKI public key string")
    p_ver.add_argument("--pubkey-pem", help="Path to rindle_public.pem")
    p_ver.set_defaults(func=cmd_verify_csv)

    args = parser.parse_args()
    args.func(args)


if __name__ == "__main__":
    main()
