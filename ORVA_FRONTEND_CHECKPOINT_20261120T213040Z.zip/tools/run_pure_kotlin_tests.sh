#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
KOTLINC_BIN="${KOTLINC_BIN:-kotlinc}"
KOTLIN_BIN="${KOTLIN_BIN:-kotlin}"
JAVAC_BIN="${JAVAC_BIN:-javac}"

for tool in "$KOTLINC_BIN" "$KOTLIN_BIN" "$JAVAC_BIN"; do
  if ! command -v "$tool" >/dev/null 2>&1; then
    printf 'Missing required tool: %s\n' "$tool" >&2
    exit 127
  fi
done

TMP_DIR="$(mktemp -d)"
trap 'rm -rf "$TMP_DIR"' EXIT
mkdir -p "$TMP_DIR/src/org/junit" "$TMP_DIR/src/runner" "$TMP_DIR/classes"

cat > "$TMP_DIR/src/org/junit/Test.java" <<'JAVA'
package org.junit;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.METHOD)
public @interface Test {}
JAVA

cat > "$TMP_DIR/src/org/junit/Assert.java" <<'JAVA'
package org.junit;

import java.util.Objects;

public final class Assert {
  private Assert() {}

  public static void assertEquals(Object expected, Object actual) {
    assertEquals(null, expected, actual);
  }

  public static void assertEquals(String message, Object expected, Object actual) {
    if (!Objects.equals(expected, actual)) {
      fail(message, "expected <" + expected + "> but was <" + actual + ">");
    }
  }

  public static void assertTrue(boolean condition) {
    assertTrue(null, condition);
  }

  public static void assertTrue(String message, boolean condition) {
    if (!condition) fail(message, "expected true");
  }

  public static void assertFalse(boolean condition) {
    assertFalse(null, condition);
  }

  public static void assertFalse(String message, boolean condition) {
    if (condition) fail(message, "expected false");
  }

  public static void assertNull(Object value) {
    if (value != null) fail(null, "expected null but was <" + value + ">");
  }

  public static void assertNotNull(Object value) {
    assertNotNull(null, value);
  }

  public static void assertNotNull(String message, Object value) {
    if (value == null) fail(message, "expected a non-null value");
  }

  private static void fail(String message, String detail) {
    throw new AssertionError(message == null ? detail : message + ": " + detail);
  }
}
JAVA

cat > "$TMP_DIR/src/runner/PureKotlinTestRunner.java" <<'JAVA'
package runner;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Arrays;
import org.junit.Test;

public final class PureKotlinTestRunner {
  private PureKotlinTestRunner() {}

  public static void main(String[] args) throws Exception {
    int passed = 0;
    int failed = 0;
    for (String className : args) {
      Class<?> testClass = Class.forName(className);
      Method[] methods = testClass.getDeclaredMethods();
      Arrays.sort(methods, (left, right) -> left.getName().compareTo(right.getName()));
      for (Method method : methods) {
        if (!method.isAnnotationPresent(Test.class)) continue;
        Object instance = testClass.getDeclaredConstructor().newInstance();
        try {
          method.invoke(instance);
          passed++;
          System.out.println("PASS " + testClass.getSimpleName() + " :: " + method.getName());
        } catch (InvocationTargetException error) {
          failed++;
          System.err.println("FAIL " + testClass.getSimpleName() + " :: " + method.getName());
          error.getCause().printStackTrace(System.err);
        }
      }
    }
    System.out.printf("RESULT %d passed; %d failed%n", passed, failed);
    System.out.println("Scope: pure JVM tests only; this does not run Android, Compose, or Robolectric tests.");
    if (passed == 0) {
      System.err.println("No tests were discovered; refusing to report an empty run as success.");
      System.exit(2);
    }
    if (failed != 0) System.exit(1);
  }
}
JAVA

"$JAVAC_BIN" -d "$TMP_DIR/classes" \
  "$TMP_DIR/src/org/junit/Test.java" \
  "$TMP_DIR/src/org/junit/Assert.java" \
  "$TMP_DIR/src/runner/PureKotlinTestRunner.java"

"$KOTLINC_BIN" \
  "$ROOT_DIR/app/src/main/java/com/rindleworks/orva/ui/about/agentic/AgentTaskScheduler.kt" \
  "$ROOT_DIR/app/src/main/java/com/rindleworks/orva/ui/about/agentic/AgenticGraphemeBoundaries.kt" \
  "$ROOT_DIR/app/src/main/java/com/rindleworks/orva/ui/about/gesture/AboutGestureClassifier.kt" \
  "$ROOT_DIR/app/src/test/java/com/rindleworks/orva/ui/about/agentic/AgentTaskSchedulerTest.kt" \
  "$ROOT_DIR/app/src/test/java/com/rindleworks/orva/ui/about/agentic/AgenticGraphemeBoundariesTest.kt" \
  "$ROOT_DIR/app/src/test/java/com/rindleworks/orva/ui/about/gesture/AboutGestureClassifierTest.kt" \
  -classpath "$TMP_DIR/classes" \
  -d "$TMP_DIR/classes"

"$KOTLIN_BIN" -classpath "$TMP_DIR/classes" runner.PureKotlinTestRunner \
  com.rindleworks.orva.ui.about.agentic.AgentTaskSchedulerTest \
  com.rindleworks.orva.ui.about.agentic.AgenticGraphemeBoundariesTest \
  com.rindleworks.orva.ui.about.gesture.AboutGestureClassifierTest
