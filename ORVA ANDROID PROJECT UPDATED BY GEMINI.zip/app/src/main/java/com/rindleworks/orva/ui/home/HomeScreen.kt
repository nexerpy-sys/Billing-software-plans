package com.rindleworks.orva.ui.home

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.layout.positionInWindow
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.rindleworks.orva.R
import com.rindleworks.orva.domain.settings.AppLanguage
import com.rindleworks.orva.ui.showcase.FolderCopy
import com.rindleworks.orva.ui.showcase.HomeShowcaseUiState
import com.rindleworks.orva.ui.showcase.OrvaClosingFriezeSection
import com.rindleworks.orva.ui.showcase.OrvaShowcaseColors
import com.rindleworks.orva.ui.showcase.OrvaShowcaseCopy
import com.rindleworks.orva.ui.showcase.OrvaShowcaseFonts
import com.rindleworks.orva.ui.showcase.ShowcaseUiEvent
import com.rindleworks.orva.ui.showcase.currentShowcasePalette
import kotlinx.coroutines.launch

/**
 * Rindle Works × ORVA Home Screen (Master Frontend Build Directive §3).
 *
 * Art-directed dark editorial entry:
 * - H1: Near-fullscreen Rindle Works hero (`BUILT AROUND THE WORK.`) with monochrome architecture
 *   and quiet local readiness strip.
 * - H2: Darkness-first neutral chalk/violet touch lantern over monochrome apothecary shelving.
 * - H3: Scroll-linked cinematic image crop/scale + oversized integrated typography.
 * - H4: Flagship ORVA product panel (`IN ACTIVE DEVELOPMENT`, honest scope).
 * - H5: Three layered editorial document panels (`PRODUCT`, `CRAFT`, `ENGINEERING`).
 * - H6: Shared monochrome apothecary frieze & closing navigation.
 */
@Composable
fun HomeScreen(
  state: HomeShowcaseUiState,
  reducedMotion: Boolean,
  onEvent: (ShowcaseUiEvent) -> Unit,
  modifier: Modifier = Modifier,
) {
  val scrollState = rememberScrollState()
  val scope = rememberCoroutineScope()
  var viewportHeightPx by remember { mutableFloatStateOf(1600f) }

  val scrollProgress =
    if (scrollState.maxValue > 0) {
      (scrollState.value.toFloat() / scrollState.maxValue.toFloat()).coerceIn(0f, 1f)
    } else {
      0f
    }

  val palette = currentShowcasePalette()
  Box(
    modifier =
      modifier
        .fillMaxSize()
        .background(palette.canvasDeep)
        .onSizeChanged { viewportHeightPx = it.height.toFloat().coerceAtLeast(1f) },
  ) {
    Column(
      modifier =
        Modifier
          .fillMaxSize()
          .verticalScroll(scrollState)
          .testTag("home_scroll_container"),
    ) {
      // H1 — Editorial Rindle Works Hero
      HomeEditorialHeroSection(
        state = state,
        scrollPxProvider = { scrollState.value.toFloat() },
        reducedMotion = reducedMotion,
        onExploreOrva = { onEvent(ShowcaseUiEvent.StartBilling) },
        onOpenStudio = { onEvent(ShowcaseUiEvent.OpenAboutUs) },
        onAddStock = { onEvent(ShowcaseUiEvent.AddStock) },
      )

      // H2 — Darkness-First Lantern Surface (never traps vertical scroll)
      HomeLanternSurfaceSection(
        language = state.language,
        reducedMotion = reducedMotion,
      )

      // H3 — Scroll-Linked Cinematic Image & Oversized Type Composition
      HomeCinematicScrollSection(
        language = state.language,
        reducedMotion = reducedMotion,
        viewportHeightPx = viewportHeightPx,
      )

      // H4 — Flagship Product Feature: ORVA
      HomeFlagshipOrvaSection(
        state = state,
        onExploreProduct = { onEvent(ShowcaseUiEvent.StartBilling) },
        onOpenStudio = { onEvent(ShowcaseUiEvent.OpenAboutUs) },
      )

      // H5 — Three Physical Layered Document Panels (PRODUCT / CRAFT / ENGINEERING)
      HomeLayeredPanelsSection(
        state = state,
        reducedMotion = reducedMotion,
        onPanelAction = { id ->
          when (id) {
            "quick_billing" -> onEvent(ShowcaseUiEvent.StartBilling)
            "expiry_stock" -> onEvent(ShowcaseUiEvent.OpenInventory)
            "about_orva" -> onEvent(ShowcaseUiEvent.OpenAboutUs)
          }
        },
      )

      // H6 — Shared Monochrome Apothecary Frieze & Closing Bar
      OrvaClosingFriezeSection(
        appVersion = state.appVersion,
        language = state.language,
        isAboutScreen = false,
        reducedMotion = reducedMotion,
        viewportHeightPx = viewportHeightPx,
        onStartBilling = { onEvent(ShowcaseUiEvent.StartBilling) },
        onSecondaryNav = { onEvent(ShowcaseUiEvent.OpenAboutUs) },
        onBackToTop = {
          scope.launch {
            if (reducedMotion) scrollState.scrollTo(0)
            else scrollState.animateScrollTo(0, tween(520, easing = FastOutSlowInEasing))
          }
        },
      )
    }

    // Top 1.5dp vermilion-to-violet editorial scroll hairline
    Box(
      modifier =
        Modifier
          .align(Alignment.TopStart)
          .fillMaxWidth(scrollProgress)
          .height(1.5.dp)
          .background(
            Brush.horizontalGradient(
              listOf(OrvaShowcaseColors.AccentVermilion, OrvaShowcaseColors.AccentViolet),
            )
          ),
    )
  }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun HomeEditorialHeroSection(
  state: HomeShowcaseUiState,
  scrollPxProvider: () -> Float,
  reducedMotion: Boolean,
  onExploreOrva: () -> Unit,
  onOpenStudio: () -> Unit,
  onAddStock: () -> Unit,
) {
  val palette = currentShowcasePalette()
  Box(
    modifier =
      Modifier
        .fillMaxWidth()
        .background(palette.canvasDeep)
        .clipToBounds(),
  ) {
    // Monochrome architectural hero photography with subtle scroll scale/parallax
    Image(
      painter = painterResource(id = R.drawable.editorial_architecture_light),
      contentDescription = null,
      contentScale = ContentScale.Crop,
      alpha = 0.34f,
      modifier =
        Modifier
          .matchParentSize()
          .graphicsLayer {
            val scroll = if (reducedMotion) 0f else scrollPxProvider().coerceIn(0f, 800f)
            val p = scroll / 800f
            scaleX = 1.04f + p * 0.12f
            scaleY = 1.04f + p * 0.12f
            translationY = scroll * 0.22f
          },
    )

    // Editorial bottom-heavy dark vignette for razor-sharp type legibility
    Box(
      modifier =
        Modifier
          .matchParentSize()
          .background(
            Brush.verticalGradient(
              0.0f to palette.canvasDeep.copy(alpha = 0.48f),
              0.55f to palette.canvasDeep.copy(alpha = 0.72f),
              1.0f to palette.canvasDeep,
            )
          ),
    )

    Column(
      modifier =
        Modifier
          .fillMaxWidth()
          .widthIn(max = 960.dp)
          .align(Alignment.Center)
          .padding(horizontal = 24.dp, vertical = 44.dp)
          .graphicsLayer {
            // zll.me hero scroll parallax scale-up & fade (zero recompositions)
            val scroll = if (reducedMotion) 0f else scrollPxProvider().coerceIn(0f, 760f)
            val p = scroll / 760f
            val s = 1f + p * 0.07f
            scaleX = s
            scaleY = s
            translationY = -scroll * 0.08f
            alpha = (1f - p * 0.82f).coerceIn(0.18f, 1f)
          },
      verticalArrangement = Arrangement.spacedBy(20.dp),
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
          Box(
            modifier =
              Modifier
                .size(6.dp)
                .clip(CircleShape)
                .background(OrvaShowcaseColors.AccentVermilion),
          )
          Text(
            text = OrvaShowcaseCopy.homeEyebrow(state.language),
            fontFamily = OrvaShowcaseFonts.mono(state.language),
            fontSize = 10.5.sp,
            letterSpacing = 1.6.sp,
            color = OrvaShowcaseColors.InkSecondary,
          )
        }
        Text(
          text = "01 / 05",
          fontFamily = OrvaShowcaseFonts.IbmPlexMono,
          fontSize = 10.5.sp,
          letterSpacing = 1.4.sp,
          color = OrvaShowcaseColors.InkMuted,
        )
      }

      Spacer(Modifier.height(36.dp))

      // Monumental condensed-style display headline
      Column(
        modifier = Modifier.testTag("home_hero_headline"),
        verticalArrangement = Arrangement.spacedBy(2.dp),
      ) {
        Text(
          text = OrvaShowcaseCopy.homeHeadlineTop(state.language),
          fontFamily = OrvaShowcaseFonts.display(state.language),
          fontWeight = FontWeight.Bold,
          fontSize = 56.sp,
          lineHeight = 56.sp,
          letterSpacing = (-1.4).sp,
          color = palette.inkPrimary,
        )
        Text(
          text = OrvaShowcaseCopy.homeHeadlineItalic(state.language),
          fontFamily = OrvaShowcaseFonts.display(state.language),
          fontWeight = FontWeight.Bold,
          fontSize = 56.sp,
          lineHeight = 56.sp,
          letterSpacing = (-1.4).sp,
          color = OrvaShowcaseColors.AccentVermilion,
        )
      }

      Text(
        text = OrvaShowcaseCopy.homeSubtitle(state.language),
        fontFamily = OrvaShowcaseFonts.body(state.language),
        fontSize = 16.5.sp,
        lineHeight = 25.sp,
        color = palette.inkSecondary,
        modifier = Modifier.widthIn(max = 520.dp),
      )

      Spacer(Modifier.height(6.dp))

      // Primary & secondary actions
      FlowRow(
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
      ) {
        Button(
          onClick = onExploreOrva,
          colors =
            ButtonDefaults.buttonColors(
              containerColor = OrvaShowcaseColors.InkPrimary,
              contentColor = OrvaShowcaseColors.CanvasDeep,
            ),
          shape = RoundedCornerShape(2.dp),
          contentPadding = PaddingValues(horizontal = 20.dp, vertical = 14.dp),
          modifier = Modifier.minimumInteractiveComponentSize().testTag("home_start_billing_btn"),
        ) {
          Text(
            text = OrvaShowcaseCopy.startBillingCta(state.language),
            fontFamily = OrvaShowcaseFonts.mono(state.language),
            fontWeight = FontWeight.SemiBold,
            fontSize = 12.sp,
            letterSpacing = 1.2.sp,
          )
        }

        OutlinedButton(
          onClick = onOpenStudio,
          border = BorderStroke(1.dp, OrvaShowcaseColors.Hairline),
          colors =
            ButtonDefaults.outlinedButtonColors(
              containerColor = OrvaShowcaseColors.CanvasSecondary.copy(alpha = 0.72f),
              contentColor = OrvaShowcaseColors.InkPrimary,
            ),
          shape = RoundedCornerShape(2.dp),
          contentPadding = PaddingValues(horizontal = 18.dp, vertical = 14.dp),
          modifier = Modifier.minimumInteractiveComponentSize().testTag("home_studio_btn"),
        ) {
          Text(
            text = OrvaShowcaseCopy.studioSecondaryCta(state.language),
            fontFamily = OrvaShowcaseFonts.mono(state.language),
            fontWeight = FontWeight.Medium,
            fontSize = 12.sp,
            letterSpacing = 1.2.sp,
          )
        }

        OutlinedButton(
          onClick = onAddStock,
          border = BorderStroke(1.dp, OrvaShowcaseColors.Hairline),
          colors =
            ButtonDefaults.outlinedButtonColors(
              containerColor = Color.Transparent,
              contentColor = OrvaShowcaseColors.InkSecondary,
            ),
          shape = RoundedCornerShape(2.dp),
          contentPadding = PaddingValues(horizontal = 14.dp, vertical = 14.dp),
          modifier = Modifier.minimumInteractiveComponentSize().testTag("home_add_stock_btn"),
        ) {
          Text(
            text = OrvaShowcaseCopy.addStockCta(state.language),
            fontFamily = OrvaShowcaseFonts.mono(state.language),
            fontSize = 11.5.sp,
            letterSpacing = 1.sp,
          )
        }
      }

      Spacer(Modifier.height(14.dp))
      HorizontalDivider(thickness = 1.dp, color = OrvaShowcaseColors.Hairline)

      // Live local shop readiness strip (real SQLite state — never fake telemetry)
      Text(
        text =
          OrvaShowcaseCopy.readinessStrip(
            shopName = state.shopName,
            usableMedicines = state.usableMedicineCount,
            expiringSoonCount = state.expiringSoonCount,
            backupState = state.backupStatus,
            language = state.language,
          ),
        fontFamily = OrvaShowcaseFonts.mono(state.language),
        fontSize = 11.sp,
        lineHeight = 18.sp,
        letterSpacing = 0.5.sp,
        color = OrvaShowcaseColors.InkMuted,
        modifier = Modifier.testTag("home_readiness_strip"),
      )
    }
  }
}

/**
 * H2 — Darkness-First Lantern Surface (Master Directive §3.2).
 * Neutral chalk/violet light pool reveals monochrome apothecary shelving without trapping scroll.
 */
@Composable
private fun HomeLanternSurfaceSection(
  language: AppLanguage,
  reducedMotion: Boolean,
) {
  var lanternPos by remember { mutableStateOf<Offset?>(null) }
  var lanternActive by remember { mutableStateOf(false) }
  val lanternIntensity = remember { Animatable(0.32f) }

  LaunchedEffect(lanternActive, reducedMotion) {
    val target =
      when {
        reducedMotion -> 0.55f
        lanternActive -> 1f
        else -> 0.28f
      }
    lanternIntensity.animateTo(
      targetValue = target,
      animationSpec = tween(durationMillis = if (lanternActive) 140 else 320),
    )
  }

  Column(
    modifier =
      Modifier
        .fillMaxWidth()
        .widthIn(max = 960.dp)
        .padding(horizontal = 24.dp, vertical = 20.dp),
    verticalArrangement = Arrangement.spacedBy(12.dp),
  ) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Text(
        text = "02 / ILLUMINATION STUDY",
        fontFamily = OrvaShowcaseFonts.IbmPlexMono,
        fontSize = 10.5.sp,
        letterSpacing = 1.5.sp,
        color = OrvaShowcaseColors.InkMuted,
      )
      Text(
        text = OrvaShowcaseCopy.lanternHint(language),
        fontFamily = OrvaShowcaseFonts.mono(language),
        fontSize = 10.sp,
        letterSpacing = 1.2.sp,
        color = OrvaShowcaseColors.AccentVioletSoft,
      )
    }

    Box(
      modifier =
        Modifier
          .fillMaxWidth()
          .height(340.dp)
          .border(1.dp, OrvaShowcaseColors.Hairline)
          .background(OrvaShowcaseColors.CanvasDeep)
          .clipToBounds()
          .pointerInput(reducedMotion) {
            if (reducedMotion) return@pointerInput
            awaitEachGesture {
              val down = awaitFirstDown(requireUnconsumed = false)
              lanternPos = down.position
              lanternActive = true
              try {
                while (true) {
                  val event = awaitPointerEvent()
                  val activeChange = event.changes.firstOrNull { it.pressed }
                  if (activeChange != null) {
                    lanternPos = activeChange.position
                  } else {
                    break
                  }
                }
              } finally {
                lanternActive = false
              }
            }
          },
    ) {
      Box(
        modifier =
          Modifier
            .fillMaxSize()
            .graphicsLayer { compositingStrategy = CompositingStrategy.Offscreen },
      ) {
        Image(
          painter = painterResource(id = R.drawable.editorial_apothecary_shelves),
          contentDescription = "Monochrome apothecary glass shelving",
          contentScale = ContentScale.Crop,
          modifier = Modifier.fillMaxSize(),
        )

        Canvas(modifier = Modifier.fillMaxSize()) {
          val intensity = lanternIntensity.value.coerceIn(0f, 1f)
          // Darkness veil
          drawRect(color = OrvaShowcaseColors.CanvasDeep.copy(alpha = 0.88f))
          // Neutral chalk/violet feathered spotlight (zero yellow/amber)
          val focus = lanternPos ?: Offset(size.width * 0.56f, size.height * 0.44f)
          val radius = (size.minDimension * 0.52f).coerceAtLeast(160f)
          drawCircle(
            brush =
              Brush.radialGradient(
                0.0f to Color.White.copy(alpha = 0.94f * intensity),
                0.42f to OrvaShowcaseColors.AccentVioletSoft.copy(alpha = 0.55f * intensity),
                0.78f to Color.White.copy(alpha = 0.14f * intensity),
                1.0f to Color.Transparent,
                center = focus,
                radius = radius,
              ),
            radius = radius,
            center = focus,
            blendMode = BlendMode.DstOut,
          )
        }
      }

      Text(
        text = "APOTHECARY / DETAIL 01",
        fontFamily = OrvaShowcaseFonts.IbmPlexMono,
        fontSize = 10.sp,
        letterSpacing = 1.4.sp,
        color = OrvaShowcaseColors.InkPrimary.copy(alpha = 0.72f),
        modifier =
          Modifier
            .align(Alignment.BottomStart)
            .background(OrvaShowcaseColors.CanvasDeep.copy(alpha = 0.72f))
            .padding(horizontal = 10.dp, vertical = 6.dp),
      )
    }
  }
}

/**
 * H3 — Scroll-Linked Cinematic Image & Typography Composition (Master Directive §3.3).
 */
@Composable
private fun HomeCinematicScrollSection(
  language: AppLanguage,
  reducedMotion: Boolean,
  viewportHeightPx: Float,
) {
  var bandTopInWindow by remember { mutableFloatStateOf(viewportHeightPx) }
  var bandHeightPx by remember { mutableFloatStateOf(520f) }

  val progress =
    if (reducedMotion || viewportHeightPx <= 1f) {
      0.5f
    } else {
      val span = viewportHeightPx + bandHeightPx
      ((viewportHeightPx - bandTopInWindow) / span).coerceIn(0f, 1f)
    }

  Column(
    modifier =
      Modifier
        .fillMaxWidth()
        .padding(vertical = 36.dp)
        .onGloballyPositioned { coords ->
          bandTopInWindow = coords.positionInWindow().y
          bandHeightPx = coords.size.height.toFloat().coerceAtLeast(1f)
        },
    verticalArrangement = Arrangement.spacedBy(20.dp),
  ) {
    HorizontalDivider(thickness = 1.dp, color = OrvaShowcaseColors.Hairline)

    Box(
      modifier =
        Modifier
          .fillMaxWidth()
          .height(310.dp)
          .clipToBounds()
          .background(OrvaShowcaseColors.CanvasSecondary),
    ) {
      Image(
        painter = painterResource(id = R.drawable.editorial_thermal_counter),
        contentDescription = "Macro detail of thermal counter paper roll and aluminum hardware",
        contentScale = ContentScale.Crop,
        modifier =
          Modifier
            .fillMaxSize()
            .graphicsLayer {
              val s = 1.18f - progress * 0.14f
              scaleX = s
              scaleY = s
              translationY = (progress - 0.5f) * -36f
              alpha = 0.58f
            },
      )

      Box(
        modifier =
          Modifier
            .fillMaxSize()
            .background(
              Brush.horizontalGradient(
                0.0f to OrvaShowcaseColors.CanvasDeep.copy(alpha = 0.88f),
                0.65f to OrvaShowcaseColors.CanvasDeep.copy(alpha = 0.42f),
                1.0f to OrvaShowcaseColors.CanvasDeep.copy(alpha = 0.72f),
              )
            ),
      )

      Column(
        modifier =
          Modifier
            .align(Alignment.CenterStart)
            .padding(horizontal = 24.dp)
            .graphicsLayer {
              translationX = if (reducedMotion) 0f else (progress - 0.5f) * 28f
            },
        verticalArrangement = Arrangement.spacedBy(4.dp),
      ) {
        Text(
          text = "03 / PRECISION",
          fontFamily = OrvaShowcaseFonts.IbmPlexMono,
          fontSize = 10.5.sp,
          letterSpacing = 1.6.sp,
          color = OrvaShowcaseColors.AccentVermilion,
        )
        Text(
          text = OrvaShowcaseCopy.homeIdentityLeftLine1(language),
          fontFamily = OrvaShowcaseFonts.display(language),
          fontWeight = FontWeight.Bold,
          fontSize = 38.sp,
          lineHeight = 40.sp,
          letterSpacing = (-1).sp,
          color = OrvaShowcaseColors.InkPrimary,
        )
        Text(
          text = OrvaShowcaseCopy.homeIdentityLeftLine2(language),
          fontFamily = OrvaShowcaseFonts.editorialSerif(language),
          fontSize = 36.sp,
          lineHeight = 40.sp,
          color = OrvaShowcaseColors.InkSecondary,
        )
      }
    }

    HorizontalDivider(thickness = 1.dp, color = OrvaShowcaseColors.Hairline)
  }
}

/**
 * H4 — Flagship ORVA Product Feature (Master Directive §3.4).
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun HomeFlagshipOrvaSection(
  state: HomeShowcaseUiState,
  onExploreProduct: () -> Unit,
  onOpenStudio: () -> Unit,
) {
  Column(
    modifier =
      Modifier
        .fillMaxWidth()
        .widthIn(max = 960.dp)
        .padding(horizontal = 24.dp, vertical = 36.dp),
    verticalArrangement = Arrangement.spacedBy(16.dp),
  ) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Text(
        text = OrvaShowcaseCopy.flagshipEyebrow(state.language),
        fontFamily = OrvaShowcaseFonts.mono(state.language),
        fontSize = 11.sp,
        letterSpacing = 1.5.sp,
        color = OrvaShowcaseColors.AccentVermilion,
      )
      Text(
        text = OrvaShowcaseCopy.flagshipStateLabel(state.language),
        fontFamily = OrvaShowcaseFonts.mono(state.language),
        fontSize = 10.sp,
        letterSpacing = 1.2.sp,
        color = OrvaShowcaseColors.AccentVioletSoft,
      )
    }

    Text(
      text = "ORVA",
      fontFamily = OrvaShowcaseFonts.SpaceGrotesk,
      fontWeight = FontWeight.Bold,
      fontSize = 58.sp,
      letterSpacing = (-2.0).sp,
      color = OrvaShowcaseColors.InkPrimary,
    )

    Text(
      text = OrvaShowcaseCopy.flagshipDescriptor(state.language),
      fontFamily = OrvaShowcaseFonts.mono(state.language),
      fontSize = 12.sp,
      letterSpacing = 1.4.sp,
      color = OrvaShowcaseColors.InkMuted,
    )

    Text(
      text = OrvaShowcaseCopy.flagshipBody(state.language),
      fontFamily = OrvaShowcaseFonts.body(state.language),
      fontSize = 15.5.sp,
      lineHeight = 24.sp,
      color = OrvaShowcaseColors.InkSecondary,
    )

    Spacer(Modifier.height(4.dp))

    FlowRow(
      horizontalArrangement = Arrangement.spacedBy(12.dp),
      verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
      Button(
        onClick = onExploreProduct,
        colors =
          ButtonDefaults.buttonColors(
            containerColor = OrvaShowcaseColors.AccentVermilion,
            contentColor = OrvaShowcaseColors.CanvasDeep,
          ),
        shape = RoundedCornerShape(2.dp),
        contentPadding = PaddingValues(horizontal = 18.dp, vertical = 12.dp),
        modifier = Modifier.minimumInteractiveComponentSize(),
      ) {
        Text(
          text = OrvaShowcaseCopy.flagshipAction(state.language),
          fontFamily = OrvaShowcaseFonts.mono(state.language),
          fontWeight = FontWeight.SemiBold,
          fontSize = 11.5.sp,
          letterSpacing = 1.1.sp,
        )
      }

      OutlinedButton(
        onClick = onOpenStudio,
        border = BorderStroke(1.dp, OrvaShowcaseColors.Hairline),
        colors = ButtonDefaults.outlinedButtonColors(contentColor = OrvaShowcaseColors.InkPrimary),
        shape = RoundedCornerShape(2.dp),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
        modifier = Modifier.minimumInteractiveComponentSize(),
      ) {
        Text(
          text = OrvaShowcaseCopy.studioSecondaryCta(state.language),
          fontFamily = OrvaShowcaseFonts.mono(state.language),
          fontSize = 11.5.sp,
          letterSpacing = 1.1.sp,
        )
      }
    }
  }
}

/**
 * H5 — Three Layered Document Panels: PRODUCT / CRAFT / ENGINEERING (Master Directive §3.5).
 */
@Composable
private fun HomeLayeredPanelsSection(
  state: HomeShowcaseUiState,
  reducedMotion: Boolean,
  onPanelAction: (String) -> Unit,
) {
  val folders =
    remember(state.expiringSoonCount, state.appVersion, state.language) {
      OrvaShowcaseCopy.workspaceFolders(
        expiringSoonCount = state.expiringSoonCount,
        appVersion = state.appVersion,
        language = state.language,
      )
    }
  var expandedId by remember { mutableStateOf(folders.first().id) }

  Column(
    modifier =
      Modifier
        .fillMaxWidth()
        .widthIn(max = 960.dp)
        .padding(horizontal = 24.dp, vertical = 32.dp),
    verticalArrangement = Arrangement.spacedBy(18.dp),
  ) {
    Text(
      text = "05 / ${OrvaShowcaseCopy.folderSectionHeading(state.language)}",
      fontFamily = OrvaShowcaseFonts.mono(state.language),
      fontSize = 11.sp,
      letterSpacing = 1.6.sp,
      color = OrvaShowcaseColors.InkMuted,
    )

    BoxWithConstraints(modifier = Modifier.fillMaxWidth()) {
      val wide = maxWidth >= 720.dp
      if (wide) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(16.dp),
        ) {
          folders.forEach { folder ->
            LayeredDocumentPanel(
              folder = folder,
              expanded = expandedId == folder.id,
              reducedMotion = reducedMotion,
              language = state.language,
              onToggle = { expandedId = folder.id },
              onAction = { onPanelAction(folder.id) },
              modifier = Modifier.weight(1f),
            )
          }
        }
      } else {
        Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
          folders.forEach { folder ->
            LayeredDocumentPanel(
              folder = folder,
              expanded = expandedId == folder.id,
              reducedMotion = reducedMotion,
              language = state.language,
              onToggle = { expandedId = folder.id },
              onAction = { onPanelAction(folder.id) },
              modifier = Modifier.fillMaxWidth(),
            )
          }
        }
      }
    }
  }
}

@Composable
private fun LayeredDocumentPanel(
  folder: FolderCopy,
  expanded: Boolean,
  reducedMotion: Boolean,
  language: AppLanguage,
  onToggle: () -> Unit,
  onAction: () -> Unit,
  modifier: Modifier = Modifier,
) {
  val liftDp by animateDpAsState(
    targetValue = if (expanded && !reducedMotion) 6.dp else 0.dp,
    animationSpec = tween(220, easing = FastOutSlowInEasing),
    label = "panel_lift",
  )
  val borderAlpha by animateFloatAsState(
    targetValue = if (expanded) 1f else 0.45f,
    animationSpec = tween(220),
    label = "panel_border",
  )

  Column(
    modifier =
      modifier
        .border(
          width = 1.dp,
          color =
            if (expanded) OrvaShowcaseColors.AccentVermilion.copy(alpha = borderAlpha)
            else OrvaShowcaseColors.Hairline,
        )
        .background(if (expanded) OrvaShowcaseColors.SurfaceRaised else OrvaShowcaseColors.CanvasSecondary)
        .clickable(role = Role.Button, onClick = onToggle)
        .padding(top = 18.dp - liftDp.coerceAtMost(4.dp), bottom = 18.dp, start = 18.dp, end = 18.dp),
    verticalArrangement = Arrangement.spacedBy(10.dp),
  ) {
    Text(
      text = folder.tabLabel,
      fontFamily = OrvaShowcaseFonts.mono(language),
      fontSize = 10.sp,
      letterSpacing = 1.4.sp,
      color = if (expanded) OrvaShowcaseColors.AccentVermilion else OrvaShowcaseColors.InkMuted,
    )

    Text(
      text = folder.title,
      fontFamily = OrvaShowcaseFonts.display(language),
      fontWeight = FontWeight.Bold,
      fontSize = 22.sp,
      letterSpacing = (-0.4).sp,
      color = OrvaShowcaseColors.InkPrimary,
    )

    Text(
      text = folder.body,
      fontFamily = OrvaShowcaseFonts.body(language),
      fontSize = 13.5.sp,
      lineHeight = 20.sp,
      color = OrvaShowcaseColors.InkSecondary,
    )

    if (expanded) {
      HorizontalDivider(thickness = 1.dp, color = OrvaShowcaseColors.Hairline)
      Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        folder.sheets.forEach { sheet ->
          Text(
            text = "— $sheet",
            fontFamily = OrvaShowcaseFonts.mono(language),
            fontSize = 11.sp,
            color = OrvaShowcaseColors.InkPrimary.copy(alpha = 0.86f),
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
          )
        }
      }
    }

    Spacer(Modifier.height(4.dp))
    Box(
      modifier =
        Modifier
          .minimumInteractiveComponentSize()
          .clickable(role = Role.Button, onClick = onAction)
          .testTag("home_folder_action_${folder.id}"),
      contentAlignment = Alignment.CenterStart,
    ) {
      Text(
        text = folder.actionLabel,
        fontFamily = OrvaShowcaseFonts.mono(language),
        fontWeight = FontWeight.SemiBold,
        fontSize = 11.5.sp,
        letterSpacing = 1.sp,
        color = OrvaShowcaseColors.AccentVioletSoft,
      )
    }
  }
}
