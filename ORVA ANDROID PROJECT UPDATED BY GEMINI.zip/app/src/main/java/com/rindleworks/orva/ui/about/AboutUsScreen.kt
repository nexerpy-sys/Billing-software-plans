package com.rindleworks.orva.ui.about

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsFocusedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.layout.positionInWindow
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.rindleworks.orva.R
import com.rindleworks.orva.domain.settings.AppLanguage
import com.rindleworks.orva.ui.about.agentic.AgenticBuildController
import com.rindleworks.orva.ui.about.agentic.AgenticHudBar
import com.rindleworks.orva.ui.about.agentic.AgenticOverlayCanvas
import com.rindleworks.orva.ui.about.agentic.LayerKind
import com.rindleworks.orva.ui.about.agentic.LocalAgenticController
import com.rindleworks.orva.ui.about.agentic.agenticNode
import com.rindleworks.orva.ui.showcase.AboutShowcaseUiState
import com.rindleworks.orva.ui.showcase.OrvaCaseRailItem
import com.rindleworks.orva.ui.showcase.OrvaClosingFriezeSection
import com.rindleworks.orva.ui.showcase.OrvaShowcaseColors
import com.rindleworks.orva.ui.showcase.OrvaShowcaseCopy
import com.rindleworks.orva.ui.showcase.OrvaShowcaseFonts
import com.rindleworks.orva.ui.showcase.PrincipleCopy
import com.rindleworks.orva.ui.showcase.ShowcaseUiEvent
import com.rindleworks.orva.ui.showcase.currentShowcasePalette
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * Rindle Works × ORVA About Us Portfolio Screen (Master Frontend Build Directive §4 & §5).
 *
 * Nine art-directed portfolio scenes progressively constructed in place by the deterministic
 * 16-agent Purple & Vermilion Agentic Build system (zero opening ORVA text/glow splash):
 * - Scene 01: Studio Identity Hero (`THE WORK IS IN THE DETAILS.`)
 * - Scene 02: Point of View beside monochrome editorial photography
 * - Scene 03: Oversized Philosophy Statement (`GOOD SOFTWARE GIVES PEOPLE THEIR ATTENTION BACK.`)
 * - Scene 04: Five Principles presented as ZLL-inspired dramatic chapter scenes
 * - Scene 05: Selected Work / ORVA Case 001 + interactive horizontal product rail
 * - Scene 06: Two-column Product Concerns & Engineering Commitments split
 * - Scene 07: Asymmetric Visual Field Notes image mosaic
 * - Scene 08: Deep Dive / ORVA horizontal feature row
 * - Scene 09: Settings-driven Contact + `RINDLE WORKS` film-end closing + Shared Apothecary Frieze
 */
@Composable
fun AboutUsScreen(
  state: AboutShowcaseUiState,
  reducedMotion: Boolean,
  onEvent: (ShowcaseUiEvent) -> Unit,
  modifier: Modifier = Modifier,
) {
  val scrollState = rememberScrollState()
  val scope = rememberCoroutineScope()
  val density = LocalDensity.current
  val lifecycleOwner = LocalLifecycleOwner.current

  val controller =
    remember(reducedMotion) {
      AgenticBuildController(scrollState = scrollState, reducedMotion = reducedMotion)
    }

  var viewportHeightPx by remember { mutableFloatStateOf(1600f) }

  DisposableEffect(lifecycleOwner, controller) {
    val observer = LifecycleEventObserver { _, event ->
      when (event) {
        Lifecycle.Event.ON_PAUSE, Lifecycle.Event.ON_STOP -> controller.onLifecyclePaused(true)
        Lifecycle.Event.ON_RESUME -> controller.onLifecyclePaused(false)
        else -> Unit
      }
    }
    lifecycleOwner.lifecycle.addObserver(observer)
    onDispose {
      controller.onLifecyclePaused(true)
      lifecycleOwner.lifecycle.removeObserver(observer)
    }
  }

  LaunchedEffect(controller) {
    controller.runOrchestrator(this)
  }

  val scrollProgress =
    if (scrollState.maxValue > 0) {
      (scrollState.value.toFloat() / scrollState.maxValue.toFloat()).coerceIn(0f, 1f)
    } else {
      0f
    }

  val palette = currentShowcasePalette()
  CompositionLocalProvider(LocalAgenticController provides controller) {
    Box(
      modifier =
        modifier
          .fillMaxSize()
          .background(palette.canvasDeep)
          .onGloballyPositioned { coords ->
            controller.stageRootTopInRootPx = coords.positionInRoot().y
          }
          .onSizeChanged { size ->
            viewportHeightPx = size.height.toFloat().coerceAtLeast(1f)
            controller.onViewportSized(
              widthPx = size.width.toFloat(),
              heightPx = size.height.toFloat(),
              density = density.density,
            )
          }
          .pointerInput(controller) {
            awaitEachGesture {
              val down = awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
              controller.visitorTouchContentPos =
                Offset(down.position.x, down.position.y + scrollState.value.toFloat())
              try {
                while (true) {
                  val event = awaitPointerEvent(pass = PointerEventPass.Initial)
                  val active = event.changes.firstOrNull { it.pressed }
                  if (active != null) {
                    val deltaY = kotlin.math.abs(active.position.y - down.position.y)
                    if (deltaY > 18f) {
                      controller.onUserManualScroll()
                    }
                    controller.visitorTouchContentPos =
                      Offset(active.position.x, active.position.y + scrollState.value.toFloat())
                  } else {
                    break
                  }
                }
              } finally {
                controller.visitorTouchContentPos = null
              }
            }
          },
    ) {
      val heroHeightDp = with(density) { viewportHeightPx.toDp().coerceAtLeast(520.dp) }
      Column(
        modifier =
          Modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(bottom = 104.dp)
            .testTag("about_scroll_container"),
      ) {
        // Full-Viewport 7-Phase Deterministic Hero Intro (Ball Drop -> ! -> RINDLE -> PORTFOLIO -> FloatArray Particle Portrait + Scroll Dispersion)
        AboutIntroHeroSection(
          config = AboutIntroConfig(showTopHeader = false),
          replayToken = if (controller.act == com.rindleworks.orva.ui.about.agentic.BuildAct.ORBITAL_SCAN) 1 else 0,
          scrollProgressProvider = {
            if (viewportHeightPx <= 1f) 0f
            else (scrollState.value.toFloat() / (viewportHeightPx * 0.72f)).coerceIn(0f, 1.35f)
          },
          reducedMotion = reducedMotion,
          onCtaClick = { onEvent(ShowcaseUiEvent.StartBilling) },
          onNavClick = { label ->
            if (label == "HOME") onEvent(ShowcaseUiEvent.BackToHome)
            else if (label == "ORVA") onEvent(ShowcaseUiEvent.StartBilling)
          },
          modifier = Modifier.fillMaxWidth().height(heroHeightDp),
        )

        // Scene 01 — Studio Identity Hero (with zll.me scroll parallax scale-up & fade)
        Scene01StudioHero(
          state = state,
          viewportHeightPx = viewportHeightPx,
          reducedMotion = reducedMotion,
        )

        // Scene 02 — Who We Are / Point of View
        Scene02PointOfView(language = state.language)

        // ZLL-inspired -1.8° Tilted Dual-Track Kinetic Ribbon (solid left / hollow stroke right)
        TiltedDualMarqueeRibbon(reducedMotion = reducedMotion)

        // Scene 03 — Philosophy Statement (scroll-driven word-by-word illumination 0.22 -> 1.0)
        Scene03PhilosophyStatement(
          language = state.language,
          viewportHeightPx = viewportHeightPx,
          reducedMotion = reducedMotion,
        )

        // Scene 04 — Five Principles (scroll-scrubbed chapters + live word-by-word re-typing)
        Scene04PrincipleChapters(
          language = state.language,
          viewportHeightPx = viewportHeightPx,
          reducedMotion = reducedMotion,
        )

        // Scene 05 — Selected Work / ORVA Case 001 + Horizontal Rail
        Scene05SelectedWorkOrva(language = state.language)

        // Scene 06 — Product Concerns & Engineering Commitments Split
        Scene06ProductAndEngineeringSplit(language = state.language)

        // Scene 07 — Asymmetric Field Notes Image Mosaic
        Scene07FieldNotesMosaic(language = state.language)

        // Scene 08 — Deep Dive / ORVA Feature Row
        Scene08DeepDiveOrva(
          language = state.language,
          onExploreOrva = { onEvent(ShowcaseUiEvent.StartBilling) },
        )

        // Scene 09 — Settings-Driven Contact + Film-End `RINDLE WORKS` Closing
        Scene09ContactAndFilmClosing(
          state = state,
          onStartBilling = { onEvent(ShowcaseUiEvent.StartBilling) },
          onBackToHome = { onEvent(ShowcaseUiEvent.BackToHome) },
        )

        // Shared Closing Bar + Scroll-Controlled Monochrome Apothecary Frieze
        OrvaClosingFriezeSection(
          appVersion = state.appVersion,
          language = state.language,
          isAboutScreen = true,
          reducedMotion = reducedMotion,
          viewportHeightPx = viewportHeightPx,
          onStartBilling = { onEvent(ShowcaseUiEvent.StartBilling) },
          onSecondaryNav = { onEvent(ShowcaseUiEvent.BackToHome) },
          onBackToTop = {
            scope.launch {
              controller.onUserManualScroll()
              scrollState.animateScrollTo(0)
            }
          },
          friezeModifier = Modifier.agenticNode(id = "about_frieze_media", kind = LayerKind.MEDIA),
        )
      }

      // Top 1.5dp Vermilion-to-Violet editorial scroll hairline
      Box(
        modifier =
          Modifier
            .align(Alignment.TopStart)
            .fillMaxWidth(scrollProgress)
            .height(1.5.dp)
            .background(
              Brush.horizontalGradient(
                listOf(OrvaShowcaseColors.AccentVermilion, OrvaShowcaseColors.AccentViolet),
              )
            ),
      )

      // Live Agentic Build Overlay Canvas (draw-phase only, touches pass through cleanly)
      AgenticOverlayCanvas(
        controller = controller,
        modifier = Modifier.matchParentSize(),
      )

      // Floating bottom Agentic Build HUD
      AgenticHudBar(
        controller = controller,
        language = state.language,
        modifier = Modifier.align(Alignment.BottomCenter),
      )
    }
  }
}

@Composable
private fun Scene01StudioHero(
  state: AboutShowcaseUiState,
  viewportHeightPx: Float,
  reducedMotion: Boolean,
) {
  val palette = currentShowcasePalette()
  var topInWindowPx by remember { mutableFloatStateOf(0f) }
  Column(
    modifier =
      Modifier
        .fillMaxWidth()
        .widthIn(max = 960.dp)
        .padding(horizontal = 24.dp, vertical = 32.dp)
        .onGloballyPositioned { coords -> topInWindowPx = coords.positionInWindow().y }
        .graphicsLayer {
          if (!reducedMotion && topInWindowPx < 0f && viewportHeightPx > 1f) {
            val exitP = (-topInWindowPx / (viewportHeightPx * 0.85f)).coerceIn(0f, 1f)
            val s = 1f + exitP * 0.06f
            scaleX = s
            scaleY = s
            alpha = (1f - exitP * 0.72f).coerceIn(0.28f, 1f)
          }
        }
        .agenticNode(id = "about_hero_container", kind = LayerKind.CONTAINER),
    verticalArrangement = Arrangement.spacedBy(20.dp),
  ) {
    Row(
      modifier =
        Modifier
          .fillMaxWidth()
          .agenticNode(id = "about_hero_meta", kind = LayerKind.TEXT, parentId = "about_hero_container"),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Text(
        text = OrvaShowcaseCopy.aboutMetaLeft(state.language),
        fontFamily = OrvaShowcaseFonts.mono(state.language),
        fontSize = 10.5.sp,
        letterSpacing = 1.6.sp,
        color = OrvaShowcaseColors.AccentVermilion,
      )
      Text(
        text = "SCENE 01 / 09",
        fontFamily = OrvaShowcaseFonts.IbmPlexMono,
        fontSize = 10.5.sp,
        letterSpacing = 1.4.sp,
        color = OrvaShowcaseColors.InkMuted,
      )
    }

    Text(
      text = OrvaShowcaseCopy.aboutHeadline(state.language),
      fontFamily = OrvaShowcaseFonts.display(state.language),
      fontWeight = FontWeight.Bold,
      fontSize = 54.sp,
      lineHeight = 54.sp,
      letterSpacing = (-1.4).sp,
      color = OrvaShowcaseColors.InkPrimary,
      modifier =
        Modifier
          .agenticNode(id = "about_hero_headline", kind = LayerKind.TEXT, parentId = "about_hero_container")
          .testTag("about_hero_headline"),
    )

    Text(
      text = OrvaShowcaseCopy.aboutLead(state.language),
      fontFamily = OrvaShowcaseFonts.body(state.language),
      fontSize = 17.sp,
      lineHeight = 26.sp,
      color = OrvaShowcaseColors.InkSecondary,
      modifier =
        Modifier.agenticNode(
          id = "about_hero_lead",
          kind = LayerKind.TEXT,
          parentId = "about_hero_container",
        ),
    )

    Box(
      modifier =
        Modifier
          .fillMaxWidth()
          .height(210.dp)
          .border(1.dp, OrvaShowcaseColors.Hairline)
          .agenticNode(id = "about_hero_media", kind = LayerKind.MEDIA, parentId = "about_hero_container"),
    ) {
      Image(
        painter = painterResource(id = R.drawable.editorial_studio_workbench),
        contentDescription = "Minimal monochrome product design workbench",
        contentScale = ContentScale.Crop,
        modifier = Modifier.fillMaxSize(),
      )
      Text(
        text = "RINDLE WORKS · V${state.appVersion}",
        fontFamily = OrvaShowcaseFonts.IbmPlexMono,
        fontSize = 9.5.sp,
        letterSpacing = 1.4.sp,
        color = OrvaShowcaseColors.InkPrimary.copy(alpha = 0.85f),
        modifier =
          Modifier
            .align(Alignment.BottomStart)
            .background(OrvaShowcaseColors.CanvasDeep.copy(alpha = 0.78f))
            .padding(horizontal = 10.dp, vertical = 5.dp),
      )
    }
  }
}

@Composable
private fun Scene02PointOfView(language: AppLanguage) {
  Column(
    modifier =
      Modifier
        .fillMaxWidth()
        .agenticNode(id = "about_pov_container", kind = LayerKind.CONTAINER),
  ) {
    HorizontalDivider(
      thickness = 1.dp,
      color = OrvaShowcaseColors.Hairline,
      modifier = Modifier.agenticNode(id = "about_pov_rule", kind = LayerKind.LINE, parentId = "about_pov_container"),
    )

    BoxWithConstraints(
      modifier =
        Modifier
          .fillMaxWidth()
          .widthIn(max = 960.dp)
          .align(Alignment.CenterHorizontally)
          .padding(horizontal = 24.dp, vertical = 40.dp),
    ) {
      val wide = maxWidth >= 660.dp
      if (wide) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(28.dp),
          verticalAlignment = Alignment.Top,
        ) {
          PovMediaCard(modifier = Modifier.weight(0.42f))
          PovCopyColumn(language = language, modifier = Modifier.weight(0.58f))
        }
      } else {
        Column(verticalArrangement = Arrangement.spacedBy(20.dp)) {
          PovCopyColumn(language = language)
          PovMediaCard(modifier = Modifier.fillMaxWidth())
        }
      }
    }
  }
}

@Composable
private fun PovMediaCard(modifier: Modifier = Modifier) {
  Box(
    modifier =
      modifier
        .height(230.dp)
        .border(1.dp, OrvaShowcaseColors.Hairline)
        .agenticNode(id = "about_pov_media", kind = LayerKind.MEDIA, parentId = "about_pov_container"),
  ) {
    Image(
      painter = painterResource(id = R.drawable.editorial_apothecary_shelves),
      contentDescription = "Monochrome apothecary glass shelving",
      contentScale = ContentScale.Crop,
      modifier = Modifier.fillMaxSize(),
    )
    Text(
      text = "FIG. 01 — REAL WORKFLOWS",
      fontFamily = OrvaShowcaseFonts.IbmPlexMono,
      fontSize = 9.5.sp,
      letterSpacing = 1.3.sp,
      color = OrvaShowcaseColors.InkPrimary.copy(alpha = 0.8f),
      modifier =
        Modifier
          .align(Alignment.BottomStart)
          .background(OrvaShowcaseColors.CanvasDeep.copy(alpha = 0.78f))
          .padding(horizontal = 8.dp, vertical = 4.dp),
    )
  }
}

@Composable
private fun PovCopyColumn(language: AppLanguage, modifier: Modifier = Modifier) {
  Column(modifier = modifier, verticalArrangement = Arrangement.spacedBy(14.dp)) {
    Text(
      text = OrvaShowcaseCopy.aboutStoryLabel(language),
      fontFamily = OrvaShowcaseFonts.mono(language),
      fontSize = 11.sp,
      letterSpacing = 1.6.sp,
      color = OrvaShowcaseColors.AccentVermilion,
      modifier =
        Modifier.agenticNode(
          id = "about_pov_label",
          kind = LayerKind.TEXT,
          parentId = "about_pov_container",
        ),
    )
    Text(
      text = OrvaShowcaseCopy.aboutStoryParagraph1(language),
      fontFamily = OrvaShowcaseFonts.body(language),
      fontSize = 16.5.sp,
      lineHeight = 26.sp,
      color = OrvaShowcaseColors.InkPrimary,
      modifier =
        Modifier.agenticNode(
          id = "about_pov_p1",
          kind = LayerKind.TEXT,
          parentId = "about_pov_container",
        ),
    )
    Text(
      text = OrvaShowcaseCopy.aboutStoryParagraph2(language),
      fontFamily = OrvaShowcaseFonts.body(language),
      fontSize = 15.sp,
      lineHeight = 24.sp,
      color = OrvaShowcaseColors.InkSecondary,
      modifier =
        Modifier.agenticNode(
          id = "about_pov_p2",
          kind = LayerKind.TEXT,
          parentId = "about_pov_container",
        ),
    )
  }
}

/**
 * Scene 03 — Full Editorial Philosophy Statement (Master Directive §4.1 Scene 03).
 */
@Composable
private fun Scene03PhilosophyStatement(
  language: AppLanguage,
  viewportHeightPx: Float,
  reducedMotion: Boolean,
) {
  val palette = currentShowcasePalette()
  var bandTopPx by remember { mutableFloatStateOf(viewportHeightPx) }
  var bandHeightPx by remember { mutableFloatStateOf(420f) }
  val revealProgress =
    if (reducedMotion || viewportHeightPx <= 1f) {
      1f
    } else {
      val enterStart = viewportHeightPx * 0.90f
      val enterEnd = viewportHeightPx * 0.22f
      ((enterStart - bandTopPx) / (enterStart - enterEnd + bandHeightPx * 0.35f).coerceAtLeast(1f)).coerceIn(0f, 1f)
    }

  Box(
    modifier =
      Modifier
        .fillMaxWidth()
        .background(palette.canvasSecondary)
        .clipToBounds()
        .onGloballyPositioned { coords ->
          bandTopPx = coords.positionInWindow().y
          bandHeightPx = coords.size.height.toFloat().coerceAtLeast(1f)
        }
        .agenticNode(id = "about_philosophy_container", kind = LayerKind.CONTAINER),
  ) {
    HorizontalDivider(
      thickness = 1.dp,
      color = OrvaShowcaseColors.Hairline,
      modifier = Modifier.align(Alignment.TopCenter),
    )

    // Giant low-contrast outlined backdrop lettering
    Text(
      text = "INTENTION",
      style =
        TextStyle(
          fontFamily = OrvaShowcaseFonts.SpaceGrotesk,
          fontWeight = FontWeight.Bold,
          fontSize = 110.sp,
          letterSpacing = (-3).sp,
          color = OrvaShowcaseColors.InkPrimary.copy(alpha = 0.045f),
          drawStyle = Stroke(width = 2.5f),
        ),
      maxLines = 1,
      softWrap = false,
      modifier = Modifier.align(Alignment.Center),
    )

    Column(
      modifier =
        Modifier
          .fillMaxWidth()
          .widthIn(max = 960.dp)
          .align(Alignment.Center)
          .padding(horizontal = 24.dp, vertical = 56.dp),
      verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
      Text(
        text = "03 / PHILOSOPHY",
        fontFamily = OrvaShowcaseFonts.IbmPlexMono,
        fontSize = 10.5.sp,
        letterSpacing = 1.6.sp,
        color = OrvaShowcaseColors.InkMuted,
      )
      Column(
        modifier =
          Modifier.agenticNode(
            id = "about_philosophy_headline",
            kind = LayerKind.TEXT,
            parentId = "about_philosophy_container",
          ),
      ) {
        val leadWords = remember(language) { OrvaShowcaseCopy.philosophyLead(language).split(" ") }
        val accentWords = remember(language) { OrvaShowcaseCopy.philosophyAccent(language).split(" ") }
        val supportWords = remember(language) { OrvaShowcaseCopy.philosophySupport(language).split(" ") }
        val totalWords = (leadWords.size + accentWords.size + supportWords.size).coerceAtLeast(1)

        Text(
          text =
            buildAnnotatedString {
              leadWords.forEachIndexed { i, word ->
                val wordP = ((revealProgress * totalWords - i) / 1.8f).coerceIn(0f, 1f)
                val alpha = 0.22f + 0.78f * wordP
                withStyle(SpanStyle(color = palette.inkPrimary.copy(alpha = alpha))) {
                  append(word)
                  if (i < leadWords.lastIndex) append(" ")
                }
              }
            },
          fontFamily = OrvaShowcaseFonts.display(language),
          fontWeight = FontWeight.Bold,
          fontSize = 36.sp,
          lineHeight = 40.sp,
          letterSpacing = (-1.1).sp,
        )
        Text(
          text =
            buildAnnotatedString {
              accentWords.forEachIndexed { i, word ->
                val globalIdx = leadWords.size + i
                val wordP = ((revealProgress * totalWords - globalIdx) / 1.8f).coerceIn(0f, 1f)
                val alpha = 0.22f + 0.78f * wordP
                withStyle(SpanStyle(color = OrvaShowcaseColors.AccentVermilion.copy(alpha = alpha))) {
                  append(word)
                  if (i < accentWords.lastIndex) append(" ")
                }
              }
            },
          fontFamily = OrvaShowcaseFonts.display(language),
          fontWeight = FontWeight.Bold,
          fontSize = 36.sp,
          lineHeight = 40.sp,
          letterSpacing = (-1.1).sp,
        )
      }
      val supportWords = remember(language) { OrvaShowcaseCopy.philosophySupport(language).split(" ") }
      val headCount =
        remember(language) {
          OrvaShowcaseCopy.philosophyLead(language).split(" ").size +
            OrvaShowcaseCopy.philosophyAccent(language).split(" ").size
        }
      val totalManifestoWords = (headCount + supportWords.size).coerceAtLeast(1)
      Text(
        text =
          buildAnnotatedString {
            supportWords.forEachIndexed { i, word ->
              val globalIdx = headCount + i
              val wordP = ((revealProgress * totalManifestoWords - globalIdx) / 2.2f).coerceIn(0f, 1f)
              val alpha = 0.22f + 0.78f * wordP
              withStyle(SpanStyle(color = palette.inkSecondary.copy(alpha = alpha))) {
                append(word)
                if (i < supportWords.lastIndex) append(" ")
              }
            }
          },
        fontFamily = OrvaShowcaseFonts.body(language),
        fontSize = 15.5.sp,
        lineHeight = 25.sp,
        modifier =
          Modifier
            .widthIn(max = 560.dp)
            .agenticNode(
              id = "about_philosophy_body",
              kind = LayerKind.TEXT,
              parentId = "about_philosophy_container",
            ),
      )
    }

    HorizontalDivider(
      thickness = 1.dp,
      color = OrvaShowcaseColors.Hairline,
      modifier = Modifier.align(Alignment.BottomCenter),
    )
  }
}

/**
 * Scene 04 — Five Principles presented as ZLL-inspired Dramatic Chapter Scenes
 * (Master Directive §4.1 Scene 04 & §7.3).
 */
@Composable
private fun Scene04PrincipleChapters(
  language: AppLanguage,
  viewportHeightPx: Float,
  reducedMotion: Boolean,
) {
  val palette = currentShowcasePalette()
  val principles = remember(language) { OrvaShowcaseCopy.aboutPrinciples(language) }
  var selectedIndex by remember { mutableStateOf(0) }
  var userPinnedChapter by remember { mutableStateOf(false) }

  // Live word-by-word re-typing on chapter transitions (zll.me Knowledge chapter cue)
  val activePrinciple = principles[selectedIndex.coerceIn(0, principles.lastIndex)]
  val descWords = remember(activePrinciple.description) { activePrinciple.description.split(" ") }
  var typedWordCount by remember(selectedIndex, language) {
    mutableStateOf(if (reducedMotion) descWords.size else 0)
  }
  var caretVisible by remember { mutableStateOf(true) }

  LaunchedEffect(selectedIndex, language, reducedMotion) {
    if (reducedMotion) {
      typedWordCount = descWords.size
      return@LaunchedEffect
    }
    typedWordCount = 0
    for (w in 1..descWords.size) {
      delay(26L)
      typedWordCount = w
    }
  }

  LaunchedEffect(reducedMotion) {
    if (reducedMotion) {
      caretVisible = false
      return@LaunchedEffect
    }
    while (true) {
      delay(550L)
      caretVisible = !caretVisible
    }
  }

  Column(
    modifier =
      Modifier
        .fillMaxWidth()
        .widthIn(max = 960.dp)
        .padding(horizontal = 24.dp, vertical = 44.dp)
        .onGloballyPositioned { coords ->
          // Scroll-scrub chapters smoothly as the band travels through the viewport (yields on manual tap)
          if (!reducedMotion && !userPinnedChapter && viewportHeightPx > 1f) {
            val topY = coords.positionInWindow().y
            val heightPx = coords.size.height.toFloat().coerceAtLeast(1f)
            val scrub = ((viewportHeightPx * 0.72f - topY) / (heightPx + viewportHeightPx * 0.25f)).coerceIn(0f, 0.999f)
            val scrubbedIdx = (scrub * principles.size).toInt().coerceIn(0, principles.lastIndex)
            if (scrubbedIdx != selectedIndex) {
              selectedIndex = scrubbedIdx
            }
          }
        }
        .agenticNode(id = "about_principles_container", kind = LayerKind.CONTAINER),
    verticalArrangement = Arrangement.spacedBy(20.dp),
  ) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Text(
        text = OrvaShowcaseCopy.aboutPrinciplesLabel(language),
        fontFamily = OrvaShowcaseFonts.mono(language),
        fontSize = 11.sp,
        letterSpacing = 1.6.sp,
        color = OrvaShowcaseColors.AccentVermilion,
        modifier =
          Modifier.agenticNode(
            id = "about_principles_heading",
            kind = LayerKind.TEXT,
            parentId = "about_principles_container",
          ),
      )
      Text(
        text = "0${selectedIndex + 1} / 05",
        fontFamily = OrvaShowcaseFonts.IbmPlexMono,
        fontSize = 11.sp,
        letterSpacing = 1.4.sp,
        color = OrvaShowcaseColors.InkMuted,
      )
    }

    // Accessible 01..05 chapter selector strip (preserves about_wave_node_1..5 testTags)
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
    ) {
      principles.forEachIndexed { idx, principle ->
        val interaction = remember { MutableInteractionSource() }
        val focused by interaction.collectIsFocusedAsState()
        LaunchedEffect(focused) {
          if (focused) selectedIndex = idx
        }
        val isSelected = idx == selectedIndex
        Box(
          modifier =
            Modifier
              .minimumInteractiveComponentSize()
              .focusable(interactionSource = interaction)
              .semantics {
                selected = isSelected
                contentDescription = principle.title
              }
              .border(
                width = 1.dp,
                color = if (isSelected) OrvaShowcaseColors.AccentVermilion else OrvaShowcaseColors.Hairline,
              )
              .background(if (isSelected) OrvaShowcaseColors.AccentVermilionWash else Color.Transparent)
              .clickable(
                interactionSource = interaction,
                indication = null,
                role = Role.Button,
                onClick = { userPinnedChapter = true; selectedIndex = idx },
              )
              .padding(horizontal = 12.dp, vertical = 8.dp)
              .testTag("about_wave_node_${idx + 1}"),
          contentAlignment = Alignment.Center,
        ) {
          Text(
            text = principle.number,
            fontFamily = OrvaShowcaseFonts.IbmPlexMono,
            fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Normal,
            fontSize = 11.5.sp,
            color = if (isSelected) OrvaShowcaseColors.AccentVermilion else OrvaShowcaseColors.InkMuted,
          )
        }
      }
    }

    // ZLL-style full-height single-focus editorial chapter stage (borderless dark/paper grid, giant 156sp hollow numeral)
    Box(
      modifier =
        Modifier
          .fillMaxWidth()
          .height(360.dp)
          .clipToBounds()
          .agenticNode(
            id = "about_principle_${selectedIndex + 1}",
            kind = LayerKind.CONTAINER,
            parentId = "about_principles_container",
            cloneGroupId = "principles",
            cloneIndex = selectedIndex,
          )
          .testTag("about_principle_card_${selectedIndex + 1}"),
    ) {
      // Giant 156sp low-contrast outlined chapter numeral centered behind headline
      Text(
        text = activePrinciple.number,
        style =
          TextStyle(
            fontFamily = OrvaShowcaseFonts.SpaceGrotesk,
            fontWeight = FontWeight.Bold,
            fontSize = 156.sp,
            letterSpacing = (-5).sp,
            color = OrvaShowcaseColors.AccentVermilion.copy(alpha = 0.14f),
            drawStyle = Stroke(width = 2.6f),
          ),
        modifier = Modifier.align(Alignment.Center),
      )

      // Slim vertical chapter progress scrub rail on right edge
      Box(
        modifier =
          Modifier
            .align(Alignment.CenterEnd)
            .width(2.dp)
            .fillMaxHeight(0.72f)
            .background(OrvaShowcaseColors.Hairline),
      ) {
        Box(
          modifier =
            Modifier
              .align(Alignment.TopCenter)
              .fillMaxWidth()
              .fillMaxHeight((selectedIndex + 1).toFloat() / principles.size.toFloat())
              .background(OrvaShowcaseColors.AccentVermilion),
        )
      }

      Column(
        modifier = Modifier.align(Alignment.Center).padding(horizontal = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(14.dp),
      ) {
        Text(
          text = "(${activePrinciple.number}) PRINCIPLE",
          fontFamily = OrvaShowcaseFonts.IbmPlexMono,
          fontSize = 10.5.sp,
          letterSpacing = 1.8.sp,
          color = OrvaShowcaseColors.AccentVermilion,
        )
        Text(
          text = activePrinciple.title,
          fontFamily = OrvaShowcaseFonts.display(language),
          fontWeight = FontWeight.Bold,
          fontSize = 32.sp,
          lineHeight = 35.sp,
          letterSpacing = (-1).sp,
          textAlign = TextAlign.Center,
          color = OrvaShowcaseColors.InkPrimary,
          modifier =
            Modifier.agenticNode(
              id = "about_principle_${selectedIndex + 1}_title",
              kind = LayerKind.TEXT,
              parentId = "about_principle_${selectedIndex + 1}",
            ),
        )
        val liveTypedDesc =
          buildAnnotatedString {
            val shown = descWords.take(typedWordCount.coerceIn(0, descWords.size)).joinToString(" ")
            withStyle(SpanStyle(color = palette.inkSecondary)) { append(shown) }
            if (!reducedMotion && (typedWordCount < descWords.size || caretVisible)) {
              withStyle(SpanStyle(color = OrvaShowcaseColors.AccentVermilion)) { append(" ▏") }
            }
          }
        Text(
          text = liveTypedDesc,
          fontFamily = OrvaShowcaseFonts.body(language),
          fontSize = 15.sp,
          lineHeight = 23.sp,
          textAlign = TextAlign.Center,
          modifier =
            Modifier
              .widthIn(max = 420.dp)
              .agenticNode(
                id = "about_principle_${selectedIndex + 1}_desc",
                kind = LayerKind.TEXT,
                parentId = "about_principle_${selectedIndex + 1}",
              ),
        )
      }

      Text(
        text = "${activePrinciple.number} / 0${principles.size}",
        fontFamily = OrvaShowcaseFonts.IbmPlexMono,
        fontSize = 11.sp,
        letterSpacing = 1.5.sp,
        color = OrvaShowcaseColors.InkMuted,
        modifier = Modifier.align(Alignment.BottomStart),
      )
    }
  }
}

@Composable
private fun PrincipleChapterPanel(
  principle: PrincipleCopy,
  index: Int,
  total: Int,
  isActive: Boolean,
  language: AppLanguage,
  onSelect: () -> Unit,
) {
  val nodeId = "about_principle_${index + 1}"
  Box(
    modifier =
      Modifier
        .fillMaxWidth()
        .height(210.dp)
        .agenticNode(
          id = nodeId,
          kind = LayerKind.CONTAINER,
          parentId = "about_principles_container",
          cloneGroupId = "principles",
          cloneIndex = index,
        )
        .border(
          width = 1.dp,
          color = if (isActive) OrvaShowcaseColors.AccentVermilion else OrvaShowcaseColors.Hairline,
        )
        .background(if (isActive) OrvaShowcaseColors.SurfaceRaised else OrvaShowcaseColors.CanvasSecondary)
        .clipToBounds()
        .clickable(role = Role.Button, onClick = onSelect)
        .padding(20.dp)
        .testTag("about_principle_card_${index + 1}"),
  ) {
    // Giant low-contrast outlined chapter numeral behind central title (ZLL Knowledge cue)
    Text(
      text = principle.number,
      style =
        TextStyle(
          fontFamily = OrvaShowcaseFonts.SpaceGrotesk,
          fontWeight = FontWeight.Bold,
          fontSize = 126.sp,
          letterSpacing = (-4).sp,
          color =
            if (isActive) OrvaShowcaseColors.AccentVermilion.copy(alpha = 0.14f)
            else OrvaShowcaseColors.InkPrimary.copy(alpha = 0.06f),
          drawStyle = Stroke(width = 2.5f),
        ),
      modifier = Modifier.align(Alignment.CenterEnd),
    )

    // Slim vertical chapter progress rail on right edge
    Box(
      modifier =
        Modifier
          .align(Alignment.CenterEnd)
          .width(2.dp)
          .fillMaxHeight(0.68f)
          .background(OrvaShowcaseColors.Hairline),
    ) {
      Box(
        modifier =
          Modifier
            .align(Alignment.TopCenter)
            .fillMaxWidth()
            .fillMaxHeight((index + 1).toFloat() / total.toFloat())
            .background(if (isActive) OrvaShowcaseColors.AccentVermilion else OrvaShowcaseColors.AccentViolet),
      )
    }

    Column(
      modifier = Modifier.fillMaxSize().padding(end = 20.dp),
      verticalArrangement = Arrangement.SpaceBetween,
    ) {
      Text(
        text = "(${principle.number}) PRINCIPLE",
        fontFamily = OrvaShowcaseFonts.IbmPlexMono,
        fontSize = 10.sp,
        letterSpacing = 1.5.sp,
        color = if (isActive) OrvaShowcaseColors.AccentVermilion else OrvaShowcaseColors.InkMuted,
      )

      Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(
          text = principle.title,
          fontFamily = OrvaShowcaseFonts.display(language),
          fontWeight = FontWeight.Bold,
          fontSize = 22.sp,
          lineHeight = 26.sp,
          letterSpacing = (-0.5).sp,
          color = OrvaShowcaseColors.InkPrimary,
          modifier =
            Modifier.agenticNode(
              id = "${nodeId}_title",
              kind = LayerKind.TEXT,
              parentId = nodeId,
            ),
        )
        Text(
          text = principle.description,
          fontFamily = OrvaShowcaseFonts.body(language),
          fontSize = 14.sp,
          lineHeight = 21.sp,
          color = OrvaShowcaseColors.InkSecondary,
          modifier =
            Modifier.agenticNode(
              id = "${nodeId}_desc",
              kind = LayerKind.TEXT,
              parentId = nodeId,
            ),
        )
      }

      Text(
        text = "${principle.number} / 0$total",
        fontFamily = OrvaShowcaseFonts.IbmPlexMono,
        fontSize = 10.sp,
        letterSpacing = 1.3.sp,
        color = OrvaShowcaseColors.InkMuted,
      )
    }
  }
}

/**
 * Scene 05 — Selected Work / ORVA Case 001 + Horizontal Product Rail (Master Directive §4.1 Scene 05 & §7.4).
 */
@Composable
private fun Scene05SelectedWorkOrva(language: AppLanguage) {
  val railItems = remember(language) { OrvaShowcaseCopy.orvaCaseRail(language) }

  Column(
    modifier =
      Modifier
        .fillMaxWidth()
        .background(OrvaShowcaseColors.CanvasSecondary)
        .agenticNode(id = "about_selected_orva_container", kind = LayerKind.CONTAINER),
  ) {
    HorizontalDivider(thickness = 1.dp, color = OrvaShowcaseColors.Hairline)

    Column(
      modifier =
        Modifier
          .fillMaxWidth()
          .widthIn(max = 960.dp)
          .align(Alignment.CenterHorizontally)
          .padding(horizontal = 24.dp, vertical = 44.dp),
      verticalArrangement = Arrangement.spacedBy(18.dp),
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Text(
          text = OrvaShowcaseCopy.selectedWorkEyebrow(language),
          fontFamily = OrvaShowcaseFonts.mono(language),
          fontSize = 10.5.sp,
          letterSpacing = 1.6.sp,
          color = OrvaShowcaseColors.AccentVermilion,
        )
        Text(
          text = OrvaShowcaseCopy.flagshipStateLabel(language),
          fontFamily = OrvaShowcaseFonts.mono(language),
          fontSize = 10.sp,
          letterSpacing = 1.2.sp,
          color = OrvaShowcaseColors.AccentVioletSoft,
        )
      }

      Text(
        text = OrvaShowcaseCopy.selectedWorkStatement(language),
        fontFamily = OrvaShowcaseFonts.display(language),
        fontWeight = FontWeight.Bold,
        fontSize = 32.sp,
        lineHeight = 36.sp,
        letterSpacing = (-0.8).sp,
        color = OrvaShowcaseColors.InkPrimary,
        modifier =
          Modifier.agenticNode(
            id = "about_selected_orva_headline",
            kind = LayerKind.TEXT,
            parentId = "about_selected_orva_container",
          ),
      )

      Text(
        text = OrvaShowcaseCopy.selectedWorkBody1(language),
        fontFamily = OrvaShowcaseFonts.body(language),
        fontSize = 15.5.sp,
        lineHeight = 24.sp,
        color = OrvaShowcaseColors.InkSecondary,
        modifier =
          Modifier.agenticNode(
            id = "about_selected_orva_p1",
            kind = LayerKind.TEXT,
            parentId = "about_selected_orva_container",
          ),
      )

      Text(
        text = OrvaShowcaseCopy.selectedWorkBody2(language),
        fontFamily = OrvaShowcaseFonts.body(language),
        fontSize = 14.5.sp,
        lineHeight = 23.sp,
        color = OrvaShowcaseColors.InkMuted,
      )

      // Horizontal scrollable portrait rail of real ORVA product areas (ZLL §7.4 cue)
      Row(
        modifier =
          Modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState())
            .padding(top = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(14.dp),
      ) {
        railItems.forEach { item ->
          OrvaRailCard(item = item, language = language)
        }
      }
    }

    HorizontalDivider(thickness = 1.dp, color = OrvaShowcaseColors.Hairline)
  }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun OrvaRailCard(item: OrvaCaseRailItem, language: AppLanguage) {
  Box(
    modifier =
      Modifier
        .width(248.dp)
        .height(270.dp)
        .border(1.dp, OrvaShowcaseColors.Hairline)
        .background(OrvaShowcaseColors.CanvasDeep)
        .clipToBounds()
        .padding(18.dp),
  ) {
    Text(
      text = item.index,
      style =
        TextStyle(
          fontFamily = OrvaShowcaseFonts.SpaceGrotesk,
          fontWeight = FontWeight.Bold,
          fontSize = 104.sp,
          color = OrvaShowcaseColors.InkPrimary.copy(alpha = 0.055f),
          drawStyle = Stroke(width = 2.2f),
        ),
      modifier = Modifier.align(Alignment.TopEnd),
    )

    Column(
      modifier = Modifier.fillMaxSize(),
      verticalArrangement = Arrangement.SpaceBetween,
    ) {
      Text(
        text = "${item.code} ↗",
        fontFamily = OrvaShowcaseFonts.IbmPlexMono,
        fontSize = 10.sp,
        letterSpacing = 1.4.sp,
        color = OrvaShowcaseColors.AccentVermilion,
      )

      Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(
          text = item.title,
          fontFamily = OrvaShowcaseFonts.display(language),
          fontWeight = FontWeight.SemiBold,
          fontSize = 20.sp,
          color = OrvaShowcaseColors.InkPrimary,
        )
        Text(
          text = item.summary,
          fontFamily = OrvaShowcaseFonts.body(language),
          fontSize = 13.sp,
          lineHeight = 19.sp,
          color = OrvaShowcaseColors.InkSecondary,
        )
      }

      FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        item.tags.forEach { tag ->
          Text(
            text = tag,
            fontFamily = OrvaShowcaseFonts.IbmPlexMono,
            fontSize = 9.sp,
            letterSpacing = 1.sp,
            color = OrvaShowcaseColors.InkMuted,
            modifier =
              Modifier
                .border(1.dp, OrvaShowcaseColors.Hairline)
                .padding(horizontal = 6.dp, vertical = 3.dp),
          )
        }
      }
    }
  }
}

/**
 * Scene 06 — Product Concerns & Engineering Commitments Split (Master Directive §4.1 Scene 06 & §7.6).
 */
@Composable
private fun Scene06ProductAndEngineeringSplit(language: AppLanguage) {
  val concerns = remember(language) { OrvaShowcaseCopy.productConcerns(language) }
  val commitments = remember(language) { OrvaShowcaseCopy.engineeringCommitments(language) }

  Column(
    modifier =
      Modifier
        .fillMaxWidth()
        .widthIn(max = 960.dp)
        .padding(horizontal = 24.dp, vertical = 44.dp)
        .agenticNode(id = "about_commitments_container", kind = LayerKind.CONTAINER),
    verticalArrangement = Arrangement.spacedBy(20.dp),
  ) {
    Text(
      text = "06 / ARCHITECTURE & COMMITMENTS",
      fontFamily = OrvaShowcaseFonts.IbmPlexMono,
      fontSize = 10.5.sp,
      letterSpacing = 1.6.sp,
      color = OrvaShowcaseColors.AccentVermilion,
    )

    BoxWithConstraints(modifier = Modifier.fillMaxWidth()) {
      val twoCols = maxWidth >= 640.dp
      if (twoCols) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(28.dp),
        ) {
          CommitmentColumn(
            title = if (language == AppLanguage.Bengali) "প্রোডাক্ট অগ্রাধিকার" else "PRODUCT CONCERNS",
            items = concerns,
            accent = OrvaShowcaseColors.AccentVermilion,
            language = language,
            nodeId = "about_commitments_left",
            modifier = Modifier.weight(1f),
          )
          CommitmentColumn(
            title = if (language == AppLanguage.Bengali) "ইঞ্জিনিয়ারিং অঙ্গীকার" else "ENGINEERING COMMITMENTS",
            items = commitments,
            accent = OrvaShowcaseColors.AccentVioletSoft,
            language = language,
            nodeId = "about_commitments_right",
            modifier = Modifier.weight(1f),
          )
        }
      } else {
        Column(verticalArrangement = Arrangement.spacedBy(28.dp)) {
          CommitmentColumn(
            title = if (language == AppLanguage.Bengali) "প্রোডাক্ট অগ্রাধিকার" else "PRODUCT CONCERNS",
            items = concerns,
            accent = OrvaShowcaseColors.AccentVermilion,
            language = language,
            nodeId = "about_commitments_left",
          )
          CommitmentColumn(
            title = if (language == AppLanguage.Bengali) "ইঞ্জিনিয়ারিং অঙ্গীকার" else "ENGINEERING COMMITMENTS",
            items = commitments,
            accent = OrvaShowcaseColors.AccentVioletSoft,
            language = language,
            nodeId = "about_commitments_right",
          )
        }
      }
    }
  }
}

@Composable
private fun CommitmentColumn(
  title: String,
  items: List<String>,
  accent: Color,
  language: AppLanguage,
  nodeId: String,
  modifier: Modifier = Modifier,
) {
  Column(
    modifier =
      modifier.agenticNode(
        id = nodeId,
        kind = LayerKind.TEXT,
        parentId = "about_commitments_container",
      ),
    verticalArrangement = Arrangement.spacedBy(10.dp),
  ) {
    Text(
      text = title,
      fontFamily = OrvaShowcaseFonts.mono(language),
      fontWeight = FontWeight.SemiBold,
      fontSize = 11.5.sp,
      letterSpacing = 1.4.sp,
      color = accent,
    )
    items.forEachIndexed { idx, line ->
      HorizontalDivider(thickness = 1.dp, color = OrvaShowcaseColors.Hairline)
      Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        verticalAlignment = Alignment.Top,
      ) {
        Text(
          text = "0${idx + 1}",
          fontFamily = OrvaShowcaseFonts.IbmPlexMono,
          fontSize = 10.sp,
          color = OrvaShowcaseColors.InkMuted,
        )
        Text(
          text = line,
          fontFamily = OrvaShowcaseFonts.body(language),
          fontSize = 14.sp,
          lineHeight = 20.sp,
          color = OrvaShowcaseColors.InkPrimary,
        )
      }
    }
  }
}

/**
 * Scene 07 — Asymmetric Field Notes Image Mosaic (Master Directive §4.1 Scene 07 & §7.7).
 */
@Composable
private fun Scene07FieldNotesMosaic(language: AppLanguage) {
  Column(
    modifier =
      Modifier
        .fillMaxWidth()
        .background(OrvaShowcaseColors.CanvasSecondary)
        .agenticNode(id = "about_mosaic_container", kind = LayerKind.CONTAINER),
  ) {
    HorizontalDivider(thickness = 1.dp, color = OrvaShowcaseColors.Hairline)

    Column(
      modifier =
        Modifier
          .fillMaxWidth()
          .widthIn(max = 960.dp)
          .align(Alignment.CenterHorizontally)
          .padding(horizontal = 24.dp, vertical = 44.dp),
      verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Text(
          text = "07 / FIELD NOTES",
          fontFamily = OrvaShowcaseFonts.IbmPlexMono,
          fontSize = 10.5.sp,
          letterSpacing = 1.6.sp,
          color = OrvaShowcaseColors.AccentVermilion,
        )
        Text(
          text = "INSIDE THE WORK",
          fontFamily = OrvaShowcaseFonts.IbmPlexMono,
          fontSize = 10.sp,
          letterSpacing = 1.4.sp,
          color = OrvaShowcaseColors.InkMuted,
        )
      }

      // Asymmetric 2-column staggered masonry (readable at 360dp, balanced on wider screens)
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalAlignment = Alignment.Top,
      ) {
        Column(
          modifier = Modifier.weight(1f),
          verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
          MosaicTile(
            drawableRes = R.drawable.editorial_apothecary_shelves,
            caption = "BATCH / INVENTORY",
            heightDp = 240,
            nodeId = "about_mosaic_1",
          )
          MosaicTile(
            drawableRes = R.drawable.editorial_studio_workbench,
            caption = "SYSTEM / DETAIL",
            heightDp = 160,
            nodeId = "about_mosaic_2",
          )
        }
        Column(
          modifier = Modifier.weight(1f),
          verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
          MosaicTile(
            drawableRes = R.drawable.editorial_thermal_counter,
            caption = "BILLING / WORKFLOW",
            heightDp = 168,
            nodeId = "about_mosaic_3",
          )
          MosaicTile(
            drawableRes = R.drawable.editorial_architecture_light,
            caption = "PRODUCT / INTERFACE",
            heightDp = 232,
            nodeId = "about_mosaic_4",
          )
        }
      }
    }

    HorizontalDivider(thickness = 1.dp, color = OrvaShowcaseColors.Hairline)
  }
}

@Composable
private fun MosaicTile(
  drawableRes: Int,
  caption: String,
  heightDp: Int,
  nodeId: String,
) {
  Box(
    modifier =
      Modifier
        .fillMaxWidth()
        .height(heightDp.dp)
        .border(1.dp, OrvaShowcaseColors.Hairline)
        .agenticNode(id = nodeId, kind = LayerKind.MEDIA, parentId = "about_mosaic_container"),
  ) {
    Image(
      painter = painterResource(id = drawableRes),
      contentDescription = caption,
      contentScale = ContentScale.Crop,
      modifier = Modifier.fillMaxSize(),
    )
    Box(
      modifier =
        Modifier
          .align(Alignment.BottomCenter)
          .fillMaxWidth()
          .background(
            Brush.verticalGradient(
              listOf(Color.Transparent, OrvaShowcaseColors.CanvasDeep.copy(alpha = 0.88f)),
            )
          )
          .padding(horizontal = 10.dp, vertical = 8.dp),
    ) {
      Text(
        text = caption,
        fontFamily = OrvaShowcaseFonts.IbmPlexMono,
        fontSize = 9.5.sp,
        letterSpacing = 1.2.sp,
        color = OrvaShowcaseColors.InkPrimary,
      )
    }
  }
}

/**
 * Scene 08 — Deep Dive / ORVA Horizontal Feature Row (Master Directive §4.1 Scene 08 & §7.8).
 */
@Composable
private fun Scene08DeepDiveOrva(
  language: AppLanguage,
  onExploreOrva: () -> Unit,
) {
  Column(
    modifier =
      Modifier
        .fillMaxWidth()
        .widthIn(max = 960.dp)
        .padding(horizontal = 24.dp, vertical = 44.dp)
        .agenticNode(id = "about_deep_dive_container", kind = LayerKind.CONTAINER),
    verticalArrangement = Arrangement.spacedBy(18.dp),
  ) {
    Text(
      text = "08 / ${OrvaShowcaseCopy.deepDiveEyebrow(language)}",
      fontFamily = OrvaShowcaseFonts.mono(language),
      fontSize = 10.5.sp,
      letterSpacing = 1.6.sp,
      color = OrvaShowcaseColors.AccentVermilion,
    )

    BoxWithConstraints(
      modifier =
        Modifier
          .fillMaxWidth()
          .padding(vertical = 8.dp),
    ) {
      val wide = maxWidth >= 600.dp
      if (wide) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(24.dp),
          verticalAlignment = Alignment.CenterVertically,
        ) {
          DeepDiveArtwork(modifier = Modifier.weight(0.42f))
          DeepDiveCopy(
            language = language,
            onExploreOrva = onExploreOrva,
            modifier = Modifier.weight(0.58f),
          )
        }
      } else {
        Column(verticalArrangement = Arrangement.spacedBy(18.dp)) {
          DeepDiveArtwork(modifier = Modifier.fillMaxWidth())
          DeepDiveCopy(language = language, onExploreOrva = onExploreOrva)
        }
      }
    }
  }
}

@Composable
private fun DeepDiveArtwork(modifier: Modifier = Modifier) {
  var flattened by remember { mutableStateOf(false) }
  val rotY by animateFloatAsState(
    targetValue = if (flattened) 0f else -12f,
    animationSpec = tween(durationMillis = 360),
    label = "book_rot_y",
  )
  val rotX by animateFloatAsState(
    targetValue = if (flattened) 0f else 4f,
    animationSpec = tween(durationMillis = 360),
    label = "book_rot_x",
  )
  Box(
    modifier =
      modifier
        .aspectRatio(4f / 3f)
        .graphicsLayer {
          rotationY = rotY
          rotationX = rotX
          cameraDistance = 12f * density
          shadowElevation = if (flattened) 6f else 20f
        }
        .clickable(role = Role.Button, onClick = { flattened = !flattened })
        .border(1.dp, OrvaShowcaseColors.Hairline)
        .agenticNode(id = "about_deep_dive_media", kind = LayerKind.MEDIA, parentId = "about_deep_dive_container"),
  ) {
    Image(
      painter = painterResource(id = R.drawable.editorial_thermal_counter),
      contentDescription = "ORVA architecture cover artwork",
      contentScale = ContentScale.Crop,
      modifier = Modifier.fillMaxSize(),
    )
    // Subtle 3D book spine lighting highlight along the left edge
    Box(
      modifier =
        Modifier
          .align(Alignment.CenterStart)
          .fillMaxHeight()
          .width(12.dp)
          .background(
            Brush.horizontalGradient(
              listOf(
                Color.White.copy(alpha = 0.22f),
                Color.Black.copy(alpha = 0.35f),
                Color.Transparent,
              )
            )
          ),
    )
    Text(
      text = "ORVA / SYSTEM SPEC",
      fontFamily = OrvaShowcaseFonts.IbmPlexMono,
      fontSize = 9.5.sp,
      letterSpacing = 1.3.sp,
      color = OrvaShowcaseColors.InkPrimary,
      modifier =
        Modifier
          .align(Alignment.TopStart)
          .background(OrvaShowcaseColors.CanvasDeep.copy(alpha = 0.8f))
          .padding(horizontal = 8.dp, vertical = 4.dp),
    )
  }
}

@Composable
private fun DeepDiveCopy(
  language: AppLanguage,
  onExploreOrva: () -> Unit,
  modifier: Modifier = Modifier,
) {
  Column(modifier = modifier, verticalArrangement = Arrangement.spacedBy(12.dp)) {
    Text(
      text = OrvaShowcaseCopy.deepDiveTitle(language),
      fontFamily = OrvaShowcaseFonts.display(language),
      fontWeight = FontWeight.Bold,
      fontSize = 24.sp,
      lineHeight = 28.sp,
      letterSpacing = (-0.5).sp,
      color = OrvaShowcaseColors.InkPrimary,
      modifier =
        Modifier.agenticNode(
          id = "about_deep_dive_title",
          kind = LayerKind.TEXT,
          parentId = "about_deep_dive_container",
        ),
    )
    Text(
      text = OrvaShowcaseCopy.deepDiveBody(language),
      fontFamily = OrvaShowcaseFonts.body(language),
      fontSize = 14.5.sp,
      lineHeight = 22.sp,
      color = OrvaShowcaseColors.InkSecondary,
    )
    Button(
      onClick = onExploreOrva,
      colors =
        ButtonDefaults.buttonColors(
          containerColor = OrvaShowcaseColors.InkPrimary,
          contentColor = OrvaShowcaseColors.CanvasDeep,
        ),
      shape = RoundedCornerShape(2.dp),
      contentPadding = PaddingValues(horizontal = 18.dp, vertical = 12.dp),
      modifier = Modifier.minimumInteractiveComponentSize(),
    ) {
      Text(
        text = OrvaShowcaseCopy.flagshipAction(language),
        fontFamily = OrvaShowcaseFonts.mono(language),
        fontWeight = FontWeight.SemiBold,
        fontSize = 11.5.sp,
        letterSpacing = 1.1.sp,
      )
    }
  }
}

/**
 * Scene 09 — Settings-Driven Contact & `RINDLE WORKS` Film-End Closing (Master Directive §4.1 Scene 09 & §7.9–7.10).
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun Scene09ContactAndFilmClosing(
  state: AboutShowcaseUiState,
  onStartBilling: () -> Unit,
  onBackToHome: () -> Unit,
) {
  Column(
    modifier =
      Modifier
        .fillMaxWidth()
        .widthIn(max = 960.dp)
        .padding(horizontal = 24.dp, vertical = 44.dp)
        .agenticNode(id = "about_meta_container", kind = LayerKind.CONTAINER),
    verticalArrangement = Arrangement.spacedBy(32.dp),
  ) {
    HorizontalDivider(thickness = 1.dp, color = OrvaShowcaseColors.Hairline)

    BoxWithConstraints(modifier = Modifier.fillMaxWidth()) {
      val twoColumns = maxWidth >= 660.dp
      if (twoColumns) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(36.dp),
          verticalAlignment = Alignment.Top,
        ) {
          SupportContactColumn(state = state, modifier = Modifier.weight(1f))
          ProductOwnershipColumn(state = state, modifier = Modifier.weight(1f))
        }
      } else {
        Column(verticalArrangement = Arrangement.spacedBy(32.dp)) {
          SupportContactColumn(state = state)
          HorizontalDivider(thickness = 1.dp, color = OrvaShowcaseColors.Hairline)
          ProductOwnershipColumn(state = state)
        }
      }
    }

    FlowRow(
      horizontalArrangement = Arrangement.spacedBy(12.dp),
      verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
      Button(
        onClick = onStartBilling,
        colors =
          ButtonDefaults.buttonColors(
            containerColor = OrvaShowcaseColors.AccentVermilion,
            contentColor = OrvaShowcaseColors.CanvasDeep,
          ),
        shape = RoundedCornerShape(2.dp),
        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 14.dp),
        modifier = Modifier.minimumInteractiveComponentSize().testTag("about_start_billing_btn"),
      ) {
        Text(
          text = OrvaShowcaseCopy.startBillingCta(state.language),
          fontFamily = OrvaShowcaseFonts.mono(state.language),
          fontWeight = FontWeight.SemiBold,
          fontSize = 12.sp,
          letterSpacing = 1.1.sp,
        )
      }

      OutlinedButton(
        onClick = onBackToHome,
        border = BorderStroke(1.dp, OrvaShowcaseColors.Hairline),
        colors = ButtonDefaults.outlinedButtonColors(contentColor = OrvaShowcaseColors.InkPrimary),
        shape = RoundedCornerShape(2.dp),
        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 14.dp),
        modifier = Modifier.minimumInteractiveComponentSize().testTag("about_back_home_btn"),
      ) {
        Text(
          text = OrvaShowcaseCopy.linkBackToHome(state.language),
          fontFamily = OrvaShowcaseFonts.mono(state.language),
          fontWeight = FontWeight.Medium,
          fontSize = 12.sp,
          letterSpacing = 1.1.sp,
        )
      }
    }

    // Film-end closing lock-up: RINDLE (solid) WORKS (outlined)
    Column(
      modifier =
        Modifier
          .fillMaxWidth()
          .padding(top = 24.dp, bottom = 12.dp)
          .agenticNode(id = "about_film_end_mark", kind = LayerKind.TEXT, parentId = "about_meta_container"),
      horizontalAlignment = Alignment.CenterHorizontally,
      verticalArrangement = Arrangement.spacedBy(6.dp),
    ) {
      Row(
        horizontalArrangement = Arrangement.spacedBy(10.dp),
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Text(
          text = "RINDLE",
          fontFamily = OrvaShowcaseFonts.SpaceGrotesk,
          fontWeight = FontWeight.Bold,
          fontSize = 42.sp,
          letterSpacing = (-1.2).sp,
          color = OrvaShowcaseColors.InkPrimary,
        )
        Text(
          text = "WORKS",
          style =
            TextStyle(
              fontFamily = OrvaShowcaseFonts.SpaceGrotesk,
              fontWeight = FontWeight.Bold,
              fontSize = 42.sp,
              letterSpacing = (-1.2).sp,
              color = OrvaShowcaseColors.AccentVermilion,
              drawStyle = Stroke(width = 2.6f),
            ),
        )
      }
      Text(
        text = "SOFTWARE, WITH INTENTION.",
        fontFamily = OrvaShowcaseFonts.IbmPlexMono,
        fontSize = 10.5.sp,
        letterSpacing = 2.sp,
        color = OrvaShowcaseColors.InkMuted,
        textAlign = TextAlign.Center,
      )
    }
  }
}

@Composable
private fun SupportContactColumn(
  state: AboutShowcaseUiState,
  modifier: Modifier = Modifier,
) {
  val phone = state.supportPhone?.takeIf { it.isNotBlank() }
  val email = state.supportEmail?.takeIf { it.isNotBlank() }

  Column(
    modifier =
      modifier.agenticNode(
        id = "about_support_block",
        kind = LayerKind.TEXT,
        parentId = "about_meta_container",
      ),
    verticalArrangement = Arrangement.spacedBy(12.dp),
  ) {
    Text(
      text = OrvaShowcaseCopy.supportSectionLabel(state.language),
      fontFamily = OrvaShowcaseFonts.mono(state.language),
      fontSize = 11.sp,
      letterSpacing = 1.6.sp,
      color = OrvaShowcaseColors.AccentVermilion,
    )
    Text(
      text = OrvaShowcaseCopy.supportHeading(state.language),
      fontFamily = OrvaShowcaseFonts.display(state.language),
      fontWeight = FontWeight.Bold,
      fontSize = 28.sp,
      lineHeight = 32.sp,
      color = OrvaShowcaseColors.InkPrimary,
    )
    Text(
      text = OrvaShowcaseCopy.supportSubline(state.language),
      fontFamily = OrvaShowcaseFonts.body(state.language),
      fontSize = 14.5.sp,
      lineHeight = 22.sp,
      color = OrvaShowcaseColors.InkSecondary,
    )

    if (phone == null && email == null) {
      Text(
        text = OrvaShowcaseCopy.supportEmptyState(state.language),
        fontFamily = OrvaShowcaseFonts.body(state.language),
        fontSize = 13.5.sp,
        lineHeight = 21.sp,
        color = OrvaShowcaseColors.InkMuted,
        modifier = Modifier.testTag("about_support_empty_state"),
      )
    } else {
      if (phone != null) {
        MetadataKeyValueRow(
          label = OrvaShowcaseCopy.supportPhoneLabel(state.language),
          value = phone,
          language = state.language,
          testTag = "about_support_phone",
        )
      }
      if (email != null) {
        MetadataKeyValueRow(
          label = OrvaShowcaseCopy.supportEmailLabel(state.language),
          value = email,
          language = state.language,
          testTag = "about_support_email",
        )
      }
    }
  }
}

@Composable
private fun ProductOwnershipColumn(
  state: AboutShowcaseUiState,
  modifier: Modifier = Modifier,
) {
  Column(
    modifier =
      modifier.agenticNode(
        id = "about_ownership_block",
        kind = LayerKind.TEXT,
        parentId = "about_meta_container",
      ),
    verticalArrangement = Arrangement.spacedBy(12.dp),
  ) {
    Text(
      text = OrvaShowcaseCopy.ownershipSectionLabel(state.language),
      fontFamily = OrvaShowcaseFonts.mono(state.language),
      fontSize = 11.sp,
      letterSpacing = 1.6.sp,
      color = OrvaShowcaseColors.InkMuted,
    )
    MetadataKeyValueRow(
      label = OrvaShowcaseCopy.productLabel(state.language),
      value = OrvaShowcaseCopy.productValue(state.language),
      language = state.language,
    )
    MetadataKeyValueRow(
      label = OrvaShowcaseCopy.developedByLabel(state.language),
      value = "Rindle Works",
      language = state.language,
    )
    MetadataKeyValueRow(
      label = OrvaShowcaseCopy.versionLabel(state.language),
      value = state.appVersion,
      language = state.language,
      testTag = "about_version_value",
    )
    MetadataKeyValueRow(
      label = OrvaShowcaseCopy.buildLabel(state.language),
      value = state.buildNumber,
      language = state.language,
      testTag = "about_build_value",
    )
    Text(
      text = OrvaShowcaseCopy.studioStatusNote(state.language),
      fontFamily = OrvaShowcaseFonts.mono(state.language),
      fontSize = 11.sp,
      lineHeight = 18.sp,
      color = OrvaShowcaseColors.InkMuted,
      modifier = Modifier.testTag("about_provisional_status"),
    )
    Text(
      text = OrvaShowcaseCopy.ownershipReassurance(state.language),
      fontFamily = OrvaShowcaseFonts.body(state.language),
      fontSize = 13.5.sp,
      lineHeight = 20.sp,
      color = OrvaShowcaseColors.InkSecondary,
    )
  }
}

@Composable
private fun MetadataKeyValueRow(
  label: String,
  value: String,
  language: AppLanguage,
  testTag: String? = null,
) {
  Column(
    modifier = if (testTag != null) Modifier.testTag(testTag) else Modifier,
    verticalArrangement = Arrangement.spacedBy(2.dp),
  ) {
    Text(
      text = label.uppercase(),
      fontFamily = OrvaShowcaseFonts.mono(language),
      fontSize = 10.sp,
      letterSpacing = 1.2.sp,
      color = OrvaShowcaseColors.InkMuted,
    )
    Text(
      text = value,
      fontFamily = OrvaShowcaseFonts.body(language),
      fontSize = 14.5.sp,
      color = OrvaShowcaseColors.InkPrimary,
    )
  }
}

/**
 * `zll.me`-inspired tilted dual-track kinetic marquee band between Scene 02 and Scene 03.
 */
@Composable
private fun TiltedDualMarqueeRibbon(reducedMotion: Boolean) {
  val infinite = rememberInfiniteTransition(label = "marquee")
  val shift by infinite.animateFloat(
    initialValue = 0f,
    targetValue = -320f,
    animationSpec =
      infiniteRepeatable(
        animation = tween(durationMillis = 9000, easing = LinearEasing),
        repeatMode = RepeatMode.Restart,
      ),
    label = "marquee_shift",
  )
  val xOffset = if (reducedMotion) 0f else shift

  val palette = currentShowcasePalette()
  Column(
    modifier =
      Modifier
        .fillMaxWidth()
        .padding(vertical = 18.dp)
        .clipToBounds()
        .graphicsLayer { rotationZ = -1.8f },
    verticalArrangement = Arrangement.spacedBy(4.dp),
  ) {
    // Track 1: Solid bold left-scrolling ribbon
    Box(
      modifier =
        Modifier
          .fillMaxWidth()
          .background(palette.inkPrimary)
          .padding(vertical = 8.dp)
          .clipToBounds(),
    ) {
      Text(
        text = "LOCAL-FIRST · INTEGER PAISE · FEFO ALLOCATION · ATOMIC LEDGER · GST READY · OFFLINE SQLITE · LOCAL-FIRST · INTEGER PAISE · ",
        fontFamily = OrvaShowcaseFonts.SpaceGrotesk,
        fontWeight = FontWeight.Bold,
        fontSize = 14.sp,
        letterSpacing = 1.6.sp,
        color = palette.canvasDeep,
        maxLines = 1,
        softWrap = false,
        modifier = Modifier.graphicsLayer { translationX = xOffset },
      )
    }
    // Track 2: Hollow outlined stroke right-scrolling ribbon (zll.me dual-track contrast)
    Box(
      modifier =
        Modifier
          .fillMaxWidth()
          .background(palette.canvasSecondary)
          .border(1.dp, palette.hairline)
          .padding(vertical = 7.dp)
          .clipToBounds(),
    ) {
      Text(
        text = "RINDLE WORKS · ORVA · BATCH SAFETY · PORTABLE BACKUPS · COMPOSE NATIVE · ZERO CLOUD LOCK-IN · RINDLE WORKS · ORVA · ",
        style =
          TextStyle(
            fontFamily = OrvaShowcaseFonts.SpaceGrotesk,
            fontWeight = FontWeight.Bold,
            fontSize = 15.sp,
            letterSpacing = 1.8.sp,
            color = palette.inkPrimary.copy(alpha = 0.72f),
            drawStyle = Stroke(width = 1.8f),
          ),
        maxLines = 1,
        softWrap = false,
        modifier = Modifier.graphicsLayer { translationX = -xOffset * 0.75f - 160f },
      )
    }
  }
}
