package com.rindleworks.orva.ui.about.agentic

import androidx.compose.foundation.ScrollState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Color
import com.rindleworks.orva.ui.showcase.OrvaShowcaseColors
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.hypot
import kotlin.math.sin
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

enum class CursorVisualMode {
  POINTER,
  CROSSHAIR,
  I_BEAM,
}

private enum class TaskAnimStage {
  FLY_TO_MASTER,
  CLONE_ARC_DRAG,
  CLONE_SETTLE,
  FLY_TO_ENTRY,
  DRAFT_WIREFRAME,
  TYPE_REVEAL,
  STAGE_MEDIA,
}

private class ActiveTaskAnim(
  val claim: AgentTaskClaim,
  val renderState: LayerRenderState,
  val targetRect: Rect,
  val masterRect: Rect?,
  var stage: TaskAnimStage,
  var stageElapsedSec: Float = 0f,
  var stageDurationSec: Float,
  var arcStart: Offset,
  var arcControl: Offset,
  var arcEnd: Offset,
  val lineCount: Int = 1,
)

class VisualAgentState(
  val id: Int,
  val role: AgentRole,
  val roleLabel: String,
  val color: Color,
  var pos: Offset,
  var prevPos: Offset = pos,
  var mode: CursorVisualMode = CursorVisualMode.POINTER,
  var orbitAngleRad: Float,
  var orbitRadiusFactor: Float,
  var activeNodeId: String? = null,
  var glowEnergy: Float = 0f,
  var visualAlpha: Float = 0.20f,
  val trail: ArrayDeque<Offset> = ArrayDeque(16),
) {
  fun moveTo(next: Offset, recordTrail: Boolean = activeNodeId != null) {
    prevPos = pos
    pos = next
    if (recordTrail) {
      if (trail.isEmpty() || hypot(next.x - trail.last().x, next.y - trail.last().y) > 2.0f) {
        if (trail.size >= 14) trail.removeFirst()
        trail.addLast(next)
      }
    } else if (trail.isNotEmpty()) {
      trail.removeFirst()
    }
  }

  fun clearTrail() {
    trail.clear()
  }
}

data class ActiveWireframeVisual(
  val agentId: Int,
  val nodeId: String,
  val accentColor: Color,
  val currentRect: Rect,
  val targetRect: Rect,
  val isTextSelection: Boolean,
  val isMediaScan: Boolean,
  val progress: Float,
  val beamPhase: Float,
  val widthDp: Int,
  val heightDp: Int,
)

data class SmartGuideLine(
  val start: Offset,
  val end: Offset,
  val label: String? = null,
  val createdAtMs: Long,
  val durationMs: Long = 380L,
)

data class CloneGhostVisual(
  val nodeId: String,
  val accentColor: Color,
  val currentRect: Rect,
  val alpha: Float,
)

data class MediaGlintVisual(
  val center: Offset,
  val progress: Float,
)

/** Crisp expanding 1dp snap ring emitted when an agent locks a node into position. */
data class SnapRippleVisual(
  val center: Offset,
  val color: Color,
  val createdAtMs: Long,
  val durationMs: Long = 280L,
)

/** Delicate geometric micro-spark emitted on layer commit (inspired by cursor-swarm.js). */
data class CompletionSparkVisual(
  val origin: Offset,
  val velocity: Offset,
  val color: Color,
  val createdAtMs: Long,
  val durationMs: Long = 420L,
)

class LayerRenderState {
  var revealAlpha by mutableFloatStateOf(0f)
  var revealClipFraction by mutableFloatStateOf(0f) // [0f..1f] draw-phase reveal (zero reflow!)
  var highlightSelectionActive by mutableStateOf(false)
  var activeAccentColor by mutableStateOf(OrvaShowcaseColors.CursorPurpleCore)
  var estimatedLineCount by mutableIntStateOf(1)
  var mediaMonochromeProgress by mutableFloatStateOf(0f)
}

/**
 * Single-clock (`withFrameNanos`) 60/120Hz orchestrator for ORVA's About Us Agentic Build.
 *
 * Upgraded architecture synthesizing `cursor-swarm.js`, `saai.pro`, and `21st.dev`:
 * - Opens immediately into live cursor construction (ZERO opening ORVA text or glow splash).
 * - Curated Electric Royal Purple & Signal Vermilion agent roster with crisp role tags.
 * - Idle scouts and waiting cursors park quietly near viewport margins and dim (`alpha = 0.18f`)
 *   with zero glow halo, eliminating center-screen visual clutter and overlapping neon fog.
 * - Active builders emit tight 1:1 optical specular glow, traveling perimeter Border Beams,
 *   line-by-line typing caret sweeps, media scan wipes, snap ripples, and completion micro-sparks.
 */
class AgenticBuildController(
  val scrollState: ScrollState,
  val reducedMotion: Boolean = false,
  val scheduler: AgentTaskScheduler = AgentTaskScheduler(totalAgents = 16, maxConcurrentBuilders = 8),
) {
  val agents: List<VisualAgentState> = createRoster()
  val renderStates = LinkedHashMap<String, LayerRenderState>()
  val activeWireframes = LinkedHashMap<Int, ActiveWireframeVisual>()
  val smartGuides = mutableListOf<SmartGuideLine>()
  val cloneGhosts = LinkedHashMap<String, CloneGhostVisual>()
  val mediaGlints = mutableListOf<MediaGlintVisual>()
  val snapRipples = mutableListOf<SnapRippleVisual>()
  val completionSparks = mutableListOf<CompletionSparkVisual>()

  // Observable HUD state (coarse transitions only — never updated at 120Hz)
  var act by mutableStateOf(BuildAct.ORBITAL_SCAN)
    private set
  var introProgress by mutableFloatStateOf(0f)
    private set
  var completedCount by mutableIntStateOf(0)
    private set
  var totalCount by mutableIntStateOf(0)
    private set
  var activeBuilderCount by mutableIntStateOf(0)
    private set
  var touringEnabled by mutableStateOf(true)
  var speedMultiplier by mutableFloatStateOf(1f)
  var currentSceneLabel by mutableStateOf("SCENE 01 / STUDIO")
    private set
  var paused by mutableStateOf(false)
  var soundEnabled by mutableStateOf(false)
  var overlayAlpha by mutableFloatStateOf(1f)
    private set
  var convergenceEnergy by mutableFloatStateOf(0f)
    private set

  // Read ONLY inside Canvas draw lambda -> 0 recompositions/sec
  var frameTick by mutableLongStateOf(0L)
    private set

  // Continuous simulation clock exposed to Canvas for smooth blinking carets & beam phases
  var currentSimTimeMs: Long = 0L
    private set

  // Visitor touch finger acts as Agent #17 (nearby active cursors subtly respond)
  var visitorTouchContentPos: Offset? = null

  var viewportWidthPx: Float = 1080f
  var viewportHeightPx: Float = 2200f
  var densityPxPerDp: Float = 2.75f
  var stageRootTopInRootPx: Float = 0f

  private val activeTasks = LinkedHashMap<Int, ActiveTaskAnim>()
  private var simulationTimeMs: Long = 0L
  private var lifecyclePaused: Boolean = false
  private var hasInitializedEntryPositions: Boolean = false
  private val runGate = MutableStateFlow(true)

  private fun refreshRunGate() {
    runGate.value = !paused && !lifecyclePaused && act != BuildAct.COMPLETED
  }

  private fun createRoster(): List<VisualAgentState> {
    // 16 agents alternating Electric Royal Purple and Signal Vermilion by craft specialization
    val specs =
      listOf(
        Triple(AgentRole.LAYOUT_ARCHITECT, "LAYOUT", OrvaShowcaseColors.CursorPurpleCore),
        Triple(AgentRole.LAYOUT_ARCHITECT, "LAYOUT", OrvaShowcaseColors.CursorVermilionCore),
        Triple(AgentRole.LAYOUT_ARCHITECT, "GRID", OrvaShowcaseColors.CursorPurpleBright),
        Triple(AgentRole.COMPONENT_DUPLICATOR, "CLONE", OrvaShowcaseColors.CursorVermilionCore),
        Triple(AgentRole.COMPONENT_DUPLICATOR, "CLONE", OrvaShowcaseColors.CursorPurpleCore),
        Triple(AgentRole.COMPONENT_DUPLICATOR, "SYNC", OrvaShowcaseColors.CursorVermilionBright),
        Triple(AgentRole.TYPOGRAPHER, "TYPE", OrvaShowcaseColors.CursorPurpleBright),
        Triple(AgentRole.TYPOGRAPHER, "TYPE", OrvaShowcaseColors.CursorVermilionBright),
        Triple(AgentRole.TYPOGRAPHER, "COPY", OrvaShowcaseColors.CursorPurpleCore),
        Triple(AgentRole.TYPOGRAPHER, "COPY", OrvaShowcaseColors.CursorVermilionCore),
        Triple(AgentRole.ART_DIRECTOR, "MEDIA", OrvaShowcaseColors.CursorVermilionDeep),
        Triple(AgentRole.ART_DIRECTOR, "MEDIA", OrvaShowcaseColors.CursorPurpleDeep),
        Triple(AgentRole.IDLE_SCOUT, "SCOUT", OrvaShowcaseColors.CursorPurpleCore),
        Triple(AgentRole.IDLE_SCOUT, "SCOUT", OrvaShowcaseColors.CursorVermilionCore),
        Triple(AgentRole.IDLE_SCOUT, "SCOUT", OrvaShowcaseColors.CursorPurpleBright),
        Triple(AgentRole.IDLE_SCOUT, "SCOUT", OrvaShowcaseColors.CursorVermilionBright),
      )
    return specs.mapIndexed { idx, (role, label, color) ->
      val angle = (idx.toFloat() / specs.size.toFloat()) * (2f * PI.toFloat())
      VisualAgentState(
        id = idx,
        role = role,
        roleLabel = label,
        color = color,
        pos = Offset(if (idx % 2 == 0) 24f else 1056f, 120f + idx * 44f),
        orbitAngleRad = angle,
        orbitRadiusFactor = 0.85f + (idx % 3) * 0.06f,
      )
    }
  }

  fun getOrCreateRenderState(nodeId: String): LayerRenderState =
    renderStates.getOrPut(nodeId) {
      LayerRenderState().apply {
        if (act == BuildAct.COMPLETED) {
          revealAlpha = 1f
          revealClipFraction = 1f
          mediaMonochromeProgress = 1f
        }
      }
    }

  fun registerComposableBounds(
    id: String,
    kind: LayerKind,
    parentId: String?,
    cloneGroupId: String?,
    cloneIndex: Int,
    contentRect: Rect,
  ) {
    getOrCreateRenderState(id)
    scheduler.registerOrUpdateNode(
      id = id,
      kind = kind,
      parentId = parentId,
      cloneGroupId = cloneGroupId,
      cloneIndex = cloneIndex,
      bounds = SceneBounds(contentRect.left, contentRect.top, contentRect.right, contentRect.bottom),
    )
    if (act == BuildAct.COMPLETED) {
      scheduler.markAllRevealed()
      renderStates[id]?.apply {
        revealAlpha = 1f
        revealClipFraction = 1f
        highlightSelectionActive = false
        mediaMonochromeProgress = 1f
      }
    }
    syncHudCounters()
  }

  fun onViewportSized(widthPx: Float, heightPx: Float, density: Float) {
    viewportWidthPx = widthPx.coerceAtLeast(1f)
    viewportHeightPx = heightPx.coerceAtLeast(1f)
    densityPxPerDp = density.coerceAtLeast(1f)
    if (!hasInitializedEntryPositions) {
      hasInitializedEntryPositions = true
      resetAgentPositionsPerimeter()
    }
    if (scheduler.onViewportWidthChanged(viewportWidthPx)) {
      clearActiveTasksAndVisuals()
    }
  }

  fun onLifecyclePaused(isPaused: Boolean) {
    lifecyclePaused = isPaused
    refreshRunGate()
  }

  /** Manual user scroll immediately overrides guided Touring (never fight the user's gesture). */
  fun onUserManualScroll() {
    if (touringEnabled) {
      touringEnabled = false
    }
  }

  fun cycleSpeed() {
    speedMultiplier =
      when {
        speedMultiplier < 1.5f -> 2.0f
        speedMultiplier < 2.5f -> 3.0f
        else -> 1.0f
      }
  }

  fun togglePause() {
    paused = !paused
    refreshRunGate()
  }

  fun toggleTouring() {
    touringEnabled = !touringEnabled
  }

  fun toggleSound() {
    soundEnabled = !soundEnabled
  }

  fun skipToFinish() {
    clearActiveTasksAndVisuals()
    scheduler.markAllRevealed()
    for (rs in renderStates.values) {
      rs.revealAlpha = 1f
      rs.revealClipFraction = 1f
      rs.highlightSelectionActive = false
      rs.mediaMonochromeProgress = 1f
    }
    smartGuides.clear()
    mediaGlints.clear()
    snapRipples.clear()
    completionSparks.clear()
    convergenceEnergy = 0f
    introProgress = 1f
    overlayAlpha = 0f
    act = BuildAct.COMPLETED
    refreshRunGate()
    syncHudCounters()
    frameTick++
  }

  fun replay() {
    clearActiveTasksAndVisuals()
    scheduler.resetForReplay()
    for (rs in renderStates.values) {
      rs.revealAlpha = 0f
      rs.revealClipFraction = 0f
      rs.highlightSelectionActive = false
      rs.mediaMonochromeProgress = 0f
    }
    smartGuides.clear()
    mediaGlints.clear()
    snapRipples.clear()
    completionSparks.clear()
    simulationTimeMs = 0L
    currentSimTimeMs = 0L
    convergenceEnergy = 0f
    introProgress = 0f
    overlayAlpha = 1f
    paused = false
    touringEnabled = true
    act = BuildAct.ORBITAL_SCAN
    resetAgentPositionsPerimeter()
    refreshRunGate()
    syncHudCounters()
    frameTick++
  }

  private fun clearActiveTasksAndVisuals() {
    for ((agentId, task) in activeTasks) {
      scheduler.releaseClaim(agentId, task.claim.nodeId)
    }
    activeTasks.clear()
    activeWireframes.clear()
    cloneGhosts.clear()
    for (agent in agents) {
      agent.activeNodeId = null
      agent.mode = CursorVisualMode.POINTER
      agent.glowEnergy = 0f
      agent.visualAlpha = 0.18f
      agent.clearTrail()
    }
  }

  /**
   * Stage cursors cleanly along the outer left/right rails of the viewport so they enter
   * purposefully from the edges (inspired by `cursor-swarm.js` `outside` spawn) with zero
   * opening splash veil or center-screen clutter.
   */
  private fun resetAgentPositionsPerimeter() {
    val w = viewportWidthPx
    val h = viewportHeightPx
    val topY = scrollState.value.toFloat()
    val cx = w * 0.5f
    val cy = topY + h * 0.44f
    val rx = (w * 0.36f).coerceAtLeast(120f)
    val ry = (h * 0.16f).coerceAtLeast(110f)
    agents.forEachIndexed { idx, agent ->
      val angle = (idx.toFloat() / agents.size.toFloat()) * (2f * PI.toFloat())
      val ring = if (idx % 2 == 0) 0.78f else 1.12f
      val px = cx + cos(angle) * rx * ring
      val py = cy + sin(angle) * ry * ring
      agent.orbitAngleRad = angle
      agent.orbitRadiusFactor = ring
      agent.pos = Offset(px, py)
      agent.prevPos = agent.pos
      agent.mode = CursorVisualMode.POINTER
      agent.activeNodeId = null
      agent.glowEnergy = 0.72f
      agent.visualAlpha = 0.96f
      agent.clearTrail()
    }
  }

  /**
   * Main single-clock 60/120Hz frame loop (`withFrameNanos`).
   * Zero polling wakeups when paused, backgrounded, or `COMPLETED`.
   */
  suspend fun runOrchestrator(scope: CoroutineScope) {
    if (!hasInitializedEntryPositions) {
      hasInitializedEntryPositions = true
      resetAgentPositionsPerimeter()
    }
    var lastFrameNanos = 0L
    var lastTourScrollMs = 0L
    var convergenceStartMs = 0L

    while (scope.isActive) {
      if (paused || lifecyclePaused || act == BuildAct.COMPLETED) {
        lastFrameNanos = 0L
        refreshRunGate()
        runGate.first { it }
        continue
      }

      val frameNanos = withFrameNanos { it }
      if (lastFrameNanos == 0L) {
        lastFrameNanos = frameNanos
        continue
      }

      val rawDtSec = ((frameNanos - lastFrameNanos) / 1_000_000_000f).coerceIn(0.001f, 0.04f)
      lastFrameNanos = frameNanos
      val dtSec = rawDtSec * speedMultiplier * (if (reducedMotion) 1.75f else 1f)
      simulationTimeMs += (dtSec * 1000f).toLong().coerceAtLeast(1L)
      currentSimTimeMs = simulationTimeMs

      pruneExpiredEffects()

      val vpTop = scrollState.value.toFloat()
      val vpBottom = vpTop + viewportHeightPx
      val structuralCutoffY = viewportHeightPx * 0.95f

      when (act) {
        BuildAct.ORBITAL_SCAN -> {
          val introDurationMs = if (reducedMotion) 1100L else 5800L
          val p = (simulationTimeMs.toFloat() / introDurationMs.toFloat()).coerceIn(0f, 1f)
          introProgress = p
          currentSceneLabel = "INTRO / ORBITAL LOCK"
          updateOrbitalIntroCursors(dtSec, vpTop, p)
          syncHudCounters()
          if (p >= 1f) {
            act = BuildAct.STRUCTURAL_BUILD
          }
        }

        BuildAct.STRUCTURAL_BUILD, BuildAct.SCROLL_ASSEMBLY -> {
          // 1. Claim eligible tasks up to 8 concurrent builders
          for (agent in agents) {
            if (agent.activeNodeId == null && agent.role != AgentRole.IDLE_SCOUT) {
              val claim =
                scheduler.tryClaimNextTask(
                  agentId = agent.id,
                  role = agent.role,
                  viewportTopPx = vpTop,
                  viewportBottomPx = vpBottom,
                  ignoreViewportGate = act == BuildAct.SCROLL_ASSEMBLY && !touringEnabled,
                )
              if (claim != null) {
                startTaskForAgent(agent, claim)
              }
            }
          }

          // 2. Step EVERY active builder task analytically on this exact display frame
          stepActiveTasks(dtSec)

          // 3. Park idle scouts & waiting builders gracefully at the quiet viewport rails
          updateIdleAndScoutAgents(dtSec, vpTop, vpBottom)

          // 4. Refresh tight per-cursor optical glow (active builders only; idle = 0f)
          updateCursorGlowEnergies(dtSec)

          // 5. Transition Act II -> Act III once above-the-fold hero is in place
          if (act == BuildAct.STRUCTURAL_BUILD) {
            val heroNodesDone =
              scheduler.allNodesSnapshot().none {
                it.bounds.top < structuralCutoffY * 0.65f && it.phase != LayerPhase.REVEALED
              }
            if (heroNodesDone && scheduler.completedCount() >= 3) {
              act = BuildAct.SCROLL_ASSEMBLY
            }
          }

          // 6. Guided Touring auto-scroll (immediately yields on user touch)
          if (act == BuildAct.SCROLL_ASSEMBLY &&
            touringEnabled &&
            !scrollState.isScrollInProgress &&
            simulationTimeMs - lastTourScrollMs > 160L
          ) {
            val hasVisibleWork = scheduler.hasEligibleWorkInViewport(vpTop, vpBottom)
            if (!hasVisibleWork && scheduler.activeBuilderCount() <= 2) {
              val nextTop = scheduler.nextUnbuiltTargetTopY(vpBottom - 120f)
              if (nextTop != null && scrollState.value < scrollState.maxValue) {
                lastTourScrollMs = simulationTimeMs
                val targetScroll =
                  (nextTop - viewportHeightPx * 0.22f).toInt().coerceIn(0, scrollState.maxValue)
                if (targetScroll > scrollState.value + 16) {
                  scope.launch {
                    if (touringEnabled && !scrollState.isScrollInProgress) {
                      scrollState.animateScrollTo(targetScroll)
                    }
                  }
                }
              }
            }
          }

          syncHudCounters()

          if (scheduler.isAllCompleted() && activeTasks.isEmpty()) {
            act = BuildAct.CONVERGENCE
            convergenceStartMs = simulationTimeMs
          }
        }

        BuildAct.CONVERGENCE -> {
          val convDurationMs = if (reducedMotion) 320L else 780L
          val p = ((simulationTimeMs - convergenceStartMs).toFloat() / convDurationMs).coerceIn(0f, 1f)
          updateConvergenceExit(dtSec, p)
          convergenceEnergy = sin(p * PI.toFloat()).coerceIn(0f, 1f)
          overlayAlpha = if (p < 0.35f) 1f else (1f - (p - 0.35f) / 0.65f).coerceIn(0f, 1f)
          if (p >= 1f) {
            overlayAlpha = 0f
            convergenceEnergy = 0f
            activeWireframes.clear()
            smartGuides.clear()
            cloneGhosts.clear()
            mediaGlints.clear()
            snapRipples.clear()
            completionSparks.clear()
            act = BuildAct.COMPLETED
            refreshRunGate()
          }
        }

        BuildAct.COMPLETED -> Unit
      }

      frameTick++
    }
  }

  private fun startTaskForAgent(agent: VisualAgentState, claim: AgentTaskClaim) {
    val node = scheduler.getNode(claim.nodeId)
    if (node == null || !node.bounds.isValid) {
      scheduler.releaseClaim(agent.id, claim.nodeId)
      return
    }
    val renderState = getOrCreateRenderState(claim.nodeId)
    val targetRect = Rect(node.bounds.left, node.bounds.top, node.bounds.right, node.bounds.bottom)
    val masterRect =
      if (claim.isCloneFromMaster && claim.masterNodeId != null) {
        scheduler.getNode(claim.masterNodeId)?.bounds?.let { Rect(it.left, it.top, it.right, it.bottom) }
      } else {
        null
      }

    val approxLineHeightPx = 26f * densityPxPerDp
    val estimatedLines =
      if (claim.kind == LayerKind.TEXT) {
        (targetRect.height / approxLineHeightPx).toInt().coerceIn(1, 5)
      } else {
        1
      }
    renderState.estimatedLineCount = estimatedLines
    renderState.activeAccentColor = agent.color

    val startPos = agent.pos
    val (initialStage, destPos, durSec) =
      if (claim.isCloneFromMaster && masterRect != null) {
        Triple(TaskAnimStage.FLY_TO_MASTER, masterRect.center, 0.22f)
      } else {
        val entryPoint =
          if (claim.kind == LayerKind.TEXT) {
            Offset(targetRect.left, targetRect.top + (targetRect.height / estimatedLines) * 0.5f)
          } else {
            Offset(targetRect.left, targetRect.top)
          }
        Triple(TaskAnimStage.FLY_TO_ENTRY, entryPoint, 0.24f)
      }

    agent.activeNodeId = claim.nodeId
    agent.mode = CursorVisualMode.POINTER
    agent.clearTrail()
    activeTasks[agent.id] =
      ActiveTaskAnim(
        claim = claim,
        renderState = renderState,
        targetRect = targetRect,
        masterRect = masterRect,
        stage = initialStage,
        stageElapsedSec = 0f,
        stageDurationSec = durSec,
        arcStart = startPos,
        arcControl = arcControlPoint(startPos, destPos, agent.id),
        arcEnd = destPos,
        lineCount = estimatedLines,
      )
  }

  private fun stepActiveTasks(dtSec: Float) {
    val completedAgentIds = mutableListOf<Int>()
    val beamCycle = ((simulationTimeMs % 1400L).toFloat() / 1400f)

    for ((agentId, task) in activeTasks) {
      val agent = agents[agentId]
      task.stageElapsedSec += dtSec
      val rawT = (task.stageElapsedSec / task.stageDurationSec.coerceAtLeast(0.01f)).coerceIn(0f, 1f)

      when (task.stage) {
        TaskAnimStage.FLY_TO_MASTER -> {
          val eased = easeInOutCubic(rawT)
          agent.mode = CursorVisualMode.POINTER
          agent.moveTo(quadBezier(task.arcStart, task.arcControl, task.arcEnd, eased), recordTrail = true)
          if (rawT >= 1f) {
            val from = task.masterRect?.center ?: agent.pos
            val to = task.targetRect.center
            task.stage = TaskAnimStage.CLONE_ARC_DRAG
            task.stageElapsedSec = 0f
            task.stageDurationSec = 0.34f
            task.arcStart = from
            task.arcControl = arcControlPoint(from, to, agent.id + 3)
            task.arcEnd = to
          }
        }

        TaskAnimStage.CLONE_ARC_DRAG -> {
          val eased = easeOutQuint(rawT)
          val cur = quadBezier(task.arcStart, task.arcControl, task.arcEnd, eased)
          agent.mode = CursorVisualMode.POINTER
          agent.moveTo(cur, recordTrail = true)
          val src = task.masterRect ?: task.targetRect
          val w = lerpFloat(src.width, task.targetRect.width, eased)
          val h = lerpFloat(src.height, task.targetRect.height, eased)
          cloneGhosts[task.claim.nodeId] =
            CloneGhostVisual(
              nodeId = task.claim.nodeId,
              accentColor = agent.color,
              currentRect = Rect(cur.x - w * 0.5f, cur.y - h * 0.5f, cur.x + w * 0.5f, cur.y + h * 0.5f),
              alpha = 0.78f,
            )
          if (rawT >= 1f) {
            cloneGhosts.remove(task.claim.nodeId)
            emitRealSnapSmartGuides(task.claim.nodeId, task.targetRect)
            emitCommitCelebration(task.targetRect.center, agent.color)
            scheduler.markCloneMasterTextVisible(task.claim.nodeId)
            task.renderState.revealAlpha = 0.92f
            task.renderState.revealClipFraction = 1f
            task.renderState.highlightSelectionActive = true
            task.stage = TaskAnimStage.CLONE_SETTLE
            task.stageElapsedSec = 0f
            task.stageDurationSec = 0.14f
          }
        }

        TaskAnimStage.CLONE_SETTLE -> {
          agent.mode = CursorVisualMode.POINTER
          agent.moveTo(
            lerpOffset(agent.pos, task.targetRect.bottomRight, (dtSec * 9f).coerceIn(0f, 1f)),
            recordTrail = false,
          )
          if (rawT >= 1f) {
            task.renderState.highlightSelectionActive = false
            task.renderState.revealAlpha = 1f
            task.renderState.revealClipFraction = 1f
            completedAgentIds += agentId
          }
        }

        TaskAnimStage.FLY_TO_ENTRY -> {
          val eased = easeInOutCubic(rawT)
          agent.mode = CursorVisualMode.POINTER
          agent.moveTo(quadBezier(task.arcStart, task.arcControl, task.arcEnd, eased), recordTrail = true)
          if (rawT >= 1f) {
            task.stageElapsedSec = 0f
            when (task.claim.kind) {
              LayerKind.CONTAINER, LayerKind.LINE -> {
                task.stage = TaskAnimStage.DRAFT_WIREFRAME
                task.stageDurationSec = 0.34f
              }
              LayerKind.TEXT -> {
                task.stage = TaskAnimStage.TYPE_REVEAL
                task.stageDurationSec = (0.34f + task.lineCount * 0.055f).coerceAtMost(0.62f)
                task.renderState.revealAlpha = 1f
                task.renderState.highlightSelectionActive = true
              }
              LayerKind.MEDIA -> {
                task.stage = TaskAnimStage.STAGE_MEDIA
                task.stageDurationSec = 0.44f
              }
            }
          }
        }

        TaskAnimStage.DRAFT_WIREFRAME -> {
          val eased = easeOutQuint(rawT)
          agent.mode = CursorVisualMode.CROSSHAIR
          val curRight = lerpFloat(task.targetRect.left + 8f, task.targetRect.right, eased)
          val curBottom = lerpFloat(task.targetRect.top + 6f, task.targetRect.bottom, eased)
          val curRect = Rect(task.targetRect.left, task.targetRect.top, curRight, curBottom)
          agent.moveTo(Offset(curRight, curBottom), recordTrail = true)
          activeWireframes[agent.id] =
            ActiveWireframeVisual(
              agentId = agent.id,
              nodeId = task.claim.nodeId,
              accentColor = agent.color,
              currentRect = curRect,
              targetRect = task.targetRect,
              isTextSelection = false,
              isMediaScan = false,
              progress = eased,
              beamPhase = (beamCycle + agent.id * 0.17f) % 1f,
              widthDp = (curRect.width / densityPxPerDp).toInt().coerceAtLeast(1),
              heightDp = (curRect.height / densityPxPerDp).toInt().coerceAtLeast(1),
            )
          task.renderState.revealAlpha = (0.18f + eased * 0.82f).coerceIn(0f, 1f)
          task.renderState.revealClipFraction = eased
          if (rawT >= 1f) {
            emitRealSnapSmartGuides(task.claim.nodeId, task.targetRect)
            emitCommitCelebration(task.targetRect.bottomRight, agent.color)
            activeWireframes.remove(agent.id)
            task.renderState.revealAlpha = 1f
            task.renderState.revealClipFraction = 1f
            completedAgentIds += agentId
          }
        }

        TaskAnimStage.TYPE_REVEAL -> {
          val eased = easeOutCubic(rawT)
          // Dual-speed zll.me typing cadence: headings step char-by-char, body paragraphs step word-by-word
          val isHeading = task.lineCount <= 2
          val steps = if (isHeading) (task.lineCount * 18).coerceAtLeast(14) else (task.lineCount * 7).coerceAtLeast(10)
          val steppedProgress = (kotlin.math.floor(eased * steps) / steps.toFloat()).coerceIn(0f, 1f)
          val revealFrac = if (rawT >= 0.98f) 1f else steppedProgress
          agent.mode = CursorVisualMode.I_BEAM
          task.renderState.revealAlpha = 1f
          task.renderState.revealClipFraction = revealFrac

          // Row-by-row caret sweep matching AgenticModifiers line-clipping geometry
          val lines = task.lineCount.coerceAtLeast(1)
          val scaled = (revealFrac * lines).coerceIn(0f, lines.toFloat())
          val currentLine = scaled.toInt().coerceIn(0, lines - 1)
          val lineFrac = (scaled - currentLine).coerceIn(0f, 1f)
          val lineHeight = task.targetRect.height / lines.toFloat()
          val caretX = lerpFloat(task.targetRect.left, task.targetRect.right, lineFrac)
          val caretY = task.targetRect.top + (currentLine + 0.5f) * lineHeight

          agent.moveTo(Offset(caretX, caretY), recordTrail = false)
          activeWireframes[agent.id] =
            ActiveWireframeVisual(
              agentId = agent.id,
              nodeId = task.claim.nodeId,
              accentColor = agent.color,
              currentRect = task.targetRect,
              targetRect = task.targetRect,
              isTextSelection = true,
              isMediaScan = false,
              progress = eased,
              beamPhase = (beamCycle + agent.id * 0.23f) % 1f,
              widthDp = (task.targetRect.width / densityPxPerDp).toInt(),
              heightDp = (task.targetRect.height / densityPxPerDp).toInt(),
            )
          if (rawT >= 1f) {
            emitRealSnapSmartGuides(task.claim.nodeId, task.targetRect)
            emitCommitCelebration(Offset(caretX, caretY), agent.color)
            activeWireframes.remove(agent.id)
            task.renderState.highlightSelectionActive = false
            task.renderState.revealClipFraction = 1f
            completedAgentIds += agentId
          }
        }

        TaskAnimStage.STAGE_MEDIA -> {
          val eased = easeOutCubic(rawT)
          agent.mode = CursorVisualMode.CROSSHAIR
          task.renderState.revealAlpha = (0.20f + eased * 0.80f).coerceIn(0f, 1f)
          task.renderState.revealClipFraction = eased
          task.renderState.mediaMonochromeProgress = eased
          val scanY = lerpFloat(task.targetRect.top, task.targetRect.bottom, eased)
          agent.moveTo(Offset(task.targetRect.center.x, scanY), recordTrail = true)
          activeWireframes[agent.id] =
            ActiveWireframeVisual(
              agentId = agent.id,
              nodeId = task.claim.nodeId,
              accentColor = agent.color,
              currentRect = task.targetRect,
              targetRect = task.targetRect,
              isTextSelection = false,
              isMediaScan = true,
              progress = eased,
              beamPhase = (beamCycle + agent.id * 0.11f) % 1f,
              widthDp = (task.targetRect.width / densityPxPerDp).toInt(),
              heightDp = (task.targetRect.height / densityPxPerDp).toInt(),
            )
          updateMediaGlints(task.targetRect, eased)
          if (rawT >= 1f) {
            emitRealSnapSmartGuides(task.claim.nodeId, task.targetRect)
            emitCommitCelebration(task.targetRect.center, agent.color)
            activeWireframes.remove(agent.id)
            mediaGlints.clear()
            task.renderState.revealAlpha = 1f
            task.renderState.revealClipFraction = 1f
            task.renderState.mediaMonochromeProgress = 1f
            completedAgentIds += agentId
          }
        }
      }
    }

    for (agentId in completedAgentIds) {
      val finished = activeTasks.remove(agentId) ?: continue
      val agent = agents[agentId]
      activeWireframes.remove(agentId)
      cloneGhosts.remove(finished.claim.nodeId)
      agent.mode = CursorVisualMode.POINTER
      agent.activeNodeId = null
      scheduler.completeTask(agentId, finished.claim.nodeId)
    }
  }

  /**
   * Quiet margin parking for idle agents (`cursor-swarm.js` edge-dim discipline):
   * Instead of orbiting randomly across the middle of the page, idle cursors drift gently
   * toward the left/right viewport margins and dim so active builders own the focal stage.
   */
  /**
   * Act I Kinetic Intro Orbit: all 16 Purple & Vermilion cursors smoothly orbit the center
   * tumbling-letter intro (`RINDLE` -> `ORVA`) in synchronized counter-rotating elliptical rings,
   * tightening slightly as they acquire their first layout targets.
   */
  /**
   * Physics-reactive 16-cursor intro choreography (replaces static loading-spinner ellipse):
   * - Phase 1 (0.00-0.73s): Radial shockwave recoil outward on both ball impacts (0.23s & 0.58s).
   * - Phase 3 (1.07-2.27s): Cursors lean left/right chasing the 3-left / 3-right letter ejection waves.
   * - Phase 4-5 (2.40-3.85s): Lead builders frame the expanding `PORTFOLIO` wordmark corners.
   * - Phase 6 (3.85-5.80s): Calm orbital formation around the converging stippled monochrome silhouette.
   */
  private fun updateOrbitalIntroCursors(dtSec: Float, vpTop: Float, progress: Float) {
    val tSec = progress * 5.80f
    val cx = viewportWidthPx * 0.5f
    val cy = vpTop + viewportHeightPx * 0.50f
    val baseRx = (viewportWidthPx * 0.36f).coerceAtLeast(125f)
    val baseRy = (viewportHeightPx * 0.17f).coerceAtLeast(110f)

    // Shockwave impulse on ball-drop impacts (0.23s & 0.58s)
    val recoil1 = if (tSec in 0.22f..0.42f) sin(((tSec - 0.22f) / 0.20f) * PI.toFloat()) * 0.26f else 0f
    val recoil2 = if (tSec in 0.57f..0.74f) sin(((tSec - 0.57f) / 0.17f) * PI.toFloat()) * 0.18f else 0f
    // Pendulum horizontal bias during Phase 3 ejection
    val swingBiasX =
      when {
        tSec in 1.07f..1.60f -> -viewportWidthPx * 0.12f * sin(((tSec - 1.07f) / 0.53f) * PI.toFloat())
        tSec in 1.60f..2.15f -> viewportWidthPx * 0.12f * sin(((tSec - 1.60f) / 0.55f) * PI.toFloat())
        else -> 0f
      }

    val angularSpeed = if (tSec in 3.20f..3.90f) 0.85f else 1.45f + progress * 0.75f
    for (agent in agents) {
      val dir = if (agent.id % 2 == 0) 1f else -1f
      agent.orbitAngleRad += dtSec * angularSpeed * (0.85f + (agent.id % 3) * 0.10f) * dir
      val ring = agent.orbitRadiusFactor * (1f + recoil1 + recoil2)
      val target =
        if (tSec in 3.20f..4.10f && agent.id < 4) {
          // 4 lead agents snap to the corners of expanding PORTFOLIO wordmark
          val expEase = 1f - (1f - ((tSec - 3.20f) / 0.65f).coerceIn(0f, 1f)).let { it * it * it }
          val wy = vpTop + viewportHeightPx * (0.54f + 0.16f * expEase)
          val hw = viewportWidthPx * (0.34f + 0.08f * expEase)
          val hh = 26f * densityPxPerDp * (1f + 0.24f * expEase)
          when (agent.id) {
            0 -> Offset(cx - hw, wy - hh)
            1 -> Offset(cx + hw, wy - hh)
            2 -> Offset(cx - hw, wy + hh)
            else -> Offset(cx + hw, wy + hh)
          }
        } else {
          Offset(
            x = cx + swingBiasX + cos(agent.orbitAngleRad) * baseRx * ring,
            y = cy + sin(agent.orbitAngleRad) * baseRy * ring,
          )
        }
      val follow = (1f - exp(-dtSec * 9.0f)).coerceIn(0.08f, 0.45f)
      agent.moveTo(lerpOffset(agent.pos, target, follow), recordTrail = true)
      agent.mode = if (tSec in 3.20f..4.10f && agent.id < 4) CursorVisualMode.CROSSHAIR else CursorVisualMode.POINTER
      agent.visualAlpha = 0.96f
      agent.glowEnergy = (0.70f + recoil1 * 1.1f + recoil2 * 0.9f + 0.22f * progress).coerceIn(0.60f, 1.05f)
    }
  }

  private fun updateIdleAndScoutAgents(dtSec: Float, vpTop: Float, vpBottom: Float) {
    val marginX = 18f * densityPxPerDp
    val vpHeight = (vpBottom - vpTop).coerceAtLeast(300f)
    for (agent in agents) {
      if (agent.activeNodeId != null) continue
      agent.mode = CursorVisualMode.POINTER
      agent.orbitAngleRad += dtSec * (0.45f + (agent.id % 4) * 0.08f)
      val onLeft = agent.id % 2 == 0
      val slotFrac = ((agent.id / 2).toFloat() / 8f).coerceIn(0.06f, 0.90f)
      val driftX = sin(agent.orbitAngleRad) * 8f * densityPxPerDp
      val driftY = cos(agent.orbitAngleRad * 0.7f) * 14f * densityPxPerDp
      val target =
        Offset(
          x = if (onLeft) marginX + driftX else (viewportWidthPx - marginX + driftX),
          y = vpTop + vpHeight * (0.12f + slotFrac * 0.72f) + driftY,
        )
      val follow = 1f - exp(-dtSec * 2.6f)
      agent.moveTo(lerpOffset(agent.pos, target, follow.coerceIn(0.02f, 0.20f)), recordTrail = false)
    }
  }

  /**
   * Tight, professional optical glow modulation:
   * - Active builders receive crisp luminous energy (`0.78f..1.05f`) and full opacity (`1.0f`).
   * - Idle/parked cursors dim smoothly (`visualAlpha -> 0.16f`, `glowEnergy -> 0f`) so
   *   background halos never stack into a muddy neon cloud.
   */
  private fun updateCursorGlowEnergies(dtSec: Float) {
    val proximityPx = 68f * densityPxPerDp
    val touch = visitorTouchContentPos
    val alphaStep = (dtSec * 9f).coerceIn(0.08f, 0.45f)
    for (agent in agents) {
      val isActive = agent.activeNodeId != null
      var targetEnergy = if (isActive) 0.84f else 0f
      val targetAlpha = if (isActive) 1.0f else 0.16f

      if (isActive) {
        val speedPx = hypot(agent.pos.x - agent.prevPos.x, agent.pos.y - agent.prevPos.y)
        targetEnergy += (speedPx / 32f).coerceIn(0f, 0.16f)
      }

      if (touch != null) {
        val dt = hypot(agent.pos.x - touch.x, agent.pos.y - touch.y)
        if (dt < proximityPx * 1.4f) {
          val boost = (1f - dt / (proximityPx * 1.4f))
          targetEnergy += boost * 0.25f
        }
      }

      agent.glowEnergy = lerpFloat(agent.glowEnergy, targetEnergy.coerceIn(0f, 1.08f), alphaStep)
      agent.visualAlpha = lerpFloat(agent.visualAlpha, targetAlpha, alphaStep)
    }
  }

  private fun updateConvergenceExit(dtSec: Float, progress: Float) {
    val eased = easeOutCubic(progress)
    val vpTop = scrollState.value.toFloat()
    val vpMidY = vpTop + viewportHeightPx * 0.45f
    for (agent in agents) {
      agent.mode = CursorVisualMode.POINTER
      val exitX = if (agent.id % 2 == 0) -36f * densityPxPerDp else viewportWidthPx + 36f * densityPxPerDp
      val exitY = vpMidY + ((agent.id - 8) * 28f * densityPxPerDp)
      agent.moveTo(
        lerpOffset(agent.pos, Offset(exitX, exitY), (dtSec * 5.2f).coerceIn(0.06f, 0.30f)),
        recordTrail = false,
      )
      agent.glowEnergy = lerpFloat(agent.glowEnergy, 0f, 0.25f)
      agent.visualAlpha = lerpFloat(agent.visualAlpha, (1f - eased).coerceIn(0f, 1f), 0.22f)
    }
  }

  private fun emitCommitCelebration(point: Offset, color: Color) {
    val now = simulationTimeMs
    snapRipples += SnapRippleVisual(center = point, color = color, createdAtMs = now)
    if (snapRipples.size > 10) {
      snapRipples.subList(0, snapRipples.size - 10).clear()
    }
    if (!reducedMotion) {
      val sparkCount = 5
      val baseSpeed = 46f * densityPxPerDp
      for (i in 0 until sparkCount) {
        val angle = (i.toFloat() / sparkCount.toFloat()) * (2f * PI.toFloat()) + (now % 31) * 0.09f
        completionSparks +=
          CompletionSparkVisual(
            origin = point,
            velocity = Offset(cos(angle) * baseSpeed, sin(angle) * baseSpeed),
            color = color,
            createdAtMs = now,
          )
      }
      if (completionSparks.size > 28) {
        completionSparks.subList(0, completionSparks.size - 28).clear()
      }
    }
  }

  private fun emitRealSnapSmartGuides(nodeId: String, rect: Rect) {
    val all = scheduler.allNodesSnapshot()
    val tolerancePx = 6f
    val now = simulationTimeMs
    for (other in all) {
      if (other.id == nodeId || other.phase != LayerPhase.REVEALED || !other.bounds.isValid) continue
      if (abs(other.bounds.left - rect.left) <= tolerancePx) {
        val topY = minOf(other.bounds.top, rect.top)
        val botY = maxOf(other.bounds.bottom, rect.bottom)
        if (botY - topY < viewportHeightPx * 0.85f) {
          smartGuides +=
            SmartGuideLine(
              start = Offset(rect.left, topY),
              end = Offset(rect.left, botY),
              createdAtMs = now,
            )
          break
        }
      }
      if (abs(other.bounds.top - rect.top) <= tolerancePx) {
        val leftX = minOf(other.bounds.left, rect.left)
        val rightX = maxOf(other.bounds.right, rect.right)
        val gapDp =
          (minOf(abs(rect.left - other.bounds.right), abs(other.bounds.left - rect.right)) / densityPxPerDp).toInt()
        smartGuides +=
          SmartGuideLine(
            start = Offset(leftX, rect.top),
            end = Offset(rightX, rect.top),
            label = if (gapDp in 4..96) "${gapDp}dp" else null,
            createdAtMs = now,
          )
        break
      }
    }
    if (smartGuides.size > 8) {
      smartGuides.subList(0, smartGuides.size - 8).clear()
    }
  }

  private fun updateMediaGlints(rect: Rect, progress: Float) {
    mediaGlints.clear()
    val inset = 14f
    val corners =
      listOf(
        Offset(rect.left + inset, rect.top + inset),
        Offset(rect.right - inset, rect.top + inset),
        Offset(rect.left + inset, rect.bottom - inset),
        Offset(rect.right - inset, rect.bottom - inset),
      )
    corners.forEachIndexed { idx, pt ->
      val localP = ((progress * 1.4f) - idx * 0.12f).coerceIn(0f, 1f)
      if (localP > 0f && localP < 1f) {
        mediaGlints += MediaGlintVisual(center = pt, progress = localP)
      }
    }
  }

  private fun pruneExpiredEffects() {
    val now = simulationTimeMs
    smartGuides.removeAll { now - it.createdAtMs > it.durationMs }
    snapRipples.removeAll { now - it.createdAtMs > it.durationMs }
    completionSparks.removeAll { now - it.createdAtMs > it.durationMs }
  }

  private fun syncHudCounters() {
    totalCount = scheduler.totalCount()
    completedCount = scheduler.completedCount()
    activeBuilderCount = scheduler.activeBuilderCount()
    val activeId = activeTasks.values.firstOrNull()?.claim?.nodeId.orEmpty()
    if (activeId.isNotEmpty()) {
      currentSceneLabel =
        when {
          activeId.contains("hero") -> "SCENE 01 / STUDIO"
          activeId.contains("pov") || activeId.contains("story") -> "SCENE 02 / POV"
          activeId.contains("philosophy") -> "SCENE 03 / PHILOSOPHY"
          activeId.contains("principle") -> "SCENE 04 / PRINCIPLES"
          activeId.contains("selected") || activeId.contains("orva_case") -> "SCENE 05 / ORVA"
          activeId.contains("commitments") -> "SCENE 06 / CRAFT"
          activeId.contains("mosaic") -> "SCENE 07 / FIELD NOTES"
          activeId.contains("deep_dive") -> "SCENE 08 / DEEP DIVE"
          else -> "SCENE 09 / CLOSING"
        }
    }
  }

  private fun arcControlPoint(from: Offset, to: Offset, seed: Int): Offset {
    val dx = to.x - from.x
    val dy = to.y - from.y
    val dist = hypot(dx, dy).coerceAtLeast(1f)
    val sign = if (seed % 2 == 0) 1f else -1f
    val bend = dist * (0.16f + (seed % 3) * 0.03f) * sign
    val nx = -dy / dist
    val ny = dx / dist
    return Offset((from.x + to.x) * 0.5f + nx * bend, (from.y + to.y) * 0.5f + ny * bend)
  }

  private fun quadBezier(p0: Offset, p1: Offset, p2: Offset, t: Float): Offset {
    val u = 1f - t
    return Offset(
      x = u * u * p0.x + 2f * u * t * p1.x + t * t * p2.x,
      y = u * u * p0.y + 2f * u * t * p1.y + t * t * p2.y,
    )
  }

  private fun lerpOffset(a: Offset, b: Offset, t: Float): Offset =
    Offset(a.x + (b.x - a.x) * t, a.y + (b.y - a.y) * t)

  private fun lerpFloat(a: Float, b: Float, t: Float): Float = a + (b - a) * t

  private fun easeOutCubic(t: Float): Float {
    val inv = 1f - t.coerceIn(0f, 1f)
    return 1f - inv * inv * inv
  }

  private fun easeOutQuint(t: Float): Float {
    val inv = 1f - t.coerceIn(0f, 1f)
    return 1f - inv * inv * inv * inv * inv
  }

  private fun easeInOutCubic(t: Float): Float {
    val c = t.coerceIn(0f, 1f)
    return if (c < 0.5f) 4f * c * c * c else 1f - (-2f * c + 2f).let { it * it * it } / 2f
  }
}
