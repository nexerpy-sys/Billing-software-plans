package com.rindleworks.orva.ui.about.agentic

import androidx.compose.runtime.compositionLocalOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.layout.onGloballyPositioned

val LocalAgenticController = compositionLocalOf<AgenticBuildController?> { null }

/**
 * Attaches an actual Compose About Us composable to the deterministic Agentic Build scene graph.
 *
 * Key guardrails enforced:
 * - Registers bounds in ONE consistent root/content coordinate space (`boundsInRoot - stageRootTop + scrollY`).
 * - Real Compose content stays the single source of truth; full text is always measured up-front.
 * - For [LayerKind.TEXT], reveals progressively row-by-row during draw (`drawWithContent`) synced
 *   with the I-beam caret rather than slicing multi-line text diagonally, guaranteeing ZERO layout reflow.
 * - For [LayerKind.MEDIA], performs a `zll.me`-style top-to-bottom laser scan-line wipe
 *   (`clipRect(top = 0f, bottom = size.height * fraction)`).
 * - Reads reveal progress ONLY in draw / `graphicsLayer` phases -> zero recompositions per frame.
 */
fun Modifier.agenticNode(
  id: String,
  kind: LayerKind,
  parentId: String? = null,
  cloneGroupId: String? = null,
  cloneIndex: Int = 0,
): Modifier = composed {
  val controller = LocalAgenticController.current ?: return@composed this
  val renderState = controller.getOrCreateRenderState(id)

  this
    .onGloballyPositioned { coords ->
      val rootRect = coords.boundsInRoot()
      val contentRect =
        Rect(
          left = rootRect.left,
          top = rootRect.top - controller.stageRootTopInRootPx + controller.scrollState.value.toFloat(),
          right = rootRect.right,
          bottom = rootRect.bottom - controller.stageRootTopInRootPx + controller.scrollState.value.toFloat(),
        )
      controller.registerComposableBounds(
        id = id,
        kind = kind,
        parentId = parentId,
        cloneGroupId = cloneGroupId,
        cloneIndex = cloneIndex,
        contentRect = contentRect,
      )
    }
    .graphicsLayer {
      alpha =
        if (controller.act == BuildAct.COMPLETED) 1f
        else renderState.revealAlpha.coerceIn(0f, 1f)
    }
    .drawWithContent {
      if (controller.act == BuildAct.COMPLETED) {
        drawContent()
        return@drawWithContent
      }
      val fraction = renderState.revealClipFraction.coerceIn(0f, 1f)
      if (fraction <= 0.001f) return@drawWithContent

      val accentTint = renderState.activeAccentColor.copy(alpha = 0.08f)

      if (kind == LayerKind.TEXT && fraction < 0.999f) {
        // Row-by-row progressive reveal synchronized with the active I-beam caret
        val lines = renderState.estimatedLineCount.coerceAtLeast(1)
        val scaled = (fraction * lines).coerceIn(0f, lines.toFloat())
        val completedLines = scaled.toInt().coerceIn(0, lines)
        val currentLineFrac = (scaled - completedLines).coerceIn(0f, 1f)
        val lineHeight = size.height / lines.toFloat()

        // 1. Fully reveal completed lines above
        if (completedLines > 0) {
          val completedBottom = (completedLines * lineHeight).coerceAtMost(size.height)
          if (renderState.highlightSelectionActive) {
            drawRect(color = accentTint, topLeft = Offset.Zero, size = Size(size.width, completedBottom))
          }
          clipRect(left = 0f, top = 0f, right = size.width, bottom = completedBottom) {
            this@drawWithContent.drawContent()
          }
        }

        // 2. Progressively sweep the currently-typed line left-to-right
        if (completedLines < lines && currentLineFrac > 0.001f) {
          val lineTop = completedLines * lineHeight
          val lineBottom = ((completedLines + 1) * lineHeight).coerceAtMost(size.height)
          val lineRight = size.width * currentLineFrac
          if (renderState.highlightSelectionActive) {
            drawRect(
              color = accentTint,
              topLeft = Offset(0f, lineTop),
              size = Size(lineRight, (lineBottom - lineTop).coerceAtLeast(0f)),
            )
          }
          clipRect(left = 0f, top = lineTop, right = lineRight, bottom = lineBottom) {
            this@drawWithContent.drawContent()
          }
        }
      } else if (kind == LayerKind.MEDIA && fraction < 0.999f) {
        // Top-to-bottom laser scan-line wipe (zll.me clip-path inset(0 0 100% 0 -> 0))
        clipRect(left = 0f, top = 0f, right = size.width, bottom = size.height * fraction) {
          this@drawWithContent.drawContent()
        }
      } else {
        if (renderState.highlightSelectionActive) {
          drawRect(
            color = accentTint,
            topLeft = Offset.Zero,
            size = Size(size.width * fraction, size.height),
          )
        }
        drawContent()
      }
    }
}
