package com.rindleworks.orva.ui.navigation

import android.content.Context
import android.provider.Settings
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.rindleworks.orva.di.OrvaAppContainer
import com.rindleworks.orva.domain.settings.AppLanguage
import com.rindleworks.orva.ui.about.AboutUsScreen
import com.rindleworks.orva.ui.home.HomeScreen
import com.rindleworks.orva.ui.showcase.DarkShowcasePalette
import com.rindleworks.orva.ui.showcase.LocalPaperModeToggle
import com.rindleworks.orva.ui.showcase.LocalShowcasePalette
import com.rindleworks.orva.ui.showcase.OrvaShowcaseColors
import com.rindleworks.orva.ui.showcase.OrvaShowcaseFonts
import com.rindleworks.orva.ui.showcase.OrvaShowcaseViewModel
import com.rindleworks.orva.ui.showcase.PaperShowcasePalette
import com.rindleworks.orva.ui.showcase.ShowcaseUiEvent
import com.rindleworks.orva.ui.showcase.currentShowcasePalette
import kotlinx.serialization.Serializable

@Serializable data object HomeRoute
@Serializable data object AboutRoute
@Serializable data class OperationalWorkspaceRoute(val destinationKey: String)

/**
 * Root Compose shell hosting ORVA's Home & About Us showcase screens with type-safe Navigation
 * Compose, minimal obsidian/paper showcase top chrome, English/Bengali switcher, instant Paper
 * Mode toggle, system reduced-motion detection, and clean operational handoff routes.
 */
@Composable
fun OrvaShowcaseApp(
  container: OrvaAppContainer,
  modifier: Modifier = Modifier,
) {
  val context = LocalContext.current
  val navController = rememberNavController()
  val viewModel: OrvaShowcaseViewModel =
    viewModel(factory = remember(container) { OrvaShowcaseViewModel.Factory(container) })

  val homeState by viewModel.homeState.collectAsStateWithLifecycle()
  val aboutState by viewModel.aboutState.collectAsStateWithLifecycle()
  val backStackEntry by navController.currentBackStackEntryAsState()
  val currentRoute = backStackEntry?.destination?.route.orEmpty()
  val isAboutActive = currentRoute.contains("AboutRoute")
  val isHomeActive = currentRoute.contains("HomeRoute") || currentRoute.isEmpty()

  val reducedMotion = remember(context) { isSystemReducedMotion(context) }
  var isPaperMode by remember { mutableStateOf(false) }
  val activePalette = if (isPaperMode) PaperShowcasePalette else DarkShowcasePalette
  val togglePaperMode = remember { { isPaperMode = !isPaperMode } }

  val handleEvent: (ShowcaseUiEvent) -> Unit = { event ->
    when (event) {
      ShowcaseUiEvent.StartBilling ->
        navController.navigate(OperationalWorkspaceRoute("billing")) { launchSingleTop = true }
      ShowcaseUiEvent.AddStock ->
        navController.navigate(OperationalWorkspaceRoute("add_stock")) { launchSingleTop = true }
      ShowcaseUiEvent.OpenInventory ->
        navController.navigate(OperationalWorkspaceRoute("inventory")) { launchSingleTop = true }
      ShowcaseUiEvent.OpenSettings ->
        navController.navigate(OperationalWorkspaceRoute("settings")) { launchSingleTop = true }
      ShowcaseUiEvent.OpenAboutUs ->
        navController.navigate(AboutRoute) { launchSingleTop = true }
      ShowcaseUiEvent.BackToHome ->
        navController.navigate(HomeRoute) {
          popUpTo(HomeRoute) { inclusive = false }
          launchSingleTop = true
        }
      ShowcaseUiEvent.ToggleLanguage -> viewModel.toggleLanguage()
    }
  }

  CompositionLocalProvider(
    LocalShowcasePalette provides activePalette,
    LocalPaperModeToggle provides togglePaperMode,
  ) {
    Box(modifier = modifier.fillMaxSize()) {
      Scaffold(
        modifier = Modifier.fillMaxSize(),
        containerColor = activePalette.canvasDeep,
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        topBar = {
          ShowcaseTopBar(
            language = homeState.language,
            isHomeActive = isHomeActive,
            isAboutActive = isAboutActive,
            isPaperMode = isPaperMode,
            onNavigateHome = { handleEvent(ShowcaseUiEvent.BackToHome) },
            onNavigateAbout = { handleEvent(ShowcaseUiEvent.OpenAboutUs) },
            onToggleLanguage = { handleEvent(ShowcaseUiEvent.ToggleLanguage) },
            onTogglePaperMode = togglePaperMode,
          )
        },
      ) { innerPadding ->
        NavHost(
          navController = navController,
          startDestination = HomeRoute,
          modifier = Modifier.fillMaxSize().padding(innerPadding),
        ) {
          composable<HomeRoute> {
            HomeScreen(
              state = homeState,
              reducedMotion = reducedMotion,
              onEvent = handleEvent,
            )
          }
          composable<AboutRoute> {
            AboutUsScreen(
              state = aboutState,
              reducedMotion = reducedMotion,
              onEvent = handleEvent,
            )
          }
          composable<OperationalWorkspaceRoute> { entry ->
            val key = entry.arguments?.getString("destinationKey") ?: "billing"
            OperationalDestinationHandoffScreen(
              destinationKey = key,
              container = container,
              language = homeState.language,
              onBackToHome = { handleEvent(ShowcaseUiEvent.BackToHome) },
            )
          }
        }
      }
    }
  }
}

@Composable
private fun ShowcaseTopBar(
  language: AppLanguage,
  isHomeActive: Boolean,
  isAboutActive: Boolean,
  isPaperMode: Boolean,
  onNavigateHome: () -> Unit,
  onNavigateAbout: () -> Unit,
  onToggleLanguage: () -> Unit,
  onTogglePaperMode: () -> Unit,
) {
  val palette = currentShowcasePalette()
  Column(
    modifier =
      Modifier
        .fillMaxWidth()
        .background(palette.canvasDeep)
        .windowInsetsPadding(WindowInsets.statusBars),
  ) {
    Row(
      modifier =
        Modifier
          .fillMaxWidth()
          .padding(horizontal = 20.dp, vertical = 8.dp),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Row(
        modifier =
          Modifier
            .minimumInteractiveComponentSize()
            .clickable(role = Role.Button, onClick = onNavigateHome)
            .testTag("topbar_brand_home"),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
      ) {
        Box(
          modifier =
            Modifier
              .size(8.dp)
              .clip(CircleShape)
              .background(OrvaShowcaseColors.AccentVermilion),
        )
        Text(
          text = "RINDLE WORKS",
          fontFamily = OrvaShowcaseFonts.SpaceGrotesk,
          fontWeight = FontWeight.Bold,
          fontSize = 13.5.sp,
          letterSpacing = 2.sp,
          color = palette.inkPrimary,
        )
      }

      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp),
      ) {
        TopBarTab(
          label = if (language == AppLanguage.Bengali) "হোম" else "Home",
          selected = isHomeActive,
          language = language,
          testTag = "topbar_tab_home",
          onClick = onNavigateHome,
        )
        TopBarTab(
          label = if (language == AppLanguage.Bengali) "আমাদের কথা" else "About",
          selected = isAboutActive,
          language = language,
          testTag = "topbar_tab_about",
          onClick = onNavigateAbout,
        )
        Spacer(Modifier.width(2.dp))
        Box(
          modifier =
            Modifier
              .minimumInteractiveComponentSize()
              .clip(RoundedCornerShape(6.dp))
              .background(palette.surfaceRaised)
              .border(1.dp, palette.hairline, RoundedCornerShape(6.dp))
              .clickable(role = Role.Button, onClick = onTogglePaperMode)
              .padding(horizontal = 8.dp, vertical = 6.dp)
              .testTag("topbar_paper_toggle"),
          contentAlignment = Alignment.Center,
        ) {
          Text(
            text = if (isPaperMode) "DARK" else "PAPER",
            fontFamily = OrvaShowcaseFonts.IbmPlexMono,
            fontWeight = FontWeight.SemiBold,
            fontSize = 10.sp,
            letterSpacing = 0.8.sp,
            color = if (isPaperMode) OrvaShowcaseColors.AccentVermilion else palette.inkSecondary,
          )
        }
        Box(
          modifier =
            Modifier
              .minimumInteractiveComponentSize()
              .clip(RoundedCornerShape(6.dp))
              .background(palette.surfaceRaised)
              .border(1.dp, palette.hairline, RoundedCornerShape(6.dp))
              .clickable(role = Role.Button, onClick = onToggleLanguage)
              .padding(horizontal = 10.dp, vertical = 6.dp)
              .testTag("topbar_language_toggle"),
          contentAlignment = Alignment.Center,
        ) {
          Text(
            text = if (language == AppLanguage.Bengali) "EN" else "বাং",
            fontFamily = OrvaShowcaseFonts.NotoSansBengali,
            fontWeight = FontWeight.Medium,
            fontSize = 12.sp,
            color = if (isPaperMode) OrvaShowcaseColors.AccentViolet else OrvaShowcaseColors.AccentVioletSoft,
          )
        }
      }
    }
    HorizontalDivider(thickness = 1.dp, color = palette.hairline)
  }
}

@Composable
private fun TopBarTab(
  label: String,
  selected: Boolean,
  language: AppLanguage,
  testTag: String,
  onClick: () -> Unit,
) {
  val palette = currentShowcasePalette()
  Box(
    modifier =
      Modifier
        .minimumInteractiveComponentSize()
        .clip(RoundedCornerShape(6.dp))
        .background(if (selected) OrvaShowcaseColors.AccentVioletWash else Color.Transparent)
        .clickable(role = Role.Button, onClick = onClick)
        .padding(horizontal = 10.dp, vertical = 6.dp)
        .testTag(testTag),
    contentAlignment = Alignment.Center,
  ) {
    Text(
      text = label,
      fontFamily = OrvaShowcaseFonts.body(language),
      fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal,
      fontSize = 13.sp,
      color =
        if (selected) {
          if (palette.isPaperMode) OrvaShowcaseColors.AccentViolet else OrvaShowcaseColors.AccentVioletSoft
        } else {
          palette.inkSecondary
        },
    )
  }
}

/**
 * Lightweight truthful operational route bridge (operational Billing/Inventory/Settings UIs
 * remain cleanly isolated from the showcase pass per handoff boundaries).
 */
@Composable
private fun OperationalDestinationHandoffScreen(
  destinationKey: String,
  container: OrvaAppContainer,
  language: AppLanguage,
  onBackToHome: () -> Unit,
) {
  val context = LocalContext.current
  val hasExternalOrva = container.storagePaths.hasExternalOrvaFolderAccess()
  val title =
    when (destinationKey) {
      "billing" -> if (language == AppLanguage.Bengali) "কাউন্টার বিলিং" else "Counter Billing"
      "add_stock" -> if (language == AppLanguage.Bengali) "নতুন স্টক যোগ" else "Add Stock Entry"
      "inventory" -> if (language == AppLanguage.Bengali) "মেয়াদ ও স্টক" else "Inventory & Expiry"
      else -> if (language == AppLanguage.Bengali) "সেটিংস ও স্টোরেজ" else "Settings & Storage"
    }

  Box(
    modifier =
      Modifier
        .fillMaxSize()
        .background(OrvaShowcaseColors.CanvasDeep)
        .padding(24.dp),
    contentAlignment = Alignment.Center,
  ) {
    Column(
      modifier =
        Modifier
          .widthIn(max = 520.dp)
          .fillMaxWidth()
          .clip(RoundedCornerShape(8.dp))
          .background(OrvaShowcaseColors.CanvasSecondary)
          .border(1.dp, OrvaShowcaseColors.Hairline, RoundedCornerShape(8.dp))
          .padding(24.dp),
      verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
      Text(
        text = "ORVA · OPERATIONAL WORKSPACE",
        fontFamily = OrvaShowcaseFonts.IbmPlexMono,
        fontSize = 11.sp,
        letterSpacing = 1.4.sp,
        color = OrvaShowcaseColors.InkMuted,
      )
      Text(
        text = title,
        fontFamily = OrvaShowcaseFonts.display(language),
        fontWeight = FontWeight.SemiBold,
        fontSize = 26.sp,
        color = OrvaShowcaseColors.InkPrimary,
      )
      Text(
        text =
          if (language == AppLanguage.Bengali) {
            "ব্যাকএন্ড ইঞ্জিন (SQLite, FEFO, GST, স্টক এন্ট্রি ও ব্যাকআপ) সংযুক্ত ও প্রস্তুত। স্থানীয় ORVA ফোল্ডার: ${container.storagePaths.activeOrvaFolder().absolutePath}"
          } else {
            "Production backend services (SQLite, earliest-expiry allocation, integer-paise GST, stock entry & backups) are connected and ready. Active ORVA folder: ${container.storagePaths.activeOrvaFolder().absolutePath}"
          },
        fontFamily = OrvaShowcaseFonts.body(language),
        fontSize = 14.sp,
        lineHeight = 21.sp,
        color = OrvaShowcaseColors.InkSecondary,
      )

      if (!hasExternalOrva) {
        Button(
          onClick = {
            runCatching {
              context.startActivity(container.storagePaths.createExternalStorageAccessIntent())
            }
          },
          colors =
            ButtonDefaults.buttonColors(
              containerColor = OrvaShowcaseColors.AccentViolet,
              contentColor = OrvaShowcaseColors.CanvasDeep,
            ),
          shape = RoundedCornerShape(4.dp),
          modifier = Modifier.minimumInteractiveComponentSize().testTag("enable_orva_folder_btn"),
        ) {
          Text(
            text =
              if (language == AppLanguage.Bengali) "ORVA ফোল্ডার অ্যাক্সেস চালু করুন"
              else "Enable /ORVA Folder Access",
            fontFamily = OrvaShowcaseFonts.display(language),
            fontWeight = FontWeight.SemiBold,
          )
        }
      }

      Spacer(Modifier.height(4.dp))
      OutlinedButton(
        onClick = onBackToHome,
        border = BorderStroke(1.dp, OrvaShowcaseColors.Hairline),
        colors = ButtonDefaults.outlinedButtonColors(contentColor = OrvaShowcaseColors.InkPrimary),
        shape = RoundedCornerShape(4.dp),
        modifier = Modifier.minimumInteractiveComponentSize().testTag("workspace_back_home_btn"),
      ) {
        Text(
          text = if (language == AppLanguage.Bengali) "← হোমে ফিরে যান" else "← Back to Home",
          fontFamily = OrvaShowcaseFonts.display(language),
        )
      }
    }
  }
}

private fun isSystemReducedMotion(context: Context): Boolean =
  runCatching {
    Settings.Global.getFloat(
      context.contentResolver,
      Settings.Global.ANIMATOR_DURATION_SCALE,
      1f,
    ) == 0f
  }.getOrDefault(false)
