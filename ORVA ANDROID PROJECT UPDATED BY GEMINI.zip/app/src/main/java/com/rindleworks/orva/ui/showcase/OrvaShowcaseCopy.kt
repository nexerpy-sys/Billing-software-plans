package com.rindleworks.orva.ui.showcase

import com.rindleworks.orva.domain.settings.AppLanguage

enum class ReadinessBackupState {
  Saved,
  DueToday,
  NotYetBackedUp,
}

data class FolderCopy(
  val id: String,
  val tabLabel: String,
  val title: String,
  val actionLabel: String,
  val body: String,
  val sheets: List<String>,
)

data class PrincipleCopy(
  val number: String,
  val title: String,
  val description: String,
)

data class OrvaCaseRailItem(
  val code: String,
  val index: String,
  val title: String,
  val summary: String,
  val tags: List<String>,
)

/**
 * Authoritative bilingual (English / Bengali) display copy implementing
 * `RINDLE_WORKS_ORVA_FRONTEND_MASTER_DIRECTIVE.md` (§3 & §4).
 *
 * Guardrails enforced:
 * - Zero hardcoded fallback phone numbers or emails.
 * - Zero invented founding year, team bio, office address, customer counts, awards, or fake projects.
 * - Honest development status: ORVA Android edition is in active development.
 * - Preserves Rindle Works as studio identity and ORVA as flagship product.
 */
object OrvaShowcaseCopy {
  fun toBengaliDigits(value: Int): String = toBengaliDigits(value.toString())

  fun toBengaliDigits(raw: String): String {
    val map = charArrayOf('০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯')
    return buildString(raw.length) {
      for (ch in raw) {
        if (ch in '0'..'9') append(map[ch - '0']) else append(ch)
      }
    }
  }

  fun backupStatusLabel(state: ReadinessBackupState, language: AppLanguage): String =
    when (language) {
      AppLanguage.English ->
        when (state) {
          ReadinessBackupState.Saved -> "Saved"
          ReadinessBackupState.DueToday -> "Due today"
          ReadinessBackupState.NotYetBackedUp -> "Not yet backed up"
        }
      AppLanguage.Bengali ->
        when (state) {
          ReadinessBackupState.Saved -> "সুরক্ষিত"
          ReadinessBackupState.DueToday -> "বকেয়া"
          ReadinessBackupState.NotYetBackedUp -> "এখনো ব্যাকআপ হয়নি"
        }
    }

  // ---- Home H1 (Master Directive §3.1) ----
  fun homeEyebrow(language: AppLanguage): String =
    if (language == AppLanguage.Bengali) "RINDLE WORKS — উদ্দেশ্যমূলক সফটওয়্যার"
    else "RINDLE WORKS — SOFTWARE, WITH INTENTION"

  fun homeHeadlineTop(language: AppLanguage): String =
    if (language == AppLanguage.Bengali) "কাজের ছন্দেই" else "BUILT AROUND"

  fun homeHeadlineItalic(language: AppLanguage): String =
    if (language == AppLanguage.Bengali) "তৈরি।" else "THE WORK."

  fun homeSubtitle(language: AppLanguage): String =
    if (language == AppLanguage.Bengali) {
      "গুরুত্বপূর্ণ কাজ, সিদ্ধান্ত ও খুঁটিনাটির জন্য যত্নশীল সফটওয়্যার।"
    } else {
      "Thoughtful software for the tasks, decisions and details that matter."
    }

  fun startBillingCta(language: AppLanguage): String =
    if (language == AppLanguage.Bengali) "ORVA দেখুন →" else "EXPLORE ORVA →"

  fun studioSecondaryCta(language: AppLanguage): String =
    if (language == AppLanguage.Bengali) "স্টুডিও পরিচিতি" else "THE STUDIO"

  fun addStockCta(language: AppLanguage): String =
    if (language == AppLanguage.Bengali) "+ স্টক যোগ" else "+ ADD STOCK"

  fun readinessStrip(
    shopName: String,
    usableMedicines: Int,
    expiringSoonCount: Int,
    backupState: ReadinessBackupState,
    language: AppLanguage,
  ): String {
    val backupText = backupStatusLabel(backupState, language)
    return if (language == AppLanguage.Bengali) {
      "$shopName · ${toBengaliDigits(usableMedicines)}টি ওষুধ প্রস্তুত · ৩০ দিনের মধ্যে মেয়াদ শেষ: ${toBengaliDigits(expiringSoonCount)} · ব্যাকআপ: $backupText"
    } else {
      "$shopName · $usableMedicines medicines ready · $expiringSoonCount expiring within 30 days · Backup: $backupText"
    }
  }

  fun lanternHint(language: AppLanguage): String =
    if (language == AppLanguage.Bengali) "আলো ফেলতে স্পর্শ করে টানুন" else "TOUCH & DRAG TO ILLUMINATE"

  // ---- Home H2/H3 (Cinematic Image/Typography & Flagship ORVA §3.3–3.4) ----
  fun homeIdentityLeftLine1(language: AppLanguage): String =
    if (language == AppLanguage.Bengali) "পরিষ্কার বিল।" else "CLEAR BILLS."

  fun homeIdentityLeftLine2(language: AppLanguage): String =
    if (language == AppLanguage.Bengali) "সতর্ক স্টক।" else "CAREFUL STOCK."

  fun flagshipEyebrow(language: AppLanguage): String =
    if (language == AppLanguage.Bengali) "প্রধান পণ্য / ০১" else "FLAGSHIP PRODUCT / 01"

  fun flagshipDescriptor(language: AppLanguage): String =
    if (language == AppLanguage.Bengali) "ফার্মেসি বিলিং ও ইনভেন্টরি" else "PHARMACY BILLING & INVENTORY"

  fun flagshipBody(language: AppLanguage): String =
    if (language == AppLanguage.Bengali) {
      "ফার্মেসির প্রতিদিনের বাস্তব কাজের জন্য একটি নিবিড় পণ্য: বিলিং, ব্যাচ-ভিত্তিক স্টক, মেয়াদ তদারকি এবং নির্ভরযোগ্য রেকর্ড।"
    } else {
      "A focused product for the daily reality of pharmacy work: billing, batch-aware stock, expiry visibility and dependable records."
    }

  fun flagshipStateLabel(language: AppLanguage): String =
    if (language == AppLanguage.Bengali) "সক্রিয় নির্মাণে" else "IN ACTIVE DEVELOPMENT"

  fun flagshipAction(language: AppLanguage): String =
    if (language == AppLanguage.Bengali) "পণ্যটি দেখুন →" else "EXPLORE THE PRODUCT →"

  // ---- Home H5 (Three Physical Layered Panels §3.5: PRODUCT / CRAFT / ENGINEERING) ----
  fun folderSectionHeading(language: AppLanguage): String =
    if (language == AppLanguage.Bengali) "তিনটি স্তম্ভ।" else "THREE PILLARS OF THE WORK."

  fun workspaceFolders(
    expiringSoonCount: Int,
    appVersion: String,
    language: AppLanguage,
  ): List<FolderCopy> =
    if (language == AppLanguage.Bengali) {
      listOf(
        FolderCopy(
          id = "quick_billing",
          tabLabel = "০১ · PRODUCT",
          title = "PRODUCT",
          actionLabel = "কাউন্টার বিলিং খুলুন →",
          body = "দ্রুত বিলিং, ব্যাচ বাছাই এবং পরিষ্কার গ্রাহক রসিদ—সবকিছু স্থানীয়ভাবে।",
          sheets =
            listOf(
              "দ্রুত কাউন্টার বিলিং ও রসিদ",
              "ব্যাচ ও মেয়াদ সুরক্ষা",
              "৩০ দিনের মধ্যে মেয়াদ শেষ: ${toBengaliDigits(expiringSoonCount)}",
            ),
        ),
        FolderCopy(
          id = "expiry_stock",
          tabLabel = "০২ · CRAFT",
          title = "CRAFT",
          actionLabel = "ইনভেন্টরি দেখুন →",
          body = "কম ঘর্ষণ, স্পষ্ট সিদ্ধান্ত এবং প্রতিদিনের কাজের জন্য শান্ত ইন্টারফেস।",
          sheets =
            listOf(
              "অপ্রয়োজনীয় জটিলতাহীন বিন্যাস",
              "স্পষ্ট অগ্রাধিকার ও পরবর্তী ধাপ",
              "বাংলা ও ইংরেজি উভয় ভাষায় স্পষ্টতা",
            ),
        ),
        FolderCopy(
          id = "about_orva",
          tabLabel = "০৩ · ENGINEERING",
          title = "ENGINEERING",
          actionLabel = "স্টুডিও পোর্টফোলিও পড়ুন →",
          body = "পূর্ণ পয়সার হিসাব, আগে মেয়াদ শেষ হওয়া ব্যাচ বাছাই ও স্থানীয় ব্যাকআপ।",
          sheets =
            listOf(
              "Rindle Works · ORVA v$appVersion",
              "অ্যাটমিক ইনভয়েস ও স্টক লেনদেন",
              "স্থানীয় স্টোরেজ ও ব্যাকআপ নিয়ন্ত্রণ",
            ),
        ),
      )
    } else {
      listOf(
        FolderCopy(
          id = "quick_billing",
          tabLabel = "01 · PRODUCT",
          title = "PRODUCT",
          actionLabel = "OPEN COUNTER BILLING →",
          body = "Fast billing, batch-aware stock and clear receipts—kept local on your device.",
          sheets =
            listOf(
              "Counter Billing & GST Receipts",
              "Batch & Expiry Visibility",
              "$expiringSoonCount Expiring ≤ 30 Days",
            ),
        ),
        FolderCopy(
          id = "expiry_stock",
          tabLabel = "02 · CRAFT",
          title = "CRAFT",
          actionLabel = "INSPECT INVENTORY →",
          body = "Less friction, clearer decisions and calm interfaces built for ordinary days.",
          sheets =
            listOf(
              "Every Element Earns Its Place",
              "Readable Under Counter Pressure",
              "English & Bengali Native Clarity",
            ),
        ),
        FolderCopy(
          id = "about_orva",
          tabLabel = "03 · ENGINEERING",
          title = "ENGINEERING",
          actionLabel = "ENTER THE STUDIO →",
          body = "Integer-paise math, earliest-expiry allocation and local-first dependability.",
          sheets =
            listOf(
              "Rindle Works · ORVA v$appVersion",
              "Atomic Invoice & Stock Ledger",
              "Local-First Backup & Recovery",
            ),
        ),
      )
    }

  // ---- Shared Closing / Footer ----
  fun closingLine(language: AppLanguage): String =
    if (language == AppLanguage.Bengali) "উদ্দেশ্যমূলক সফটওয়্যার।" else "Software, with intention."

  fun linkStartBilling(language: AppLanguage): String =
    if (language == AppLanguage.Bengali) "ORVA দেখুন" else "Explore ORVA"

  fun linkAboutUs(language: AppLanguage): String =
    if (language == AppLanguage.Bengali) "স্টুডিও পরিচিতি" else "The Studio"

  fun linkBackToHome(language: AppLanguage): String =
    if (language == AppLanguage.Bengali) "হোমে ফিরে যান" else "Back to Home"

  fun linkBackToTop(language: AppLanguage): String =
    if (language == AppLanguage.Bengali) "উপরে যান ↑" else "Back to top ↑"

  // ---- About Us 9-Scene Portfolio (Master Directive §4.1) ----
  fun aboutMetaLeft(language: AppLanguage): String =
    if (language == AppLanguage.Bengali) "RINDLE WORKS / স্টুডিও" else "RINDLE WORKS / THE STUDIO"

  fun aboutHeadline(language: AppLanguage): String =
    if (language == AppLanguage.Bengali) "কাজের মান লুকিয়ে থাকে খুঁটিনাটিতে।" else "THE WORK IS IN THE DETAILS."

  fun aboutLead(language: AppLanguage): String =
    if (language == AppLanguage.Bengali) {
      "কাজ বাস্তবে যেভাবে চলে, আমরা সেইভাবেই সফটওয়্যার তৈরি করি।"
    } else {
      "We build software around the way work actually happens."
    }

  fun aboutStoryLabel(language: AppLanguage): String =
    if (language == AppLanguage.Bengali) "০২ / দৃষ্টিভঙ্গি" else "02 / POINT OF VIEW"

  fun aboutStoryParagraph1(language: AppLanguage): String =
    if (language == AppLanguage.Bengali) {
      "ভালো সফটওয়্যার শুধু গোছানো দেখায় না। এটি কাজের চাপ বোঝে, পরবর্তী ধাপ স্পষ্ট করে এবং মানুষের নির্ভর করা প্রতিটি খুঁটিনাটি সুরক্ষিত রাখে।"
    } else {
      "Good software does more than look organised. It understands the pressure of the task, makes the next step clear, and protects the details people depend on."
    }

  fun aboutStoryParagraph2(language: AppLanguage): String =
    if (language == AppLanguage.Bengali) {
      "এই ভাবনা থেকেই Rindle Works-এর জন্ম। বাস্তব কর্মপ্রবাহের জন্য নিবিড় সফটওয়্যার গড়তে আমরা প্রোডাক্ট ভাবনা ও ইঞ্জিনিয়ারিং শৃঙ্খলাকে একসাথে আনি। স্ক্রিন কেবল কাজের একটি অংশ; এর পেছনের সিদ্ধান্তগুলোও সমান গুরুত্বপূর্ণ।"
    } else {
      "Rindle Works is shaped by that idea. We bring product thinking and engineering discipline together to make focused software for real workflows. The screen is only one part of the work; the decisions behind it matter just as much."
    }

  fun philosophyLead(language: AppLanguage): String =
    if (language == AppLanguage.Bengali) "ভালো সফটওয়্যার মানুষের" else "GOOD SOFTWARE GIVES PEOPLE"

  fun philosophyAccent(language: AppLanguage): String =
    if (language == AppLanguage.Bengali) "মনোযোগ ফিরিয়ে দেয়।" else "THEIR ATTENTION BACK."

  fun philosophySupport(language: AppLanguage): String =
    if (language == AppLanguage.Bengali) {
      "কম ঘর্ষণ। স্পষ্ট সিদ্ধান্ত। দ্বিতীয়বার ভাবার কম ঝামেলা। সেরা ইন্টারফেস নিজে নজর কাড়ে না; বরং কাজকে এগিয়ে নিয়ে যায়।"
    } else {
      "Less friction. Clearer decisions. Fewer things to second-guess. The best interface is not the one asking to be noticed; it is the one helping the work move forward."
    }

  fun aboutPrinciplesLabel(language: AppLanguage): String =
    if (language == AppLanguage.Bengali) "০৪ / পাঁচটি মূলনীতি" else "04 / PRINCIPLES"

  fun aboutPrinciples(language: AppLanguage): List<PrincipleCopy> =
    if (language == AppLanguage.Bengali) {
      listOf(
        PrincipleCopy("01", "বাস্তব কাজ থেকে শুরু", "শুধু ফিচারের তালিকা নয়—কাজের পরিবেশ, বাধা ও দায়িত্বগুলো গভীরভাবে বুঝে নেওয়া।"),
        PrincipleCopy("02", "স্পষ্টতাকে দৃশ্যমান করা", "প্রয়োজনীয় তথ্য সঠিক জায়গায় রাখা এবং পরবর্তী ধাপ স্বতঃস্ফূর্ত করে তোলা।"),
        PrincipleCopy("03", "রেকর্ডের প্রতি সম্মান", "নির্ভুলতা, অনুসন্ধানযোগ্যতা ও নিরাপদ তথ্য-পরিবর্তন পণ্যের মূল অংশ।"),
        PrincipleCopy("04", "সাধারণ দিনের জন্য নকশা", "কেবল ডেমোতে নয়—পুনরাবৃত্তি, ব্যস্ততা ও অনিশ্চিত পরিস্থিতিতেও যেন কর্মপ্রবাহ টিকে থাকে।"),
        PrincipleCopy("05", "অদৃশ্য অংশগুলোও সম্পূর্ণ করা", "ফাঁকা অবস্থা, ব্যতিক্রম, পুনরুদ্ধার, গতি ও সহজগম্যতাও প্রোডাক্ট ডিজাইনের অংশ।"),
      )
    } else {
      listOf(
        PrincipleCopy(
          number = "01",
          title = "START WITH THE REAL TASK",
          description = "Understand the conditions, interruptions and responsibilities around the work—not just the feature list.",
        ),
        PrincipleCopy(
          number = "02",
          title = "MAKE CLARITY VISIBLE",
          description = "Put essential information where it belongs. Make the next action obvious. Let every element earn its place.",
        ),
        PrincipleCopy(
          number = "03",
          title = "RESPECT THE RECORD",
          description = "Accuracy, traceability and safe state changes are part of the product—not details to repair later.",
        ),
        PrincipleCopy(
          number = "04",
          title = "DESIGN FOR THE ORDINARY DAY",
          description = "A workflow must hold up under repetition, interruptions and imperfect conditions, not only in a polished demo.",
        ),
        PrincipleCopy(
          number = "05",
          title = "FINISH THE UNSEEN PARTS",
          description = "Empty states, edge cases, recovery, speed, accessibility and feedback are also product design.",
        ),
      )
    }

  // ---- Scene 05: Selected Work / ORVA ----
  fun selectedWorkEyebrow(language: AppLanguage): String =
    if (language == AppLanguage.Bengali) "নির্বাচিত কাজ / কেস ০০১" else "SELECTED WORK / CASE 001"

  fun selectedWorkStatement(language: AppLanguage): String =
    if (language == AppLanguage.Bengali) "কাউন্টারেই প্রতিটি খুঁটিনাটির গুরুত্ব।" else "THE COUNTER IS WHERE EVERY DETAIL COUNTS."

  fun selectedWorkBody1(language: AppLanguage): String =
    if (language == AppLanguage.Bengali) {
      "ফার্মেসি পরিচালনার প্রতিদিনের চাহিদা ঘিরে ORVA তৈরি হচ্ছে: ওষুধ খোঁজা, ব্যাচ-ভিত্তিক স্টক, মেয়াদ সচেতনতা, বিলিং, রিটার্ন এবং নির্ভরযোগ্য রেকর্ড।"
    } else {
      "ORVA is being shaped around the everyday demands of pharmacy operations: medicine lookup, batch-aware stock, expiry awareness, billing, returns and dependable records."
    }

  fun selectedWorkBody2(language: AppLanguage): String =
    if (language == AppLanguage.Bengali) {
      "এর কেন্দ্রে রয়েছে স্থানীয় পরিচালনা এবং নির্ভুল লেনদেন। লক্ষ্য হলো কাউন্টারের কাজের জন্য একটি স্পষ্ট ও নির্ভরযোগ্য কর্মক্ষেত্র—কোনো সাধারণ চেকআউট টেমপ্লেট নয়।"
    } else {
      "Its product direction puts local-first operation and careful transaction handling at the centre. The aim is a clear, dependable workspace for the work behind the counter—not another generic checkout template."
    }

  fun orvaCaseRail(language: AppLanguage): List<OrvaCaseRailItem> =
    listOf(
      OrvaCaseRailItem(
        code = "ORVA_01",
        index = "01",
        title = if (language == AppLanguage.Bengali) "কাউন্টার বিলিং" else "Counter Billing",
        summary =
          if (language == AppLanguage.Bengali) "দ্রুত ওষুধ বাছাই, পূর্ণ পয়সার GST হিসাব এবং অ্যাটমিক ইনভয়েস চূড়ান্তকরণ।"
          else "Fast lookup, integer-paise GST calculation and atomic invoice finalisation.",
        tags = listOf("BILLING", "GST", "PAISE"),
      ),
      OrvaCaseRailItem(
        code = "ORVA_02",
        index = "02",
        title = if (language == AppLanguage.Bengali) "ব্যাচ ও মেয়াদ (FEFO)" else "Batch & FEFO Stock",
        summary =
          if (language == AppLanguage.Bengali) "আগে মেয়াদ শেষ হওয়া ব্যাচ অগ্রাধিকার এবং মেয়াদোত্তীর্ণ স্টক আলাদা রাখা।"
          else "Earliest-expiry-first allocation keeping expired stock out of regular sales.",
        tags = listOf("FEFO", "BATCHES", "EXPIRY"),
      ),
      OrvaCaseRailItem(
        code = "ORVA_03",
        index = "03",
        title = if (language == AppLanguage.Bengali) "রিটার্ন ও সংশোধন" else "Returns & Ledger",
        summary =
          if (language == AppLanguage.Bengali) "সেলস রিটার্ন, বাতিলকরণ এবং প্রতিটি স্টক পরিবর্তনের নির্ভরযোগ্য রেকর্ড।"
          else "Traceable sales returns, cancellations and auditable stock movement records.",
        tags = listOf("RETURNS", "LEDGER", "AUDIT"),
      ),
      OrvaCaseRailItem(
        code = "ORVA_04",
        index = "04",
        title = if (language == AppLanguage.Bengali) "স্থানীয় ব্যাকআপ" else "Local-First Vault",
        summary =
          if (language == AppLanguage.Bengali) "ইন্টারনেট ছাড়াই সম্পূর্ণ পরিচালনা এবং দোকানের নিজস্ব ব্যাকআপ ও পুনরুদ্ধার।"
          else "Zero cloud lock-in with local SQLite persistence and portable shop backups.",
        tags = listOf("SQLITE", "OFFLINE", "BACKUP"),
      ),
    )

  // ---- Scene 06: Product Concerns & Engineering Commitments ----
  fun productConcerns(language: AppLanguage): List<String> =
    if (language == AppLanguage.Bengali) {
      listOf(
        "বিলিংয়ের নির্ভুলতা",
        "ইনভেন্টরি ও ব্যাচ ব্যবস্থাপনা",
        "মেয়াদ-সচেতন স্টক",
        "রিটার্ন ও বাতিলকরণ",
        "স্থানীয়-প্রথম পরিচালনা",
        "ব্যাকআপ ও পুনরুদ্ধার",
      )
    } else {
      listOf(
        "Billing integrity",
        "Inventory and batches",
        "Expiry-aware stock",
        "Returns and cancellation",
        "Local-first operation",
        "Backup and recovery",
      )
    }

  fun engineeringCommitments(language: AppLanguage): List<String> =
    if (language == AppLanguage.Bengali) {
      listOf(
        "পূর্ণ পয়সার এককে আর্থিক হিসাব",
        "সহস্রাংশ পূর্ণসংখ্যায় পরিমাণের হিসাব",
        "FEFO বরাদ্দ (আগে মেয়াদ শেষ হওয়া ব্যাচ আগে)",
        "অ্যাটমিক ইনভয়েস চূড়ান্তকরণ ও স্টক পরিবর্তন",
        "Compose UI থেকে ডোমেইন নিয়ম পৃথক রাখা",
        "সুস্পষ্ট স্কিমা মাইগ্রেশন ও যাচাইকরণ",
      )
    } else {
      listOf(
        "Money represented as integer paise",
        "Quantities represented in thousandths",
        "FEFO allocation (earliest expiry first)",
        "Atomic invoice finalisation and stock movements",
        "Domain rules separated from Compose UI",
        "Explicit migrations and validation",
      )
    }

  // ---- Scene 08: Deep Dive / ORVA ----
  fun deepDiveEyebrow(language: AppLanguage): String =
    if (language == AppLanguage.Bengali) "গভীর পর্যবেক্ষণ / ORVA" else "DEEP DIVE / ORVA"

  fun deepDiveTitle(language: AppLanguage): String =
    if (language == AppLanguage.Bengali) "নিয়মের ভিত্তি থেকে গড়া ফার্মেসি কর্মপ্রবাহ।"
    else "A PHARMACY WORKFLOW, BUILT FROM THE RULES UP."

  fun deepDiveBody(language: AppLanguage): String =
    if (language == AppLanguage.Bengali) {
      "বিলিং, ব্যাচ বরাদ্দ, স্টক পরিবর্তন ও নির্ভরযোগ্য রেকর্ড কীভাবে একটি নিবিড় পণ্যে একসাথে কাজ করে তা দেখুন।"
    } else {
      "Explore how billing, batch allocation, stock movements and dependable records fit together in one focused product."
    }

  // ---- Scene 09: Contact & Closing ----
  fun supportSectionLabel(language: AppLanguage): String =
    if (language == AppLanguage.Bengali) "০৯ / যোগাযোগ" else "09 / CONTACT"

  fun supportHeading(language: AppLanguage): String =
    if (language == AppLanguage.Bengali) "চলুন কাজটিকে আরও ভালো করি।" else "LET'S MAKE THE WORK BETTER."

  fun supportSubline(language: AppLanguage): String =
    if (language == AppLanguage.Bengali) "সমাধানের যোগ্য কোনো প্রোডাক্ট সমস্যা আছে? কথা শুরু করুন।"
    else "Have a product problem worth solving? Start a conversation."

  fun supportPhoneLabel(language: AppLanguage): String =
    if (language == AppLanguage.Bengali) "ফোন" else "Phone"

  fun supportEmailLabel(language: AppLanguage): String =
    if (language == AppLanguage.Bengali) "ইমেইল" else "Email"

  fun supportEmptyState(language: AppLanguage): String =
    if (language == AppLanguage.Bengali) {
      "সহায়তার যোগাযোগের তথ্য এখনো সেটিংসে যুক্ত করা হয়নি।"
    } else {
      "Support contact details are not configured yet. Add them in Settings."
    }

  fun ownershipSectionLabel(language: AppLanguage): String =
    if (language == AppLanguage.Bengali) "পণ্য ও পরিচিতি" else "PRODUCT & OWNERSHIP"

  fun productLabel(language: AppLanguage): String =
    if (language == AppLanguage.Bengali) "পণ্য" else "Product"

  fun productValue(language: AppLanguage): String =
    if (language == AppLanguage.Bengali) "ORVA — ফার্মেসি বিলিং ও ইনভেন্টরি" else "ORVA — Pharmacy Billing & Inventory"

  fun developedByLabel(language: AppLanguage): String =
    if (language == AppLanguage.Bengali) "নির্মাতা" else "Developed by"

  fun studioStatusNote(language: AppLanguage): String =
    if (language == AppLanguage.Bengali) {
      "স্টুডিওর নাম: আপাতত ব্যবহৃত; ভারতে ট্রেডমার্ক যাচাই ও অনুমোদন বাকি।"
    } else {
      "Studio name: Provisional; Indian trademark clearance pending."
    }

  fun versionLabel(language: AppLanguage): String =
    if (language == AppLanguage.Bengali) "সংস্করণ" else "Version"

  fun buildLabel(language: AppLanguage): String =
    if (language == AppLanguage.Bengali) "বিল্ড" else "Build"

  fun ownershipReassurance(language: AppLanguage): String =
    if (language == AppLanguage.Bengali) {
      "আপনার দোকানের ব্যবসায়িক রেকর্ড স্থানীয় স্টোরেজে আপনার নিয়ন্ত্রণেই সুরক্ষিত থাকে।"
    } else {
      "Your shop's business records remain in local storage under your control."
    }
}
