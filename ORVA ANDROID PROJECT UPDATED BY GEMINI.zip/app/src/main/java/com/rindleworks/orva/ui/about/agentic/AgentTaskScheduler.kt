package com.rindleworks.orva.ui.about.agentic

import kotlin.math.abs

/**
 * Five specialized roles across the 16-agent About Us construction roster.
 */
enum class AgentRole {
  LAYOUT_ARCHITECT,
  COMPONENT_DUPLICATOR,
  TYPOGRAPHER,
  ART_DIRECTOR,
  IDLE_SCOUT,
}

enum class LayerKind {
  CONTAINER,
  MEDIA,
  TEXT,
  LINE,
}

enum class LayerPhase {
  HIDDEN,
  BUILDING,
  CLONED_MASTER_TEXT,
  REVEALED,
}

enum class BuildAct {
  ORBITAL_SCAN,
  STRUCTURAL_BUILD,
  SCROLL_ASSEMBLY,
  CONVERGENCE,
  COMPLETED,
}

/** Platform-independent rectangle in unified root/content coordinates (pixels). */
data class SceneBounds(
  val left: Float,
  val top: Float,
  val right: Float,
  val bottom: Float,
) {
  val width: Float get() = (right - left).coerceAtLeast(0f)
  val height: Float get() = (bottom - top).coerceAtLeast(0f)
  val centerX: Float get() = (left + right) * 0.5f
  val centerY: Float get() = (top + bottom) * 0.5f
  val isValid: Boolean get() = width > 0.5f && height > 0.5f

  fun intersectsVerticalWindow(windowTop: Float, windowBottom: Float): Boolean =
    isValid && bottom >= windowTop && top <= windowBottom

  companion object {
    val Empty = SceneBounds(0f, 0f, 0f, 0f)
  }
}

/**
 * Node registered by an actual Compose composable inside the About Us component tree.
 */
data class RegisteredSceneNode(
  val id: String,
  val kind: LayerKind,
  val orderIndex: Int,
  val parentId: String? = null,
  val cloneGroupId: String? = null,
  val cloneIndex: Int = 0, // 0 = Master, >0 = Alt-Drag Clone sibling
  val bounds: SceneBounds = SceneBounds.Empty,
  val phase: LayerPhase = LayerPhase.HIDDEN,
  val claimedByAgentId: Int? = null,
  val boundsGeneration: Int = 0,
)

data class AgentTaskClaim(
  val agentId: Int,
  val role: AgentRole,
  val nodeId: String,
  val kind: LayerKind,
  val isCloneFromMaster: Boolean,
  val masterNodeId: String?,
  val boundsGeneration: Int,
)

/**
 * Pure-Kotlin deterministic DAG task scheduler for ORVA's About Us Agentic Build experience.
 *
 * Enforced invariants:
 * 1. Parent-before-child ordering (`parentId` MUST be `REVEALED` before any child is eligible).
 * 2. Master-before-clone ordering (`cloneIndex == 0` MUST be `REVEALED` before `cloneIndex > 0` in the same `cloneGroupId`).
 * 3. Bounded concurrency: maximum [maxConcurrentBuilders] (default 8) active builders out of [totalAgents] (default 16).
 * 4. Viewport + prefetch gating so off-screen sections wait until scrolled/toured into range.
 * 5. Atomic claim / commit / release semantics so cancellation restores tasks cleanly without stranding.
 * 6. Responsive layout resize invalidation clears stale geometry and pending claims safely.
 * 7. Deterministic ordering (top-to-bottom + registration `orderIndex`) so Replay reproduces the same choreography.
 */
class AgentTaskScheduler(
  val totalAgents: Int = 16,
  val maxConcurrentBuilders: Int = 8,
  val prefetchMarginPx: Float = 260f,
) {
  private val nodes = LinkedHashMap<String, RegisteredSceneNode>()
  private val activeClaimsByAgent = LinkedHashMap<Int, AgentTaskClaim>()
  private var nextOrderCounter = 0
  private var currentBoundsGeneration = 0
  private var lastViewportWidthPx: Float = -1f

  @Synchronized
  fun registerOrUpdateNode(
    id: String,
    kind: LayerKind,
    parentId: String? = null,
    cloneGroupId: String? = null,
    cloneIndex: Int = 0,
    bounds: SceneBounds,
  ) {
    val existing = nodes[id]
    if (existing == null) {
      nodes[id] =
        RegisteredSceneNode(
          id = id,
          kind = kind,
          orderIndex = nextOrderCounter++,
          parentId = parentId,
          cloneGroupId = cloneGroupId,
          cloneIndex = cloneIndex,
          bounds = bounds,
          phase = LayerPhase.HIDDEN,
          claimedByAgentId = null,
          boundsGeneration = currentBoundsGeneration,
        )
    } else {
      val movedSignificantly =
        abs(existing.bounds.left - bounds.left) > 4f ||
          abs(existing.bounds.top - bounds.top) > 4f ||
          abs(existing.bounds.width - bounds.width) > 4f ||
          abs(existing.bounds.height - bounds.height) > 4f
      nodes[id] =
        existing.copy(
          parentId = parentId,
          cloneGroupId = cloneGroupId,
          cloneIndex = cloneIndex,
          bounds = bounds,
          boundsGeneration = if (movedSignificantly) currentBoundsGeneration else existing.boundsGeneration,
        )
    }
  }

  /**
   * Invalidates stale geometry and releases in-flight claims when viewport width changes
   * (e.g., orientation change, foldable unfold, split-screen resize).
   */
  @Synchronized
  fun onViewportWidthChanged(newWidthPx: Float): Boolean {
    if (newWidthPx <= 0f) return false
    if (lastViewportWidthPx > 0f && abs(newWidthPx - lastViewportWidthPx) < 8f) {
      return false
    }
    lastViewportWidthPx = newWidthPx
    currentBoundsGeneration++
    // Release any active in-flight claims so builders re-anchor to newly measured bounds.
    val claimList = activeClaimsByAgent.values.toList()
    for (claim in claimList) {
      releaseClaim(claim.agentId, claim.nodeId)
    }
    return true
  }

  @Synchronized
  fun resetForReplay() {
    activeClaimsByAgent.clear()
    currentBoundsGeneration++
    val updated = LinkedHashMap<String, RegisteredSceneNode>(nodes.size)
    for ((id, node) in nodes) {
      updated[id] =
        node.copy(
          phase = LayerPhase.HIDDEN,
          claimedByAgentId = null,
          boundsGeneration = currentBoundsGeneration,
        )
    }
    nodes.clear()
    nodes.putAll(updated)
  }

  @Synchronized
  fun markAllRevealed() {
    activeClaimsByAgent.clear()
    val updated = LinkedHashMap<String, RegisteredSceneNode>(nodes.size)
    for ((id, node) in nodes) {
      updated[id] = node.copy(phase = LayerPhase.REVEALED, claimedByAgentId = null)
    }
    nodes.clear()
    nodes.putAll(updated)
  }

  @Synchronized
  fun getNode(id: String): RegisteredSceneNode? = nodes[id]

  @Synchronized
  fun allNodesSnapshot(): List<RegisteredSceneNode> = nodes.values.toList()

  @Synchronized
  fun totalCount(): Int = nodes.size

  @Synchronized
  fun completedCount(): Int = nodes.values.count { it.phase == LayerPhase.REVEALED }

  @Synchronized
  fun activeBuilderCount(): Int = activeClaimsByAgent.size

  @Synchronized
  fun isAllCompleted(): Boolean = nodes.isNotEmpty() && completedCount() == nodes.size

  /**
   * Atomically claims the next eligible task for [agentId] with [role] inside the current
   * visible viewport `[viewportTopPx, viewportBottomPx]` (expanded by [prefetchMarginPx]).
   */
  @Synchronized
  fun tryClaimNextTask(
    agentId: Int,
    role: AgentRole,
    viewportTopPx: Float,
    viewportBottomPx: Float,
    ignoreViewportGate: Boolean = false,
  ): AgentTaskClaim? {
    if (role == AgentRole.IDLE_SCOUT) return null
    if (activeClaimsByAgent.containsKey(agentId)) return null
    if (activeClaimsByAgent.size >= maxConcurrentBuilders) return null

    val windowTop = viewportTopPx - prefetchMarginPx
    val windowBottom = viewportBottomPx + prefetchMarginPx

    val allReady =
      nodes.values
        .asSequence()
        .filter { node ->
          node.phase == LayerPhase.HIDDEN &&
            node.claimedByAgentId == null &&
            node.bounds.isValid &&
            (ignoreViewportGate || node.bounds.intersectsVerticalWindow(windowTop, windowBottom)) &&
            isParentSatisfied(node) &&
            isCloneMasterSatisfied(node)
        }
        .sortedWith(
          compareBy<RegisteredSceneNode>(
            { if (isRoleCompatible(role, it)) 0 else 1 },
            { it.kind.priorityRank() },
            { it.bounds.top },
            { it.orderIndex },
          )
        )
        .toList()

    val chosen = allReady.firstOrNull() ?: return null
    val cloneGroup = chosen.cloneGroupId
    val isClone = cloneGroup != null && chosen.cloneIndex > 0
    val masterId = if (isClone) findMasterNodeId(cloneGroup) else null

    nodes[chosen.id] =
      chosen.copy(
        phase = LayerPhase.BUILDING,
        claimedByAgentId = agentId,
      )

    val claim =
      AgentTaskClaim(
        agentId = agentId,
        role = role,
        nodeId = chosen.id,
        kind = chosen.kind,
        isCloneFromMaster = isClone,
        masterNodeId = masterId,
        boundsGeneration = chosen.boundsGeneration,
      )
    activeClaimsByAgent[agentId] = claim
    return claim
  }

  @Synchronized
  fun markCloneMasterTextVisible(nodeId: String) {
    val existing = nodes[nodeId] ?: return
    if (existing.phase == LayerPhase.BUILDING) {
      nodes[nodeId] = existing.copy(phase = LayerPhase.CLONED_MASTER_TEXT)
    }
  }

  /** Atomically completes a claimed task and releases the agent's active slot. */
  @Synchronized
  fun completeTask(agentId: Int, nodeId: String): Boolean {
    val claim = activeClaimsByAgent[agentId]
    if (claim == null || claim.nodeId != nodeId) return false
    activeClaimsByAgent.remove(agentId)
    val node = nodes[nodeId] ?: return false
    nodes[nodeId] = node.copy(phase = LayerPhase.REVEALED, claimedByAgentId = null)
    return true
  }

  /**
   * Restores a claimed node back to `HIDDEN` so another builder can pick it up.
   * Always called inside `finally` if an agent coroutine is cancelled mid-task.
   */
  @Synchronized
  fun releaseClaim(agentId: Int, nodeId: String) {
    val claim = activeClaimsByAgent[agentId]
    if (claim != null && claim.nodeId == nodeId) {
      activeClaimsByAgent.remove(agentId)
    }
    val node = nodes[nodeId] ?: return
    if (node.claimedByAgentId == agentId && node.phase != LayerPhase.REVEALED) {
      nodes[nodeId] = node.copy(phase = LayerPhase.HIDDEN, claimedByAgentId = null)
    }
  }

  /** Returns the lowest `top` coordinate of the next unbuilt node below the viewport for guided Touring. */
  @Synchronized
  fun nextUnbuiltTargetTopY(afterY: Float): Float? =
    nodes.values
      .asSequence()
      .filter { it.phase != LayerPhase.REVEALED && it.bounds.isValid && it.bounds.top >= afterY }
      .minByOrNull { it.bounds.top }
      ?.bounds
      ?.top

  @Synchronized
  fun hasEligibleWorkInViewport(viewportTopPx: Float, viewportBottomPx: Float): Boolean {
    val windowTop = viewportTopPx - prefetchMarginPx
    val windowBottom = viewportBottomPx + prefetchMarginPx
    return nodes.values.any { node ->
      node.phase != LayerPhase.REVEALED &&
        node.bounds.isValid &&
        node.bounds.intersectsVerticalWindow(windowTop, windowBottom)
    }
  }

  private fun isParentSatisfied(node: RegisteredSceneNode): Boolean {
    val pid = node.parentId ?: return true
    val parent = nodes[pid] ?: return true
    return parent.phase == LayerPhase.REVEALED
  }

  private fun isCloneMasterSatisfied(node: RegisteredSceneNode): Boolean {
    val group = node.cloneGroupId ?: return true
    if (node.cloneIndex == 0) return true
    val master =
      nodes.values.firstOrNull { it.cloneGroupId == group && it.cloneIndex == 0 } ?: return true
    return master.phase == LayerPhase.REVEALED
  }

  private fun findMasterNodeId(groupId: String): String? =
    nodes.values.firstOrNull { it.cloneGroupId == groupId && it.cloneIndex == 0 }?.id

  private fun isRoleCompatible(role: AgentRole, node: RegisteredSceneNode): Boolean {
    val isClone = node.cloneGroupId != null && node.cloneIndex > 0
    return when (role) {
      AgentRole.LAYOUT_ARCHITECT ->
        !isClone && (node.kind == LayerKind.CONTAINER || node.kind == LayerKind.LINE)
      AgentRole.COMPONENT_DUPLICATOR ->
        isClone || node.kind == LayerKind.CONTAINER
      AgentRole.TYPOGRAPHER ->
        node.kind == LayerKind.TEXT
      AgentRole.ART_DIRECTOR ->
        node.kind == LayerKind.MEDIA || node.kind == LayerKind.LINE
      AgentRole.IDLE_SCOUT -> false
    }
  }

  private fun LayerKind.priorityRank(): Int =
    when (this) {
      LayerKind.CONTAINER -> 0
      LayerKind.LINE -> 1
      LayerKind.MEDIA -> 2
      LayerKind.TEXT -> 3
    }
}
