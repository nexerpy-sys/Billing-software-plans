package com.rindleworks.orva.ui.showcase

import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.assertTextContains
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performScrollTo
import com.rindleworks.orva.domain.settings.AppLanguage
import com.rindleworks.orva.ui.about.AboutUsScreen
import com.rindleworks.orva.ui.home.HomeScreen
import org.junit.Assert.assertEquals
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class HomeAboutShowcaseRobolectricTest {

  @get:Rule
  val composeRule = createComposeRule()

  @Test
  fun `HomeScreen renders real local readiness strip, exact EN copy, and 3 workspace folders`() {
    val events = mutableListOf<ShowcaseUiEvent>()
    val state =
      HomeShowcaseUiState(
        shopName = "Arogya Medico",
        dateText = "20 NOV 2026",
        usableMedicineCount = 42,
        expiringSoonCount = 3,
        backupStatus = ReadinessBackupState.Saved,
        appVersion = "1.0",
        language = AppLanguage.English,
        isLoaded = true,
      )

    composeRule.setContent {
      HomeScreen(
        state = state,
        reducedMotion = true,
        onEvent = { events += it },
      )
    }
    composeRule.waitForIdle()

    composeRule.onNodeWithTag("home_hero_headline").assertIsDisplayed().assertTextContains("BUILT AROUND")
    composeRule
      .onNodeWithTag("home_readiness_strip")
      .assertIsDisplayed()
      .assertTextContains("Arogya Medico")
      .assertTextContains("42 medicines ready")
      .assertTextContains("3 expiring within 30 days")
      .assertTextContains("Backup: Saved")

    composeRule.onNodeWithTag("home_start_billing_btn").performClick()
    composeRule.onNodeWithTag("home_add_stock_btn").performClick()
    composeRule.onNodeWithTag("home_folder_action_about_orva").performScrollTo().performClick()
    composeRule.waitForIdle()

    assertEquals(
      listOf(
        ShowcaseUiEvent.StartBilling,
        ShowcaseUiEvent.AddStock,
        ShowcaseUiEvent.OpenAboutUs,
      ),
      events,
    )
  }

  @Test
  fun `HomeScreen switches cleanly to authoritative Bengali copy`() {
    val state =
      HomeShowcaseUiState(
        shopName = "Arogya Medico",
        dateText = "20 NOV 2026",
        usableMedicineCount = 0,
        expiringSoonCount = 0,
        backupStatus = ReadinessBackupState.NotYetBackedUp,
        appVersion = "1.0",
        language = AppLanguage.Bengali,
        isLoaded = true,
      )

    composeRule.setContent {
      HomeScreen(
        state = state,
        reducedMotion = true,
        onEvent = {},
      )
    }
    composeRule.waitForIdle()

    composeRule.onNodeWithTag("home_hero_headline").assertTextContains("কাজের ছন্দেই")
    composeRule
      .onNodeWithTag("home_readiness_strip")
      .assertTextContains("০টি ওষুধ প্রস্তুত")
      .assertTextContains("এখনো ব্যাকআপ হয়নি")
  }

  @Test
  fun `AboutUsScreen omits absent Support phone and email rows and displays approved empty state`() {
    composeRule.mainClock.autoAdvance = false
    val state =
      AboutShowcaseUiState(
        appVersion = "1.0",
        buildNumber = "1",
        supportPhone = null,
        supportEmail = null,
        language = AppLanguage.English,
      )

    composeRule.setContent {
      AboutUsScreen(
        state = state,
        reducedMotion = true,
        onEvent = {},
      )
    }
    composeRule.mainClock.advanceTimeByFrame()

    // Skip Agentic Build via HUD so all layers immediately finalize to COMPLETED
    composeRule.onNodeWithTag("hud_skip_btn").performClick()
    composeRule.mainClock.advanceTimeByFrame()

    // Replay chip appears once Completed
    composeRule.onNodeWithTag("hud_replay_btn").assertIsDisplayed()

    composeRule.onNodeWithTag("about_hero_headline").assertTextContains("THE WORK IS IN THE DETAILS.")
    composeRule.onNodeWithTag("about_support_empty_state").performScrollTo().assertIsDisplayed()
    composeRule
      .onNodeWithTag("about_support_empty_state")
      .assertTextContains("Support contact details are not configured yet. Add them in Settings.")
    composeRule.onNodeWithTag("about_support_phone").assertDoesNotExist()
    composeRule.onNodeWithTag("about_support_email").assertDoesNotExist()
    composeRule
      .onNodeWithTag("about_provisional_status")
      .performScrollTo()
      .assertTextContains("Provisional; Indian trademark clearance pending.")
    composeRule.onNodeWithTag("about_version_value").performScrollTo().assertTextContains("1.0")
  }

  @Test
  fun `AboutUsScreen shows only configured Support phone and omits blank email, plus supports Replay`() {
    composeRule.mainClock.autoAdvance = false
    val state =
      AboutShowcaseUiState(
        appVersion = "1.0",
        buildNumber = "7",
        supportPhone = "+91 98300 00000",
        supportEmail = null,
        language = AppLanguage.English,
      )

    composeRule.setContent {
      AboutUsScreen(
        state = state,
        reducedMotion = true,
        onEvent = {},
      )
    }
    composeRule.mainClock.advanceTimeByFrame()

    // Finish -> shows Replay -> verify settings-driven contact rows & 5 wave nodes -> click Replay
    composeRule.onNodeWithTag("hud_skip_btn").performClick()
    composeRule.mainClock.advanceTimeByFrame()
    composeRule.onNodeWithTag("about_support_phone").performScrollTo().assertTextContains("+91 98300 00000")
    composeRule.onNodeWithTag("about_support_email").assertDoesNotExist()
    composeRule.onNodeWithTag("about_support_empty_state").assertDoesNotExist()
    composeRule.onNodeWithTag("about_wave_node_1").performScrollTo().assertIsDisplayed()
    composeRule.onNodeWithTag("about_wave_node_5").assertIsDisplayed()

    composeRule.onNodeWithTag("hud_replay_btn").performClick()
    composeRule.mainClock.advanceTimeByFrame()
    composeRule.onNodeWithTag("hud_skip_btn").assertIsDisplayed()
  }
}
