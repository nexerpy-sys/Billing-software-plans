package com.rindleworks.orva.ui.about.agentic

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class AgentTaskSchedulerTest {

  private fun rect(top: Float, height: Float = 120f, left: Float = 24f, width: Float = 800f) =
    SceneBounds(left = left, top = top, right = left + width, bottom = top + height)

  @Test
  fun `parent must be revealed before child can be claimed`() {
    val scheduler = AgentTaskScheduler()
    scheduler.registerOrUpdateNode(id = "hero_container", kind = LayerKind.CONTAINER, bounds = rect(100f))
    scheduler.registerOrUpdateNode(
      id = "hero_headline",
      kind = LayerKind.TEXT,
      parentId = "hero_container",
      bounds = rect(140f),
    )

    // Even a TYPOGRAPHER cannot claim hero_headline while hero_container is HIDDEN or BUILDING
    val first = scheduler.tryClaimNextTask(0, AgentRole.TYPOGRAPHER, 0f, 1000f)
    assertNotNull(first)
    assertEquals("hero_container", first!!.nodeId)

    // While hero_container is still BUILDING, no other agent can claim hero_headline
    val blocked = scheduler.tryClaimNextTask(1, AgentRole.TYPOGRAPHER, 0f, 1000f)
    assertNull(blocked)

    // Once parent completes, child unlocks immediately
    assertTrue(scheduler.completeTask(0, "hero_container"))
    val childClaim = scheduler.tryClaimNextTask(1, AgentRole.TYPOGRAPHER, 0f, 1000f)
    assertNotNull(childClaim)
    assertEquals("hero_headline", childClaim!!.nodeId)
  }

  @Test
  fun `master node must complete before clone siblings can be claimed`() {
    val scheduler = AgentTaskScheduler()
    scheduler.registerOrUpdateNode(
      id = "principle_1",
      kind = LayerKind.CONTAINER,
      cloneGroupId = "principles",
      cloneIndex = 0,
      bounds = rect(200f),
    )
    scheduler.registerOrUpdateNode(
      id = "principle_2",
      kind = LayerKind.CONTAINER,
      cloneGroupId = "principles",
      cloneIndex = 1,
      bounds = rect(360f),
    )
    scheduler.registerOrUpdateNode(
      id = "principle_3",
      kind = LayerKind.CONTAINER,
      cloneGroupId = "principles",
      cloneIndex = 2,
      bounds = rect(520f),
    )

    val masterClaim = scheduler.tryClaimNextTask(3, AgentRole.COMPONENT_DUPLICATOR, 0f, 1200f)
    assertNotNull(masterClaim)
    assertEquals("principle_1", masterClaim!!.nodeId)
    assertFalse(masterClaim.isCloneFromMaster)
    assertNull(masterClaim.masterNodeId)

    // Clones remain blocked while master is BUILDING
    assertNull(scheduler.tryClaimNextTask(4, AgentRole.COMPONENT_DUPLICATOR, 0f, 1200f))

    // Complete master -> clones unlock in parallel referencing masterNodeId
    assertTrue(scheduler.completeTask(3, "principle_1"))
    val clone2 = scheduler.tryClaimNextTask(4, AgentRole.COMPONENT_DUPLICATOR, 0f, 1200f)
    val clone3 = scheduler.tryClaimNextTask(5, AgentRole.COMPONENT_DUPLICATOR, 0f, 1200f)
    assertNotNull(clone2)
    assertNotNull(clone3)
    assertEquals("principle_2", clone2!!.nodeId)
    assertTrue(clone2.isCloneFromMaster)
    assertEquals("principle_1", clone2.masterNodeId)
    assertEquals("principle_3", clone3!!.nodeId)
    assertTrue(clone3.isCloneFromMaster)
    assertEquals("principle_1", clone3.masterNodeId)
  }

  @Test
  fun `max concurrent builders cap is strictly enforced at 8 and IDLE_SCOUT never claims`() {
    val scheduler = AgentTaskScheduler(totalAgents = 16, maxConcurrentBuilders = 8)
    for (i in 0 until 12) {
      scheduler.registerOrUpdateNode(id = "node_$i", kind = LayerKind.CONTAINER, bounds = rect(100f + i * 60f))
    }

    // IDLE_SCOUT can never claim build tasks
    assertNull(scheduler.tryClaimNextTask(12, AgentRole.IDLE_SCOUT, 0f, 2000f))

    // First 8 builder agents succeed
    for (agentId in 0 until 8) {
      val claim = scheduler.tryClaimNextTask(agentId, AgentRole.LAYOUT_ARCHITECT, 0f, 2000f)
      assertNotNull("Agent $agentId should claim a task", claim)
    }
    assertEquals(8, scheduler.activeBuilderCount())

    // 9th builder is rejected by concurrency cap
    assertNull(scheduler.tryClaimNextTask(8, AgentRole.LAYOUT_ARCHITECT, 0f, 2000f))

    // Completing one slot allows the 9th builder to claim immediately
    val node0 = scheduler.allNodesSnapshot().first { it.claimedByAgentId == 0 }.id
    assertTrue(scheduler.completeTask(0, node0))
    assertEquals(7, scheduler.activeBuilderCount())
    assertNotNull(scheduler.tryClaimNextTask(8, AgentRole.LAYOUT_ARCHITECT, 0f, 2000f))
    assertEquals(8, scheduler.activeBuilderCount())
  }

  @Test
  fun `viewport and prefetch margin gate off-screen nodes until scrolled into range`() {
    val scheduler = AgentTaskScheduler(prefetchMarginPx = 200f)
    scheduler.registerOrUpdateNode(id = "top_hero", kind = LayerKind.CONTAINER, bounds = rect(100f))
    scheduler.registerOrUpdateNode(id = "deep_footer", kind = LayerKind.CONTAINER, bounds = rect(2400f))

    // Viewport [0..800], prefetch reaches 1000 -> top_hero eligible, deep_footer blocked
    val first = scheduler.tryClaimNextTask(0, AgentRole.LAYOUT_ARCHITECT, 0f, 800f)
    assertEquals("top_hero", first?.nodeId)
    assertNull(scheduler.tryClaimNextTask(1, AgentRole.LAYOUT_ARCHITECT, 0f, 800f))

    // Move viewport down to [1600..2300], prefetch reaches 2500 -> deep_footer now eligible
    val second = scheduler.tryClaimNextTask(1, AgentRole.LAYOUT_ARCHITECT, 1600f, 2300f)
    assertEquals("deep_footer", second?.nodeId)
  }

  @Test
  fun `releaseClaim restores interrupted task cleanly without stranding`() {
    val scheduler = AgentTaskScheduler()
    scheduler.registerOrUpdateNode(id = "story_block", kind = LayerKind.CONTAINER, bounds = rect(200f))

    val claim = scheduler.tryClaimNextTask(0, AgentRole.LAYOUT_ARCHITECT, 0f, 1000f)
    assertNotNull(claim)
    assertEquals(LayerPhase.BUILDING, scheduler.getNode("story_block")?.phase)
    assertEquals(1, scheduler.activeBuilderCount())

    // Simulate coroutine cancellation -> finally releases claim
    scheduler.releaseClaim(0, "story_block")
    assertEquals(0, scheduler.activeBuilderCount())
    assertEquals(LayerPhase.HIDDEN, scheduler.getNode("story_block")?.phase)
    assertNull(scheduler.getNode("story_block")?.claimedByAgentId)

    // Another agent can safely claim and complete it
    val retryClaim = scheduler.tryClaimNextTask(1, AgentRole.LAYOUT_ARCHITECT, 0f, 1000f)
    assertEquals("story_block", retryClaim?.nodeId)
    assertTrue(scheduler.completeTask(1, "story_block"))
    assertEquals(LayerPhase.REVEALED, scheduler.getNode("story_block")?.phase)
  }

  @Test
  fun `responsive viewport width resize releases in-flight claims and advances bounds generation`() {
    val scheduler = AgentTaskScheduler()
    scheduler.onViewportWidthChanged(1080f)
    scheduler.registerOrUpdateNode(id = "meta_panel", kind = LayerKind.CONTAINER, bounds = rect(300f))

    val claim1 = scheduler.tryClaimNextTask(0, AgentRole.LAYOUT_ARCHITECT, 0f, 1200f)
    assertNotNull(claim1)
    val initialGen = claim1!!.boundsGeneration

    // Small noise (< 8px) does not invalidate
    assertFalse(scheduler.onViewportWidthChanged(1083f))
    assertEquals(1, scheduler.activeBuilderCount())

    // Real orientation / foldable width change invalidates claims & bumps generation
    assertTrue(scheduler.onViewportWidthChanged(2200f))
    assertEquals(0, scheduler.activeBuilderCount())
    assertEquals(LayerPhase.HIDDEN, scheduler.getNode("meta_panel")?.phase)

    scheduler.registerOrUpdateNode(id = "meta_panel", kind = LayerKind.CONTAINER, bounds = rect(300f, width = 1800f))
    val claim2 = scheduler.tryClaimNextTask(0, AgentRole.LAYOUT_ARCHITECT, 0f, 1200f)
    assertNotNull(claim2)
    assertTrue(claim2!!.boundsGeneration > initialGen)
  }

  @Test
  fun `role preference prioritizes matching kind with graceful assist fallback`() {
    val scheduler = AgentTaskScheduler()
    scheduler.registerOrUpdateNode(id = "media_frieze", kind = LayerKind.MEDIA, bounds = rect(100f))
    scheduler.registerOrUpdateNode(id = "headline_text", kind = LayerKind.TEXT, bounds = rect(100f))

    // TYPOGRAPHER prefers TEXT even though MEDIA has lower priorityRank
    val typoClaim = scheduler.tryClaimNextTask(6, AgentRole.TYPOGRAPHER, 0f, 1000f)
    assertEquals("headline_text", typoClaim?.nodeId)

    // ART_DIRECTOR claims MEDIA
    val artClaim = scheduler.tryClaimNextTask(10, AgentRole.ART_DIRECTOR, 0f, 1000f)
    assertEquals("media_frieze", artClaim?.nodeId)

    // If only MEDIA remains, TYPOGRAPHER gracefully assists rather than stalling
    scheduler.registerOrUpdateNode(id = "extra_media", kind = LayerKind.MEDIA, bounds = rect(300f))
    val assistClaim = scheduler.tryClaimNextTask(7, AgentRole.TYPOGRAPHER, 0f, 1000f)
    assertEquals("extra_media", assistClaim?.nodeId)
  }

  @Test
  fun `resetForReplay reproduces deterministic claim sequence and convergence waits for all nodes`() {
    val scheduler = AgentTaskScheduler()
    scheduler.registerOrUpdateNode(id = "a_container", kind = LayerKind.CONTAINER, bounds = rect(100f))
    scheduler.registerOrUpdateNode(id = "b_rule", kind = LayerKind.LINE, parentId = "a_container", bounds = rect(180f))
    scheduler.registerOrUpdateNode(id = "c_text", kind = LayerKind.TEXT, parentId = "a_container", bounds = rect(240f))

    fun drainSequence(): List<String> {
      val order = mutableListOf<String>()
      while (!scheduler.isAllCompleted()) {
        val c = scheduler.tryClaimNextTask(0, AgentRole.LAYOUT_ARCHITECT, 0f, 1000f) ?: break
        order += c.nodeId
        assertFalse(scheduler.isAllCompleted())
        assertTrue(scheduler.completeTask(0, c.nodeId))
      }
      return order
    }

    val run1 = drainSequence()
    assertEquals(listOf("a_container", "b_rule", "c_text"), run1)
    assertTrue(scheduler.isAllCompleted())
    assertEquals(3, scheduler.completedCount())

    scheduler.resetForReplay()
    assertFalse(scheduler.isAllCompleted())
    assertEquals(0, scheduler.completedCount())

    val run2 = drainSequence()
    assertEquals(run1, run2)
    assertTrue(scheduler.isAllCompleted())
  }

  @Test
  fun `empty scheduler never falsely reports completed`() {
    val scheduler = AgentTaskScheduler()
    assertFalse(scheduler.isAllCompleted())
    assertEquals(0, scheduler.totalCount())
    assertEquals(0, scheduler.completedCount())
  }
}
