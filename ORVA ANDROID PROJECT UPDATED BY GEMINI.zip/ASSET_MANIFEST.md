# ORVA Android Frontend — Asset Manifest

All showcase visual assets and fonts are bundled locally inside `app/src/main/res/` so Home and About Us render 100% offline with zero external CDN dependencies.

## Bundled Drawable Imagery (`app/src/main/res/drawable/`)

| Local Filename | Origin / Source | Creator / License | Date Added | Planned Use in ORVA | Model / Property / Trademark Notes |
|---|---|---|---|---|---|
| `apothecary_frieze_bw.jpg` | Existing ORVA project asset | ORVA / Rindle Works owned asset | Pre-existing | Shared Home & About closing monochrome scroll frieze (`OrvaScrollFrieze.kt`) | None — original project asset |
| `editorial_architecture_light.jpg` | Studio-generated monochrome architectural photography (offline sandbox) | Generated for Rindle Works × ORVA showcase; replaceable with licensed Pexels ([license](https://www.pexels.com/license/)) or Unsplash ([license](https://unsplash.com/license)) photography | 2026-11-20 | Home H1 Hero background (`HomeScreen.kt`) & About Scene 07 Field Notes tile (`PRODUCT / INTERFACE`) | Text-free, unbranded architectural geometry; zero identifiable people or trademarks |
| `editorial_apothecary_shelves.jpg` | Studio-generated monochrome apothecary glass shelving (offline sandbox) | Generated for Rindle Works × ORVA showcase; replaceable with licensed Pexels/Unsplash photography | 2026-11-20 | Home H2 Lantern reveal surface (`HomeScreen.kt`), About Scene 02 POV media & Scene 07 Field Notes tile (`BATCH / INVENTORY`) | Text-free, unbranded glass bottles; zero third-party pharmacy branding |
| `editorial_thermal_counter.jpg` | Studio-generated monochrome macro counter paper/hardware (offline sandbox) | Generated for Rindle Works × ORVA showcase; replaceable with licensed Pexels/Unsplash photography | 2026-11-20 | Home H3 Cinematic scroll section (`HomeScreen.kt`), About Scene 07 Field Notes tile (`BILLING / WORKFLOW`) & Scene 08 Deep Dive cover | Text-free, unbranded hardware detail; zero trademarks |
| `editorial_studio_workbench.jpg` | Studio-generated monochrome overhead drafting workbench (offline sandbox) | Generated for Rindle Works × ORVA showcase; replaceable with licensed Pexels/Unsplash photography | 2026-11-20 | About Scene 01 Studio Hero (`AboutUsScreen.kt`) & Scene 07 Field Notes tile (`SYSTEM / DETAIL`) | Text-free, unbranded studio tools; zero identifiable people or logos |

## Bundled Local Fonts (`app/src/main/res/font/`)

| Local Filename | Family | License | Planned Use |
|---|---|---|---|
| `space_grotesk.ttf` | Space Grotesk | SIL OFL 1.1 | Display headlines, scene titles, wordmarks |
| `instrument_serif.ttf` | Instrument Serif | SIL OFL 1.1 | Editorial serif accents & closing lines |
| `plus_jakarta_sans.ttf` | Plus Jakarta Sans | SIL OFL 1.1 | Body prose and supporting descriptions |
| `ibm_plex_mono.ttf` | IBM Plex Mono | SIL OFL 1.1 | Scene index metadata, HUD telemetry, technical tags |
| `noto_sans_bengali.ttf` | Noto Sans Bengali | SIL OFL 1.1 | Native Bengali display, body, and mono fallback |
